# Categorias

Tag spara serrem colocadas entre parêntesis

+ POST EXAMPLE - :ds/:de/:da
+ PROJECT - :ds/:de/:da
+ CompVision
+ Entrevista/Vaga
+ Download
+ Book
+ English
+ Exterior



https://www.linkedin.com/posts/activity-7000943829109379073-dhtC?utm_source=share&utm_medium=member_desktop

https://www.linkedin.com/posts/nelington-chaves-102478237_analisededados-powerbi-reports-activity-7000609548709318656-sBy1?utm_source=share&utm_medium=member_desktop

https://www.linkedin.com/posts/giulian-smith-araujo-monteiro-bb5496222_lichess-sample-dashboard-activity-6999007807177932800-UB__?utm_source=share&utm_medium=member_desktop

Um dash bem bonito sobre linkedin
- https://www.linkedin.com/posts/daniellsiqueira_analisededados-businessintelligence-powerbi-activity-6997640437725294592-ZfhB?utm_source=share&utm_medium=member_desktop

Exmeplos de templte de PBI
https://www.linkedin.com/posts/gustaw-dudek_powerbi-analytics-data-activity-6997596909750095872-zT1t?utm_source=share&utm_medium=member_desktop

Dash de RH
https://www.linkedin.com/posts/pradipnichite_freelancing-datascience-datasciencefreelancing-activity-6996824930117906433-sqPn?utm_source=share&utm_medium=member_desktop


https://www.linkedin.com/posts/andley-cardoso-0a3578135_dataviz-analytics-qualidade-activity-6996598656497823744-PO1L?utm_source=share&utm_medium=member_desktop
