# Linkedin Saves - 12/10/2022


De tempos em tempos devo acessar o linkedin save e anotar tanto aqui quanto no caderno as melhores coisas.

Se forem muito grande anoto aqui. Se forem pequenas anoto aqui e no caderno.

IMPORTANTE: após preencher o forms os convites só chegam em Dezembro quando encerram as inscrições.

## Index

+ [Linkedin Saves - 12/10/2022](#linkedin-saves---12/10/2022)
  - [Index](#index)
  - [Webnar Lucas Galindo](#webnar-lucas-galindo)
  - [Cursos que o pessoal está fazendo](#cursos-que-o-pessoal-está-fazendo)
  - [Trabalhar no Exterior](#trabalhar-no-exterior)
  - [Exemplos de Dashboard PBI](#exemplos-de-dashboard-pbi)
  - [Perfis para seguir](#perfis-para-seguir)
  - [Linkdein Saves REview 12/10/2022](#linkdein-saves-review-12/10/2022)
    * [Curso Com badges de Data Science do google](#curso-com-badges-de-data-science-do-google)
    * [Curso PyTorch](#curso-pytorch)
    * [PDF de ML de modelo de risco de crédito](#pdf-de-ml-de-modelo-de-risco-de-crédito)
    * [Dicas para melhorar Spark](#dicas-para-melhorar-spark)
    * [Dicas para iniciar DataEngineer](#dicas-para-iniciar-dataengineer)
    * [Aplicativo ELSA para aprender Inglês](#aplicativo-elsa-para-aprender-inglês)
    * [Aprender Inglês](#aprender-inglês)
    * [Como postar Badge no Linkedin](#como-postar-badge-no-linkedin)
    * [Python for Data Engineering](#python-for-data-engineering)
    * [MIniCursos DevOps](#minicursos-devops)
    * [Data Eng](#data-eng)
    * [Darshil Parmar - Projetos Frre com Youtube para DataEng](#darshil-parmar---projetos-frre-com-youtube-para-dataeng)
    * [5 Repos apra Aprender AWS](#5-repos-apra-aprender-aws)
    * [Certificacao PL-300](#certificacao-pl-300)
    * [O que estudar para ser DataEngineer](#o-que-estudar-para-ser-dataengineer)
    * [Build Your Data Engineering Resume with this -](#build-your-data-engineering-resume-with-this--)
    * [Darshil Parmar - Airflow project](#darshil-parmar---airflow-project)
    * [Lucas Galindo - O que Bilionários fazem  no tempo livre](#lucas-galindo---o-que-bilionários-fazem--no-tempo-livre)
    * [Montar Curriculo em ingles em PDF](#montar-curriculo-em-ingles-em-pdf)
    * [Uberhub Fernando Khun](#uberhub-fernando-khun)
    * [Atekita Dev - Porque não consigo meu 1 emprego](#atekita-dev---porque-não-consigo-meu-1-emprego)
    * [Ilustrando Word2Vec](#ilustrando-word2vec)
    * [Estatística Descritiva](#estatística-descritiva)
    * [Lazy Predccit - Lib em python que teta umonte de modelos em uma linha de código](#lazy-predccit---lib-em-python-que-teta-umonte-de-modelos-em-uma-linha-de-código)
    * [Haddop is dead](#haddop-is-dead)
    * [ULTRA - CANAIS PARA ACOMPANHA NA ÁREA DE DADOS](#ultra---canais-para-acompanha-na-área-de-dados)
    * [Exemplo de Layout PBI no FIgma](#exemplo-de-layout-pbi-no-figma)
    * [Busque pelo repo do livro 'Python Dta Science Handbook'](#busque-pelo-repo-do-livro-'python-dta-science-handbook')
    * [Se preparara para vagas no exteior](#se-preparara-para-vagas-no-exteior)
    * [Extensão  JSON Crack, no VS Code](#extensão--json-crack,-no-vs-code)
    * [Nação Fluente - Vânia](#nação-fluente---vânia)
    * [Extensão para ajudar nas vagas do lnikedin](#extensão-para-ajudar-nas-vagas-do-lnikedin)
    * [Odemir exemplos](#odemir-exemplos)
    * [Melhorar README do Github](#melhorar-readme-do-github)
    * [Como ganhar em dólar](#como-ganhar-em-dólar)
    * [O que o mercado espera de um Data Engineer Junior?🧐](#o-que-o-mercado-espera-de-um-data-engineer-junior?🧐)
    * [Seu salário é proporcional ao problema que você resolve](#seu-salário-é-proporcional-ao-problema-que-você-resolve)
    * [Dicas para quem vai começar CLT na áre de dados](#dicas-para-quem-vai-começar-clt-na-áre-de-dados)
    * [Perfis BR da área de dados](#perfis-br-da-área-de-dados)
    * [Dicas para entrar na área de CIência de dados](#dicas-para-entrar-na-área-de-ciência-de-dados)
    * [Entrevista de Data Eng - SQL](#entrevista-de-data-eng---sql)
    * [Coisas que aprendi num ML Complexo](#coisas-que-aprendi-num-ml-complexo)
    * [Coloque inglês como prioridade](#coloque-inglês-como-prioridade)
    * [Erros comuns de quem está começando em DS](#erros-comuns-de-quem-está-começando-em-ds)
    * [Links úteis paa PBI](#links-úteis-paa-pbi)
    * [Livros interessantes e legais sobre dado/estatisticas](#livros-interessantes-e-legais-sobre-dado/estatisticas)
    * [Lembrar dessaas palavras em ingles](#lembrar-dessaas-palavras-em-ingles)
    * [ESTATÍSTICA É MUITO MAIS DO QUE VOCê RAFAEL PENSA](#estatística-é-muito-mais-do-que-você-rafael-pensa)
    * [Canal BR sobre DBT](#canal-br-sobre-dbt)
    * [Filipe Balseiro - Data Engineering RoadMaps by Days](#filipe-balseiro---data-engineering-roadmaps-by-days)
    * [Odemir Sistema de Recomendação](#odemir-sistema-de-recomendação)
    * [Como criar portfólio para Data Engineering?](#como-criar-portfólio-para-data-engineering?)

---
---
---

## Webnar Lucas Galindo

10/12 (10 de dezembro) um sábado das 10h -12h via plataforma zoom e fica gravado por 21 dias.

O webinar custa 60 reais (pode me pedir bolsa, se não estiver empregado), você sai com o LinkedIn tinindo para ser encontrado por recrutadores internacionais, tem 2 brindes, vai ser dia 10/12 que é um sábado ás 10h.

---
---
---

## Cursos que o pessoal está fazendo

+ trilha do data bricks: Lakehoyse Fundamentlas
+ Azure Badge de ceritificados
+ Selo de copenetneiacas do LInkedin
+ Skill Builder da AWS
  - https://explore.skillbuilder.aws/learn/external-ecommerce;view=none?ctldoc-catalog-0=l-_%22pt-br%22

---
---
---

## Trabalhar no Exterior

Lucas Galindo (Webnar)
+ https://www.linkedin.com/posts/lucas-renan-galindo-lourenco_um-ano-trabalhando-remoto-do-brasil-para-activity-6985329069311553537-j-Vx?utm_source=share&utm_medium=member_desktop
+ https://www.linkedin.com/posts/lucas-renan-galindo-lourenco_por-que-fazer-networking-quando-se-est%C3%A1-trabalhando-activity-6979501711388209152-zB1Q?utm_source=share&utm_medium=member_desktop

Cassio Bolba
+ https://www.linkedin.com/posts/cassiobolba_coding-vagas-instagram-activity-6983755364110368768-54jI?utm_source=share&utm_medium=member_desktop

## Exemplos de Dashboard PBI

+ [PBI - Dashboard](https://www.linkedin.com/posts/activity-6985243491018674177-yxsN?utm_source=share&utm_medium=member_desktop)

+ [PBI - Dashboard](https://www.linkedin.com/posts/roberto-amarante-adm_varia%C3%A7%C3%A3o-g%C3%A1s-cozinha-2016-a-2022-activity-6984290519707234305-p-GU?utm_source=share&utm_medium=member_desktop)

+ [PBI - Dashboard](https://www.linkedin.com/posts/yuribarbosagpires_powerbi-microsoft-freelance-activity-6984139451790692352-_8gm?utm_source=share&utm_medium=member_desktop)

+ [PBI - Dashboard](https://www.linkedin.com/posts/yuribarbosagpires_powerbi-microsoft-freelance-activity-6980487499802382336-a7ny?utm_source=share&utm_medium=member_desktop)

+ [PBI - Dashboard](https://www.linkedin.com/posts/srodrigomoura_powerbi-bi-dados-activity-6972563843558330369-yQ6J?utm_source=share&utm_medium=member_desktop)

+ [PBI - Dashboard](https://www.linkedin.com/posts/yuribarbosagpires_power-bi-activity-6974331076278124544-tS-x?utm_source=share&utm_medium=member_desktop)

+ [PBI - Dashboard](https://www.linkedin.com/posts/naiani-lopes-munhoz-285a5615a_databrains-semanadopowerbi-data-activity-6971951744398290945-KAzW?utm_source=share&utm_medium=member_desktop)

+ [PBI - Dashboard](https://www.linkedin.com/posts/hugoventurini-excel-and-powerbi_powerbi-dashboard-datanalytics-activity-6972164571692175360-pDsn?utm_source=share&utm_medium=member_desktop)

+ [PBI - Dashboard](https://www.linkedin.com/posts/marcelom2015_logaedstica-mundopowerbi-powerbi-activity-6971918639679590400-f_u1?utm_source=share&utm_medium=member_desktop)

+ [PBI - Dashboard](https://www.linkedin.com/posts/luizcruzdf_powerbi-microsoft-etl-activity-6970050035774316544-P6EL?utm_source=share&utm_medium=member_desktop)

+ [PBI - Dashboard](https://www.linkedin.com/posts/ivan-moreno-marcos_powerbi-dax-linguagemm-activity-6967559866957639680-E1OK?utm_source=share&utm_medium=member_desktop)

---
---
---

## Perfis para seguir

+ https://www.linkedin.com/in/andriellimarcos
  - Conseguiu vava de Data ENginer na BLueShift

+ https://www.linkedin.com/in/adiltoncantos/
  - Data Enginer Accenture

+ https://www.linkedin.com/in/poweranalysis
  - Analista de Dados/BI

+ https://www.linkedin.com/in/let%C3%ADcia-gerola?miniProfileUrn=urn%3Ali%3Afs_miniProfile%3AACoAABK-lZoBqRyUvEhP8Z1cNhRwJIkuLOhueqo&lipi=urn%3Ali%3Apage%3Ad_flagship3_saved_items%3BxN%2BZEMyqRLeXLGu7ZOuQIQ%3D%3D
  - COnseguiu vaga como cientista de dados

+ https://www.linkedin.com/in/brunoszdl?miniProfileUrn=urn%3Ali%3Afs_miniProfile%3AACoAAC0Lw_kBu_pDy_xmWtKtII1Je3KW64xkoEU&lipi=urn%3Ali%3Apage%3Ad_flagship3_saved_items%3B12zm1uaBSTq3Cxr8Z5ujPQ%3D%3D
  - Postou um cheet-sheet legal

---
---
---

## Linkdein Saves REview 12/10/2022

### Curso Com badges de Data Science do google

https://www.linkedin.com/posts/iamarifalam_datascientist-datascience-python-activity-6985808856538853376-hxOm?utm_source=share&utm_medium=member_desktop

Free Certification Courses in Data Science using Python from Google

1. Learn Python Basics for Data Analysis

⚡️ https://lnkd.in/dRunXPtA

2. Data Science Foundation

⚡️ https://lnkd.in/d5Dz7q8Y

3. Data Science with Python

⚡️ https://lnkd.in/dkr4KGHD

4. Machine Learning Crash Course

⚡️ https://lnkd.in/dmZinF4p

### Curso PyTorch

https://www.linkedin.com/posts/rami-krispin_pytorch-deeplearning-machinelearning-activity-6985579815248551936-WOBL?utm_source=share&utm_medium=member_desktop

New course for deep learning and machine learning with PyTorch! 🚀🚀🚀

FreeCodeCamp released a new course for deep learning and machine learning with PyTorch to YouTube by Daniel Bourke. The course is for beginners, and it contains 24 hours (!) of video, and it covers the following topics:

+ ✅ PyTorch Fundamentals
+ ✅ PyTorch Workflow
+ ✅ Neural Network Classification
+ ✅ Computer Vision
+ ✅ Custom Datasets


Resources 📚
+ ➡️ Video: https://lnkd.in/gcAukkec
+ ➡️ Code: https://lnkd.in/gfN6V5qb
+ ➡️ Course materials: https://lnkd.in/g-fDFDnZ

### PDF de ML de modelo de risco de crédito

https://www.linkedin.com/posts/odemir-depieri-jr_modelo-de-risco-de-cr%C3%A9dito-activity-6985563426810941442-B5Fs?utm_source=share&utm_medium=member_desktop

com pdf

### Dicas para melhorar Spark

https://www.linkedin.com/posts/abhishek-kumar-79021712a_bigdata-data-apachespark-activity-6984512051003953152-aAbm?utm_source=share&utm_medium=member_desktop

Spark Optimization Techniques:

1. Filter require data as earlier as possible.
2. Try to avoid shuffle as much as possible.
3. Use Reduce by key instead of group by key.
4. For decrease the partition use coalesce techniques instead of repartition
5. Use broadcast join as much as possible
6. Use Broadcast variable as much as possible.
7. Vectorization is one of the good technique to more Optimization
8. Use structure api as much as possible.
9. Use dataframe on top of datasets and rdd.
10. Use suitable file format.
11. When using rdd try to convert into structure api as early as possible.
12. Use partitionBy and bucketBy


### Dicas para iniciar DataEngineer

Aí vai uma dica...

Se eu fosse começar a estudar hoje pra engenharia de dados, começaria com(Prioridade):

+ Conceitos de BI e Big data
+ Modelagem de dados
+ Alguma nuvem (AWS, Azure ou GCP)
+ ETL/Pipeline: Das próprias nuvens, Integration Services, Pentaho.
+ SQL (DDL, DQL, DML)
+ Python (Pandas, Numpy, PySpark SQL)

### Aplicativo ELSA para aprender Inglês

https://www.linkedin.com/posts/lucas-renan-galindo-lourenco_qual-linguagem-paga-mais-ingl%C3%AAs-segundo-activity-6984902022458167296-Dep_?utm_source=share&utm_medium=member_desktop

### Aprender Inglês

https://www.linkedin.com/posts/rodrigo-santana-ferreira-0ab041128_meu-maior-erro-na-jornada-para-trabalhar-activity-6983117216929992704-0rwu?utm_source=share&utm_medium=member_desktop

Meu maior ERRO na jornada para trabalhar para fora do país:

Eu sempre fui de estudar sozinho e com inglês não foi diferente.
Aprendi muito lendo documentações, assistindo videos no youtube etc.

Isso sempre deu certo, só que isso tem um preço.

No caso do inglês, alguns dólares a menos na minha conta.

Eu só percebi isso depois de alguns meses que decidir fazer aulas particulares com um professor.

Me lembro que pensei:

“Como fui burro, se tivesse começado antes estaria muito melhor hoje”

Esse foi meu principal erro na trajetória rumo a um emprego fora do Brasil.

Se tivesse começado estudar certo antes teria muito mais resultado e logo, mais dólares na conta rs.

Bom, fica de aprendizado!

Hoje, tento sempre ganhar tempo investindo em mim.
Fiz um curso online, tenho aulas com dois professores e participo de um grupo de conversação.

Investir em conhecimento SEMPRE vai valer a pena.
A conta fecha, o conhecimento transforma.

### Como postar Badge no Linkedin

https://www.linkedin.com/posts/leandro-cavalcanti-a39202165_dbt-developer-leandro-cavalcanti-dbt-activity-6961139222682431488-d2Cg?utm_source=share&utm_medium=member_desktop





https://www.linkedin.com/posts/natan-ximenes_dbt-fundamentals-natan-ximenes-dbt-learn-activity-6982690864602968064-xvwg?utm_source=share&utm_medium=member_desktop

I just got dbt Labs credential for dbt fundamentals course.
This demonstrates fundamental understanding of models, sources, tests, docs, and deployment in dbt.

My next goal is to get the dbt Analytics Engineer Certification.
\#DataAnalytics \#AnalyticsEngineer \#DataModeling #ELT



### Python for Data Engineering

https://www.linkedin.com/posts/darshil-parmar_dataengineering-python-datawithdarshil-activity-6982572115166158848-1kFk?utm_source=share&utm_medium=member_desktop

Python for Data Engineering (Topics to cover) 👇🏻

👉🏻 There are 3 steps to learning Python 👈🏻
1. Learn Basic Fundamentals
2. Learning Advance Concept For Better Understanding/ Hands-On
3. Picking Niche

👇🏻 Let's talk about learning Python for Data Engineering 👇🏻

What does a Data Engineer do on day to day basis?
1. Read different types of files and write them
2. Do cleaning/manipulation of data
3. Write transformation job
4. Query database using libraries
5. Automate some tasks
and many other things

⏳ Where do you need to focus?

Once you get your fundamentals and logic clear then focus on these things

1. Understand the different types of file formats (Read and Write)
+ ✅ CSV
+ ✅ AVRO
+ ✅ JSON
+ ✅ ORC
+ ✅ PARQUET

2. Learn how to connect and query database using Code
+ ✅ SQLAlchemy
+ ✅ pymysql
+ ✅ psycopg2

3. Working with different types of DateTime formats and timezone
+ ✅ Yes, your columns will be in UTC timezone but you need to convert it to local timezone
+ ✅ Sometimes date and time are not properly formatted so make sure you know how to handle it

4. Doing Transformation
+ ✅ There are many libraries in python that can help you to read files and do operations on top of it

One of them is Pandas

5. Learn to Automate things
+ ✅ These include setting up cron jobs or deploying code automatically on the cloud using some scripts (Yes, this is a little bit towards DevOps but knowing this is also important)

6. Learn to read the documentation and connect with different tools
+ ✅ Many times you will have to make connections to different tools
Working on the cloud? Connect to the service using code to create/update or remove things

🤓 I can only remember this much right now, I will add and keep adding more.

Do you remember something that I might have missed? Put that in the comment so that others can learn it 👨🏻‍💻

Outro link interressante:

https://lnkd.in/gAjyMTm

### MIniCursos DevOps

Minicursos DevOps:
- Terraform: https://lnkd.in/dPn3waTA
- Docker: https://lnkd.in/duuijWK5
- Ansilbe: https://lnkd.in/dn7frvvb
- Linux: https://lnkd.in/dyeMDEbh
- Agilidade: https://lnkd.in/d9t7UcrY

### Data Eng

https://www.linkedin.com/posts/asheesh-aa67a57b_bigdata-aws-pyspark-activity-6981881100545470465-uqjs?utm_source=share&utm_medium=member_desktop

𝙳𝚊𝚝𝚊 𝙴𝚗𝚐𝚒𝚗𝚎𝚎𝚛: According to coursera, Data engineers work in a variety of settings to build systems that collect, manage, and convert raw data into usable information for data scientists to make data accessible so that organizations can use it to evaluate and optimize their performance.

ᴺᵒʷ ᵗʰᵉ Qᵘᵉˢᵗⁱᵒⁿ ⁱˢ what ᵗᵒ ᵖʳᵉᵖᵃʳᵉ ᶠᵒʳ ᵗʰᵉ ᵈᵃᵗᵃ ᵉⁿᵍⁱⁿᵉᵉʳⁱⁿᵍ ⁱⁿᵗᵉʳᵛⁱᵉʷ.ᴰᵃᵗᵃ ᴱⁿᵍⁱⁿᵉᵉʳⁱⁿᵍ ʳᵒˡᵉˢ demands ᵗʰᵉˢᵉ skills ᵐᵃʲᵒʳˡʸ.

1. Big Data ( such as Spark, PySpark, MapReduce, Hive , Pig , HDFS etc.)
+ 🔗https://lnkd.in/diSS_Dfu

2. Data Warehousing( such as Snowflake, Redshift, ETL tools etc.)
+ 🔗https://lnkd.in/dZ-ZSXH6

3. Cloud Computing( AWS , GCP, Azure etc.)
+ 🔗https://lnkd.in/d6V8KNdq
+ 🔗https://lnkd.in/dSz4nd5S

4. Programming Language( Python , Scala etc)
+ 🔗https://lnkd.in/dmjcnHPE

### Darshil Parmar - Projetos Frre com Youtube para DataEng

🚀 5 Data Engineering Projects for FREE!


You need the experience to get a job
🔁
You need a job to get experience


👨🏻‍💻 Here are the 5 Projects that you can start this weekend

1. Building Data Model and Writing ETL Job
Data modeling is an essential part of Data Engineering, DO NOT SKIP THIS!!!

What will you learn?
+ ✅ Python
+ ✅ SQL
+ ✅ Building Data Models
+ ✅ Basics of DBMS
+ ✅ Writing ETL Job
+ ✅ Querying Data Programmatically
+ ✅ PostgreSQL


2. ETL Pipeline on AWS Cloud
If have no idea about Cloud Computing then this project is for you

What will you learn?
+ ✅ Python
+ ✅ SQL
+ ✅ Cloud Computing Basics
+ ✅ AWS Services - Athena, Glue, Redshift, S3, IAM
+ ✅ Creating Data Pipeline

3. Covid Data Analysis Project
This will be your first end-to-end Data Engineering project on Covid-19 Data

What will you learn?
+ ✅ Python
+ ✅ SQL
+ ✅ Building Data Model
+ ✅ AWS Services - Athena, Glue, Redshift, S3, IAM
+ ✅ Creating Data Pipeline
+ ✅ PostgreSQL


4. YouTube Data Analysis (End-To-End Data Engineering Project)
This is 3 hours long project where you will execute a complete Data Engineering project

What will you learn?
✅ Python and PySpark
✅ SQL
✅ How to understand the business problem
✅ AWS Services - Athena, Glue, Redshift, S3, IAM, Lambda, Quicksight
✅ Building Data Pipeline and Scheduling it

5. Twitter Data Pipeline using Airflow
If you are someone who wants to learn the basics about Airflow and how to build a data pipeline this project is for you

What will you learn?
✅ Python
✅ Basics of Airflow
✅ Working with Twitter Data and Package - Tweepy
✅ Python Package - Pandas
✅ Writing ETL job and storing data on S3

💪🏻 Doing these projects will give you the confidence to start your career in Data Engineering

1. Building Data Model and Writing ETL Job - https://youtube.com/playlist?list=PLBJe2dFI4sgukOW6O0B-OVyX9c6fQKJ2N

2. ETL Pipeline on AWS Cloud - https://youtube.com/playlist?list=PLBJe2dFI4sgt-9GR2j-rTeKtimE9pfqyt

3. Covid Data Analysis Project - https://youtube.com/playlist?list=PLBJe2dFI4sgvavQzL2Hm5CsnoIWHY5fI3

4. YouTube Data Analysis (End-To-End Data Engineering Project) - https://youtube.com/playlist?list=PLBJe2dFI4sguF2nU6Z3Od7BX8eALZN3mU

5. Twitter Data Pipeline using Airflow - https://www.youtube.com/watch?v=q8q3OFFfY6c

### 5 Repos apra Aprender AWS

https://www.linkedin.com/posts/semaan_aws-repos-activity-6981256835546681345-OJQN?utm_source=share&utm_medium=member_desktop

### Certificacao PL-300

Dicas: Sobre a certificação PL-300

Recebi diversas mensagens pedindo orientações/dicas sobre a prova e vou tentar resumir nessa postagem, ajudando assim de forma geral.

Microsoft Learn: A trilha da Microsoft é fundamental e precisa ser feita 100%. Não finalizei e senti dificuldade justamente nas questões onde não dei muita atenção. Então recomendo que façam TODA a trilha.

Udemy: Fiz apenas um curso na Udemy (em inglês) e recomendo, pois o instrutor tem uma didática espetacular e abre a mente. Claro que o material apresenta alguns problemas de atualização, já que o Power BI é atualizado mensalmente e fica impossível acompanhar as mudanças. Sendo assim, é importante estar atento às mudanças, para perceber que, por exemplo, agrupar está em home e não em transformar, como ele cita. Os estudos de caso são apresentados de outra forma, na prova (mais detalhados e complicados). O simulado, apesar de ser bom, não tem o formato da prova, que varia bastante entre múltipla escolha, drag and drop, menus suspensos, etc. Não percebi NENHUMA questão na prova que tenha sido copiada no simulado, o que é bem legal, pois o instrutor mostra honestidade e não vende solução, mas sim orienta como aprender. No mais, o curso é excelente e realmente indico. https://lnkd.in/diKsiTz5

Idioma: Fiz a prova em inglês e pelas experiências anteriores (onde fiz em português) eu achei que poderia traduzir durante a prova (precisei mudar de português para inglês em alguns momentos por conhecer alguns termos e funcionalidades apenas em inglês). Na prova do Power BI eu não tive opção de tradução para português e apesar de não ter precisado poderia ter sido desastroso, caso não conseguisse entender alguma questão.

Tempo de prova: Minha prova teve 40 questões + 10 no estudo de caso (recebi um, mas acho que podem colocar até 2). O contador de tempo de prova mostra o tempo restante e achei que teria 01h40 para a prova geral e mais 30 minutos para o estudo de caso, mas o tempo é pra tudo (falta de atenção minha). Terminei a prova faltando 3 minutos e foi BEM apertado. Recebemos um lápis e uma folha em branco e existe a possibilidade de usar calculadora, então sugiro que de vez em quando procure saber quanto tempo ainda tem para cada questão, para não ficar além do tempo disponível tentando resolver algo que vai te impedir de responder o que você poderia ter acertado, mas não teve tempo. Gerenciar o tempo é fundamental e utilizei o tempo limite pra cada questão e precisei revisar duas que não respondi e deixei pro final. Se vc tem x minutos pra uma questão e tem certeza absoluta, marca e avança. Teve dúvida? Pula pra próxima e volta depois, já que outras questões podem te fazer entender a que ficou pra trás.

Estudo de caso: O estudo de caso tem MUITA coisa pra ler e se você começar lendo ele, vai se atrapalhar. É melhor ler a questão e buscar a informação que precisa na descrição, que é BEM detalhada. As questões de estudo de caso do curso que recomendei são completamente diferentes da prova.

Conteúdo: Questões sobre RLS devem ser consideradas no seu estudo. Como não faz parte das minhas atribuições essa questão de RLS, não tenho muito conhecimento e tive dificuldades. Questões que envolvem DAX são drag and drop e estar atento nas novas funções é importante, pois eles colocam as antigas com parâmetros errados e você acostumado marca a questão errada. Lembrem que funções, geralmente, têm outras implícitas, ou seja, uma tem outra(s) por trás. Saber esses detalhes fará diferença.

Por fim, desejo boa sorte e aconselho dedicação, pois a prova NÃO É FÁCIL (se fosse, todo mundo passaria.

### O que estudar para ser DataEngineer

Casiso Bolba Artigo

https://cassio-bolba.medium.com/o-que-eu-estudaria-hoje-para-virar-engenheiro-de-dados-2074eb7a32f4

### Build Your Data Engineering Resume with this - 

Darshil Parmar

https://www.linkedin.com/posts/darshil-parmar_dataengineering-dataengineer-bigdata-activity-6980907575852568576-FvS3?utm_source=share&utm_medium=member_desktop

https://youtu.be/nr9ujxeCOfA

### Darshil Parmar - Airflow project

🚀 Airflow Data Engineering Project For Beginners for FREE!

https://www.youtube.com/watch?v=q8q3OFFfY6c&feature=youtu.be

Crossed 10K+ views already on the latest Data Engineering Project

Kick start your career in Data Engineering by implementing this project

What you will learn?

1. How to extract data from Twitter (especially Elon Musk's tweet)
2. Writing Python script for data extraction and transformation
3. Install Airflow on Amazon EC2 instance
4. Deploy code in Airflow and build pipeline
5. Store data in Amazon S3

Execute the entire Data Engineering project in under 40 minutes and learn the basic concept of Airflow

You can find the video link in the comment section

### Lucas Galindo - O que Bilionários fazem  no tempo livre

Um dos podcasts que mais curto escutar é o Like a Boss, é um podcast onde o Paulo Silveira e o Rodrigo Dantas entrevistam CEOs de empresas muito grandes e sempre tem uma perguntinha no final:

O que você faz no seu tempo livre?

Quase todos os CEOs são atletas no tempo livre, muitas vezes eles são atletas de alto rendimento, um dos fundadores da Alvin faz triatlo olimpico e na verdade mais da metade dos funcionários da empresa são atletas em algum nível.

Quer uma dica para aumentar seu rendimento no trabalho, ganhar mais e ficar mais feliz?

Faça um exercício, faz bem para a saúde, para a alma e comprovadamente para o bolso!

### Montar Curriculo em ingles em PDF

https://www.linkedin.com/posts/leonardodpmaia_modelo-de-curr%C3%ADculo-em-ingl%C3%AAs-activity-6978336236813840384-zYhV?utm_source=share&utm_medium=member_desktop

### Uberhub Fernando Khun

https://www.linkedin.com/in/ferdinandokun?miniProfileUrn=urn%3Ali%3Afs_miniProfile%3AACoAAA67nWMBHBeNQvuzsjyZcwcxmfPjiH_isJE&lipi=urn%3Ali%3Apage%3Ad_flagship3_saved_items%3BZvBjbnFZS4aZImjmQmUg8w%3D%3D

### Atekita Dev - Porque não consigo meu 1 emprego

https://youtu.be/SbIPLlhz1oc

### Ilustrando Word2Vec

https://www.youtube.com/watch?app=desktop&v=ISPId9Lhc1g

### Estatística Descritiva

Seria interressante se eu pega-se todos esse conceitos e coloca-se em portugues, isso seria uma boa base para entender estatística perfeitamente

https://towardsai.gumroad.com/l/descriptive-statistics

https://github.com/towardsai/tutorials/tree/master/descriptive-statistics

### Lazy Predccit - Lib em python que teta umonte de modelos em uma linha de código

https://medium.com/@fareedkhandev/apply-40-machine-learning-models-in-two-lines-of-code-c01dad24ad99

### Haddop is dead

https://www.linkedin.com/posts/admond1994_hadoop-bigdata-activity-6974728361864503296-badY?utm_source=share&utm_medium=member_desktop

adoop is dead.

Instead of:
+ • YARN (resource manager)
+ • HDFS (data storage layer)
+ • MapReduce (Compute layer)

We now have:
+ • Kubernetes (replace YARN)
+ • S3 (replace HDFS)
+ • Spark / Lambda (replace MapReduce)

More reasons why Hadoop is dead 👇🏻

1. Large enterprises are moving towards cloud solution

+ • Many large enterprises still have their own data centers and are using Hadoop cluster
+ • Because of huge admin overhead and legacy system, most of them are moving to cloud (AWS / GCP / Azure)
+ • Those who are not moving to cloud, it's because of bureacracy


2. SMEs don't use Hadoop

+ • SMEs don't have the data volume, resources and expertise to use Hadoop
+ • Instead, they use cloud solution to store data, host websites/apps, run analytics

Conclusion?

Learn Spark, not Hadoop.
Learn AWS, not Hadoop.
Learn SQL, not Hadoop.

### ULTRA - CANAIS PARA ACOMPANHA NA ÁREA DE DADOS

[LISTA DE PESSOAS E CANAIS PARA ACOMPANHAR DISCUSSÕES NA ÁREA DE DADOS + VAGAS]

Você junior, pleno, sênior, líder, já ouviu ou perguntou sobre como um candidato se "mantém atualizado"? Neste post decidi reunir algumas das pessoas, canais e comunidades que eu adoro acompanhar e pode interessar outras pessoas da área de dados!

ᴛᴇʟᴇɢʀᴀᴍ - ᴄᴀɴᴀɪꜱ ᴅᴇ ᴠᴀɢᴀꜱ:
+ https://lnkd.in/dD5_sFJz
+ https://t.me/ReelsEmpregos
+ https://t.me/CafeinaVagas (SÓ VAGA P JUNIOR)
+ https://t.me/remotarjobs
+ https://t.me/temvagaprajr (SÓ VAGA P JUNIOR)

ᴛᴇʟᴇɢʀᴀᴍ - ᴄᴀɴᴀɪꜱ ᴅᴇ ᴅɪꜱᴄᴜꜱꜱᴀᴏ:
+ Canal do André Sionek (Eng. de Dados Mão na Massa): https://lnkd.in/dzch8NnG 
+ Ciência de Dados - Brasil (não achei link de entrada, adição de membros diretamente por outro usuário que já esteja dentro ) 
+ https://lnkd.in/diaGScmz 
+ https://lnkd.in/dJjUW5aw
+ https://lnkd.in/deNgksbR
+ https://t.me/kafkabr
+ https://lnkd.in/dVPdHf4N 
+ https://t.me/dadosabertos

ʟɪɴᴋᴇᴅɪɴ ᴘʀᴏꜰɪʟᴇꜱ (ɪɴɢʟᴇꜱ) ᴄᴏᴍ ᴄᴏɴᴛᴇᴜᴅᴏꜱ ᴅᴇ ᴅᴀᴅᴏꜱ (ᴍᴀɪᴏʀɪᴀ ᴠᴏʟᴛᴀᴅᴏ ᴘᴀʀᴀ ᴇɴɢᴇɴʜᴀʀɪᴀ, ᴍᴀꜱ ᴀʟɢᴜɴꜱ ᴘʀᴀ ᴄɪᴇɴᴄɪᴀꜱ ᴅᴇ ᴅᴀᴅᴏꜱ ᴇ ᴀɴᴀʟʏᴛɪᴄꜱ):
+ Darshil Parmar
+ Benjamin Rogojan
+ Zach Wilson
+ Shashank Mishra 🇮🇳
+ Ankit Bansal
+ Gowtham SB
+ Saikat Dutta
+ Suraz G.
+ Mehdi Ouazza
+ Sagar Prajapati
+ POOJA JAIN
+ Feenaz Aarif
+ Sumit Mittal
+ Deepanshu Kalra
+ Deepak Goyal
+ Andreas Kretz
+ Marc Lamberti
+ Joseph M.
+ Jash Radia
+ Abhishek Choudhary
+ Joe Reis 🤓

Source: https://lnkd.in/dJMH-gwx 

ᴘᴇʀꜰɪꜱ ᴅᴇ ʙʀᴀꜱɪʟᴇɪʀᴏꜱ(!) ᴄᴏᴍ ᴄᴏɴᴛᴇᴜᴅᴏ ᴅᴇ ᴅᴀᴅᴏꜱ ᴏᴜ ʀᴇꜰᴇʀᴇɴᴄɪᴀ ɴᴀ ᴀʀᴇᴀ:
+ André Sionek
+ Téo Calvo
+ Rhuan Lima
+ Cassio Bolba
+ Lucas Renan Galindo Lourenço
+ Allan Sene
+ Carlos Barbosa
+ Luan Moreno M. Maciel
+ Mateus Henrique Cândido de Oliveira
+ Rodrigo Ferreira
+ Felipe Santana

Source: Lista montada com ajuda do João Ortiz

ᴄᴏᴍᴜɴɪᴅᴀᴅᴇꜱ:
+ Data Hackers: https://lnkd.in/dzMzHHAM (comunidade no Slack, tem newsletter via e-mail, ver no site!)
+ ChartR https://www.chartr.co/ (newsletter com visualizações diferentonas muito interessantes, veja print nos comentários)

ᴛᴡɪᴛᴛᴇʀ - ᴄᴀɴᴀɪꜱ ᴅᴇ ᴠᴀɢᴀꜱ:
+ https://lnkd.in/dMNF2Mbu
+ https://lnkd.in/dgBXbSbF (SÓ VAGA P JUNIOR)

ᴛᴡɪᴛᴛᴇʀ - ᴄᴀɴᴀɪꜱ ᴅᴇ ᴅɪꜱᴄᴜꜱꜱÃᴏ:
+ Data Engineering: https://lnkd.in/dX373eS9
+ Bolha Tech 🇧🇷 https://lnkd.in/dTxJqmYp

ʏᴏᴜᴛᴜʙᴇ:
Infinitos canais, sério, INFINITOS, é só procurar, comece procurando os canais dos brasileiros indicados na lista; o limite de caracteres de post do Linkedin inclusive não me permite escrever mais NADA; now go on by your own.

### Exemplo de Layout PBI no FIgma

https://www.figma.com/file/WcveERG06dFrGl9GBxFntQ/Layout-Dark-by-Sayuri-Valente-Power-BI?node-id=0%3A1

### Busque pelo repo do livro 'Python Dta Science Handbook'

É um livro com um lagarto na frente. TEm o repo em JUpyter notebook.

### Se preparara para vagas no exteior

Fazer aquela entrevista em inglês para uma vaga gringa pode ser um baita desafio.

Hoje trago 3 ferramentas para te ajudar nessa missão 👇

1 - BigInterview - Esse app tem ferramentas específicas para quem tem o inglês como segunda linguagem, ajudando nas nossas principais dores na hora de uma entrevista com gringos.

2 - MyInterviewPractice - Aqui você escolhe entre 120 tipos de entrevista personalizados para cada área de atuação. O app te ajuda a lidar com a pressão, organizar os pensamentos e mandar bem na hora H.

3 - Google Interview Warmup - O queridinho da galera. Aqui você treina com perguntas pré-estabelecidas e ainda recebe feedback sobre suas respostas de forma 100% gratuita.

Vou deixar o link aqui embaixo para você conferir cada uma dessas ferramentas

### Extensão  JSON Crack, no VS Code

Pesquise no VSCode

### Nação Fluente - Vânia

Às vezes você tem a impressão de que seu inglês não está evoluindo e tem a sensação de que está aprendendo coisas que não usa no dia a dia do trabalho?

Se respondeu sim, é porque provavelmente você está estudando errado. Corre que é uma cilada, Bino.

Vamos resolver isso?

1️⃣ Estude vocabulário do dia a dia para a sua profissão: https://lnkd.in/eaqfuVCg 


2️⃣ Aprenda o inglês corporativo:

→ Vocabulário do dia a dia no trabalho: https://lnkd.in/ehUQZKag

→ 50 expressões úteis para entender os nativos: https://lnkd.in/eS7ksZet

→ Abreviações do inglês corporativo: https://lnkd.in/e6XtmmNQ


3️⃣ Inglês para reuniões

→ Frases úteis para reuniões em inglês: https://lnkd.in/ePQtNvhw

→ Ligações internacionais: como falar bem ao telefone em inglês e soar como profissional https://lnkd.in/eHiFGU5

→ Guia: tudo o que você precisa para falar em inglês ao telefone: https://lnkd.in/dTEwg65

→ 50 frases para iniciar uma conversa em inglês no trabalho: https://lnkd.in/e47bTU6E


4️⃣ Inglês para e-mails

→ Escreva e-mails em inglês como um profissional e sem depender do Google Translate: https://lnkd.in/eXUBMsQ

→ 7 modelos de e-mail em inglês para você copiar: https://lnkd.in/e24WbxQ

→ 8 passos simples para escrever e-mails profissionais em inglês: https://lnkd.in/euGsJ6H


🎯 EXTRA:

→ Faça o download de um cronograma de estudos (do básico ao avançado). O cronograma está organizado para você estudar em 3, 6 ou 12 meses. Você escolhe e vai no seu ritmo: https://lnkd.in/eKM8FTB

### Extensão para ajudar nas vagas do lnikedin

https://www.linkedin.com/posts/leandro-baptista-international-career_tuesdaytool-activity-6972892411710590976-7tmh?utm_source=share&utm_medium=member_desktop

JobSeer

Jobalytics

Sâo extensoes do crhome (use somente uma delas) que vai dar um score informando se a vaga está de acorrdo com seu perfil ou não.

### Odemir exemplos

https://www.linkedin.com/posts/odemir-depieri-jr_guia-arima-by-odemir-depieri-jr-activity-6969984545945206784-Tkm0?utm_source=share&utm_medium=member_desktop

Odemi posta pdfs com o script em jupyter + comentários de como criar projetos inteiros de ML/DA

### Melhorar README do Github

**Gerador de README do Github**
https://rahuldkjain.github.io/gh-profile-readme-generator/

Exemplo do cara: https://github.com/sudiptob2

### Como ganhar em dólar

https://www.linkedin.com/in/ACoAAB9US0MBB4qOHq842hGSP6E57NmmVE2eAH4?miniProfileUrn=urn%3Ali%3Afs_miniProfile%3AACoAAB9US0MBB4qOHq842hGSP6E57NmmVE2eAH4&lipi=urn%3Ali%3Apage%3Ad_flagship3_myitems_savedposts%3BgUwXV5W7T%2F%2BinHVebxUyZQ%3D%3D

### O que o mercado espera de um Data Engineer Junior?🧐

Sempre olho essas habilidades técnicas quando vou contratar alguém..

- SQL Intermediário: #sql é uma linguagem extremamente necessária para um Engenheiro de Dados. O básico sobre sintaxe ou funções simples é realmente muito fácil e pode ser aprendido em dois dias de estudo. Logo, o que se espera é que a pessoa já saiba algo mais intermediário como: agrupametos, sub-queries, ordenação, tipos de joins, windows functions.

- Python: O que se espera é que esse profissional tenha habilidades de:
 - Ler e entender bem um código #python .
 - Entender basicamente sobre Orientação a Objetos.
 - Conhecer como usar funções para análise de dados (pandas, numpy, matplotlib, seaborn.)
 - Saiba interagir com bancos de dados usando biblioteca SQLAlchemy, por exemplo. Aqui se espera que saiba fazer consultas e emitir instruções de DML. (Nada avançado).
 - Cloud: É importante que o profissional saiba como funciona alguns serviços para Data engineering em cloud. Não precisa ser especialista, mas saber quais são os principais serviços para processamento distribuído ou Data Warehousing é importante.

- Proeficiência para resolver problemas: Nesse ponto, se espera que o profissinal saiba como resolver problemas. Como fazer debug de código (ler logs em inglês), como olhar para um problema e identificar como resolver de forma macro.

### Seu salário é proporcional ao problema que você resolve

Já parou para pensar que o salário que você recebe é proporcional ao tamanho dos problemas que você consegue resolver? É sério! A lógica é simples:

Se o problema é fácil e a solução pode ser feita por qualquer um, então a compensação vai ser baixa. É o caso de garçons, zeladores, atendentes, etc.

Esse insight ficou muito claro para mim quando um grande executivo me contou um pepino gigantesco de sua empresa e eu não fazia ideia de como resolve-lo. É por isso que o cara ganha muito mais do que eu. 

Quando poucas pessoas são capazes de resolver um problema, elas podem ganhar dinheiro infinito. Portanto, pense em si mesmo não na profissão que você exerce, mas que tipos de problema você resolve e, sobretudo, para QUEM você está resolvendo esses problemas.

Agora me diga: você é um bom resolvedor de problemas? Você tem a acabativa necessária para executar o que precisa ser executado? E mais: você SABE que tipos de problemas precisam ser solucionados para que você receba uma remuneração maior?

### Dicas para quem vai começar CLT na áre de dados

https://www.linkedin.com/posts/bruno-medeiros-75305a107_quem-depois-de-muito-estudo-e-dedica%C3%A7%C3%A3o-activity-6968971103679492096-ncY_?utm_source=share&utm_medium=member_desktop

OLHE OS COMENTÁRIOS

### Perfis BR da área de dados

No post de hoje quero recomendar os seguintes perfis:

Felipe Santana : Fala sobre Data Science.
Rafael Zenorini 智海飞: Fala sobre Soft Skills, dicas de carreira e de como migrar para área de dados.
João Oliveira: Fala sobre migração de carreira para área de dados
Cassio Bolba: Fala sobre Data Engineering.
Téo Calvo: Fala sobre Data Science.
Lucas Renan Galindo Lourenço: Fala sobre trabalho no exterior
Laura Oliveira: Fala sobre contratação e oportunidades no exterior.

Recomendo muito o trabalho dessas pessoas e acredito que você vai gostar de seguir também.

### Dicas para entrar na área de CIência de dados

Algumas coisas que não te contaram sobre trabalhar com ciência de dados:

- Há muitas vagas na área, mas também há muitos candidatos e os processos seletivos formam um jogo de enorme assimetria de informação. Tenha paciência, a oportunidade irá surgir, mas vai levar mais tempo do que alguns te venderam.

- Se você é curioso e ama aprender, saiba que em Data Science você nunca vai saber tudo o que gostaria. A área é muito extensa, não deixe que isso te frustre.

- Cada cientista de dados tem sua história, não se compare com os outros. Seu colega sabe mais séries temporais que você porque ele sempre trabalhou com isso, ou teve uma formação que puxava mais para esse lado. Se você olhar melhor, vai ver que supera ele em outras habilidades. Faz parte do jogo, cada um teve sua formação, sua experiência.

- Aprenda sobre produto/negócio. Nenhum executivo se importa com seu algoritmo, p-valor, acurácia, AUC ou f1-score. Eles querem saber que problema está sendo solucionado e qual o retorno obtido. O melhor modelo é o modelo que resolve o seu problema!

- Modelagem é uma parte muito pequena da nossa rotina. Boa parte do seu dia será limpando dados e caçando informações.

- Algumas técnicas funcionam super bem em tutoriais, mas são quase que inúteis no dia à dia. Eu sempre gosto de usar o SMOTE como exemplo. No Medium, a técnica parece imbatível, enquanto no mundo real é bem pouco eficiente.

- Você provavelmente deixou passar algum conceito de data leakage e validação nos seus estudos. Isso significa que você vai experienciar alguns modelos falhando somente quando estiverem em produção. Não deixe de investir em monitoramento para evitar desastres maiores!

- Todas empresas vendem a imagem de que são data-driven, mas pouquíssimas realmente abraçam a cultura. Para piorar, nem sempre você terá os líderes ao seu lado nessa luta.

- Saiba diferenciar inferência de predição. Um mesmo algoritmo pode ter premissas e riscos diferentes a depender da aplicação. 

- Tensorflow, Pycaret, Catboost e outras bibliotecas vão te impressionar. Mas jamais subestime o poder do combo Numpy, Pandas e Scikit-Learn. Você constrói soluções inacreditáveis com elas. 

- A pior coisa é passar horas (ou até dias) em um estudo e só depois descobrir que havia um furo nos dados ou no entendimento deles. É chato demais vivenciar isso, mas acontece com todo mundo. Não se culpe, nem perca a paciência com os outros. Tire a lição que tiver para tirar ali e bola para frente!

- Já se foi o tempo em que as empresas pagavam uma nota a qualquer um que conseguisse rodar um pd.merge() da vida. A régua já subiu bastante e está em constante movimento. Cloud, noções de engenharia de dados, causalidade e outras habilidades são cada vez mais comuns nos pré-requisitos de um cientista de dados.

### Entrevista de Data Eng - SQL

Em entrevistas para Data Engineers é comum algumas questões sobre SQL, como:

1 - Como encontrar duplicatas em uma tabela
2 - Como excluir duplicatas de uma tabela
3 - Diferença entre Union e Union ALL
4 - Diferença entre rank, row_number e dense_rank
5 - Localizar registros em uma tabela que não estão presentes em outra tabela
6 - Encontre o segundo funcionário com maior salário em cada departamento
7 - Encontre funcionários com salário maior que o salário do gerente
8 - Diferença entre inner, left e right join
9 - atualize uma tabela e troque os valores de gênero.

### Coisas que aprendi num ML Complexo

https://www.linkedin.com/feed/update/urn:li:activity:6953082226762735617?updateEntityUrn=urn%3Ali%3Afs_feedUpdate%3A%28V2%2Curn%3Ali%3Aactivity%3A6953082226762735617%29

Coisas que aprendi errando no projeto de Machine Learning mais complexo que desenvolvi sozinho:

- Se os dados não têm label, a primeira coisa é classificar uma boa quantidade à mão. Sem isso, você só consegue executar testes pouco objetivos e não consegue determinar se houve avanço significativo;

- É necessário utilizar uma ferramenta de testes (MLFlow, test.ai, SageMaker Experiments, etc.) desde o início, para não se perder e começar a atirar pra todo lado em vez de seguir em uma direção promissora;

- Desde o início construir o projeto de forma modular (separar cada pedaço para ser fácil de modificar ou substituir);

- Test-driven development: rechear o código de pequenos testes para garantir que o resultado que você precisa está sendo atingido;

- Salvar coisas que demoram para rodar em pickles (criar um cachê);

- Entregar um resultado preliminar o mais rápido possível para o cliente, a fim de entender se você está no caminho certo (tentar fazer isso várias vezes);

- Trabalhar para entender como e ter certeza que o produto será utilizado em seu pleno potencial com a mesma dedicação aplicada aos aspectos técnicos.

### Coloque inglês como prioridade

Coloquem o inglês como uma prioridade nos seus estudos.

Sempre que vou dar mentoria, pergunto qual o nível do inglês do aluno e, a partir disso, construo a trilha que o aluno deve percorrer. O que tenho notado com o tempo é que a lacuna entre o material que consigo passar para quem não fala o idioma versus o que é passado para quem já o domina é enorme. A maioria dos alunos não percebe isso e acaba adotando a estratégia de primeiro estudar os conteúdos X, Y e Z da sua área, para só depois começar no inglês. Essa é uma estratégia que me parece bem equivocada, pois o inglês não é algo que traz benefício por si só, ele também serve para alavancar o seu potencial em X, Y e Z. Deixá-lo para depois é desperdiçar o seu potencial nos estudos.

Os melhores cursos ainda estão em inglês, a Udemy possui muito mais opções bem avaliadas em inglês, a Udacity - uma das melhores plataformas de MOOCs - só possui cursos em inglês, o melhor do Coursera está em inglês, a editora Springer - que possui as obras mais extensas de Data Science - só tem conteúdo em inglês, a maioria dos livros disponíveis de graça da O'Reilly estão em inglês, as discussões nos principais fóruns são feitas em inglês, e por aí vai. Não deixe o idioma em segundo plano, o inglês é tão prioritário quanto qualquer outro requisito da sua profissão.

### Erros comuns de quem está começando em DS

Estes são erros comuns de iniciantes (e até avançados) em Data Science.

Adianto que já cometi alguns, principalmente o terceiro.

1. Entender de forma superficial o requisito de negócio.

2. Menosprezar a etapa de análise exploratória de dados e ir direto para experimentação com algoritmos.

3. Subestimar técnicas simples até quebrar a cara e voltar com o rabo entre as pernas. Esse é classico, que atire a primera pedra quem nunca.

4. Se apegar a ferramentas e tecnologias ao invés de focar na solução do problema.

5. Tomar decisão puramente técnica sem levar em consideração a experiência do usuário.

6. Não investigar de forma minuciosa os resultados do modelo e alinhar com as métricas de negócio.

7. Não saber se comunicar e apresentar de forma clara e sucinta o seu trabalho.

Se você concorda ou se já cometeu algum desses, marque um amigo que também esteja na caminhada.

### Links úteis paa PBI

https://elsanalytics.com.br/2022/04/24/links-uteis-ao-trabalhar-com-microsoft-power-bi/

### Livros interessantes e legais sobre dado/estatisticas

Uma lista de livros não-técnicos para quem se interessa por dados. São leituras ótimas que podem ser úteis tanto para executivos e PMs que não querem ficar de fora dessa revolução, quanto para cientistas e analistas de dados. Os 5 primeiros eu considero leitura obrigatória:
- Como mentir com estatística
- O andar do bêbado
- Todo mundo mente
- Rápido e Devagar
- Freakonomics
- Naked Statistics
- O sinal e o ruído
- The Book of Why
- The Why Axis
- Uma senhora toma chá
- Pode não ser o que parece
- Cisne Negro
- Algoritmos de destruição em massa
- The Information
- Dataclysm
- Algorithms to Live By
- Complex Adaptive Systems
- Life 3.0: Being Human in the Age of Artificial Intelligence
- Invisible Women: Data Bias in a World Designed for Men
- Automating Inequality: How High-Tech Tools Profile, Police, and Punish the Poor
- Algorithms of Oppression: How Search Engines Reinforce Racism
- The Shame Machine: Who Profits in the New Age of Humiliation

### Lembrar dessaas palavras em ingles

Algumas palavras que me ajudaram a falar Inglês com mais naturalidade:

almost / quase
at least / pelo menos
rather / em vez
perhaps / talvez
overwhelmed / sobrecarregada
unless / a não ser que
instead / em vez de
otherwise / de outra forma
therefore / portanto
however / contudo

### ESTATÍSTICA É MUITO MAIS DO QUE VOCê RAFAEL PENSA

https://www.linkedin.com/feed/update/urn:li:activity:6946082882209677312/

Vejo muitos cientistas de dados por aí dizendo que a estatística é importante.

Quando você vai ver os trabalhos deles:

- Não tem teste de hipótese
- O modelo que se utiliza da premissa da distribuição ser normal está lidando com outras famílias de distribuições
- Não tem análise de outlier
- Usa a correlação de Pearson para todos os tipos de variáveis em todas as situações
- Resultado é um número único e não um intervalo
- A média é a resposta de tudo

Comece a refletir sobre esses tópicos e você se tornará um melhor cientista de dados! 

**Termos que eu nâo conheço**

==> Entre um cientista de dados junior claramente vale mais a pena contratar um que entenda justificar backtesting e corrigir overfitting do que compreender métodos não parametricos e modelagem whitebox.

==> Pelo que tenho observado, aqui no BR, a maioria dos cientistas de dados sequer sabem o básico de estatística e o mercado também não cobra. Quando vejo vagas do exterior, geralmente colocam um peso maior em modelagem estatística, pois realmente querem determinar relações e explicar as fontes de variabilidade do problema em questão (ANOVA, LMM e outros).

### Canal BR sobre DBT

https://www.youtube.com/channel/UCSCtlb4ozQxyuaRaWUYPQkg

### Filipe Balseiro - Data Engineering RoadMaps by Days

https://www.linkedin.com/feed/update/urn:li:activity:6942202732644589568/?updateEntityUrn=urn%3Ali%3Afs_feedUpdate%3A%28V2%2Curn%3Ali%3Aactivity%3A6942202732644589568%29

### Odemir Sistema de Recomendação

https://www.linkedin.com/feed/update/urn:li:activity:6937907005122588672/?updateEntityUrn=urn%3Ali%3Afs_feedUpdate%3A%28V2%2Curn%3Ali%3Aactivity%3A6937907005122588672%29

### Como criar portfólio para Data Engineering?

https://www.linkedin.com/posts/rodrigo-santana-ferreira-0ab041128_dataengineering-python-portfolio-activity-6937047115021840385-DVut?utm_source=share&utm_medium=member_desktop


Como criar portfólio para Data Engineering?

+ -> Escreva um código em python que extrai dados de uma Api pública.
+ -> Crie uma função ou classe que valide os dados.
+ -> Persista os dados em um banco de dados como o PostgreSQL ou SQlite na sua máquina local.
+ -> Crie alguns modelos usando dbt. (Escreva boas querys).
+ -> Crie alguns tetes também usando dbt.
+ -> Instale o Airflow via docker e crie dags para automatizar a coleta, tratamento e as transformações com dbt.
+ -> Salve tudo isso em um repositório público no github.
+ -> Faça um dashboard simples usando PowerBi ou DataStudio.
+ -> Explique tudo que fez em um arquivo Readme.md
+ -> Públique o seu trabalho no Linkedin

Esses são passos simples mas bastante eficientes para quem quer construir portfólio.

Eu adoraria ver um repo de alguém que eu estive contratando como Engenheiro de Dados que contivesse tudo isso que falei.

Em quanto tempo você faz isso? entre estudos e testes, eu diria que no máximo uma semana.

O que você acha dessa receita de bolo? :)


==============

## 17/10/2022

### Mentoria de BI/Análise de Dados

https://www.youtube.com/c/joaomdeoliveira
