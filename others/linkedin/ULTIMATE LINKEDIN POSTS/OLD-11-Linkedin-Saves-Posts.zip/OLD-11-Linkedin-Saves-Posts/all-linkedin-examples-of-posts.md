# Exemplo de Posts de Linkedin

## Publicar Badge/Certificado

### AWS CRISP

https://www.linkedin.com/posts/amanda-araujo-de-alvarenga_aws-amazon-activity-6985993340827627524-scu-?utm_source=share&utm_medium=member_desktop

Gostaria de compartilhar que recebi uma nova certificação: Process Model: CRISP-DM on the AWS Stack da empresa Amazon Web Services (AWS)! #aws #amazon

## Vaga e Emprego

### Vaga 1

https://www.linkedin.com/in/augusto-maillo/ ==> O cara vem da UFMG

https://www.linkedin.com/posts/augusto-maillo_gostaria-de-compartilhar-que-estou-come%C3%A7ando-activity-6986286116597305345-cPk-?utm_source=share&utm_medium=member_desktop

Gostaria de compartilhar que estou começando em um novo cargo de Data Scientist Jr na AeC.
