# Linkedin Saves 3 - 28/11/2022


De tempos em tempos devo acessar o linkedin save e anotar tanto aqui quanto no caderno as melhores coisas.

Se forem muito grande anoto aqui. Se forem pequenas anoto aqui e no caderno.

IMPORTANTE: após preencher o forms os convites só chegam em Dezembro quando encerram as inscrições.

## Index



## Página de PBI



## Linkedin Saves



### (English) Links auxiliares para estudar

https://www.linkedin.com/posts/joaovitor-front-end_find-out-how-strong-your-vocabulary-is-and-activity-7002685487526088704-_j6s?utm_source=share&utm_medium=member_desktop

Olá, rede! Trago para vocês um compilado de links para auxiliar no aprendizado dessa skill imprescindível para o mercado que estamos situados.

Segue links incríveis para melhor o aprendizado no idioma inglês:
→ Aumentar o vocabulário: https://lnkd.in/dTHJN3gA
→ Aprender com vídeos: https://lnkd.in/dij_tafG
→ Testar seu vocabulário: https://lnkd.in/dxhKfPwH
→ Dicionário de collocations: https://lnkd.in/dZwu6HQG
→ Encontrar palavras em contexto: https://lnkd.in/dEm8J_5g
→ Curso de inglês gratuito (1): https://lnkd.in/d9xeCeHT
→ Curso de inglês gratuito (2): https://lnkd.in/dC3FnaVj
→ Tirar dúvidas sobre o inglês: https://lnkd.in/dRsKPp_N
→ Praticar inglês com diversos recursos: https://lnkd.in/deeiziHV
→ Gírias em inglês: https://lnkd.in/dra-eh-R
→ Praticar conversação (1): https://lnkd.in/dgp8hEGe
→ Praticar conversação (2): https://lnkd.in/dmtnraay
→ Aprender inglês pelo YouTube: https://lnkd.in/dFceFJPn
→ Dicionário: https://lnkd.in/duMPdRN6
→ Descobrir seu verdadeiro nível de inglês: https://lnkd.in/diJgsV7B
→ Troca de idiomas (1): https://lnkd.in/dwcZJTMm
→ Troca de idiomas (2): https://lnkd.in/df38x2vu
→ Pronúncia correta com filmes e séries: https://lnkd.in/dKz5QjR4
→ Rádios em inglês: https://lnkd.in/dG-juR2U
→ Melhorar a fala: https://lnkd.in/d5M9B-gr
→ Palestras TED: https://lnkd.in/dvJDsM9D
→ Praticar inglês com nativos (1): https://lnkd.in/dvdufB25
→ Praticar inglês com nativos (2): https://lnkd.in/d2whpMtU
→ Corrigir a pronúncia: https://lnkd.in/dhru_-3k
→ Corrigir a escrita: https://lnkd.in/dMWkJzYE
→ Comunidade para praticar inglês: https://lnkd.in/dT3a2fjf
→ Descobrir a pronúncia das palavras: https://lnkd.in/dsGY_YNq
→ Notícias em inglês: https://lnkd.in/dyupruVD
→ Aprender coisas diferentes com estrangeiros: https://lnkd.in/d5yBdSVr
→ Fórum sobre a língua inglesa: https://lnkd.in/dcmCbGk6
→ Livros em inglês: https://lnkd.in/dJsuikfc
→ Aulas de audição: https://lnkd.in/d6KYTjj4
→ Dicionário visual: https://lnkd.in/dYZBC4Nn
→ Praticar a leitura: https://lnkd.in/dpHZ7xcW
→ Treinar entrevista em inglês: https://lnkd.in/dg8QU6Ei
→ Aprender inglês cantando: https://lnkd.in/dKre5vDF

Conheça outros recursos fantásticos para aprender inglês sozinho: https://lnkd.in/duXYcD9D

Gostou das sugestões? Compartilhe e ajude a sua rede.



### (English) Vania - Canis para aprender ingles

https://www.linkedin.com/posts/vaniapaulacoach_links-para-aprender-ingl%C3%AAs-de-gra%C3%A7a-v%C3%ADdeos-activity-7002949242075914240-Ddos?utm_source=share&utm_medium=member_desktop

LINKS PARA APRENDER INGLÊS DE GRAÇA

VÍDEOS & CANAIS NO YOUTUBE:

→ Mais de 1000 vídeos de vários professores: [lnkd.in/dnS37wgM](http://lnkd.in/dnS37wgM)
→ Bom para alunos mais avançados: [lnkd.in/dkAvBMxd](http://lnkd.in/dkAvBMxd)
→ Ótimos vídeos sobre pronúncia, gírias e muito mais: [lnkd.in/dydbK3ay](http://lnkd.in/dydbK3ay)
→ Mais de 10 anos de vídeos de ensino de inglês: [lnkd.in/dgHZGDXY](http://lnkd.in/dgHZGDXY)
→ Divertida e enérgica professora americana de inglês: [lnkd.in/d83kbdZp](http://lnkd.in/d83kbdZp)
→ Conversas, audição avançada, curso para iniciantes: [lnkd.in/duWbWjmD](http://lnkd.in/duWbWjmD)
→ Professora de inglês australiano: [lnkd.in/daM7JgzT](http://lnkd.in/daM7JgzT)
→ Professora de inglês britânico: [lnkd.in/dFNsb8_9](http://lnkd.in/dFNsb8_9)
→ Expressões naturais, pronúncia, phrasal verbs: [lnkd.in/dWxqqBv9](http://lnkd.in/dWxqqBv9)
→ Aprender inglês através de ritmo e rap: [lnkd.in/dVt3ShMd](http://lnkd.in/dVt3ShMd)
→ Pronúncia, preposições, vocabulário do inglês britânico: [lnkd.in/dxahhky5](http://lnkd.in/dxahhky5)
→ Mais de 400 vídeos sobre muitos tópicos diferentes: [lnkd.in/d_eaJGdK](http://lnkd.in/d_eaJGdK)
→ Foco especial em melhorar a escrita: [lnkd.in/drNpNiYm](http://lnkd.in/drNpNiYm)

PODCASTS & LISTENING:

→ Mais de 700 episódios sobre estratégias de estudo: [lnkd.in/dcUCn8BT](http://lnkd.in/dcUCn8BT)
→ Conversas divertidas sobre assuntos do dia a dia: [lnkd.in/dZjqupcd](http://lnkd.in/dZjqupcd)
→ Mais de 2.500 áudios e vídeos de vários falantes de inglês: [lnkd.in/d4vegJmH](http://lnkd.in/d4vegJmH)
→ Notícias, tecnologia, estilo de vida e tópicos atuais: [lnkd.in/dQQ3GJmW](http://lnkd.in/dQQ3GJmW)
→ Todos os tópicos de negócios que você pode imaginar: [lnkd.in/dPzEiKWG](http://lnkd.in/dPzEiKWG)
→ Podcasts e vídeos para vários níveis: [lnkd.in/d8PJT_Xf](http://lnkd.in/d8PJT_Xf)
→ Só tem 1 minuto? Você ainda pode praticar sua escuta: [lnkd.in/dj_qyCyW](http://lnkd.in/dj_qyCyW)
→ Inglês britânico, episódios sobre expressões e gírias: [lnkd.in/dPUevh5J](http://lnkd.in/dPUevh5J)

SITES & BLOGS:

→ Aulas para todos os níveis, negócios, conversas: [lnkd.in/d_tjurdM](http://lnkd.in/d_tjurdM)
→ Um falante não nativo que se tornou fluente e tem ótimas dicas: [lnkd.in/dre9fRcu](http://lnkd.in/dre9fRcu)
→ Artigos e áudios sobre uma variedade de tópicos: [lnkd.in/duYRMBAh](http://lnkd.in/duYRMBAh)
→ Professor de inglês britânico com aulas diárias: [lnkd.in/dUqWYbEk](http://lnkd.in/dUqWYbEk)
→ Vocabulário, gramática e dicas de estudo: [lnkd.in/drUQaABE](http://lnkd.in/drUQaABE)
→ Explicações de frases úteis: [lnkd.in/dia3qNhB](http://lnkd.in/dia3qNhB)
→ Conversas práticas e perguntas para discussão: [lnkd.in/dCCa4Rjb](http://lnkd.in/dCCa4Rjb)
→ Foco em inglês corporativo e expressões idiomáticas: [lnkd.in/dt7FEVQ4](http://lnkd.in/dt7FEVQ4)
→ Recursos, dicas e lições de aprendizado de inglês: [lnkd.in/dk87mCMF](http://lnkd.in/dk87mCMF)
→ Gramática, vocabulário e inglês cotidiano: [lnkd.in/d9ziQ48p](http://lnkd.in/d9ziQ48p)
→ Blog divertido com gráficos coloridos: [lnkd.in/dhJ2vSAD](http://lnkd.in/dhJ2vSAD)
→ Lições simples organizadas em níveis: [lnkd.in/d8pKDU5p](http://lnkd.in/d8pKDU5p)
→ Diálogos sobre muitos tópicos com frases comuns: [lnkd.in/dBAC-MXb](http://lnkd.in/dBAC-MXb)
→ Guias e recomendações em inglês: [lnkd.in/dAtCHngB](http://lnkd.in/dAtCHngB)

Conheça outros recursos fantásticos para aprender inglês sozinho: [lnkd.in/duXYcD9D](http://lnkd.in/duXYcD9D)

Aulas gratuitas de inglês pelo YouTube (com cronograma de estudos): [lnkd.in/dFceFJPn](http://lnkd.in/dFceFJPn)

Gostou das sugestões? Compartilhe e ajude a sua rede.

### (Download)  Theoretical Computer Science Cheat Sheet 

https://www.linkedin.com/posts/greg-coquillo_theoretical-computer-science-cheat-sheet-activity-7002674914260389888-t__x?utm_source=share&utm_medium=member_desktop

### (Book) 100 Indicadores de Gestão

https://www.linkedin.com/posts/m%C3%A1rcio-monteiro_bom-dia-rede-para-quem-procura-um-bom-livro-activity-7002625231454392320-4sKk?utm_source=share&utm_medium=member_desktop

Para quem procura um bom livro com indicadores Kpi, e não sabe como realizar as métrica certas e criar os Dashboard, recomendo esse livro são 100 Kpi de diversões áreas como:

Financeira
Tesouraria
Recursos humanos
Sistemas de Informação
Projetos
Produção
Marketing
Marketing Digital
Armazém
Ambiental.

### (Book) Learning data engineer

https://www.linkedin.com/posts/ravitjain_learn-data-engineering-activity-7002308296447549440-dTTl?utm_source=share&utm_medium=member_desktop

### (Excel) Atalhos

https://www.linkedin.com/posts/almeidafelipe88_excel-compartilhamento-activity-7002239537519210497-cql_?utm_source=share&utm_medium=member_desktop

## (React) 15 excelentes repos de react

https://www.linkedin.com/posts/moelzanaty3_github-reactjs-learning-activity-7002190363880796160-NOZo?utm_source=share&utm_medium=member_desktop

15 GitHub repositories to become a React master (start learning now) 👇👇
\1. ReactJS https://lnkd.in/dwFxgkUA
\2. React-18-workshop https://lnkd.in/d-D4DV7C
\3. under-the-hood-reactjs https://lnkd.in/dHjsedRm
\4. react-developer-roadmap https://lnkd.in/dJc-5SnN
\5. react-in-patterns https://lnkd.in/dU7P5kHq
\6. 30-days-of-react https://lnkd.in/dtVtBsPh
\7. real-world-react-apps https://lnkd.in/dVQEygdV
\8. react-bits https://lnkd.in/dWMEFh2p
\9. react-redux-typescript-guide https://lnkd.in/dfNbTsyk
\10. awesome-react-components https://lnkd.in/dfveGCDW
\11. hocs https://lnkd.in/d-uHPqwa
\12. react-use https://lnkd.in/dPvm_s8r
\13. beautiful-react-hooks https://lnkd.in/dQTT_9Ug
\14. react-cheatsheets https://lnkd.in/dy7HYFBN
\15. react-hooks-cheatsheet https://lnkd.in/dHdmbjfu

⛳️ If you liked my content, make sure to:

🚨 Subscribe to my youtube channel - 🔗 https://bit.ly/mz-ut
🚨 Be one of your community at discord - 🔗 https://bit.ly/mz-discord


[#github](https://www.linkedin.com/feed/hashtag/?keywords=github&highlightedUpdateUrns=urn%3Ali%3Aactivity%3A7002190363880796160) [#reactjs](https://www.linkedin.com/feed/hashtag/?keywords=reactjs&highlightedUpdateUrns=urn%3Ali%3Aactivity%3A7002190363880796160) [#learning](https://www.linkedin.com/feed/hashtag/?keywords=learning&highlightedUpdateUrns=urn%3Ali%3Aactivity%3A7002190363880796160) [#react](https://www.linkedin.com/feed/hashtag/?keywords=react&highlightedUpdateUrns=urn%3Ali%3Aactivity%3A7002190363880796160) [#developer](https://www.linkedin.com/feed/hashtag/?keywords=developer&highlightedUpdateUrns=urn%3Ali%3Aactivity%3A7002190363880796160) [#moelzanaty3](https://www.linkedin.com/feed/hashtag/?keywords=moelzanaty3&highlightedUpdateUrns=urn%3Ali%3Aactivity%3A7002190363880796160) [#mohammedelzanaty](https://www.linkedin.com/feed/hashtag/?keywords=mohammedelzanaty&highlightedUpdateUrns=urn%3Ali%3Aactivity%3A7002190363880796160)



### (CSS, REACT, Next) Site sou junior

https://www.linkedin.com/posts/ana-saantos_soujunior-dev-frontend-activity-7001955362031439872-VbqT?utm_source=share&utm_medium=member_desktop

Excelente projeto com boa GUI



### Examplo Portifolio

https://www.linkedin.com/posts/azmine-toushik-wasi_github-projects-blogs-activity-7002128128118579200-Tqum?utm_source=share&utm_medium=member_desktop

### (Project DE) Datalake com dados do youtube

https://www.linkedin.com/posts/wesleyscesar_python-datalake-airflow-activity-7001894946903363585-_lOJ?utm_source=share&utm_medium=member_desktop

### (!) Conceitos de BI e DW

https://www.linkedin.com/posts/francisco--schmidt_modelodimensional-modelagem-modelagemdimensional-activity-7001895107180261376-AiAb?utm_source=share&utm_medium=member_desktop

Continuando a falar de Modelagem Dimensional, vou apresentar alguns termos que aparecem muito quando tocamos no assunto!

Termos comuns:

· Fato: É o dado central, é o tema que se quer analisar. Não existe modelo dimensional sem uma fato. Um processo de negócio na organização gera uma fato;
Exemplos: vendas, produção, faturas, viagens, impostos, contas a pagar, bugs etc.

· Dimensão: São os diversos pontos de vista sobre os quais se quer analisar o fato. Estão sempre relacionadas a uma ou mais fatos. Exemplos: tempo (obrigatória), cliente, produto, região, vendedor etc;

· Granularidade: É o nível de detalhamento em que a informação gerencial é armazenada. O nível de detalhamento deve ser o suficiente para atender todos os departamentos que vão usar a informação, porém o menor grão acarreta maior processamento e projeto mais complexo;

· Cubo: É uma das principais ferramentas para a visualização de dados em várias dimensões. Um cubo representa um fato, as dimensões ficam nos eixos verticais e horizontais e as medidas no centro. Nele podemos aumentar ou diminuir o nível de detalhe da informação, aplicar filtros, agrupar etc.;

· Medidas: São valores que serão analisados. Podem envolver cálculos complexos (indicadores). Ficam fisicamente nas fatos;

· SK (Surrogate Key): É uma “chave primária” por evento, que se faz necessária porque no modelo dimensional vamos ter redundância em alguns campos. Através da SK relacionamos a dimensão com a fato;

· Batch: Carga processada em intervalos (1 vez ao dia, 1 vez ao mês etc.). Um conjunto de processos para carregar um lote de dados em um intervalo de tempo específico;

· Streaming: Informação processada à medida que é produzida;

· Latência: É a diferença entre o tempo que o dado é produzido e o tempo que o dado está disponível para o usuário final. Influencia diretamente em arquitetura (servidores, redes etc.) e custos do projeto. Informações críticas precisam de baixa latência (exemplo: boletos fraudados);

· Staging: Armazenamento intermediário dos dados, após a extração e antes de transformar e carregar (ETL). Durante o processo de staging os dados não devem ser acessados pelos usuários.

Lições valiosas:

· Desnormalizar o máximo possível as dimensões;

· As métricas devem ficar nas fatos;

· O crescimento muito grande de uma dimensão prejudica a performance;

· Dimensões podem receber um atributo de validade indicando o período em que aquele dado estava válido. Pode ser através de um campo status (ativo, inativo) ou através de dois atributos (data de validade inicial e final). Isso facilita muito quando a dimensão é compartilhada entre fatos ou quando é necessário corrigir problemas de carga e bugs.

[#modelodimensional](https://www.linkedin.com/feed/hashtag/?keywords=modelodimensional&highlightedUpdateUrns=urn%3Ali%3Aactivity%3A7001895107180261376)
[#modelagem](https://www.linkedin.com/feed/hashtag/?keywords=modelagem&highlightedUpdateUrns=urn%3Ali%3Aactivity%3A7001895107180261376)
[#modelagemdimensional](https://www.linkedin.com/feed/hashtag/?keywords=modelagemdimensional&highlightedUpdateUrns=urn%3Ali%3Aactivity%3A7001895107180261376)
[#analisededados](https://www.linkedin.com/feed/hashtag/?keywords=analisededados&highlightedUpdateUrns=urn%3Ali%3Aactivity%3A7001895107180261376)

### Melhores análise de KPI para gestores Comerciais

https://www.linkedin.com/posts/leokarpa_an%C3%A1lises-comerciais-activity-7001912855386025984-0F6H?utm_source=share&utm_medium=member_desktop

### Repo dbt metrics

https://www.linkedin.com/posts/josephmachado1991_github-dbt-labsdbtmetrics-macros-for-activity-7001181381410062339-Z-yE?utm_source=share&utm_medium=member_desktop

### (!!) Portifolio de Ciência de Dados

https://www.linkedin.com/posts/bernardo8768_github-bernardisdatascienceprojects-activity-7001248927962292224-X1ko?utm_source=share&utm_medium=member_desktop

https://lnkd.in/dBvD8Apg

### Run Multiples ML-Algs once `lazypredict`

https://www.linkedin.com/posts/cyprien-cambus_datascience-python-machinelearning-activity-7000803011996303360-KPyz?utm_source=share&utm_medium=member_desktop

During a machine learning project, we often look to get the best possible results by trying multiple algorithms. 

This is extremely time consuming. 

Indeed, for each algorithm, we may have to load new libraries, declare a new object, re-train the model and store the results. 

The python library {lazypredict} allows to test a set of the most used algorithms in data science in one go! 

It's really useful, especially to have a first overview and to know which machine learning solution to turn to for further analysis.

Have a look at it 👉 https://lnkd.in/entssC6T

## DS Great Repos

https://www.linkedin.com/posts/activity-7001188622041325568-66cw?utm_source=share&utm_medium=member_desktop

🚀 Top 6 Github Repos to Learn Python and Data Science 👨‍💻

\1. Learn Python 3
By Jerry Pussinen
🌐 https://lnkd.in/eVbza36G

\2. All algorithms implemented in Python
By The Algorithms
🌐 https://lnkd.in/eEU8uNkZ

\3. Data Science Resources
By Jonathan Bower
🌐 https://lnkd.in/e8Qwnw_K

\4. Awesome Data Science
By Fatih Aktürk, Hüseyin Mert & Osman Ungur, Recep Erol
🌐 https://lnkd.in/e-Nj8iRJ

\5. Data Science Best Resources
By Tirthajyoti Sarkar
🌐 https://lnkd.in/eEgxBKqG

\6. Data Scientist Roadmap
By MrMimic
🌐 https://lnkd.in/e7fJ8p3Y

Tagging [W3Schools.com](https://www.linkedin.com/company/w3schools.com/) for best Content!!



### (Book) data quality

https://www.linkedin.com/posts/riyazahd_the-ultimate-guide-to-effective-data-collection-activity-7001489427768242176-ucMx?utm_source=share&utm_medium=member_desktop

### Jupyter IPywidget - Interatividade MUITO BOM

https://www.linkedin.com/posts/avi-chawla_python-datascience-jupyternotebook-activity-7001499142493495296-4aeM?utm_source=share&utm_medium=member_desktop

While using Jupyter, we often re-run the same cell repeatedly after changing the input slightly. This is time-consuming and also makes your data exploration tasks tedious and unorganized.

Instead, pivot towards building interactive controls in your notebook. This allows you to alter the inputs without needing to rewrite and re-run your code.

In Jupyter, you can do this using 𝐈𝐏𝐲𝐰𝐢𝐝𝐠𝐞𝐭𝐬. Embedding interactive controls is as simple as using a decorator.

As a result, it provides you with interactive controls such as dropdowns and sliders. This saves you from tons of repetitive coding and makes your notebook organized.

\--

Check out AlphaSignal (https://lnkd.in/dFs4-45J) to get a weekly summary of the top 1% Research papers, news, Repos, and Tweets in Machine Learning.





### Conceitos de Segurança

https://www.linkedin.com/posts/alexxubyte_systemdesign-coding-interviewtips-activity-7001221451047436288-E4GN?utm_source=share&utm_medium=member_desktop

Session, cookie, JWT, token, SSO, and OAuth 2.0 - what are they?

These terms are all related to user identity management. When you log into a website, you declare who you are (identification). Your identity is verified (authentication), and you are granted the necessary permissions (authorization). Many solutions have been proposed in the past, and the list keeps growing.

From simple to complex, here is my understanding of user identity management:

🔹WWW-Authenticate is the most basic method. You are asked for the username and password by the browser. As a result of the inability to control the login life cycle, it is seldom used today.
🔹A finer control over the login life cycle is session-cookie. The server maintains session storage, and the browser keeps the ID of the session. A cookie usually only works with browsers and is not mobile app friendly.
🔹To address the compatibility issue, the token can be used. The client sends the token to the server, and the server validates the token. The downside is that the token needs to be encrypted and decrypted, which may be time-consuming.
🔹JWT is a standard way of representing tokens. This information can be verified and trusted because it is digitally signed. Since JWT contains the signature, there is no need to save session information on the server side.
🔹By using SSO (single sign-on), you can sign on only once and log in to multiple websites. It uses CAS (central authentication service) to maintain cross-site information
🔹By using OAuth 2.0, you can authorize one website to access your information on another website

 👉 Over to you: nowadays, some website allows you to log in by scanning the QR code using your phone. Do you know how it works?

Make sure you subscribe to our weekly newsletter to learn more about QR code login: 
https://bit.ly/3FEGliw

### Linkedin Secrets

https://www.linkedin.com/posts/sam-browne_secrets-of-the-algorithm-v2-activity-7000898777217650688-Gt_3?utm_source=share&utm_medium=member_desktop

### Estudos para AWS

https://www.linkedin.com/posts/tuliocesarleite_estudos-aws-cloud-practitionerpdf-activity-7000957939461033984-OCr6?utm_source=share&utm_medium=member_desktop

Oi, pessoal! No sábado da semana passada (12/11) fui aprovado no exame AWS Cloud Practitioner (ainda estou bem feliz!!!). Hoje olhando para todo o conteúdo que estudei e agora desusado, me perguntei o que fazer com meus resumos e links de estudo, então, achei melhor compartilhar e quem sabe ajudar aquela pessoa que queira conquistar também a primeira certificação da AWS.

Segue o resumo que desenvolvi a partir da documentação da AWS, do guia do exame e de dois cursos (gratuito e pago):
https://lnkd.in/dkMxzGD4

O curso AWS Cloud Practitioner Essentials (Portuguese) é disponibilizado pela própria AWS Skill Builder, totalmente gratuito e desenvolvido em português por ótimos professores [Marilia Brito](https://www.linkedin.com/in/ACoAABPwsOAB7a97Mf7K7nK1v4K15NU-KyGsasg), [Bruno Lopes](https://www.linkedin.com/in/ACoAAAR3F8MBQEQhkllz6ZvnzKp8QvSIw_LymH0), [Henrique Ferreira](https://www.linkedin.com/in/ACoAAAxqS_EBKcHsar_7P2Lx1UPe_eOHmWlwvKw):
https://lnkd.in/d9ZPRXBD

Também há o simulado disponibilizado gratuitamente pela AWS:
https://lnkd.in/dQfwQ3-T

O segundo curso é o Certificação AWS Certified Cloud Practitioner: Exame 2022, foi adquirido na Udemy, desenvolvido pelo professor [Eduardo LARA](https://www.linkedin.com/in/ACoAAAcgLBIB42lEEK6JanrABd16MjZelBxn2T0), totalmente em português e com simulados:
https://lnkd.in/dczEFW69

Todas as questões da prova estão espalhadas pelo resumo que criei e o curso da AWS que citei, se não quiser não precisar comprar nada, só buscar o conhecimento por lá!

Precisando tirar qualquer dúvida, estou à disposição, não hesite em chamar.
Bons estudos!



### Book - BI e DA para gestão de negócio

https://www.linkedin.com/posts/rodrigoalbuquerquebus_businessintelligence-livros-analisededados-activity-7000954390261981184-xSEP?utm_source=share&utm_medium=member_desktop

### DataViz

https://www.linkedin.com/posts/mattmayo13_telling-a-great-data-story-a-visualization-activity-7000875330433425408-b5KI?utm_source=share&utm_medium=member_desktop

### (Book) Excleentes livros Baixe

https://www.linkedin.com/posts/andrew-jones-dsi_datascience-dataengineering-data-activity-7000850102915325952-oBpB?utm_source=share&utm_medium=member_desktop

💥 Data Science vs. Data Engineering 💥 Which do you want? I'll mail a copy anywhere in the world to someone in my network 🌎

How?

[1] Like this post to spread the word

[2] Let me know which book you'd most like in the comments below (and also what you're looking to learn from it)

I'll pick a lucky winner at random and then get it in the post to you!

You can choose from:

\- Fundamentals of Data Engineering (Reis, Housley)
\- Ace The Data Science Interview (Huo, Singh)

FYI - I'm doing this EACH WEEK until Christmas, check the pinned comment below for more info.

Love to you all - thanks for being part of my network - let's spread the love of learning all around the world!

### 30 projeto de Deep Learning

https://www.linkedin.com/posts/theravitshow_30-deep-learning-project-with-dataset-details-activity-7000837007887265793-nh8o?utm_source=share&utm_medium=member_desktop

### Como fazer bons Data pipelines

https://www.linkedin.com/posts/azevedo94_what-makes-a-good-data-pipelinea-pre-production-activity-7000818117740244993-q3XV?utm_source=share&utm_medium=member_desktop

### (!!) Freelance em DataScience

https://www.linkedin.com/posts/pradipnichite_freelancing-datascience-activity-6999612693791846400-7oRy?utm_source=share&utm_medium=member_desktop

### (English) Vania 2

LINKS ÚTEIS PARA APRENDER INGLÊS

Esses são os tópicos que os estudantes geralmente têm mais dificuldade. Salve os links para estudar e não cometer erros básicos na hora de usar essas estruturas importantes da língua:

\* Phrasal verbs: [lnkd.in/dkRNuzhj](http://lnkd.in/dkRNuzhj)

\* Preposições
\- Prepositions of time: [lnkd.in/d5ifQx_W](http://lnkd.in/d5ifQx_W)
\- Prepositions of place: [lnkd.in/dMGZwMW5](http://lnkd.in/dMGZwMW5)

\* Tempos verbais:
\- Present Simple: [lnkd.in/difrr-qs](http://lnkd.in/difrr-qs)
\- Present Continuous: [lnkd.in/dhjJNkXt](http://lnkd.in/dhjJNkXt)
\- Present Continuous for temporary situations and things happening now, Future arrangements: [lnkd.in/dk5j_s8M](http://lnkd.in/dk5j_s8M)
\- Present Perfect, Participles: [lnkd.in/dEHkdNCm](http://lnkd.in/dEHkdNCm)
\- Present Simple for future facts: [lnkd.in/dk-2xsXa](http://lnkd.in/dk-2xsXa)
\- Present Perfect: [lnkd.in/dXzjNenU](http://lnkd.in/dXzjNenU)
\- Past Simple and Present Perfect: [lnkd.in/dbeUxY3Z](http://lnkd.in/dbeUxY3Z)
\- Present Perfect Continuous: [lnkd.in/dfenChSf](http://lnkd.in/dfenChSf)
\- Habit in the Present and habit in the past: [lnkd.in/dzt92aKF](http://lnkd.in/dzt92aKF)
\- Present Perfect Simple and Present Perfect Continuous: [lnkd.in/dT5ZqSH9](http://lnkd.in/dT5ZqSH9)
\- Will, going to, Present Simple, Present Continuous for the future: [lnkd.in/dW9-9Fkb](http://lnkd.in/dW9-9Fkb)
\- Modals: present and perfect: [lnkd.in/d5TCME4Q](http://lnkd.in/d5TCME4Q)
\- Always for frequency + present continuous: [lnkd.in/dsiASjRf](http://lnkd.in/dsiASjRf)
\- Habit in the Present and the Past Participle: [lnkd.in/d-MDFFuj](http://lnkd.in/d-MDFFuj)
\- Present Perfect Simple and Present Perfect Continuous: [lnkd.in/dMaC6PEk](http://lnkd.in/dMaC6PEk)
\- Past Simple: [lnkd.in/dCY9VYDy](http://lnkd.in/dCY9VYDy)
\- Past Continuous: [lnkd.in/d5bYrVrf](http://lnkd.in/d5bYrVrf)
\- Past Perfect Simple: [lnkd.in/dnETBYuW](http://lnkd.in/dnETBYuW)
\- Past Simple and Past Continuous and Past Perfect: [lnkd.in/d85BNkuP](http://lnkd.in/d85BNkuP)
\- Past Perfect: [lnkd.in/dYpbsasX](http://lnkd.in/dYpbsasX)
\- Future Simple for future facts: [lnkd.in/db2REeUQ](http://lnkd.in/db2REeUQ)
\- Going to and will for predictions and future events and spontaneous decisions: [lnkd.in/dvxSm96w](http://lnkd.in/dvxSm96w)
\- Future Perfect: [lnkd.in/d-a3JuYP](http://lnkd.in/d-a3JuYP)
\- Future Continuous: [lnkd.in/dWHqrN_M](http://lnkd.in/dWHqrN_M)

\* Verbos irregulares:
\- Irregular plurals: [lnkd.in/dujDPNMm](http://lnkd.in/dujDPNMm)
\- Irregular Adverbs: [lnkd.in/dyXGm2wn](http://lnkd.in/dyXGm2wn)

\* Expressões idiomáticas: [lnkd.in/dUT-DZnQ](http://lnkd.in/dUT-DZnQ)

\* Números:
Numbers (cardinal/ordinal), Money: [lnkd.in/diyaJVTC](http://lnkd.in/diyaJVTC)
Large numbers: [lnkd.in/dcDAdcqf](http://lnkd.in/dcDAdcqf)


Aqui você encontra as principais diferenças entre o inglês britânico e americano, muita gente come bola nisso também > https://lnkd.in/eiXVSaUd

### (Exterior) sites

5 ferramentas para desbloquear sua Carreira Internacional usando tecnologia:

1 - JobSeer - ferramenta que analiza a % de match entre as vagas e o seu Resume. Ajuda muito a melhorar sua candidatura para conquistar a vaga que deseja.

2 - Google Interview WarmUp - que tal treinar entrevistas em inglês usando a IA do Google?

3 - Jobscan Resume Scanner - essa ferramenta passa um pente fino no seu resume mostrando como melhorá-lo nos padrões gringos.

4 - CoverBuild(.)io - fazer uma cover letter boa pode dar dor de cabeça. Esse app te ajuda com todo o processo.

5 - Huntr(.).co - ferramenta que cria um pipeline visual de todas as suas aplicações para que possa dar o seu melhor em cada uma delas.

Bora aprender a usar essas ferramentas e muitos hacks pra conseguir sua vaga lá fora?

Cola na nossa Masterclass ao vivo no dia 07/12 - https://leandrobpt.com.br/



### Fit CUltural

Como as empresas avaliam o “fit cultural”? | Ao conduzir entrevistas de emprego, as empresas não avaliam apenas se o candidato cumpre os requisitos técnicos e comportamentais da vaga. Elas também precisam verificar se ele se encaixa na cultura organizacional – ou seja, se há o chamado “fit cultural”. 

Para isso, podem ser feitas perguntas pouco ou nada relacionadas com o dia a dia do trabalho. A Fast Company listou algumas delas e deu dicas de como se sair bem ao respondê-las: 

🔎 “O que você gosta de fazer fora do trabalho?” Segundo a publicação, o ideal é falar sobre seu envolvimento em hobbies que agregam algum valor ao seu perfil, como voluntariado, caminhadas, atividades intelectuais (como aprender idiomas) e participação em esportes competitivos, por exemplo. 

🔎 “Qual o último livro que você leu?” Aqui, é bom ter uma boa opção de resposta para ficção e outra para não ficção, já que alguns recrutadores podem perguntar especificamente sobre essas categorias. Esteja pronto para dizer o nome dos autores, o tema, por que você os escolheu e que lição aprendeu com eles. 

🔎 “Quem é uma pessoa que inspira você e por quê?” A resposta não precisa envolver alguém famoso – na verdade, o ideal é evitar nomes muito clichês. Pode ser até alguém da sua família: o que importa é que a sua justificativa seja boa. “É uma boa ideia escolher alguém que tenha lhe ensinado uma lição moral ou de vida”, diz o texto. 

💬 Que outras perguntas de “fit cultural” você já respondeu em processos seletivos? 

Fonte: 
https://lnkd.in/gaxisn7g 





### (!) Como por expericnai em curriculo

https://www.linkedin.com/posts/anapaulavillegas_dica-para-cv-e-linkedin-activity-7000488212414541825-MDmw?utm_source=share&utm_medium=member_desktop

### (!) Porfifolio do github

https://www.linkedin.com/posts/natannael-icaro_github-activity-7000430153059188738-MXaE?utm_source=share&utm_medium=member_desktop

### REmover Outliers

https://www.linkedin.com/posts/odemir-depieri-jr_cienciadedados-activity-7000419691445796865-4LXC?utm_source=share&utm_medium=member_desktop



### (!!) GREAT CSS

https://www.linkedin.com/posts/activity-7000072278394695680-lhbk?utm_source=share&utm_medium=member_desktop



### DATA VIZ COLORS

https://www.linkedin.com/posts/data-science-dojo_bigdata-datascience-datavisualization-activity-6999840248415334400-3VAJ?utm_source=share&utm_medium=member_desktop

![Não foi fornecido texto alternativo para esta imagem](https://media-exp1.licdn.com/dms/image/C4D22AQE8WGUAbLEcEA/feedshare-shrink_800/0/1668891960773?e=1672272000&v=beta&t=S1tGdu5DbVn80Zhw_jxFKjNMklV7TS8QRxL_Qf8jk24)

### (Exteriir) linkedin notiicias



O que fazer se você travar na hora de falar inglês? | Muitos brasileiros têm medo de “travar” ao usar o idioma em uma entrevista de emprego ou apresentação. Como evitar que esse medo paralise você? 

🥶 Vários profissionais já compartilharam dicas no LinkedIn para situações como essas. No começo do ano, a professora de inglês [Tânia Carmonario](https://www.linkedin.com/in/ACoAAAl9qBYB44kVEvcAzB-DilelOsWldYPRfus) escreveu: “Travar e dar branco não são falhas no idioma, pois isso também acontece com a língua portuguesa. A gente também falha, erra, gagueja, esquece palavras… Ninguém fala inglês como nos filmes.” Por isso, uma boa dica para começar é tentar não se cobrar tanto. 

🥶 A coordenadora de marketing [Jéssica D.](https://www.linkedin.com/in/ACoAABNCozkBe3ICeLrG0zVlUpdaHK1l4NfKGx4) é a prova viva de que isso funciona e contou que seu inglês melhorou muito quando parou de “sentir medo de estar falando algo errado” e se permitiu se “comunicar com as pessoas e ver que elas entendiam”.

🥶 A professora de inglês [Carla D'Elia](https://www.linkedin.com/in/ACoAAAOj_9ABqOHV_zGwKnPXyYcAjfJvnChtr6Q) recomenda, além disso, encarar os “travamentos” com leveza e bom humor, se permitindo rir de si mesmo. Usar um "What was I saying?" (“o que eu estava dizendo?”) também pode ser muito útil. 

💬 E você, já travou ao falar em inglês? Como lidou com essa situação? 

Fontes:
https://lnkd.in/dfrrY3uP
https://lnkd.in/dEppbRJF 
https://lnkd.in/dy44uem5 



### Projetos de DS

https://www.linkedin.com/posts/neel-shah-553105178_python-data-datascience-activity-6999377633062895616-8zyD?utm_source=share&utm_medium=member_desktop

👨‍💻Machine learning Project 🎯

👉Project Credit : Aman Kharwal

1- Ukraine Russia War Twitter Sentiment Analysis
❄️ https://bit.ly/3tG9BQR

2- Stock Price Prediction
❄️ http://bit.ly/3tEfL43

3-Covid-19 Deaths Prediction
❄️ https://bit.ly/3gcgG8N

4- Product Demand Prediction
❄️ https://bit.ly/3ElBin2

5- Twitter Sentiment Analysis
❄️ http://bit.ly/3An3sfZ

Join Group : https://bit.ly/3hO3LKo

Image credit : [Medium](https://www.linkedin.com/company/medium-com/)

### (CheatSheet) Python DS e DA

https://www.linkedin.com/posts/arockialiborious_python-cheatsheet-activity-6999381601159688192-bRgB?utm_source=share&utm_medium=member_desktop

### Ultimate lnkeidn

https://www.linkedin.com/posts/nubcoder_linkedin-cheatsheet-activity-6999366707643322368-BOHj?utm_source=share&utm_medium=member_desktop

### (Project - DE) $$$ Processando dado do enem com pyspar

https://www.linkedin.com/posts/gabrielpedrosati_processando-dados-do-enem-com-pyspark-activity-6999338685808685056-E75r?utm_source=share&utm_medium=member_desktop

### (Book) SQL para analaise de dados

https://www.linkedin.com/posts/wilson-franquilino-55879a18a_chegou-meu-novo-companheiro-esse-eu-segui-activity-6999067081593810944-QkVm?utm_source=share&utm_medium=member_desktop

Indicaçâo do grupo de joao Oliveira

### (Vagas) Use o site da empresa ao invez do linkedin

https://www.linkedin.com/posts/priscilachaves-recruiter_carreiras-vagas-linkedin-activity-6998310082262302721-xKIb?utm_source=share&utm_medium=member_desktop

### (SPARK) Preparar para spark developer EXAM

https://www.linkedin.com/pulse/dicas-para-conseguir-certifica%C3%A7%C3%A3o-databricks-certified-karina-kato?lipi=urn%3Ali%3Apage%3Ad_flagship3_saved_items%3Br1Ay6J3oQf68yoP1%2F754wQ%3D%3D

Escrevi esse artigo compartilhando algumas dicas e a minha experiência para te ajudar, caso esteja planejando fazer o exame Spark Developer 3.0 do Databricks

### (PROJETO MENTORANDO JOÃO OLIVEIRA) Data Warehouse Olist

https://www.linkedin.com/posts/pedro-ribeiro257_python-sql-sqlserver-activity-6998751945398071296-nSi-?utm_source=share&utm_medium=member_desktop

Compartilhando mais um projeto para meu portfólio de análise de dados.

Neste projeto implemento dois banco de dados, um com abordagem relacional utilizando Python integrado ao SQL Server, e outro com uma modelagem multidimensional, criando um ETL com a ferramenta SQL Server Integration Services.
Faço então uma breve comparação entre os modelos.

Neste artigo detalho um pouco do projeto.

Link para o projeto completo: https://lnkd.in/dwxzagJw

[#python](https://www.linkedin.com/feed/hashtag/?keywords=python&highlightedUpdateUrns=urn%3Ali%3Aactivity%3A6998751945398071296) [#sql](https://www.linkedin.com/feed/hashtag/?keywords=sql&highlightedUpdateUrns=urn%3Ali%3Aactivity%3A6998751945398071296) [#sqlserver](https://www.linkedin.com/feed/hashtag/?keywords=sqlserver&highlightedUpdateUrns=urn%3Ali%3Aactivity%3A6998751945398071296) [#datawarehouse](https://www.linkedin.com/feed/hashtag/?keywords=datawarehouse&highlightedUpdateUrns=urn%3Ali%3Aactivity%3A6998751945398071296) [#dataengineer](https://www.linkedin.com/feed/hashtag/?keywords=dataengineer&highlightedUpdateUrns=urn%3Ali%3Aactivity%3A6998751945398071296) [#dataanalysis](https://www.linkedin.com/feed/hashtag/?keywords=dataanalysis&highlightedUpdateUrns=urn%3Ali%3Aactivity%3A6998751945398071296)

### (Book) Data Quality Fundamental O'Reilly



https://www.linkedin.com/posts/ravitjain_data-quality-fundamentals-activity-6998690848641060864-CkRz?utm_source=share&utm_medium=member_desktop

### (CheatSheet) DBT

https://www.linkedin.com/posts/ravitjain_data-quality-fundamentals-activity-6998690848641060864-CkRz?utm_source=share&utm_medium=member_desktop



### Python Cheat sheet

https://www.linkedin.com/posts/theravitshow_python-cheatsheet-activity-6998195353871147008-utmn?utm_source=share&utm_medium=member_desktop

### Galatic - REsumeir artigos ciencitficps

https://www.linkedin.com/posts/papers-with-code_machinelearning-deeplearning-ai-activity-6998315655317889024-hlSu?utm_source=share&utm_medium=member_desktop

### (Englihs) Vania - Erros em ingles

ERROS COMUNS EM INGLÊS

Se você ainda desliza nesses tópicos, veja o conteúdo dos links abaixo para não errar mais ao usar essas estruturas importantes:

\* Adjetivos com ED e adjetivos com ING: https://lnkd.in/etM5rYj9

\* Uso do verbo GET: https://lnkd.in/eHxjb4jr

\* Comparativo com adjetivos curtos: https://lnkd.in/e5zbaUQH

\* Diferença entre DO e MAKE: https://lnkd.in/egpkzjYQ

\* Diferença entre HAVE vs THERE IS/ARE: https://lnkd.in/ea4MvSc5

\* Diferença entre ME TOO e ME NEITHER: https://lnkd.in/eWYQGkyA

\* Diferença entre Other x Another: https://lnkd.in/eWcZjaUV

\* Diferença entre SAY, TALK e TELL: https://lnkd.in/e-dbHmKd

\* Diferença entre MAKE/EARN money: https://lnkd.in/e-frF2_D

\* Diferença entre WIN, GAIN e EARN: https://lnkd.in/epFGXEQN

\* Expressões idiomáticas: https://lnkd.in/e2bEmQTd

\* Falso cognatos: https://lnkd.in/e72_tK3p

\* IN, ON, AT: https://lnkd.in/eabkiUCW

\* Números: https://lnkd.in/eDuX9fqt

\* Present Perfect X Simple Past: https://lnkd.in/e-D-mSgj

\* Pronúncia: https://lnkd.in/e7Qge2Ki

\* Quando usar o verbo no ING (Stative Verbs): https://lnkd.in/e5sJiwxU
 
Por fim, confira esse rico material com uma coleção de erros comuns e o mais importante, como evitá-los: [lnkd.in/e3H6naR7](http://lnkd.in/e3H6naR7)

Gostou das dicas? Compartilhe e ajude a sua rede.

### Exterior- alguns sites

HOME OFFICE EM DÓLAR (US$) 🇺🇸

Visite estes sites gratuitos:

👉 [remoteok.com](http://remoteok.com/)

👉 [angel.co](http://angel.co/)

👉 [workingnomads.com/jobs](http://workingnomads.com/jobs)

👉 [remotive.com](http://remotive.com/)

👉 [himalayas.app](http://himalayas.app/)

### Project DA - Andre Yukio

https://www.linkedin.com/posts/felipegomesdsantos_an%C3%A1lise-de-dados-activity-6998320225460883456-ew2P?utm_source=share&utm_medium=member_desktop

Hoje, feriado, também é dia de colocar a mão na massa.
Fiz minha primeira análise de dados.
Simples, porém foi desafiadora. Utilizando jupyter notebook, importei algumas bibliotecas. A ideia foi verificar os Cursos que fiz este ano (Janeiro até o dia de hoje, 15 de Novembro). E a partir disso responder a duas questões:
1 - Quantos Cursos foram feitos?
2 - Total de carga horária

Era uma ideia que eu tinha, porém vendo o vídeo sobre Análise de Dados no canal de [Andre Yukio](https://www.linkedin.com/in/ACoAAAiRU0kBR7SZFh6V5CpPTQNUE3SWPC1FzPw), acreditei que era possível e topei me desafiar.
Claro, como primeira análise, não devo ter feito da melhor maneira, porém consegui. O resultado é possível conferir a partir do documento abaixo.

Quem quiser sugerir melhorias, fazer críticas construtivas, fiquem à vontade. E bom feriado!

### Prospectar cleinte de forma autoamatica no linkedin

https://www.linkedin.com/posts/yuribarbosagpires_powerbi-powerquery-data-activity-6998326265413812224-l1lU?utm_source=share&utm_medium=member_desktop

### Estudar Para DE

https://www.linkedin.com/posts/rodrigo-santana-ferreira-0ab041128_machinelearning-dataengineering-datascience-activity-6998303621163458560-jj_b?utm_source=share&utm_medium=member_desktop

Como estudar Engenharia ou Ciência de Dados?🧐

Independente da sua escolha, é importante ter em mente que você precisará se dedicar bastante.

Não basta só fazer cursos. Na verdade, isso importa quase nada.
Você precisará praticar com projetos para criar portfólio.

Pensando em Engenharia de Dados a gente ver por aí, tecnologias como:

\- Spark, SQL, Python.
\- AWS, Azure, GCP.
\- Airbyte, Airflow, dbt, Terraform, Git, Github.
\- Data Warehouses, ETL, ELT, Kubernets, (DevOps?) e etc.
\- ….

Pensando em Ciência de Dados, vemos:
\- Python, Pyspark, Machine Learning, Deep Learning
\- AWS, Azure, GCP
\- Pycaret, Power BI, Plotly, APis, FastAPi, Deploy de Modelos e etc.
\- …
Mas a grande questão é: “São muitas tecnologias, quais eu devo priorizar?”

Sim, são muitas tecnologias mesmo.

O quanto antes você lidar melhor com isso, melhor.

O segredo é priorizar as tecnologias certas.

Isso é muito importante e pode mudar tudo!

Priorizar as tecnologias certas vai encurtar muito a sua jornada!

E se você pudesse estudar tudo isso em um único lugar?

Em uma plataforma feita por quem está realmente no mercado?

Bom, se isso faz sentido para você, aproveite a Black Friday da Stack Academy.

A promoção só vai ficar disponível por um dia, nesta quinta-feira.

O link para você se inscrever e receber exatamente sobre como vai funcionar está no primeiro comentário.

Eu vejo vocês por lá ;)



### Repo com o Básico de PyTorch

https://www.linkedin.com/posts/amanda-araujo-de-alvarenga_github-amanda-aapytorch-basics-activity-6998004909421805568-g4Jk?utm_source=share&utm_medium=member_desktop



### Importar Tabelas com ctrl+c e v direto como dataframe pandas e asism economiza

https://www.linkedin.com/posts/giannis-tolios_datascience-python-machinelearning-activity-6997264179590008832-rxvb?utm_source=share&utm_medium=member_desktop



### Linkeidn dica

A lot of people on LinkedIn ask me to look at their resumes.
Here are the top 3 common resume mistakes that I have seen:

1)  What are you all about?
Include a summary section on the top of your resume. This is a place for you to summarize your career, highlight your achievements, and share what type of opportunities you’re looking for.

This allows the reader to quickly understand who you are, what makes you qualified, and what you’re looking for.

2)  What are your results?
Make sure all your resume bullets contain a quantifiable accomplishment. Also, what was the impact of this accomplishment?

Don’t just say: Reached out to suppliers for data.

Instead: Reached out to 25 suppliers and conducted introductory meetings with them to request parts forecasting data. Received data for 500 parts to add to company database.

3)  What’s your most important section?
Put the most important section on top and the least important section on the bottom.

Ask yourself: Does the reader value my work experience, my projects, or my skills more? Then, put it in the relevant order.

What are your top resume tips? Share in the comments below!  



### (!) Modelo de carta de apresnetaça

Alguém online no Linkedin em pleno final de semana?
Hoje estou disponibilizando gratuitamente alguns modelos de Carta de Apresentação para envio aos recrutadores e empresas, juntamente com o currículo, pois grande parte dos currículos que chegam sem uma apresentação, são descartados de cara na triagem inicial.

A ideia é editar o documento com as suas informações e enviar a apresentação no corpo do e-mail.

Faça o download abaixo para ter acesso ao documento, por meio do link: https://lnkd.in/dpCZfjbv

Também fiz a inclusão de vários cursos de qualificação bem interessantes nesse PDF, para dar um upgrade no currículo. Vale a pena conferir!

Compartilhem e marquem seus amigos nos comentários, para que eles também saibam dessa novidade.

Sucesso!

[#currículo](https://www.linkedin.com/feed/hashtag/?keywords=currículo&highlightedUpdateUrns=urn%3Ali%3Aactivity%3A6997124638937919489) [#linkedin](https://www.linkedin.com/feed/hashtag/?keywords=linkedin&highlightedUpdateUrns=urn%3Ali%3Aactivity%3A6997124638937919489) [#recrutadores](https://www.linkedin.com/feed/hashtag/?keywords=recrutadores&highlightedUpdateUrns=urn%3Ali%3Aactivity%3A6997124638937919489) [#empresas](https://www.linkedin.com/feed/hashtag/?keywords=empresas&highlightedUpdateUrns=urn%3Ali%3Aactivity%3A6997124638937919489) [#repassando](https://www.linkedin.com/feed/hashtag/?keywords=repassando&highlightedUpdateUrns=urn%3Ali%3Aactivity%3A6997124638937919489) [#sucesso](https://www.linkedin.com/feed/hashtag/?keywords=sucesso&highlightedUpdateUrns=urn%3Ali%3Aactivity%3A6997124638937919489) [#oportunidade](https://www.linkedin.com/feed/hashtag/?keywords=oportunidade&highlightedUpdateUrns=urn%3Ali%3Aactivity%3A6997124638937919489) [#vagas](https://www.linkedin.com/feed/hashtag/?keywords=vagas&highlightedUpdateUrns=urn%3Ali%3Aactivity%3A6997124638937919489)



### (!) Excel shortcuts

https://www.linkedin.com/posts/jesus-fajardo_excel-formulas-cheat-sheet-activity-6997210008518094849-ZNeE?utm_source=share&utm_medium=member_desktop



### (Project DE) Aluno de Fernando Amaral

https://www.linkedin.com/posts/elcom-junior_github-elcomjdataengineerproject02-activity-6994384137306423296-2e6X?utm_source=share&utm_medium=member_desktop

Boa tarde, tudo bem ?

Venho compartilhar o meu repositório no github a partir do Projeto Final 02 do curso Formação Engenharia de Dados 2022 do [Fernando Amaral](https://www.linkedin.com/in/ACoAAALMH7YBBB9u7eWhPUbW6VPzhXgmENw55Ec), aonde o objetivo é realizar aquisição de dados em tempo real (Streaming) a partir de sensores em uma turbina eólica.

A cloud utilizada é a AWS para realizar desde a captura dos dados a partir do Kinesis Data Stream, até a catalogação deles e consulta utilizando o Athena.



### (CheatSheet) DataScience e Statistics

https://www.linkedin.com/posts/imarpit_data-science-statistics-cheatsheet-activity-6997026215832244224-SbTr?utm_source=share&utm_medium=member_desktop



### (Books) Diversos livvros apra engenhiro de dados

https://learning.oreilly.com/playlists/0e6cc4bc-9ef6-4c85-8a7e-99c0ca508dcf/


book**BOOK**

[Data Quality Fundamentals](https://learning.oreilly.com/library/view/data-quality-fundamentals/9781098112035/)

By Barr Moses, Lior Gavish and Molly Vorwerck

![img](https://learning.oreilly.com/library/cover/0321125215/)

book**BOOK**

[Domain-Driven Design: Tackling Complexity in the Heart of Software](https://learning.oreilly.com/library/view/domain-driven-design-tackling/0321125215/)

By Eric Evans

![img](https://learning.oreilly.com/library/cover/9781098133283/)

book**BOOK**

[Fundamentals of Data Observability](https://learning.oreilly.com/library/view/fundamentals-of-data/9781098133283/)

By Andy Petrella

![img](https://learning.oreilly.com/library/cover/9781492098348/)

book**BOOK**

[Cloud FinOps, 2nd Edition](https://learning.oreilly.com/library/view/cloud-finops-2nd/9781492098348/)

By J.R. Storment and Mike Fuller

![img](https://learning.oreilly.com/library/cover/9781492092384/)

book**BOOK**

[Data Mesh](https://learning.oreilly.com/library/view/data-mesh/9781492092384/)

By Zhamak Dehghani



### (Vaga/Entrevista) COmo responder quais sâo os meus pontos fracos

https://www.linkedin.com/posts/eduardomfelix_carreiras-rh-activity-6996949205680295936-czZ0?utm_source=share&utm_medium=member_desktop

Aprenda a responder na prática as perguntas consideradas mais difíceis de responder nas entrevistas de emprego.

[#carreiras](https://www.linkedin.com/feed/hashtag/?keywords=carreiras&highlightedUpdateUrns=urn%3Ali%3Aactivity%3A6996949205680295936) [#rh](https://www.linkedin.com/feed/hashtag/?keywords=rh&highlightedUpdateUrns=urn%3Ali%3Aactivity%3A6996949205680295936)



### (!) ROC e AUC Explicados

https://www.linkedin.com/posts/mlikoga_datascience-machinelearning-activity-6996859200198840320-ylEm?utm_source=share&utm_medium=member_desktop

O que raios é ROC AUC??

Essa foi minha pergunta quando vi pela primeira vez. Mesmo sendo uma métrica super usada, eu nunca tinha ouvido falar nela antes.

Fui estudar, vi o (excelente) vídeo do [StatQuest](https://www.linkedin.com/company/statquest/) e finalmente entendi! É uma ótima métrica para comparar modelos de classificação, e entender todo universo de thresholds possíveis (antes eu só usava threshold 0.5 e pronto rs).

ROC (receiver operating characteristic) é o nome da curva, que é o gráfico de recall x false positive rate, e cada ponto na curva é um threshold possível, ou seja, uma opção de uso do modelo dentro de todo universo de opções! Já AUC é simplesmente "area under the curve", é um número para resumir o gráfico. Aqui no Nubank, trabalhando com fraude que é um caso bem desbalanceado, normalmente acabo usando mais uma métrica similar, PR AUC, que é a área da curva precision-recall.

Obrigado [Joshua Starmer PhD](https://www.linkedin.com/in/ACoAACAd8VYBqvN-leU7VPrO93tKYbEfzhAFOgY) pela explicação! E vocês, também já usaram StatQuest para aprender alguma coisa?

[#datascience](https://www.linkedin.com/feed/hashtag/?keywords=datascience&highlightedUpdateUrns=urn%3Ali%3Aactivity%3A6996859200198840320) [#machinelearning](https://www.linkedin.com/feed/hashtag/?keywords=machinelearning&highlightedUpdateUrns=urn%3Ali%3Aactivity%3A6996859200198840320)

### (!) Freelancer de Data Science

https://www.linkedin.com/posts/pradipnichite_freelancing-datascience-datasciencefreelancing-activity-6996824930117906433-sqPn?utm_source=share&utm_medium=member_desktop



### Grande dica para aprender a fazer alguma coisa

https://www.linkedin.com/posts/darshil-parmar_dataengineering-dataengineer-learning-activity-6997101462988181504-_q2L?utm_source=share&utm_medium=member_desktop

👨🏻‍💻 Reasons you are not able to learn Data Engineering or new skills


\1. You spend your time watching content that sells dreams (5LPA to 50LPA)

Nothing wrong with watching someone else's story but in the end, you need to sit in front of your computer and learn new things.

👉🏻 STOP WASTING TIME AND CREATE YOUR OWN STORY!!! 👈🏻

\2. You are focusing on the end goal

"I have to learn so many different skills to become a data engineer"

🚶🏻‍♂️ Start small, and set small goals, it's a long journey

You can't finish everything in a few weeks or 1-2 months!

🥷🏻 Patience is the key here

\3. Lack of routine
👨🏻‍💻 I have created a daily 2 hours routine to learn something new.

It can be learning from Courses/Blogs/Videos etc...

❌ Every day you need to turn off your phone, TV, or whatever you do to distract yourself and focus on learning

Everything around you is built to distract you, it's on you to manage it!

Either you can waste your time or learn something that will help you in the long run.

Delayed Gratification > Short-Term Gratification

I do watch TV shows, Standup videos, and other things but I have allotted time for it!

✅ The only thing you can control is your MIND, don't let it run YOU!!

I also have a detailed video on how I learn new things and build my routine!

I have added a link to that video in the comment section 👇

[#dataengineering](https://www.linkedin.com/feed/hashtag/?keywords=dataengineering&highlightedUpdateUrns=urn%3Ali%3Aactivity%3A6997101462988181504) [#dataengineer](https://www.linkedin.com/feed/hashtag/?keywords=dataengineer&highlightedUpdateUrns=urn%3Ali%3Aactivity%3A6997101462988181504) [#learning](https://www.linkedin.com/feed/hashtag/?keywords=learning&highlightedUpdateUrns=urn%3Ali%3Aactivity%3A6997101462988181504)



### Daniel Scoot - ENtrevista de Emprego

Aproximadamente 90% da sua carreira se resume à sua habilidade de passar por entrevistas. Geralmente quando somos jovens, somos péssimos nisso. Mas muita gente mais velha acaba tendo essa dificuldade.

Quer ter sucesso na carreira? Domine a arte de ser entrevistado! Aqui vão algumas dicas:

1 - Use roupas apropriadas. Calça jeans e camiseta não é uma boa pedida. Na dúvida, jogue no Google modelos de roupas para se usar em entrevistas para o seu mercado.

2 - Não evite suas fraquezas. Entrevistadores geralmente não se importam com o que você é fraco, eles querem ver se você é honesto sobre isso.

3 - Não seja pego desprevenido. Prepare-se sempre para possíveis perguntas e desafios. Tenha as respostas na cabeça.

4 - Nunca vá embora sem fazer uma pergunta quando o entrevistador mandar um "você tem alguma pergunta para nós?". Pense em algo relevante, como oportunidades de carreiras, quais serão as metas para os próximos 90 dias, programas de treinamento, etc.

5 - Conte histórias. Compartilhar suas habilidades é importante, mas pessoas se conectam a histórias. Conte sobre desafios pelos quais você passou, como superou, o que aprendeu com isso e quais resultados foram gerados.

6 - Não reclame das coisas. Ninguém gosta de gente pessimista e negativa.

7 - Não apreça um robô que decorou tudo. Dê respostas personalizadas para a empresa em questão, não respostas gerais.

8 - Se possível, leve um caderno para anotações com você e tome notas. faz você parecer mais profissional e organizado. Empresas gostam de profissionais assim.

Faz sentido essas dicas? O que mais você sugere para uma boa entrevista?



### (!!!!) O que por de projetos

https://www.linkedin.com/posts/andreyukio_machinelearning-cienciadedados-analisededados-activity-6996800059359023104-eYkl?utm_source=share&utm_medium=member_desktop

Como vários cientistas e analistas de dados mais experientes já disseram nesta rede, portfólio é muito mais valioso do que qualquer certificação/diploma. Colocar a mão na massa é o que faz um profissional de dados se sobressair, não é uma área em que estudar de forma passiva funcione bem.

Bom, como muitos me contam que possuem dificuldades em saber o que fazer para um portfólio, vamos a algumas dicas.

Primeiro, o que pode ser utilizado como portfólio:

\- ARTIGOS MEDIUM: Tutoriais de ferramentas como Python ou SQL, explicações mais técnicas de Machine Learning e Estatística, tudo isso é válido como portfólio. Inclusive, ter um Medium ajuda a demonstrar sua habilidade em storytelling;

\- REPOSITÓRIOS GITHUB: Melhor ainda que o Medium é ter projetos no Github. Não importa muito qual o tipo de projeto, desde que tenha algum capricho e envolva dados. Pode ser um webapp, uma análise exploratória bem robusta, um modelo preditivo, vale tudo. Não deixe de incluir um readme, o gestor da vaga não vai conseguir se localizar se só tiver um monte de códigos jogados.

Agora, essas duas coisas já existem aos montes por aí, é o básico. Para se sobressair, é interessante ter projetos mais completos, mais extensos. Se possível, seria bacana usar dados reais e temas que não foram tão explorados. Faltam ideias? Não mais, olhe algumas propostas bem simples para iniciantes na área:

\- Criar uma calculadora de IMC, TMB e outras métricas relacionadas ao corpo, aproveitando o hype fitness. Utilize Python Orientado a Objetos e suba num Streamlit.

\- Qual a relação de idade x vitórias de um clube de futebol? Responda essa pergunta com algumas estatísticas descritivas e uma boa análise exploratória que já vai impressionar muita gente.
\- Explore a relação entre as notas de plataformas como imdb e rotten tomatoes com as premiações do cinema/tv.
\- Como tem evoluído a diversidade dos políticos brasileiros? Será que você consegue criar um dashboard legal para que as pessoas consigam enxergar isso sob diversas perspectivas?
\- Qual o perfil dos religiosos no Brasil? Existem alguns censos feitos pela igreja católica, que tal desvendar mais dessa população?
\- Como tem evoluído a diversidade dos alunos das universidades públicas?
\- Onde são gastos o dinheiro dos impostos? Por que não abrir as contas públicas de uma forma bem didática para as pessoas?

Se conseguir subir o trabalho como um dashboard/webapp público, melhor ainda! Apenas não deixe de compartilhar e dar uma ideia do que foi feito e descoberto.

ATENÇÃO: Tenha cuidado com as opiniões pessoais, não ofenda ninguém. Não é sobre "ser isentão" ou omisso, é sobre fazer um trabalho que venha para agregar e não para fechar portas. Também vale o cuidado nas conclusões, cautela com o uso de termos referentes à causalidade, você provavelmente não tem um estudo criterioso o bastante para afirmar isso.

Bora trabalhar nesse portfólio e arrumar uma vaguinha em dados?🚀🚀🚀🚀



### APrender cosia da ára de dados

[#dataengineering](https://www.linkedin.com/feed/hashtag/?keywords=dataengineering&highlightedUpdateUrns=urn%3Ali%3Aactivity%3A6996681376997552128) is so much in demand.

Learn directly from the great content creators on [LinkedIn](https://www.linkedin.com/company/linkedin/) for free here...........

\1. sql
[Ankit Bansal](https://www.linkedin.com/in/ACoAAAPUXxoBdtZMZyb3jcEbh5OSmGce4e-RxEg)
[Sumit Mittal](https://www.linkedin.com/in/ACoAACJzMI4BTUqzEvB3xp7WB5b8cubanufc6fc)
[Danny Ma](https://www.linkedin.com/in/ACoAAAXbuuABxtrJYX833gq699JJJc5JjvfdOfo)

\2. dataengineering/bigdata
[Sumit Mittal](https://www.linkedin.com/in/ACoAACJzMI4BTUqzEvB3xp7WB5b8cubanufc6fc)
[Zach Wilson](https://www.linkedin.com/in/ACoAABPHqmcB2FuAuIzZ2LerHRr3Hlr7tUL8-e8)
[Shashank Mishra 🇮🇳](https://www.linkedin.com/in/ACoAAB2keNIBLzdHc63tszwqdD4m4W0ZNlpL6yE)
[Benjamin Rogojan](https://www.linkedin.com/in/ACoAAA3roGYByurxK9YsOLOqN2Mn748HOZhjuSE)
[Suraz G.](https://www.linkedin.com/in/ACoAABs5_20BU7ZYtWAnGnazD4wfxO_zvmxMtHY)
[Andreas Kretz](https://www.linkedin.com/in/ACoAAB056RoBumZOcY6lX3Pr53FhAwqKn90f53Y)
[POOJA JAIN](https://www.linkedin.com/in/ACoAABq7pjQBkinp8oz1qssB7WY7_YpspFME9sM)

3.1 . azure cloud
[Deepak Goyal](https://www.linkedin.com/in/ACoAAANjjbwBqmZxYq0aHLAt8i6w3x6kfqE1UFM)

3.2 AWS cloud
MAYANK Pandey

\4. Dsa/algo
[Kunal Kushwaha](https://www.linkedin.com/in/ACoAACijSzsBjAxeQL-RXs9RRjITPsrzSQpLU-Q)
[GeeksforGeeks](https://www.linkedin.com/company/geeksforgeeks/)
[Nishant Chahar](https://www.linkedin.com/in/ACoAAClor3cBTUD2rwBWf_KvA74lZjZG_BB4_jQ)
[Love Babbar](https://www.linkedin.com/in/ACoAABJ_jhoBvyGG2L1SovqOM92B8Fj9BXRYE_I)

\5. projects
[Dhaval Patel](https://www.linkedin.com/in/ACoAAAHeAToBefXXCt3hf_hHmb_-yy7lz8bBNns)
[Darshil Parmar](https://www.linkedin.com/in/ACoAAB5QzkIB7H3vliuE1puA21D60J9uTPkTMpw)
[ProjectPro](https://www.linkedin.com/company/goprojectpro/)

\6. Orchestration:
[Marc Lamberti](https://www.linkedin.com/in/ACoAAA0Bh60BjdsGZtwdwQdYp92Lw8mPHDMMI8g)

They are best resources according to my experience. follow them🤞

do comment your favourite content creator in [#comments](https://www.linkedin.com/feed/hashtag/?keywords=comments&highlightedUpdateUrns=urn%3Ali%3Aactivity%3A6996681376997552128) 👇

hope this helpful everyone who are keen join bigdata.

keep learning💯

do follow [Ajay Kadiyala](https://www.linkedin.com/in/ACoAACMqY_UBKQi4wg8LG5QtUPu56SUEChkue1g) ✅

[#dataengineering](https://www.linkedin.com/feed/hashtag/?keywords=dataengineering&highlightedUpdateUrns=urn%3Ali%3Aactivity%3A6996681376997552128) [#demand](https://www.linkedin.com/feed/hashtag/?keywords=demand&highlightedUpdateUrns=urn%3Ali%3Aactivity%3A6996681376997552128) [#skills](https://www.linkedin.com/feed/hashtag/?keywords=skills&highlightedUpdateUrns=urn%3Ali%3Aactivity%3A6996681376997552128) [#contentcreators](https://www.linkedin.com/feed/hashtag/?keywords=contentcreators&highlightedUpdateUrns=urn%3Ali%3Aactivity%3A6996681376997552128) [#jobangebot](https://www.linkedin.com/feed/hashtag/?keywords=jobangebot&highlightedUpdateUrns=urn%3Ali%3Aactivity%3A6996681376997552128)

Visualizar tradução



### (Exterior) Book para se preparar para vagas internacionais

https://www.linkedin.com/posts/thalitasimon_voc%C3%AA-est%C3%A1-se-preparando-para-entrevistas-activity-6988474398726893568-IMAl?utm_source=share&utm_medium=member_desktop