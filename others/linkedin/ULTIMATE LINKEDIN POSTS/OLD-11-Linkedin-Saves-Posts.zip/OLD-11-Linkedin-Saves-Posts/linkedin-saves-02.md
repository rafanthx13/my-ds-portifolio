# Linkedin Saves - 10/11/2022


De tempos em tempos devo acessar o linkedin save e anotar tanto aqui quanto no caderno as melhores coisas.

Se forem muito grande anoto aqui. Se forem pequenas anoto aqui e no caderno.

IMPORTANTE: após preencher o forms os convites só chegam em Dezembro quando encerram as inscrições.

## Index
+ [Linkedin Saves - 10/11/2022](#linkedin-saves---10/11/2022)
  - [Index](#index)
  - [Página de PBI](#página-de-pbi)
    * [(!) Fórumla do google sheet que pega direto na página Web](#(!)-fórumla-do-google-sheet-que-pega-direto-na-página-web)
    * [(POST EXAMPLE - DE) Projeto dbt](#(post-example---de)-projeto-dbt)
    * [(POST EXAMPLE - DS) - Previzão de vendas](#(post-example---ds)---previzão-de-vendas)
    * [(!) Livro de Python Feature Engineering](#(!)-livro-de-python-feature-engineering)
    * [(VSCODE Extension - Turbo Console Log](#(vscode-extension---turbo-console-log)
    * [(!!) 5 Top DE Projects (Darshill Parmar Denovo)](#(!!)-5-top-de-projects-(darshill-parmar-denovo))
    * [Jupyter Notebook em aplicação stand-alone](#jupyter-notebook-em-aplicação-stand-alone)
    * [(CompVision) Ira Bar - Guy atrás de Computer Vision](#(compvision)-ira-bar---guy-atrás-de-computer-vision)
    * [(CompVision) - 5 Great COmpVision Projects](#(compvision)---5-great-compvision-projects)
    * [(CompVision) - Great Repo](#(compvision)---great-repo)
    * [(CompVision) - Corretor automático de provas](#(compvision)---corretor-automático-de-provas)
    * [Como ganhar em Dolar](#como-ganhar-em-dolar)
    * [Linkedin Secrets of THe Algorithm](#linkedin-secrets-of-the-algorithm)
    * [( Entrevista) - "O que vocÊ se se daqui a 5 anos?](#(entrevista-de-emprego---vaga)---"o-que-você-se-se-daqui-a-5-anos?)
    * [Quais os principais problemas que o SPark Resolve](#quais-os-principais-problemas-que-o-spark-resolve)
    * [(Example Post - DS ) - ML NBA MVP Prevision](#(example-post---ds-)---ml-nba-mvp-prevision)
    * [(Estatística) - p-value no teste A/B](#(estatística)---p-value-no-teste-a/b)
    * [30 dicas para melhorar código python](#30-dicas-para-melhorar-código-python)
    * [(Download) Study Guide Data Manipulation](#(download)-study-guide-data-manipulation)
    * [(!!!) Como fazer e publicar um projeto de DS/DE/DA/BI](#(!!!)-como-fazer-e-publicar-um-projeto-de-ds/de/da/bi)
    * [(Download) ML cheat sheet](#(download)-ml-cheat-sheet)
    * [Porque sair da Europa](#porque-sair-da-europa)
    * [(Example Project - DA/BI)](#(example-project---da/bi))
    * [Pratica do Ingles](#pratica-do-ingles)
    * [(Example of Project DS) - Odemir](#(example-of-project-ds)---odemir)
    * [Videos das carreiras mais promissoras para 2023](#videos-das-carreiras-mais-promissoras-para-2023)
    * [As leis fundamentais para escrevre código na área de dados](#as-leis-fundamentais-para-escrevre-código-na-área-de-dados)
    * [Python - Printar nome da variável](#python---printar-nome-da-variável)
    * [(!) Cursos gratuiros da Amazon](#(!)-cursos-gratuiros-da-amazon)
    * [Keep Track State of Art Machine and Deep Learning](#keep-track-state-of-art-machine-and-deep-learning)
    * [POrque o Airflow é muito usado](#porque-o-airflow-é-muito-usado)
    * [(Download) Guida de Data Warehouse](#(download)-guida-de-data-warehouse)
    * [Data Eng](#data-eng)
    * [dbt lançous mais 2 cursos gratuitos](#dbt-lançous-mais-2-cursos-gratuitos)
    * [(!!) Awesome Data Engineering](#(!!)-awesome-data-engineering)
    * [(!) (Example of Project) Projeto DS/DE do zero](#(!)-(example-of-project)-projeto-ds/de-do-zero)
    * [Aprender Spark de Graça](#aprender-spark-de-graça)
    * [(Example of Project - DS)](#(example-of-project---ds))
    * [(Example Of Project - DE) - Track tweets](#(example-of-project---de)---track-tweets)
    * [Orquestrando pipelines spark com airflow](#orquestrando-pipelines-spark-com-airflow)
    * [Post Radnom](#post-radnom)
    * [(!) Livro: COmo trabalhar com dados desbalanceados](#(!)-livro:-como-trabalhar-com-dados-desbalanceados)
    * [(Example Of Project - DevOps DE)](#(example-of-project---devops-de))
    * [(!) Template of DE PROJECT](#(!)-template-of-de-project)
    * [PORQUE VAI SER IMPOSSIVEL EU ENTRAR EM DS](#porque-vai-ser-impossivel-eu-entrar-em-ds)
    * [Dica de livro de data cleaning](#dica-de-livro-de-data-cleaning)
    * [(!!!) CMO ESTUDAR INGLES SOZINHO](#(!!!)-cmo-estudar-ingles-sozinho)
    * [(Download) ML Cheat sheet](#(download)-ml-cheat-sheet)
    * [Terraform](#terraform)
    * [(EXTERIOR) O que nâo dizer na entrevista](#(exterior)-o-que-nâo-dizer-na-entrevista)
    * [Modern Data Stack](#modern-data-stack)


## Página de PBI

+ People Analytics - RH (Grande ideia)
  - https://www.linkedin.com/feed/update/urn:li:activity:6996302131150381056

+ De alunode Karpinsky
  - https://www.linkedin.com/feed/update/urn:li:activity:6995786012350136320

+ Nike - Datset achado na kaggle
  - https://www.linkedin.com/feed/update/urn:li:activity:6996101552285351936

+ Eleições
  - https://www.linkedin.com/feed/update/urn:li:activity:6992161901044486144

+ Desafios de Dash (5 de 100)
  - https://www.linkedin.com/feed/update/urn:li:activity:6995007030843330560

+ Vídeo - Dicas de ideias de layout para dashboards
  - https://www.linkedin.com/feed/update/urn:li:activity:6993326641334636544

+ Análise dos próprios gastos pessoais
  - https://www.linkedin.com/feed/update/urn:li:activity:6993173255708684288

+ Outro Dash
  - https://www.linkedin.com/feed/update/urn:li:activity:6992958457263886337?updateEntityUrn=urn%3Ali%3Afs_feedUpdate%3A%28V2%2Curn%3Ali%3Aactivity%3A6992958457263886337%29

### (!) Fórmula do google sheet que pega direto na página Web

Essa fórmula faz evitar fazer muito web-scraping. Permitindo assim criar um dataset rapidamente

https://www.linkedin.com/feed/update/urn:li:activity:6996324102575726592?updateEntityUrn=urn%3Ali%3Afs_feedUpdate%3A%28V2%2Curn%3Ali%3Aactivity%3A6996324102575726592%29

### (POST EXAMPLE - DE) Projeto dbt

https://www.linkedin.com/feed/update/urn:li:activity:6996219657628073984?updateEntityUrn=urn%3Ali%3Afs_feedUpdate%3A%28V2%2Curn%3Ali%3Aactivity%3A6996219657628073984%29

Montei um pipeline de dados utilizando o dbt como ferramenta de transformação.
- Python: Ingestão de dados para o Amazon S3
- Leitura de dados do S3 pelo Redshift via COPY.
- Conectei Dbt com o DW Redshift como source e estou criando alguns modelos de dados.
https://lnkd.in/dG9RraUE


### (POST EXAMPLE - DS) - Previsão de vendas

https://www.linkedin.com/feed/update/urn:li:activity:6996243570265329664?updateEntityUrn=urn%3Ali%3Afs_feedUpdate%3A%28V2%2Curn%3Ali%3Aactivity%3A6996243570265329664%29

Finalizei mais um projeto de Ciência de Dados!

Desta vez desenvolvi uma solução de previsão de vendas para a rede de drogarias europeia Rossmann, a fim otimizar a alocação de recursos para reforma das filiais.

O algoritmo de regressão supervisionado utilizado foi o XGBoost que apresentou excelentes resultados nas predições.

Fiz o deploy do modelo no Heroku e as previsões de vendas podem ser acessadas por qualquer pessoa através de um bot no telegram.

Acesse o link abaixo para visualizar o projeto completo e testar o bot.

### (!) Livro de Python Feature Engineering

https://www.linkedin.com/feed/update/urn:li:activity:6996063884952383489

### (VSCODE Extension - Turbo Console Log

https://www.linkedin.com/posts/engenheiracoelho_essa-extens%C3%A3o-no-vscode-ajuda-a-criar-um-activity-6996067633343172608-5x2d?utm_source=share&utm_medium=member_desktop

### (!!) 5 Top DE Projects (Darshill Parmar Denovo)

https://www.linkedin.com/feed/update/urn:li:activity:6995818329068187649

https://www.youtube.com/watch?v=q8q3OFFfY6c

🚀 𝟓 𝐓𝐎𝐏 𝐃𝐚𝐭𝐚 𝐄𝐧𝐠𝐢𝐧𝐞𝐞𝐫𝐢𝐧𝐠 𝐏𝐫𝐨𝐣𝐞𝐜𝐭𝐬 [FREE ACCESS & DOWNLOAD]

Here are the 5 Projects that you can start this weekend:

1. Building Data Model and Writing ETL Job
Data modeling is an essential part of Data Engineering, DO NOT SKIP THIS!

What will you learn?
✅ Python
✅ SQL
✅ Building Data Models
✅ Basics of DBMS
✅ Writing ETL Job
✅ Querying Data Programmatically
✅ PostgreSQL


2. ETL Pipeline on AWS Cloud
If have no idea about Cloud Computing then this project is for you

What will you learn?
✅ Python
✅ SQL
✅ Cloud Computing Basics
✅ AWS Services - Athena, Glue, Redshift, S3, IAM
✅ Creating Data Pipeline

3. Covid Data Analysis Project
This will be your first end-to-end Data Engineering project on Covid-19 Data

What will you learn?
✅ Python
✅ SQL
✅ Building Data Model
✅ AWS Services - Athena, Glue, Redshift, S3, IAM
✅ Creating Data Pipeline
✅ PostgreSQL


4. YouTube Data Analysis (End-To-End Data Engineering Project)
This is 3 hours long project where you will execute a complete Data Engineering project

What will you learn?
✅ Python and PySpark
✅ SQL
✅ How to understand the business problem
✅ Amazon Web Services (AWS) - Athena, Glue, Redshift, S3, IAM, Lambda, Quicksight
✅ Building Data Pipeline and Scheduling it

5. Twitter Data Pipeline using Airflow
If you are someone who wants to learn the basics about Airflow and how to build a data pipeline this project is for you

What will you learn?
✅ Python
✅ Basics of Airflow
✅ Working with Twitter Data and Package - Tweepy
✅ Python Package - Pandas
✅ Writing ETL job and storing data on S3

💪🏻 Successfully completing these projects will give you the confidence to start your career in Data Engineering.

Tag someone who might find these projects useful, below you can find the link to the projects in the comment 👇🏻

### Jupyter Notebook em aplicação stand-alone

https://www.linkedin.com/posts/eric-vyacheslav-156273169_deeplearning-machinelearning-neuralnetworks-activity-6995716742966587392-bJCJ?utm_source=share&utm_medium=member_desktop

Voilà turns Jupyter notebooks into standalone applications without requiring any modification to the content. .

Blog https://lnkd.in/dV8EnPAX
GitHub https://lnkd.in/gzAsnS2
↓
Check out https://AlphaSignal.ai to get a summary of top publications and breakthroughs in Machine Learning.

### (CompVision) Ira Bar - Guy atrás de Computer Vision

https://www.linkedin.com/feed/update/urn:li:activity:6994975740467273728

### (CompVision) - 5 Great CompVision Projects

https://www.linkedin.com/feed/update/urn:li:activity:6994737614457040896?updateEntityUrn=urn%3Ali%3Afs_feedUpdate%3A%28V2%2Curn%3Ali%3Aactivity%3A6994737614457040896%29

https://www.linkedin.com/feed/update/urn:li:activity:6994737614457040896

### (CompVision) - Great Repo

https://www.linkedin.com/feed/update/urn:li:activity:6987761626548473856?updateEntityUrn=urn%3Ali%3Afs_feedUpdate%3A%28V2%2Curn%3Ali%3Aactivity%3A6987761626548473856%29

🎉 Top 4 Best Resource you should check in 2022 🎉

☑️ GitHub: https://lnkd.in/dRAeYqkE - 350🌟

🎉 It's covered: 🛫

1. 95% Data Science Skill Covered Course
2. COMPUTER VISION
3. NATURAL LANGUAGE PROCESSING
4. MLOPS

🏔️ Resources Include:
1. Learning Path
2. Books with Code Links
3. Best Video Courses
4. Best Github links

[**Curso bom de CompVision**](https://www.linkedin.com/feed/update/urn:li:activity:6994946966166089728?updateEntityUrn=urn%3Ali%3Afs_feedUpdate%3A%28V2%2Curn%3Ali%3Aactivity%3A6994946966166089728%29)

### (CompVision) - Corretor automático de provas

CNN e Transfer Learning

https://www.linkedin.com/feed/update/urn:li:activity:6993922880577155072

### Como ganhar em Dolar

https://www.linkedin.com/feed/update/urn:li:activity:6995855717609975808

### Linkedin Secrets of The Algorithm

https://www.linkedin.com/feed/update/urn:li:activity:6995830804966690816

### (Entrevista) - "O que você se se daqui a 5 anos?

https://www.linkedin.com/feed/update/urn:li:activity:6995738417158369280

Onde você se vê daqui a 5 anos?

Essa pergunta ainda é feita em grande parte das entrevistas de emprego e costuma deixar os candidatos um tanto quanto ansiosos, muitos não sabem exatamente o sentido dessa pergunta e não conseguem formular uma boa resposta.

Quando o recrutador(a) faz essa pergunta ele(a) está tentando entender seu momento profissional e suas perspectivas para um futuro próximo, ele(a) tenta extrair o seu real interesse na empresa e oportunidade, tentando avaliar se valerá a pena investir em um profissional como você ou não.

Quando for questionado, seja claro e objetivo, responda com sinceridade, demonstrando seu real interesse em ingressar na empresa e sua disposição para contribuir com a organização.

Coloquei aqui um exemplo prático de como responder, lembrando que não existe uma resposta certa ou padrão, você pode usar esse modelo e adaptar conforme sua realidade atual.

EXEMPLO DE RESPOSTA:

"Imagino que dentro desse período de 5 anos eu já tenha desenvolvido todas as competências e habilidades necessárias na minha área de atuação, pretendo ter concluído alguns cursos e certificações e quero ter aprimorado meu conhecimento em inglês, que hoje vejo que é um requisito em muitas empresas. Acredito que essa empresa tenha um bom plano de desenvolvimento que irá me permitir evoluir enquanto profissional"

### Quais os principais problemas que o Spark Resolve

https://www.linkedin.com/feed/update/urn:li:activity:6995831731903705088

### (Example Post - DS ) - ML NBA MVP Prevision

https://www.linkedin.com/feed/update/urn:li:activity:6995775808308940802

Meu primeiro projeto de Machine Learning onde realizei todas as etapas do processo. Comecei realizando a raspagem de dados no site oficial da nba para criar o meu banco de dados com as features desejadas. Houve a análise exploratória e limpeza de dados. Foram testados alguns algoritmos com diversas transformações dos dados para obter o modelo com melhores resultados. Organizei os dados com o MLFlow, que possui uma interface gráfica fantástica para a visualização dos valores de métricas que cada modelo forneceu. Já fiz mais de uma versão deste projeto e resolvi postar hoje.
Meu dataset é desbalanceado e após procurar muito conteúdo sobre como contornar tal problema, acabei conhecendo o conteúdo do Andre Yukio, a quem agradeço pelas dicas sobre ter um olhar mais crítico ao utilizar o SMOTE e buscar contornar a dificuldade de balancear os dados de outra forma possível. E agradecer o Leon Silva pelas dicas de data leakage, validação cruzada em dados desbalanceados e afins. As dicas na qual me refiro são encontradas no instagram e canal do youtube de ambos.

Por fim, realizei o deploy do modelo na plataforma Hugging Face e o projeto pode ser encontrado no meu github abaixo e está como público.

### (Estatística) - p-value no teste A/B

https://www.linkedin.com/feed/update/urn:li:activity:6995474652022067200

Today, an interviewer finally asked the question I've been waiting for: Can you explain what a p-value means in the context of an A/B Test?

My answer:

The p-value represents the conditional probability that we would arrive at our results (or more extreme results) given that the null hypothesis is true.

If this probability is less than our alpha, there are low odds of finding our results under the conditions of the null hypothesis, and we can reject it.

If the p-value is greater than our alpha, we fail to reject the null hypothesis.

Assuming the alternative hypothesis represents a new feature we're testing, a low p-value indicates that this feature is achieving its goal.

Someone requested a definition of alpha:

If our null hypothesis were correct, but we found a very low p-value, that would provide evidence for our incorrect alternative hypothesis.

This situation is known as a Type I Error or false positive; the alpha, or significance level, is the probability of such an error.

We aim for an industry standard alpha of 0.05 in order to avoid Type I Errors in our testing.

### 30 dicas para melhorar código python

https://www.linkedin.com/feed/update/urn:li:activity:6995364437746417664


### (Download) Study Guide Data Manipulation

https://www.linkedin.com/feed/update/urn:li:activity:6995405060138573825

### (!!!) Como fazer e publicar um projeto de DS/DE/DA/BI

https://www.linkedin.com/feed/update/urn:li:activity:6995463607509528576/

Depois de alguns anos de experiência vejo muita gente ainda confusa sobre como entrar na área de #dataengineering e #datascience .

Na minha opinião, o maior problema é que a galera fica pirada em fazer vários cursos, mas não aplica quase nada.

O que sempre ressalto é: Conhecimento comprovado é mais importante que curriculo.

Ninguém vai olhar os cursos que você fez.

Isso importa muito pouco.

Mais vale você ter alguns projetos no seu github do que ter alguns cursos no curriculo.

Coloque toda sua energia em desenvolver alguns projetos.
Aqui vai uma ideia para desenvolvimento:

- Escolha um Dataset público
- Crie um processo de ingestão deste para uma Cloud.
- Use Python para carregar este dataset em um banco de dados na AWS ou Google Cloud ou Azure.
- Crie o seu data lake, persista isso em um S3 por exemplo.
- Crie um job usando Spark para processar esse dado,
- Enriquecendo-o e escreva em formatos como: parquet ou delta.
Suba uma máquina virtual, instale o Apache Airflow, orquestre seu job spark.
- Escreva um novo job Spark, agora crie tabelas com dados mais analíticos e persista isso em um Redshift.

Agora o seu projeto está básico, mas já atende muitos cenários de Data engineering.
Escreva tudo isso usando #terraform , assim você sobe todos os códigos no github e este já será um belo projeto para portfólio.

Comente aqui se seria um projeto legal?
Alguma sugestão?

### (Download) ML cheat sheet

https://www.linkedin.com/feed/update/urn:li:activity:6995389588173131776

### Porque sair da Europa

https://www.linkedin.com/feed/update/urn:li:activity:6995364945236230144

Decidir voltar para o Brasil (estando bem empregado no exterior) foi a decisão mais difícil do ponto de vista profissional que eu já tive que tomar. Isto em um momento aonde o mundo vive uma recessão econômica e aonde demissões em massa tem demitido milhares da noite para o dia.

Porém o que está acontecendo na Europa:

- Conta de luz e gás aumentando em 10% todo o mês. Desde o início da guerra as contas quase que dobraram. E a tendência da situação é só piorar.

- Alimentos no mercado tendo reajustes de 10-100% de uma só vez. No Brasil estamos acostumados com a alta continua nos preços, mas dificilmente vemos produtos dobrando de preço da noite para o dia.

- Aluguéis abusivos em todos os principais países. Irlanda, Portugal, Alemanha, Holanda. Em todos esses países, mesmo em cidades fora do centro, você irá pagar 100-200% a mais de aluguel do que era há apenas alguns anos atrás. Levando em conta que nesses países você chega no marco de 40-50% de imposto para "altos" salários, fica literalmente impossível de pagar por uma casa adequada.

- Em alguns países como Irlanda e Portugal, que são os principais destinos para brasileiros, mesmo com dinheiro você não consegue alugar uma casa. Você tem, literamente algumas centenas de casas no país inteiro e dezenas de milhares de pessoas lutando por essas casas. Foi mais difícil arrumar uma casa para morar do que foi para arrumar emprego.

Vai ser cada vez mais comum ver gente voltando para o Brasil. A Europa de alguns anos atrás já não é mais a mesma. Ela é muito boa para quem já tem casa, carro e uma vida estabilizada. Mas para quem está começando, ela simplesmente se tornou inviável.

#datascience #machinelearning #cienciadedados #ti #emprego #vagas #europa

### (Example Project - DA/BI)

https://www.linkedin.com/feed/update/urn:li:activity:6995278199437811712

Data Engineering using AWS Services:

In this project, I have used the Trending YouTube Video Statistics data from Kaggle to analyze and prepare it for usage.

This dataset has two kinds of files: JSON and CSV files. The process goes as follows:

1. Uploaded the data from my local machine into the S3 bucket using AWS CLI commands while trying to maintain a proper file organization. Stored the JSON and CSV files in separate folders.
2.  Used AWS Glue Catalog to crawl the data from JSON and CSV files from the raw bucket which would be stored in a separate database.
3. On facing issues raised due to the data in the JSON format, create a Python function using AWS Lambda to clean them and convert them into parquet format.
4. Created a trigger on this Lambda function so as to run every time new data is being added to S3 bucket and the output was stored in a new database in Athena.
5. Converted the CSV files into parquet format as well using AWS Glue ETL.
6. Created a new Glue Crawler to crawl the clean data into the database.
7. Now when all the clean data from the parquet files (converted from CSV and JSON files) is present in the same database, developed an ETL job using AWS Glue Studio to join both the tables and store it in a separate S3 bucket intended to use for BI purposes.
8. The data is now ready to be used for building dashboards out of it.

I decided to analyze this data for finding out the popularity, most liked video categories, video reach, engagement and likes to views comparison of channels in UK and Canada.

The dashboard is attached below.

To sum up my learnings from this project, I would say:

a.  It was quite smooth using the AWS cloud services as there was no strain on my local machine in terms of processing power.
b. IAM roles are really important. Providing correct access to specific roles is essential for the services to function effortlessly. Although they might seem like simple steps but missing them might lead to silly errors which end up taking time unnecessarily.

This would not have been possible without Darshil Parmar. Thank you for creating amazing content on Youtube

Project link: https://lnkd.in/e7WMFWRi

### Pratica do Ingles

https://www.linkedin.com/feed/update/urn:li:activity:6995340988588122112

THE BOOK IS ON THE TABLE!
QUAL NÍVEL DE INGLÊS EU PRECISO PARA TRABALHAR FORA DO BRASIL?

A maioria dos brasileiros que eu conheço tem muito medo de falar inglês (quando já não morando fora a um bom tempo), achando que tem que falar como nativo, sotaque perfeito, frases e palavras na melhor construção gramatical… Eu até queria ter esse nível, mas te digo que não é necessário. O importante é conseguir se comunicar profissionalmente, e pronto!

Ai vai algumas dicas pra praticar para entrevistas:
-> Estude os contextos da sua area de atuação em aprenda as principais palavras usadas
-> Escreva em papel ou digitalmente o seu roteiro, do que vocês falarão
-> Não tem muita certeza dos assuntos da entrevista para treinar? Tem muitas entrevistas simuladas no youtube para várias áreas de atuação
-> Entreviste o máximo que puder! Aceite as entrevistas que te propõem, pois normalmente elas iniciam com um bate papo de meia hora. Que oportunidade pra praticar de graça, certo?
-> Logo realizar suas entrevistas, inclua no roteiro o que pode ter aparecido de novo, para você se familiarizar!
-> Treine com pessoas se possível, se não, treine sozinho, mas falando em voz alta, nada de leitura mental =P

Treine bastante, erre, corrija, e tome lições de todas experiências. Estou aqui te dizendo não precisa falar como nativo para conseguir um trampo fora, na verdade, precisa falar muito menos do tu imagina! 

-> Image by Freepik

### (Example of Project DS) - Odemir

https://www.linkedin.com/feed/update/urn:li:activity:6995343328913289217

Novembro Azul de um jeito diferente.

Para incentivar a campanha do Novembro Azul, desenvolvi esse modelo de Machine Learning bem simples para detectar câncer de próstata a partir de alguns dados coletados de próstatas, como:
- Raio;
- Textura;
- Simetria;
- Dimensão Fractal;
- Outros.

O objetivo era prever se existe câncer ou não.


Um em cada seis homens desenvolve o câncer de próstata.
O preconceito ou o descuido podem custar a sua vida!


Gostou? Deixa o like para apoiar o trabalho ;D

### Videos das carreiras mais promissoras para 2023

https://www.linkedin.com/feed/update/urn:li:activity:6993280782316261376

### As leis fundamentais para escrevre código na área de dados

https://www.linkedin.com/feed/update/urn:li:activity:6995146802446364672

### Python - Printar nome da variável

https://www.linkedin.com/posts/avi-chawla_python-pythonprogramming-activity-6994998781003874304-Zp3B?utm_source=share&utm_medium=member_desktop

### (!) Cursos gratuiros da Amazon

https://www.linkedin.com/feed/update/urn:li:activity:6995035159364341760

### Keep Track State of Art Machine and Deep Learning

https://www.linkedin.com/posts/giannis-tolios_python-machinelearning-deeplearning-activity-6994728396979093504-ttvZ?utm_source=share&utm_medium=member_desktop

𝗞𝗲𝗲𝗽 𝗧𝗿𝗮𝗰𝗸 𝗼𝗳 𝘁𝗵𝗲 𝗟𝗮𝘁𝗲𝘀𝘁 𝗠𝗮𝗰𝗵𝗶𝗻𝗲 𝗟𝗲𝗮𝗿𝗻𝗶𝗻𝗴 𝗥𝗲𝘀𝗲𝗮𝗿𝗰𝗵!💡
Papers with Code is a website showcasing the latest machine learning research, accompanied by Github repositories that implement each paper in Python. The website also includes a list of benchmark datasets, as well as performance rankings for each one of them. For example, the EffNet-L2 model currently provides state of the art (SOTA) classification accuracy on the CIFAR-100 image dataset. Personally, I'm a big fan of the site and I consider it a valuable resource for ML practitioners and researchers. You can visit the links below for more information, and make sure to follow me for regular content!

𝗣𝗮𝗽𝗲𝗿𝘀 𝘄𝗶𝘁𝗵 𝗖𝗼𝗱𝗲 𝘄𝗲𝗯𝘀𝗶𝘁𝗲: https://lnkd.in/da4ksUgN
𝗦𝗶𝗺𝗽𝗹𝗶𝗳𝘆𝗶𝗻𝗴 𝗠𝗮𝗰𝗵𝗶𝗻𝗲 𝗟𝗲𝗮𝗿𝗻𝗶𝗻𝗴 𝘄𝗶𝘁𝗵 𝗣𝘆𝗖𝗮𝗿𝗲𝘁 𝗯𝗼𝗼𝗸📚: https://lnkd.in/eUkTaBcW
𝗡𝗲𝘂𝗿𝗮𝗹 𝗡𝗲𝘁𝘄𝗼𝗿𝗸𝘀 𝗮𝗻𝗱 𝗗𝗲𝗲𝗽 𝗟𝗲𝗮𝗿𝗻𝗶𝗻𝗴 𝗖𝗼𝘂𝗿𝘀𝗲🧠: https://lnkd.in/dCd7YmaJ

### Porque o Airflow é muito usado

https://www.linkedin.com/feed/update/urn:li:activity:6994749158242816001

Por que o Apache Airflow é a plataforma de orquestração mais utilizada do mundo?

Existem vários fatores mas quero mostrar aqui os que acho mais latentes:

- Python virou a língua-franca da programação para times de Dados

- A utilização de Providers e Modules para que você possa reduzir drasticamente seu código

- Integração com diversos sistemas, basicamente tudo que está disponível hoje na área de dados

- Após o Apache Airflow 2.0 novas features como - Smart Sensors, TaskFlow API, TaskGroups, Kubernetes Operator podem reduzir seu código de 3K para 500 linhas, sim eu passei por isso!

- Nova forma de agendamento - Data Aware Scheduler, game changer se não sabe o que é veja os links!

- AstroSDK por favor me digam que sabe o que é, se não sabe você não sabe o que está perdendo...

Ta faltando mais alguma coisa para adicionar ao nosso mastigadinho?

https://lnkd.in/dsbsB8yr
https://lnkd.in/dj5CmYBN
https://lnkd.in/d9jPVdrJ
https://lnkd.in/dVz-fvbG

### (Download) Guida de Data Warehouse

Para completar a trilogia de Guias de Bolso, chegou o Guia de Bolso de Data Warehouse... é um compilado com alguns dos principais conceitos e técnicas utilizados em modelagem multidimensional (fato, dimensão, cubo, olap, oltp, drill down, top down, botton up, Star Schema, Snow flake Schema, transformação do modelo relacional para multidimensional e muito mais...)

Espero que gostem do compilado! Excelente para quem tá iniciando!!!

https://lnkd.in/d_5AYfnx

### Data Eng

https://www.linkedin.com/feed/update/urn:li:activity:6993320199898689536

A Engenharia de Dados tem tudo a ver com a era da transformação digital — até porque essa é uma área que envolve a transformação dos dados de uma empresa. Ela é a primeira etapa do processamento dos dados e é importantíssima para garantir que os próximos passos funcionem corretamente.

É sobre esse tema que vamos falar no próximo episódio do Papo Data Driven! Participe desse super bate-papo com Luiz Gabriel Braun, Head de Marketing e idealizador da Data Driven Organization, Silas Silva, IT And Analytics Specialist na Bunge e Bernardo Cambruzzi, Data Engineering na Bix Tecnologia - Consultoria de Dados!

Inscreva-se em: https://lnkd.in/dGzF_V7J

### dbt lançous mais 2 cursos gratuitos

😎Weekend activity incoming—

We just launched two new *advanced* training courses on dbt Learn!

📝 dbt Learn Advanced Testing
🚀 dbt Learn Advanced Deployment

If Coalesce still has you buzzing to level-up your expertise, these courses (+5 more that go deep on materializations, macros, and seeds, and refactoring) are a great place to start!

👂Psst: These two courses are also *great* resources to help you prepare for the dbt Certification Exam 👀

https://hubs.li/Q01rvj230

### (!!) Awesome Data Engineering

Want to become a DATA ENGINEER, but you don't know what to learn? Fear not anymore! I found this website that takes engineers from zero to hero-ish with free resources, books and courses: https://lnkd.in/eZ5mSdPX. Ok, you won't be a data engineer after following that curriculum, but at least, you'll know where to focus your effort. Plus, it doesn't seem too bad to simply prepare for interviews, but this is not my specialty, so I'll let other experts provide their more educated opinions on the subject.

The curriculum covers:
- SQL
- Programming language
- Relational Databases - Design & Architecture
- noSql
- Columnar Databases
- Data warehouses
- OLAP Data modeling
- Batch data processing & MapReduce
- Stream data processing
- Pipeline / Workflow Management
- Security and privacy

I think I am going to work through a bit of that curriculum myself. 

Looking for Data Science career mentoring and/or Machine Learning consulting services? Let's chat: 

https://lnkd.in/gGBMXuR4

###(!) (Example of Project) Projeto DS/DE do zero

https://www.linkedin.com/posts/koray-caglar_creating-end-to-end-ai-data-productimage-activity-6994291807262019584-foYY?utm_source=share&utm_medium=member_desktop

Hi! During my internship with my mentors Nilden Tutalar and Gürkan G. I worked on a MLOps project that is about processing streaming data. 

The function of the created system was to classify defects on marble blocks in real-time using machine learning applications. The system was built on a virtual machine of Google Cloud Platform's Compute Engine.

I used Docker, Elastic Stack (ELK), Apache Airflow, RabbitMQ tools and explained the designing process on 6 part Medium series.

You can view my Medium stories below.

https://medium.com/@koraycaglar/creating-end-to-end-ai-data-product-image-processing-app-with-mlops-by-using-docker-elk-airflow-15336ade44f9

### Aprender Spark de Graça

Don't pay for Apache Spark Courses just because it is in demand.

You can learn for free here -

1. Install Spark from here - 
+ https://lnkd.in/gx_Dc8ph
+ https://lnkd.in/gg6-8xDz

2. Learn Spark Basics from here -
+ https://lnkd.in/g-gCpUyi
+ https://lnkd.in/gkNhMnTZ
+ https://lnkd.in/gkbVB6YX

+ 2.1 Learn Spark with Scala from here -
  
+ https://lnkd.in/gtrZAmn4
  
+ 2.2 Learn Spark with Python from here -
  
+ https://lnkd.in/gQaeSjbH
  
+ 3. Learn Pyspark from here -
  + https://lnkd.in/g6kyihyW

4. Work on Spark projects from here -
+ https://lnkd.in/gE8hsyZx
+ https://lnkd.in/gwWytS-Q
+ https://lnkd.in/gR7DR6_5
+ https://lnkd.in/gzngHhrC
+ https://lnkd.in/gACn6bK8

5. Finally list down your projects in GitHub which can be referenced or showcased in interviews

I highly recommend above steps which any data enthusiast could follow.

Let me know #comments if its "helpful""👍

Do follow Ajay Kadiyala for such useful content

### (Example of Project - DS)

https://www.linkedin.com/feed/update/urn:li:activity:6994304359698157568



Fala pessoal, bom dia !

Hoje compartilho com vocês o case segundo case do bootcamp ministrado pelos professores: Odemir Depieri Jr, Ronisson Lucas Calmon da Conceição e Nelson Jacob Dressler. Nessa segunda aula, vimos modelos de regressão com penalização (Redge, Lasso e Elasticnet). Portanto, o objetivo era fazer um EDA no dataset e depois criar um modelo explorando ao máximo suas possibilidades. 

Como a regressão Lasso possui um método para realizar feature selection, decidi usá-la para pratica, espero que gostem !!

### (Example Of Project - DE) - Track tweets

https://www.linkedin.com/feed/update/urn:li:activity:6994304053786599425

Hey, everyone!

Have you ever wondered how to periodically get Twitter data from a specific topic? 

I've just written a blogpost about a data engineering project that I worked alongside Samuel Huff Dieterich and Luiz Alves, in which we tracked Tweets about IMDb's best movies.

Our engineering stack was mainly made of Python, Apache Airflow, Docker and a SQL database running in AWS.

You can read the article here: https://lnkd.in/ep6fg3TX

Let me know what's your feedback on this!


### Orquestrando pipelines spark com airflow

https://www.linkedin.com/feed/update/urn:li:activity:6994397650930315264

### Post Radnom

https://www.linkedin.com/feed/update/urn:li:activity:6993972249078706176

Essa vai pra quem quer trabalhar com Dados: Desenvolver sua capacidade de resolução de problemas é mais importante do que aprender ferramentas!

Por que eu digo isso? 

1. Porque o mundo muda com uma velocidade absurdamente rápida. Ferramentas são criadas e caem em desuso todos os dias.

2. Saber olhar para um problema e propor uma solução que agregue valor e que seja factível é o que vai te tornar um profissional diferenciado. Não interessa muito se vai usando Python com Pandas, Excel, Data Studio ou PowerBI.

O mercado busca pessoas para resolver seus problemas, ao invés de meras aplicações de ferramentas.

"OK Lucas, e como eu posso desenvolver isso se ainda não trabalho na área?"

Deixo aqui alguns caminhos possíveis:
- Procure por cases reais e tente replica-los. Hoje há uma abundância de dados públicos e desafios (tipo o Kaggle) na internet. 

- Participe de um projeto de pesquisa ou de um projeto de ONG que envolva Dados. Assim você terá contato com problemas REAIS e irá exercitar tanto algum uso de ferramenta quanto sua capacidade de resolver problemas. 

- Busque trocar ideia com profissionais mais experientes e descubra "como eles pensam". 

E ai, tem mais alguma sugestão? 

Me conta o que você pensa!

Créditos a Bruna Machado que me inspirou a fazer esse post.

\#dados \#carreira

### (!) Livro: Como trabalhar com dados desbalanceados

https://www.linkedin.com/feed/update/urn:li:activity:6989353539961556992

### (Example Of Project - DevOps DE)

https://www.linkedin.com/posts/julioszeferino_aws-data-github-activity-6993688603633582081-eMxt?utm_source=share&utm_medium=member_desktop

Os Data Lakehouses são uma das arquiteturas de dados mais poderosas por sua capacidade de consultar dados diretamente no datalake utilizando engines especificas.

Neste projeto, desenvolvi uma arquitetura criada na nuvem da AWS utilizando uma função lambda para subir um cluster EMR e processar dados no datalake. O consumo dos dados e feito utilizando um jupyter notebook e pyspark.

Todo o deploy foi automatizado utilizando o Terraform e o Github Actions.

O repositório do projeto está no primeiro comentário.

Por aqui, seguimos estudando!

### (!) Template of DE PROJECT

https://www.linkedin.com/feed/update/urn:li:activity:6993556175623442432

Are you trying to set up the infrastructure, CI/CD, automated testing, and database changes for your data engineering project (portfolio)? Then this post is for you! In this post: https://lnkd.in/eCGcVHt5, we will see how to set up an Airflow + Postgres + Metabase stack and can also set up AWS infra to run them.

 With the following tools

 Local development: Docker & Docker compose
 DB Migrations: yoyo-migrations (lightweight alembic alternative)
 IAC: Terraform
 CI/CD: GitHub Actions
 Testing: Pytest
 Formatting: isort & black
 Lint check: flake8
 Type check: mypy

 Here are a few other projects that use the same infra tools but different Data tools.

 https://lnkd.in/ehjt8cfC: Airflow, Redshift, EMR, S3, Metabase
 https://lnkd.in/g-nsDvw: Cron, Postgres, Metabase
 https://lnkd.in/eC8J795E: Dagster, dbt, Postgres, Metabase

 This easy-to-use template helps people start building data engineering projects (for portfolio) & providing a good understanding of commonly used development practices. I hope this helps someone :) 

### PORQUE VAI SER IMPOSSIVEL EU ENTRAR EM DS

https://www.linkedin.com/feed/update/urn:li:activity:6993376139029164032

4 reasons you’re not landing your first data science role.

1. Your profile is built to show how you could be qualified for a range of roles. Make the change to show how qualified you are for a much smaller range of roles. Broad appeal works if you’re trying to solve a $50 problem for 2,500 companies. You’re trying to solve a $125K problem for 1 company. Change the way you market yourself to match.

2. Hiring managers don’t believe you’re qualified. In research, every assertion must be supported with evidence. Approach your profile or resume the same way. If you say, “Proficient in Python,” support it with evidence and explain what you have built that proves it. If you say, “Strong machine learning knowledge,” back it up with an example.

3. Your resume or profile talks about tools you can use. It should focus on problems you can solve or work products you can create. Reframe your language to “I build {work product} using {tools}.” The biggest complaint hiring managers have is they get resumes from people with knowledge of, and they want people who are capable of.

4. You’re optimizing for short-term vanity goals. You’ll be in your first role for 2-3 years. Your career will span 40+ years. Landing a data analyst vs. data scientist role doesn’t mean much. Starting at Google vs. a small business doesn’t either. Spending 2 years working towards Google or a data scientist role changes very little in the long run.

### Dica de livro de data cleaning

https://www.linkedin.com/feed/update/urn:li:activity:6993441543999111168

Book: Data Cleaning and Exploration with Machine Learning by Mike Walker
Special Thanks to Shifa Ansari for providing the review copy of the book.

### (!!!) VANIA ENGLISH INGLES - ESTUDAR INGLES SOZINHO

https://www.linkedin.com/pulse/cronograma-para-estudar-ingl%C3%AAs-sozinho-em-novembro-paula-de-freitas/

### PRIMEIRA SEMANA

01 – Assista a uma lição de 1 minuto e pratique os exercícios no [elllo.org/vídeo](http://elllo.org/video). Tome nota das palavras desconhecidas.

02 – Pesquise as palavras do item anterior em um [dicionário inglês](https://www.nacaofluente.com/blog/6-dicionarios-de-ingles-para-melhorar-seu-vocabulario/).

03 – Pratique escrita fazendo perguntas no [hinative.com](https://br.hinative.com/).

04 – [Revise ou aprenda](https://www.nacaofluente.com/blog/como-aprender-ingles-no-youtube/) 2 temas de gramática.

05 – [Escolha um tema neste artigo](https://www.nacaofluente.com/blog/perguntas-praticar-conversacao-em-ingles/) e grave um áudio respondendo a 3 perguntas disponíveis nele.



### SEGUNDA SEMANA

06 – Leia uma lição de *business English* no [Breaking News](https://breakingnewsenglish.com/business_english.html).

07 – Faça os exercícios de vocabulário da lição do dia 06.

08 – Pesquise palavras novas no [youglish.com](https://youglish.com/) para que você possa aprender em contextos diferentes.

09 – Estude a gramática proposta pelo exercício do dia 06.

10 – Faça os exercícios de ditado (*Dictation*) da lição do dia 06.

11 – Escreva a resposta de 5 perguntas na seção *Discussion* do exercício do dia 06.

12 – Pratique conversação com alguém sobre o tema estudado ao longo da semana. Nesse site você encontra [parceiros para praticar inglês](https://www.nacaofluente.com/blog/onde-praticar-ingles/).

 

### TERCEIRA SEMANA

13 – Assista a um TED Talks com assunto do seu interesse, com legenda. Eu recomendo começar por aqui ([TED Talks indispensáveis para melhorar o inglês](https://www.linkedin.com/posts/vaniapaulacoach_ted-talks-indispensáveis-para-melhorar-o-activity-6962718407410515968-3Q0y/)).

14 – Pesquise as palavras desconhecidas no Google Imagens ou no [Dictionary.com](http://dictionary.com/)

15 – Assista novamente, sem legendas. Se necessário, reduza a velocidade para 0.75x para obter uma melhor compreensão.

16 – Escreva os principais tópicos da palestra. Podem ser palavras soltas, apenas ideias do que você entendeu.

17 – Converse com alguém sobre o que você assistiu. Compartilhe o link do vídeo com essa pessoa.

18 – Revise ou aprenda 2 [temas de gramática](https://www.nacaofluente.com/blog/como-aprender-ingles-no-youtube/).

19 – Aprenda essa estratégia para melhorar drasticamente o seu [inglês com TED Talks](https://www.nacaofluente.com/blog/como-melhorar-seu-ingles-com-ted/).



### QUARTA SEMANA

 \* Preparação para o último [Meetup](https://www.nacaofluente.com/meetup/) do ano da Nação Fluente. O tema do encontro será: *Fake News*

 20 – Assista a um vídeo sobre o tema do nosso meetup no YouTube, eu [recomendo este](https://youtu.be/zIToWT2C3S8). Assista primeiro com legenda, depois sem legenda. Reduza e acelere a velocidade até que você sinta que a sua compreensão auditiva está melhorando. Anote as palavras que você desconhece.

21 – Use o [vocabulary.com](http://vocabulary.com/) para aprender o significado das palavras que você anotou no item anterior

22 – Assista a esse TED Talk sobre o tema da semana ([How Real Is Fake News?](https://www.youtube.com/watch?v=UQcCIzjz9_s)). Você pode usar as mesmas estratégias ensinadas no dia 19.

23 – Escreva respostas para 5 a 10 perguntas desse [tema](https://www.nacaofluente.com/blog/perguntas-praticar-conversacao-em-ingles/#Fake_news:~:text=a “bad boss”%3F-,Fake news,-What is your).

24 – Participe do último encontro de conversação do ano da Nação Fluente – junte-se gratuitamente em [nacaofluente.com/meetup](http://nacaofluente.com/meetup).

25 – Ouça esses podcasts sobre o tema Fake News ([episódio 1](https://www.nacaofluente.com/download/4671) e [episódio 2](https://www.nacaofluente.com/download/4673)).

26 – Estude gramática, eu sugiro o [Past Perfect Tense](https://www.nacaofluente.com/blog/como-aprender-ingles-no-youtube/#:~:text=Political systems-,Past Perfect Simple,-Family relationships).

 

### QUINTA SEMANA

27 – Aprenda vocabulário de inglês corporativo com os vídeos do [Business English Pod](http://youtube.com/c/Businessenglishpod)

28 – Pratique seus conhecimentos de inglês corporativo com os exercícios do [QuizLet](https://quizlet.com/search?query=business-english&type=all)

29 – Habilite o recurso de ditado do Microsoft Word e configure o idioma para inglês e pratique a fala respondendo a essas [questões do inglês corporativo](https://www.nacaofluente.com/blog/perguntas-praticar-conversacao-em-ingles/#Perguntas_para_treinar_o_ingles_corporativo:~:text=Conteúdo adicional-,Perguntas para treinar o inglês corporativo,-Where do you).

30 – Aprenda e pratique seus conhecimentos da língua com testes super objetivos e práticos no [test-english.com](http://test-english.com/)

### (Download) ML Cheat sheet

https://www.linkedin.com/feed/update/urn:li:activity:6993233363541110785

### Terraform

Terraform é game changer para quem trabalha com #dataengineering
Aqui listo alguns motivos para você usar hoje:

- Provisionamento de infraestrutura com código da segurança, confiabilidade e permite reproduzir uma infraestrutura de forma muito rápida.
- Atualizações e mudanças podem ser reproduzidas de forma simples em ambientes de teste e homologação.
- Gestão simples de diversos ambientes tais como: produção, desenvolvimento, homologação, staging. etc.
- Aumento da segurança: todo o provisionamento da infra pode ser centralizado na solução de CI/CD.
- Com terraform podemos estimar alterações em infraestrutura apenas adicionando algumas linhas de código.
- Provisionamentos em Multicloud usando uma única linguagem e com poucas mudanças.
- O código se torna uma documentação atualizada da sua infraestrutura.

Se você trabalha com #cloud, é importantíssimo ter conhecimento de uma solução de IaC.

Faz sentido? comenta aí.

### (EXTERIOR) O que não dizer na entrevista

[Inglês de TI] [Entrevista no exterior]

NÃO FALE ISSO EM UMA ENTREVISTA DE EMPREGO NO EXTERIOR!

Pessoal, quando eu estava no Canadá e fazendo entrevistas de emprego, eu sempre cometia um erro que me fazia reprovar. Conversando com nossos alunos, percebi que eles também cometem o mesmo erro.

Não pergunte sobre salário e benefícios na hora da entrevista. Isso mesmo, não pergunte sobre isso!

O único papel do entrevistador é determinar se você é aquela peça faltando do quebra cabeça que vai se encaixar perfeitamente.

Quando você pergunta sobre o que VOCÊ vai ganhar, isso mostra ao entrevistador que você está apenas pensando no seu benefício e em não em como você vai agregar para a empresa trazendo suas qualidades profissionais.

Se você foca em si, tentando conseguir o maior salário e os melhores benefícios de início, isso mostra que você não está pensando se você vai se adequar, se a cultura e valores daquela empresa resonam com você e se você irá se adequar ao time.

Quando eu reprovava nas entrevistas, achava que era por causa da minha experiência, pelo meu nível de inglês, por eu ser estrangeiro ou por 1001 outros motivos.

Mas o que eu não percebia é que era por causa dessa simples coisa que eu perguntava na hora errada e não percebia que acabava afastando o entrevistador.

Depois que eu parei de fazer isso, comecei a ter muito mais sucesso nas entrevistas e consegui passar e trabalhar para diversas empresas em projetos web e se vocês também pararem de falar isso, tenho certeza que irão ter muito mais sucesso nas entrevistas.

Pessoal, isso não quer dizer que você NUNCA deve perguntar sobre salários e benefícios. Uma estimativa de salário e benefícios pode ser discutida antes da entrevista e a hora de realmente negociar e falar sobre o que você quer e espera é quando você já passou na vaga e vai negociar o salário, mas não na hora da entrevista! 

É por isso que eu sempre digo para nossos alunos fazerem perguntas que demonstram que você tem real interesse no trabalho e na empresa e não apenas no que você irá ganhar. 

Gostou? Deixe seu like, comente e/ou marque seus colegas que precisam turbinar o inglês para o trabalho. 😊

PS: Você deseja avançar suas habilidades de inglês focado em entrevistas em inglês e começar a ganhar em dólar? 💵💵💵

Então acompanhe nossos posts e comece a estudar o verdadeiro INGLÊS DE TI e aprenda como responder as principais 
perguntas de ENTREVISTAS EM INGLÊS.

### Modern Data Stack

https://www.linkedin.com/feed/update/urn:li:activity:6992895850708393984

Modern Data Stack

Entre outros temas que vou compartilhar durante esta semana com vocês, no #BigDataBrazilExperience22, o Mateus Henrique Cândido de Oliveira e eu tivemos a oportunidade de falar sobre #ModernDataStack. 🎯 🎯

Explicamos para o público que é preciso pipelines mais simples para atender às necessidades de analistas de dados e negócios.

Assim, temos o #Airbyte para ingerir dados utilizando uma UI simples, #Snowflake para armazenar os dados de entrada e os processados como Modern Data Warehouse, juntamente Airflow e DBT para orquestração no #Airflow e processamento usando #SQL com #DBT.

Além de entregarmos para consumidores de dados processados, também podemos utilizar uma nova técnica, chamada “ETL Reverso”. 🚀 🚀 

Quer saber mais sobre este assunto? Continue nos acompanhando!

Salve esse esquema explicativo clicando no link a abaixo: ⬇️
https://lnkd.in/ds9rBVns
.
.
.
.
➡️ Acompanhe nossas diferentes redes sociais e fique por dentro de todas as novidades. Clique no link abaixo:

 https://lnkd.in/dzdc_US4

 https://lnkd.in/dvY_Aaab 
