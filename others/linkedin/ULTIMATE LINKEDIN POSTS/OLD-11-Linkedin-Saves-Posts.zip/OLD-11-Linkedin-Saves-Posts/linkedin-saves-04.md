# Linkedin Saves 4 - 14/12/2022


De tempos em tempos devo acessar o linkedin save e anotar tanto aqui quanto no caderno as melhores coisas.

Se forem muito grande anoto aqui. Se forem pequenas anoto aqui e no caderno.

IMPORTANTE: após preencher o forms os convites só chegam em Dezembro quando encerram as inscrições.

## Index

[TOC]

* [Index](#index)
* [Procurar vaga nas seguitne s exmpresas](#procurar-vaga-nas-seguitne-s-exmpresas)
* [ChatGPT Posts](#chatgpt-posts)
  + [Extensão - ChatGPT como extensão no chrome](#extens-o---chatgpt-como-extens-o-no-chrome)
  + [ChatGPT para gerar dataset](#chatgpt-para-gerar-dataset)
  + [ChatGPT - Outro bom caso](#chatgpt---outro-bom-caso)
  + [ChatGPT - Melhora Código](#chatgpt---melhora-c-digo)
* [Posts diretos sobre Chat GPT](#posts-diretos-sobre-chat-gpt)
* [Empresas legais que alguém conseguiu vaga](#empresas-legais-que-algu-m-conseguiu-vaga)
* [PBI Dashborards](#pbi-dashborards)
* [Linkedin Save Posts](#linkedin-save-posts)
  + [(Course) MLOps de Stanford Free](#-course--mlops-de-stanford-free)
  + [Pessoas BR referência em Tech](#pessoas-br-refer-ncia-em-tech)
  + [(DE) Airflow + GreatExpectations Youtube Long video](#-de--airflow---greatexpectations-youtube-long-video)
  + [(Excel) O Excel novo consegue converter imagem de tabela em uma tabela CSV](#-excel--o-excel-novo-consegue-converter-imagem-de-tabela-em-uma-tabela-csv)
  + [(Front) Front Legal](#-front--front-legal)
  + [Portugues - Como usar 'mim'/'me'](#portugues---como-usar--mim---me-)
  + [DE - Carinha fazendo um projeto em DE e documentando tudo](#de---carinha-fazendo-um-projeto-em-de-e-documentando-tudo)
  + [(Front) Front legal](#-front--front-legal)
  + [DE - Diferença entre batch e Streamming](#de---diferen-a-entre-batch-e-streamming)
  + [Resume - Como fazer](#resume---como-fazer)
  + [Melhorar git com Rafael Balistrini](#melhorar-git-com-rafael-balistrini)
  + [(Publish Linkedin) Como publicar certificaod no linkedin](#-publish-linkedin--como-publicar-certificaod-no-linkedin)
  + [DE - Déficit em Data Engineering](#de---d-ficit-em-data-engineering)
  + [(Exterior) Vagas para Portugal](#-exterior--vagas-para-portugal)
  + [(OCR) - Python e WebScraping](#-ocr----python-e-webscraping)
  + [ML - ML Tool documentos e pdf](#ml---ml-tool-documentos-e-pdf)
  + [(Exterior) matéria no correio brasiliens](#-exterior--mat-ria-no-correio-brasiliens)
  + [Apache NiFi BRASIL](#apache-nifi-brasil)
  + [(Exterior) Como você é tratado no BR e fora](#-exterior--como-voc----tratado-no-br-e-fora)
  + [Cracking All - Google Interview Questions](#cracking-all---google-interview-questions)
  + [(Currículo) O que falar sobre os certificados](#-curr-culo--o-que-falar-sobre-os-certificados)
  + [(Currículo) - Dica](#-curr-culo----dica)
  + [DE - Relato de curso da XP sobre DE](#de---relato-de-curso-da-xp-sobre-de)
  + [(Front) - Exemplo de Projeto](#-front----exemplo-de-projeto)
  + [(DS) Handler missing data](#-ds--handler-missing-data)
  + [SQL - dicas de query](#sql---dicas-de-query)
  + [TabNews - Como trabalhar remoto](#tabnews---como-trabalhar-remoto)
  + [Construindo uma Stack Moderna de DE](#construindo-uma-stack-moderna-de-de)
  + [ChatGPT que faz resumo de artigo cientifico](#chatgpt-que-faz-resumo-de-artigo-cientifico)
  + [???](#---)
  + [Annotations em Spring](#annotations-em-spring)
  + [Exterior - ir para Malta](#exterior---ir-para-malta)
  + [Trilha de BI](#trilha-de-bi)
  + [Como aprender ingles](#como-aprender-ingles)
  + [KPI](#kpi)
  + [9 FONTES DE COISAS MUITO BOAS](#9-fontes-de-coisas-muito-boas)
  + [(Currículo) Erros apra nâo cometer no seu linkedin](#-curr-culo--erros-apra-n-o-cometer-no-seu-linkedin)
  + [(!!) (Currículo) (ML) Como criar um repositório de ML em 10 passos](#------curr-culo---ml--como-criar-um-reposit-rio-de-ml-em-10-passos)
  + [DE - CheatSHeet de DataEngineering](#de---cheatsheet-de-dataengineering)
  + [Post sobre Modern Data Stack](#post-sobre-modern-data-stack)
  + [(English) Como aprender inglês de uma vez](#-english--como-aprender-ingl-s-de-uma-vez)
  + [DE Project](#de-project)
  + [DE - Sobre saber usar as coisa de DE](#de---sobre-saber-usar-as-coisa-de-de)
  + [(RPA Python Supreme) Best courses/tools](#-rpa-python-supreme--best-courses-tools)
  + [Pytorch Cheat Sheet](#pytorch-cheat-sheet)
  + [Projeto de DE - Ações on Brasil](#projeto-de-de---a--es-on-brasil)
  + [ML - Ultra video de NLP](#ml---ultra-video-de-nlp)
  + [(Front) 10 Fonte de templates de html/css](#-front--10-fonte-de-templates-de-html-css)
  + [(Currículo) Como deixar recrutadores de queijo caído](#-curr-culo--como-deixar-recrutadores-de-queijo-ca-do)
  + [(Publish Linkedin) O que publicar no linkedin](#-publish-linkedin--o-que-publicar-no-linkedin)
  + [Técnica de Feynam para aprender qualquer coisa](#t-cnica-de-feynam-para-aprender-qualquer-coisa)
  + [HPO - tunning parmetros](#hpo---tunning-parmetros)
  + [Automatizar criaçao de post no linkeidn](#automatizar-cria-ao-de-post-no-linkeidn)
  + [DE Project Exemplo](#de-project-exemplo)
  + [(!!!) ULTRA - COMO SABER REACT](#------ultra---como-saber-react)
  + [Livro - Python Feature Engineering COokbook](#livro---python-feature-engineering-cookbook)
  + [(DS) PDF sobre pandas](#-ds--pdf-sobre-pandas)
  + [Virada de chave no ingles](#virada-de-chave-no-ingles)
  + [(Entrevista) MUITO BOM A SERIE DESSA MULHER, EM INGLES](#-entrevista--muito-bom-a-serie-dessa-mulher--em-ingles)
  + [DE - Modern Data Stack](#de---modern-data-stack)
  + [Book - 100 indicadores de Gestão (KPI)](#book---100-indicadores-de-gest-o--kpi-)
  + [DE - Projeto do twitter (repo bt)](#de---projeto-do-twitter--repo-bt-)
  + [(Currículo) Criador de currículo](#-curr-culo--criador-de-curr-culo)
  + [Necessidade de fazer refatoração de código](#necessidade-de-fazer-refatora--o-de-c-digo)
  + [BigMac Index em PBI](#bigmac-index-em-pbi)
  + [Exemplo de Site portifolio](#exemplo-de-site-portifolio)
  + [ML - Score de cŕedito / risco de crédito](#ml---score-de-c-edito---risco-de-cr-dito)
  + [SQL interview Questions](#sql-interview-questions)
  + [Queda de DS e auento de DA](#queda-de-ds-e-auento-de-da)
  + [DE -  Big Data Interview Questions](#de----big-data-interview-questions)
  + [Become IBM Certified](#become-ibm-certified)
  + [OCR - exemplo bom](#ocr---exemplo-bom)
  + [5 hobbies](#5-hobbies)
  + [Dica para análise de dados](#dica-para-an-lise-de-dados)

<small><i><a href='http://ecotrust-canada.github.io/markdown-toc/'>Table of contents generated with markdown-toc</a></i></small>



## Procurar vaga nas seguitne s exmpresas

https://www.linkedin.com/company/xpinc/?lipi=urn%3Ali%3Apage%3Ad_flagship3_saved_items%3BWQihJD6rS1WKO%2B3rDuYtBQ%3D%3D



## ChatGPT Posts



### Extensão - ChatGPT como extensão no chrome

https://www.linkedin.com/posts/miguelgfierro_ai-machinelearning-activity-7007957041340166144-z_pR?utm_source=share&utm_medium=member_desktop

There is a Chrome extension that adds a ChatGPT output to the Google interface.

See the comparison of the query: "what is a markov decision process" and judge for yourself.



### ChatGPT para gerar dataset 

https://www.linkedin.com/posts/shubhamsaboo_data-analytics-on-autopilot-activity-7007986625846644738-dUyW?utm_source=share&utm_medium=member_desktop



### ChatGPT - Outro bom caso

https://www.linkedin.com/posts/fernando-junior-2106_chatgpt-activity-7007485007715799040-WKic?utm_source=share&utm_medium=member_desktop

What a time to be alive!

Desde seu lançamento venho testando diversos aspectos do que o [#chatGPT](https://www.linkedin.com/feed/hashtag/?keywords=chatgpt&highlightedUpdateUrns=urn%3Ali%3Aactivity%3A7007485007715799040) é capaz de realizar. Estou bem impressionado com os resultados, como exemplo, pensei que seria interessante entender como essa ferramenta poderia ajudar processos que tenho no dia a dia e, pensei: "será que consigo elaborar testes para desafios de vagas de ciêntistas de dados com simples direcionamentos?".

Confeso que os resultados foram bem melhores do que eu estava esperando.

Confiram abaixo os meus testes:



![](https://media.licdn.com/dms/image/D4D22AQFeAezh1e1n4A/feedshare-shrink_800/0/1670714617382?e=1674086400&v=beta&t=BJ7vVGTwUNfkDBQq4E2XWVnwSG1e6aZ_WyjwjSk277c)

### ChatGPT - Melhora Código

https://www.linkedin.com/posts/lets-data_datascience-machinelearning-openai-activity-7007393735961407488-2JPa?utm_source=share&utm_medium=member_desktop

ChatGPT da OpenAI invadiu a timeline de todo mundo! Muito legal fazer testes, brincadeiras, mas sabia que dá pra usar pra coisas realmente úteis? E mais, sabia que ele “entende” português?

Experimente escrever “Como agrupar dados utilizando pandas?”, ou, “Como fazer uma regressão utilizando scikit-learn?”. Ele até sugere melhorias no código.

Pra quem ainda não paga o Copilot, pode ser uma boa alternativa!

## Posts diretos sobre Chat GPT

CHATS GPT

https://www.linkedin.com/posts/imohitmayank_chatgpt-pythonprogramming-stackoverflow-activity-7005814250958909440-vtuT?utm_source=share&utm_medium=member_desktop

https://www.linkedin.com/posts/shubhamsaboo_chatgpt-openai-activity-7005798356266463232-9BQ5?utm_source=share&utm_medium=member_desktop

https://www.linkedin.com/posts/carlosemello_cienciadedados-universidade-pesquisacientifica-activity-7005284911926374400-JZdI?utm_source=share&utm_medium=member_desktop

https://www.linkedin.com/posts/lorhan_python-rpa-rpadeveloper-activity-7005559292133027840-E9_k?utm_source=share&utm_medium=member_desktop

https://www.linkedin.com/posts/marcuos_inteligenciaartificial-machinelearning-gpt3-activity-7004247698220453888-L6IA?utm_source=share&utm_medium=member_desktop

https://www.linkedin.com/posts/felipedamascena_print-do-dashboard-em-pdf-activity-7003018467297669121-HTwY?utm_source=share&utm_medium=member_desktop

## Empresas legais que alguém conseguiu vaga

EMPRSAS QUE ALGUEM BACANA CONSEGUIU VAGA

https://www.linkedin.com/posts/marcos-gueiros_gostaria-de-compartilhar-que-estou-come%C3%A7ando-activity-7008203496021766144-_VZS?utm_source=share&utm_medium=member_desktop

Gostaria de compartilhar que estou começando em um novo cargo de Desenvolvedor Full Stack Junior no Grupo ICTS.

https://www.linkedin.com/posts/pedrosoprano_gostaria-de-compartilhar-que-estou-come%C3%A7ando-activity-7007379613664358400-S-kY?utm_source=share&utm_medium=member_desktop

https://www.linkedin.com/posts/azevedo94_data-activity-7006196376153812992-7UAU?utm_source=share&utm_medium=member_desktop

https://www.linkedin.com/posts/laurindo-vilonga-dumba-45b214102_gostaria-de-compartilhar-que-estou-come%C3%A7ando-activity-7006413383763685376-P20Q?utm_source=share&utm_medium=member_desktop

https://www.linkedin.com/posts/amanda-araujo-de-alvarenga_gostaria-de-compartilhar-que-estou-come%C3%A7ando-activity-7001552824220160000-l4qT?utm_source=share&utm_medium=member_desktop

https://www.linkedin.com/posts/jhonata99_gostaria-de-compartilhar-que-estou-come%C3%A7ando-activity-7005957944664076289-OX8D?utm_source=share&utm_medium=member_desktop

https://www.linkedin.com/posts/alansoares_gostaria-de-compartilhar-que-estou-come%C3%A7ando-activity-7001156752066920448-0LyB?utm_source=share&utm_medium=member_desktop

MEINA QUE PASSOU NA EXPLOR
https://www.linkedin.com/posts/amandarodriguescruz_im-happy-to-share-that-im-starting-a-new-activity-7006345205373132800-Wn6B?utm_source=share&utm_medium=member_desktop

## PBI Dashborards

https://www.linkedin.com/posts/emanuellsantos_elsanalytics-powerbi-consumo-activity-7006025347628437504-xMt1?utm_source=share&utm_medium=member_desktop

https://www.linkedin.com/posts/emanuellsantos_analista-automatizado-automatizar-activity-7005664188723302400-Qu_i?utm_source=share&utm_medium=member_desktop

## Linkedin Save Posts



### (Course) MLOps de Stanford Free

https://www.linkedin.com/posts/luanacsoares_deeplearning-artificialintelligence-machinelearning-activity-7008766198171492353-DntU?utm_source=share&utm_medium=member_desktop

A Stanford University oferece design de sistemas de aprendizado de máquina (MLOps). 🥇 ** Gratuito**

O Idiona Original é em Inglês, mas no vídeo explicativo é possivel colocar legenda e traduzi-la e os materiais é possivel traduzir também caso você precise

🏢 Página Oficial do cs329s: https://lnkd.in/dfdJ8edE
📹 Vídeo Palestras: https://lnkd.in/dhNhctW8
📑 : Projetando sistemas de aprendizado de máquina Livro por [Chip Huyen](https://www.linkedin.com/in/ACoAAAIQAJQBE3ykLNnsOPVvxwuuVCOir2zAjOQ)

🔸 O design de sistemas de aprendizado de máquina é o processo de definição da arquitetura de software, infraestrutura, algoritmos e dados para um sistema de aprendizado de máquina para satisfazer os requisitos especificados.

🔸Traduzido da Publicação original de [Ashish Patel 🇮🇳](https://www.linkedin.com/in/ACoAAATOnMIBYFNuqVOB33Dkrrhcd4bGpGp6FIM)

📅 Catálogo de Palestras:
*************************
🔹 1. Noções básicas sobre a produção de aprendizado de máquina: 
📑 : https://bit.ly/3Fpjjwi



### Pessoas BR referência em Tech

https://web3news.com.br/noticia/172/saiba-quem-sao-as-25-pessoas-mais-importantes-da-tecnologia-no-brasil-em-2022

Veja quem são os brasileiros mais importantes na tecnologia em 2022:

+  [Henrique Dubugras](https://www.linkedin.com/in/ACoAAAcfbZ0Bb7nuZFvzyPDc4IM0DCFeM6PEX3I) 
+ , [Pedro Franceschi](https://www.linkedin.com/in/ACoAAAMevSMB2UXVJy_ab9lgQ0hxogGfo2T5BdE) ,
+  [Conrado Leister](https://www.linkedin.com/in/ACoAABW_584BTAIMtAXE_bDuARwAi3CNHXHXkHE) 
+ , [Guilherme Horn, PhD](https://www.linkedin.com/in/ACoAAAEZxqEBA_sZLsfQUxs5AKpOCeVHYFY9gOs) 
+ , [Fábio Coelho](https://www.linkedin.com/in/ACoAAAAEG5YBPClyv-gLf4Pie0ZNkOq6dvoUfRw) ,
+  [Gabriela Chaves Schwery Comazzetto](https://www.linkedin.com/in/ACoAAAD5xL4BF-uK8d-WodKgpgOlqpdBu2at01M) ,
+  [Guilherme Ribenboim](https://www.linkedin.com/in/ACoAAAAEm60BVPkc4wtDqJy1VXbcH7SO6wAP6Ek) ,
+  [Jonathas Freitas](https://www.linkedin.com/in/ACoAAATwxkYBN94L7mitTm6viVqxrIJuAN4Ih84) ,
+  [Marcio Waldman](https://www.linkedin.com/in/ACoAAAT_osUBxA9J46sjyYAi4VlO-cpb8ODSWDM) , 
+ [Paulo Fernandes](https://www.linkedin.com/in/ACoAAAD5wtABHdiMY8DXm_wHlzZS8f0er1x9Y-A) , [Patricia Muratori Calfat](https://www.linkedin.com/in/ACoAAAAGpj8BsPbMpJHXEUQWrGdwyY7FnfFsc1A) , [Cristina Junqueira](https://www.linkedin.com/in/ACoAAAF-Z-UBXOiCynOoLtdr6D48e-mVStKa8SU) , [Erick Bretas](https://www.linkedin.com/in/ACoAAAQJ86MB5jDDCPI1eoPGB1HZrpxuL4n12EY) , [Stelleo Tolda](https://www.linkedin.com/in/ACoAAAAFFvsBhWDxCXz514n-t-3P5yZk6Rw0XG0) , [Fabricio Bloisi](https://www.linkedin.com/in/ACoAAAAB5wgBnU6gULQF2GPOE1_1wB5JBu1TC6M) , [Daniel Mazini](https://www.linkedin.com/in/ACoAAAAM5LYByauZxukaJh8Z3qo7M4slt1Xfedg) , [elisabetta zenatti](https://www.linkedin.com/in/ACoAAA_jT-4BhX1OvXRnuStH32Wniz3QAQU0vcg) , [Felipe Feistler, CFA](https://www.linkedin.com/in/ACoAAAykE7UBE8eEXUgAp7V55AgemG4uFAU_0g0) , [Tania Cosentino](https://www.linkedin.com/in/ACoAAAE72zsB7mId93Um_XjUlLAUH0jkqpBdNgs) , [João Vitor Menin](https://www.linkedin.com/in/ACoAADE3fPQBnTv2KHjhisegl86g_gWWo2dxhIg) , [Frederico Trajano](https://www.linkedin.com/in/ACoAAAxCZPsBTMkE_D9DGdivYbvUN6NpYrmB2XY) , [Anna Saicali](https://www.linkedin.com/in/ACoAABXzTzoB56Z66Dp3Z1X_q-5uQsYgYZBnBfs) , [Suelen Marcolino](https://www.linkedin.com/in/ACoAAAViFwoB2UbR_SIds9ZlwiNvLemfIFst8e8) , [Fatima Pissarra](https://www.linkedin.com/in/ACoAAAAXDC0BFJaHUo0sn5X4wTncudh2a-pdemk) , [Marcelo Leal](https://www.linkedin.com/in/ACoAAAGmmRoB0piCiprnzkr_he9wSC-USJk3cqc) e o fenômeno [Erick Wendel](https://www.linkedin.com/in/ACoAABS1ckYBm0_ZMP8TT2e4opa3bFMxTRxyJ3w?lipi=urn%3Ali%3Apage%3Ad_flagship3_saved_items%3BWQihJD6rS1WKO%2B3rDuYtBQ%3D%3D) .

### (DE) Airflow + GreatExpectations Youtube Long video

https://www.linkedin.com/posts/engenharia-de-dados_bigdata-dataengineer-dataquality-activity-7008797215947165696-hdz9?utm_source=share&utm_medium=member_desktop

Você sabe o que é Data Quality e como este conceito pode ser 𝗮𝗽𝗹𝗶𝗰𝗮𝗱𝗼 𝗲 𝗼𝗿𝗾𝘂𝗲𝘀𝘁𝗿𝗮𝗱𝗼 com Apache Airflow? 🚀🔥

Na Live de hoje, Mateus Oliveira e Luan Moreno irão explicar o 𝗰𝗼𝗻𝗰𝗲𝗶𝘁𝗼 𝗱𝗲 𝗗𝗮𝘁𝗮 𝗤𝘂𝗮𝗹𝗶𝘁𝘆 e mostrar como é possível entregar pipelines blindados com o 𝗚𝗿𝗲𝗮𝘁 𝗘𝘅𝗽𝗲𝗰𝘁𝗮𝘁𝗶𝗼𝗻𝘀, uma das ferramentas que mais crescem nesse ecossistema.

O Great Expectations Operator torna possível executar um trabalho de qualidade de dados em um 𝐀𝐢𝐫𝐟𝐥𝐨𝐰 𝐃𝐀𝐆.

Com isso, você pode 𝐜𝐫𝐢𝐚𝐫 𝐞 𝐝𝐞𝐬𝐞𝐧𝐯𝐨𝐥𝐯𝐞𝐫 𝐩𝐢𝐩𝐞𝐥𝐢𝐧𝐞𝐬 𝐝𝐞 𝐝𝐚𝐝𝐨𝐬 𝐢𝐧𝐭𝐞𝐥𝐢𝐠𝐞𝐧𝐭𝐞𝐬 de forma que seja possível validar a qualidade e riqueza dos dados que são entregues.

🚨A Live será hoje, 𝟭𝟰 𝐝𝐞 𝐝𝐞𝐳𝐞𝐦𝐛𝐫𝐨, às 𝟮𝟬 𝐡𝐨𝐫𝐚𝐬. Participe!



### (Excel) O Excel novo consegue converter imagem de tabela em uma tabela CSV

https://www.linkedin.com/posts/gersonggv_excel-planilha-office365-activity-7008773167859044352-1tZB?utm_source=share&utm_medium=member_desktop

Veja como ficou fácil converter imagem em texto no Excel. Lembrando que está disponível apenas no Office 365.
Salve este post e não deixe de me seguir para mais dicas.



### (Front) Front Legal

https://www.linkedin.com/posts/abelardo-junior_reactjs-react-tech-activity-7008231225505026049-kSf-?utm_source=share&utm_medium=member_desktop

Saudações Rede!
Hoje foi dia de dá o pontapé inicial no tão temido ReactJS, confesso que ainda estou me adaptando, mas dizem que é assim mesmo no começo né?

Até aqui já foi aprendido e aplicado:
-Styled Components
-React Router
-React Hooks
-React Icons

Isso feito acompanhando um bootcamp chamado Orange Tech+ uma iniciativa do Banco [Inter](https://www.linkedin.com/company/inter/) na plataforma da [DIO](https://www.linkedin.com/company/dio-makethechange/) com o professor [Pablo Henrique](https://www.linkedin.com/in/ACoAACDF-aQBkWnrSvO8PKnl8k6fEwN2S0w8pqk)
[#reactjs](https://www.linkedin.com/feed/hashtag/?keywords=reactjs&highlightedUpdateUrns=urn%3Ali%3Aactivity%3A7008231225505026049) [#react](https://www.linkedin.com/feed/hashtag/?keywords=react&highlightedUpdateUrns=urn%3Ali%3Aactivity%3A7008231225505026049) [#tech](https://www.linkedin.com/feed/hashtag/?keywords=tech&highlightedUpdateUrns=urn%3Ali%3Aactivity%3A7008231225505026049) [#github](https://www.linkedin.com/feed/hashtag/?keywords=github&highlightedUpdateUrns=urn%3Ali%3Aactivity%3A7008231225505026049)
GitHub: https://lnkd.in/dGmQwWPK

### Portugues - Como usar 'mim'/'me'

MENTIRA que nos contam:
jamais se usa ‘mim’ antes de verbo.

Pode-se usar, sim!

Veja ambas as frases a seguir, que estão corretas:
1) É cansativo para mim preencher tanto documento!
2) Esse documento é para eu preencher?

Por que ambas estão corretas? Vamos ao macete:

1) Quando o trecho “para + pronome” puder ser trocado de posição na frase, o pronome deve ser o “mim”. Faça o teste na frase 1:
É cansativo para mim preencher tanto documento!
Para mim, preencher tanto documento é cansativo!
Preencher tanto documento é cansativo para mim!

2) Quando o trecho “para + pronome” não puder ser trocado de posição na frase, o pronome deve ser o “eu”. Faça o teste na frase 2 e veja como a troca de posição não dá certo:
Esse documento é para eu preencher?
Para eu preencher esse documento é?
Esse documento é preencher para eu?

RESUMO:
\- a troca de posição deu certo, usa-se ‘mim’.
\- a troca de posição não deu certo, usa-se ‘eu’.

(Obs.: Isso é um macete, tá?! Eu poderia explicar de uma forma teórica, falando em oração subordinada substantiva subjetiva reduzida de infinitivo, mas acho que muitos não compreenderiam.)

### DE - Carinha fazendo um projeto em DE e documentando tudo

PARTE 1

https://www.linkedin.com/posts/alan-roger-moreira-aragao-057875247_gostaria-de-compartilhar-um-projeto-que-estou-activity-7008622147568861184-r6_F?utm_source=share&utm_medium=member_desktop

PARTE 2

https://www.linkedin.com/posts/alan-roger-moreira-aragao-057875247_depois-de-muita-luta-avancei-no-projeto-activity-7008750978170531840-E4xs?utm_source=share&utm_medium=member_desktop



### (Front) Front legal

https://www.linkedin.com/posts/dsjonat_nextjs-typescript-web-activity-7007491394885836800-KoWv?utm_source=share&utm_medium=member_desktop

Landing page da Blizzard utilizando [#NextJS](https://www.linkedin.com/feed/hashtag/?keywords=nextjs&highlightedUpdateUrns=urn%3Ali%3Aactivity%3A7007491394885836800), [#TypeScript](https://www.linkedin.com/feed/hashtag/?keywords=typescript&highlightedUpdateUrns=urn%3Ali%3Aactivity%3A7007491394885836800), Context API e Styled Components.
Você pode testar aqui: https://lnkd.in/dVagxSBV

O projeto foi desenvolvido para um desafio da BRChallenges (https://lnkd.in/dBp4b78e), plataforma de desafios dev do [Leonardo Luis de Vargas](https://www.linkedin.com/in/ACoAACbwMMkBOcilXBr31t6L6RYmycxckXKje1g). A proposta era desenvolver a página da Blizzard a partir de um layout feito pelo [Gilberto Prado](https://www.linkedin.com/in/ACoAABJTF9kBAmp5W8KtKI3Su5_XMECXwTyEFgc), implementando alguns requisitos divididos entre fáceis, médios e difíceis.

Pretendo continuar realizando melhorias, a fim de aumentar a performance da página e a legibilidade do código.

Repositório: https://lnkd.in/dNivQgdP

### DE - Diferença entre batch e Streamming

https://www.linkedin.com/posts/dhanvanth-medoju_data-activity-7008651681521442816-Bhjy?utm_source=share&utm_medium=member_desktop

![](https://media.licdn.com/dms/image/C5622AQGzALzgIzyWgQ/feedshare-shrink_2048_1536/0/1670992773771?e=1674086400&v=beta&t=LCz7zqlthkKQToWb6Gp01aiG1GzFVAOq151BHJmnbsw)

### Resume - Como fazer

https://www.linkedin.com/posts/jonathan-wonsulting_resume-jobsearch-jwow-activity-7008445429667282945-zvYH?utm_source=share&utm_medium=member_desktop

LinkedIn: I’m breaking down step-by-step the [#resume](https://www.linkedin.com/feed/hashtag/?keywords=resume&highlightedUpdateUrns=urn%3Ali%3Aactivity%3A7008445429667282945) I had after working at Snap + Google.

I promise you it’ll help you, whether you're looking for your next job or have been affected by layoffs, so feel free to share with those who are on the journey (And get help on your [#JobSearch](https://www.linkedin.com/feed/hashtag/?keywords=jobsearch&highlightedUpdateUrns=urn%3Ali%3Aactivity%3A7008445429667282945) here:https://bit.ly/3pDbGLV). I've done these for many years now to help job-seekers and have taken feedback from previous posts; I color coordinated for easier accessibility👇

💡Red = Action Verbs: started w/ each resume bullet; Ex: collaborated (teamwork skills), managed (leadership skills), improved (efficiency), scaled (outside the box thinking). Put present if current role (Collaborate); if past, put -Ed (Collaborated)

💡Orange = Hard Skills/Tools: Specific hard skills/tools/platforms based on job title's qualifications (esp. minimum qualifications). Bottom of resume where "skills" are, I want to make sure they are throughout resume. Thought process: if a recruiter were to see if I had X experience in my skills, where could they find it on my resume bullets? Took a look at 5 job descriptions for target job to see which skills showed consistently

💡Near bottom = Education: When I was a student/new grad, I kept at the top; after, moved near bottom; add where you graduated + location. Optional parts: GPA (if student, add if over 3.5; if not omit), organizations/awards (IMO: become irrelevant once you get later onto your career), relevant coursework (IMO: only relevant if you have 0 experience in the field you're trying to get into), graduation date (Omit; unfortunately, have seen situations where there is "ageism")

💡Header: Location as "City, State" (Full address = not needed), LinkedIn (linked), phone number, and email (Optional: Portfolio/Personal Website)

💡Light green = impact metrics: these are numbers and percentages showcasing my impact within my roles. How did I get these numbers? I either a) asked my peers/managers b) calculated estimations based on own observations (Note: Do not lie on your resume. Ex: if you add you increase revenues by 15,000%, it seems not possible unless you had 0 revenues)

💡Cyan = Impact statements before the number/percentages: This showcases if I improved, optimized, or made an impact in a role.

💡Yellow = soft skills: broad or simple statements; Ex: collaboration, providing recommendations, and identifying solutions. I don't add these as "skills" at bottom because I'd rather showcase in experience bullets

Notes:
\- For my bullets, I'll usually follow a structure where I have the responsibility as the first half, separate the impact with a comma
\- It was difficult for me to break into companies until I get my first offer at Snap (utilized a LOT of networking). Once you get your first role, it is much easier to land more so if you're getting rejected, don't give up!

If you have any questions, feel free to leave them below. I'm just here to help you as much as I can, so follow for more breakdowns👀💡

![](https://media.licdn.com/dms/image/D5622AQFEWLzssZ7hXA/feedshare-shrink_800/0/1670916995636?e=1674086400&v=beta&t=tmY-EeWMnSJ-xBg23Rzs9CFYvt_jughYfK3R63U0zNk)

### Melhorar git com Rafael Balistrini

https://www.linkedin.com/posts/winiciuscastanha_github-tecnologia-programacao-activity-7008281614606581760-uKTK?utm_source=share&utm_medium=member_desktop



### (Publish Linkedin) Como publicar certificaod no linkedin

https://www.linkedin.com/posts/vivianbotelhoeng_metodopeai-engenhariaecarreira-activity-7008581562820661248-mjhD?utm_source=share&utm_medium=member_desktop

COMO PUBLICAR CERTIFICADOS NO LINKEDIN?
Não se trata do passo a passo de como fazer isso.

Isso você encontra facilmente na internet.
É como fazer de forma estratégica.
Mas antes, me fale.
Você costuma publicar seus certificados no Linkedin?

ERROS QUE VOCÊ COMETE AO PUBLICAR SEU CERTIFICADO NO LINKEDIN!

Não basta postar por postar.
Tudo que você publica no Linkedin precisa ter um propósito.

Não vá me dizer que o propósito que é dizer que você concluir o curso X.
Que vai agregar... e tal.
Não, um NÃO bem sonoro, para você nunca mais publicar sem estratégia.

Ter um certificado, não significa necessariamente que você aprendeu algo.

Quantas vezes é burlado, deixando rolar ou buscando as respostas no Passei Direto.

Então, toda vez que você publicar seu certificado, você usará desta estratégia:
Você não vai ficar agradecendo, por mais uma conquista, e o quanto está feliz.

Quando você postar, irá descrever, como você aplicará ou já está aplicando aquele conhecimento de forma tangível.
Inclusive, dependendo do curso, até em sua vida pessoal.

Digamos que seja um BIM, que você tenha utilizado para catalogar algo e no final.
Irá fazer uma pergunta, se outras pessoas já usaram para outras finalidades, ou

onde como utilizam tal técnica... você terminará sua publicação com uma pergunta.
E desta forma, terá engajamento e sua publicação alcançará mais pessoas

principalmente os recrutadores.
Te convido a me seguir e aprender outras estratégias para que você cresça na sua carreira na Engenharia.

Toda vez que você pensar em publicar o seu CERTIFICADO.
Você vai lembrar do que eu vou te ensinar.

### DE - Déficit em Data Engineering

COMO PUBLICAR CERTIFICADOS NO LINKEDIN?
Não se trata do passo a passo de como fazer isso.

Isso você encontra facilmente na internet.
É como fazer de forma estratégica.
Mas antes, me fale.
Você costuma publicar seus certificados no Linkedin?

ERROS QUE VOCÊ COMETE AO PUBLICAR SEU CERTIFICADO NO LINKEDIN!

Não basta postar por postar.
Tudo que você publica no Linkedin precisa ter um propósito.

Não vá me dizer que o propósito que é dizer que você concluir o curso X.
Que vai agregar... e tal.
Não, um NÃO bem sonoro, para você nunca mais publicar sem estratégia.

Ter um certificado, não significa necessariamente que você aprendeu algo.

Quantas vezes é burlado, deixando rolar ou buscando as respostas no Passei Direto.

Então, toda vez que você publicar seu certificado, você usará desta estratégia:
Você não vai ficar agradecendo, por mais uma conquista, e o quanto está feliz.

Quando você postar, irá descrever, como você aplicará ou já está aplicando aquele conhecimento de forma tangível.
Inclusive, dependendo do curso, até em sua vida pessoal.

Digamos que seja um BIM, que você tenha utilizado para catalogar algo e no final.
Irá fazer uma pergunta, se outras pessoas já usaram para outras finalidades, ou

onde como utilizam tal técnica... você terminará sua publicação com uma pergunta.
E desta forma, terá engajamento e sua publicação alcançará mais pessoas

principalmente os recrutadores.
Te convido a me seguir e aprender outras estratégias para que você cresça na sua carreira na Engenharia.

Toda vez que você pensar em publicar o seu CERTIFICADO.
Você vai lembrar do que eu vou te ensinar.

### (Exterior) Vagas para Portugal

https://www.linkedin.com/posts/leandro-baptista-international-career_%3F%3F%3F%3F%3F%3F-%3F-%3F%3F%3F%3F-%3F%3F-%3F%3F%3F%3F%3F-activity-7008406964326035456-D8iJ?utm_source=share&utm_medium=member_desktop

𝗔𝗰𝗲𝘀𝘀𝗼 𝗮 𝗺𝗮𝗶𝘀 𝗱𝗲 𝟱𝟴.𝟬𝟬𝟬 𝗼𝗳𝗲𝗿𝘁𝗮𝘀 𝗱𝗲 𝗲𝗺𝗽𝗿𝗲𝗴𝗼 𝗲𝗺 𝗣𝗼𝗿𝘁𝘂𝗴𝗮𝗹 𝗰𝗼𝗺 𝗲𝘀𝘀𝗮 𝗳𝗲𝗿𝗿𝗮𝗺𝗲𝗻𝘁𝗮.

Ontem conheci o novo portal da RestartUs, com uma ferramenta que agrega todas as oportunidades remotas e presenciais dos principais sites de lá.

🤖 E ainda usa IA para organizar e apresentar as oportunidades de mais de 11 mil empregadores recrutando por lá agora.

Achei uma solução muito legal e parece que no futuro vai haver até recompensas em crypto pra quem usar a plataforma.

Pega aqui o link nos comentários e dá um confere 👇



### (OCR) - Python e WebScraping 

https://www.linkedin.com/posts/pedroalonsol_automatizando-um-pouco-a-busca-por-im%C3%B3veis-activity-7008138955464302592-f4E3?utm_source=share&utm_medium=member_desktop

Já pensou em automatizar (parcialmente) um dos capítulos mais estressantes da vida adulta?

Compartilho com vocês esse breve texto que fiz com um guia de webscraping em Python, em páginas de imóveis disponíveis para aluguel.

Pra galera que gosta de planilhar tudo mas sabe que às 18h a vista pós trabalho já tá cansada e merece descanso, o programinha que ensino vocês a construirem extrai tudo que importa de cada página e salva em um CSV. Tudo pra vocês não perderem recursos valiosos caçando número pequeno e astericos nos rodapés por aí...

https://lnkd.in/dmEckGbr

Críticas são extremamente bem-vindas!

[#webscraping](https://www.linkedin.com/feed/hashtag/?keywords=webscraping&highlightedUpdateUrns=urn%3Ali%3Aactivity%3A7008138955464302592) [#cienciadedados](https://www.linkedin.com/feed/hashtag/?keywords=cienciadedados&highlightedUpdateUrns=urn%3Ali%3Aactivity%3A7008138955464302592) [#html](https://www.linkedin.com/feed/hashtag/?keywords=html&highlightedUpdateUrns=urn%3Ali%3Aactivity%3A7008138955464302592) [#automatização](https://www.linkedin.com/feed/hashtag/?keywords=automatização&highlightedUpdateUrns=urn%3Ali%3Aactivity%3A7008138955464302592)



### ML - ML Tool documentos e pdf

POST 1

https://www.linkedin.com/posts/karndeepsingh_fine-tune-lilt-model-for-information-extraction-activity-7007935112940019712-F0Mx?utm_source=share&utm_medium=member_desktop

Post 2

https://www.linkedin.com/posts/karndeepsingh_annotate-text-pdf-image-documents-for-activity-7005541820352892928-TTUO?utm_source=share&utm_medium=member_desktop

(Document AI) :

Annotation is the most crucial task in any Machine Learning or Deep Learning Project. Finding reliable and easy tools to annotate the data with better accuracy is always difficult. UBIAI annotation is one of them, it has the following merits:
👉 Image Documents and PDF annotation and data preparation for training LayouLM models.
👉 Text annotation for NER and Joint Relationship Extraction model Training.
👉 Image Classification and Document Classification.
👉 Auto Labelling to fasten the process of annotation on Image Documents, PDFs, or Text.
👉 Team Collaboration and Management for annotation.
👉 Multi-Lingual Annotation.
👉 Inbuilt Training of NLP-based models like LayoutLM Models, Spacy-based models, etc.


📌 Best part of the tool is that it can also be used by Non-Techincal people. It has a zero-code model training process and annotation process.

➡️ If you want to try the tool for your NLP and PDF or Image Documents projects. You can signup using the following link:
UBIAI Tool Signup Link: https://lnkd.in/dMsQ5FmE

Please watch the video and let me know your views on it.
If you like my efforts and want to explore more such content on Machine Learning, Computer Vision, and Natural Language Processing.
Please support the channel by subscribing to it.
👉 Here is the link to my YouTube channel: https://lnkd.in/ePk24zd
👉 Join Telegram Group:https://lnkd.in/gfdk7Q6





### (Exterior) matéria no correio brasiliens

https://www.linkedin.com/posts/lucas-renan-galindo-lourenco_fuga-de-c%C3%A9rebros-do-brasil-para-o-exterior-activity-7007778530549751808-fy-z?utm_source=share&utm_medium=member_desktop



### Apache NiFi BRASIL



https://www.linkedin.com/posts/eliezerzarpelao_apache-nifi-br-activity-7007726794527129600-CHyh?utm_source=share&utm_medium=member_desktop

[#ApacheNiFi](https://www.linkedin.com/feed/hashtag/?keywords=apachenifi&highlightedUpdateUrns=urn%3Ali%3Aactivity%3A7007726794527129600)
Há alguns anos, participei de um projeto que utilizou Apache NiFi e na época sentimos a falta de uma comunidade sobre a ferramenta no Brasil. Tinha apenas um pequeno grupo no Telegram (que hoje já tem mais de 200 pessoas!). Recentemente nesse grupo surgiu a idéia de termos um repositório focado na comunidade brasileira. Montamos um GitHub Pages (https://nifibr.github.io/) para facilitar o acesso a conteúdos em português do tema.

Caso você seja da área de dados e trabalhe com a ferramenta, ou tenha interesse, participe de nossa comunidade. Ajude na divulgação e contribua com conteúdos no portal.

Link do portal: https://nifibr.github.io/
Link do grupo Telegram: https://t.me/nifibrasil
Repositório do portal: https://lnkd.in/daEVZdpA

[The Apache Software Foundation](https://www.linkedin.com/company/the-apache-software-foundation/)
[#apachenifi](https://www.linkedin.com/feed/hashtag/?keywords=apachenifi&highlightedUpdateUrns=urn%3Ali%3Aactivity%3A7007726794527129600) [#nifi](https://www.linkedin.com/feed/hashtag/?keywords=nifi&highlightedUpdateUrns=urn%3Ali%3Aactivity%3A7007726794527129600) [#comunidade](https://www.linkedin.com/feed/hashtag/?keywords=comunidade&highlightedUpdateUrns=urn%3Ali%3Aactivity%3A7007726794527129600) [#dados](https://www.linkedin.com/feed/hashtag/?keywords=dados&highlightedUpdateUrns=urn%3Ali%3Aactivity%3A7007726794527129600) [#nifibr](https://www.linkedin.com/feed/hashtag/?keywords=nifibr&highlightedUpdateUrns=urn%3Ali%3Aactivity%3A7007726794527129600) [#github](https://www.linkedin.com/feed/hashtag/?keywords=github&highlightedUpdateUrns=urn%3Ali%3Aactivity%3A7007726794527129600) [#dataflow](https://www.linkedin.com/feed/hashtag/?keywords=dataflow&highlightedUpdateUrns=urn%3Ali%3Aactivity%3A7007726794527129600)

[Rodolfo Duarte Dias](https://www.linkedin.com/in/ACoAAAKtNRYBmcWgrh_zwy7DsYrzvZ_dJckYPV8) [Anselmo Borges](https://www.linkedin.com/in/ACoAAAEbMgIB7gIjiFQniGquVRIxYgr9OS_gXGQ) [Rafael Bento](https://www.linkedin.com/in/ACoAAArfxhYBYGHeF3ehbRCA-_DjFEZrEG6rpho) [Gustavo Lima](https://www.linkedin.com/in/ACoAAAIwk0wBm7sXjWL0tlRpHFC6MSJ3DAax42Y) [Khaio Lopes](https://www.linkedin.com/in/ACoAACxQVfcB72Tw2ryWpnWuNWHIZvN-br3W6Ko) [Roberto Marques](https://www.linkedin.com/in/ACoAAALEBrUBOsgitzsW6JLtnmWKy1EG_4U6ggk) agradeço se puderem marcar nos comentários quem vocês conheçam que trabalhem com a ferramenta para fomentar a comunidade.



### (Exterior) Como você é tratado no BR e fora

https://www.linkedin.com/posts/4lex_uns-meses-atr%C3%A1s-tive-uma-conversa-bem-ruim-activity-7007806111521124352-hu4N?utm_source=share&utm_medium=member_desktop

Uns meses atrás tive uma conversa bem ruim com um desses "influencer" aqui do LinkedIn por DM, sobre trabalho no exterior.

Ele deu uma rápida olhada no meu perfil e viu que sai de júnior pra sênior em menos de 2 anos e disse.

Empresas sérias vêem minha carreira com maus olhos e que isso não existe no exterior.

Eu respondi que aqui no Brasil tbm é assim, mas Deus abriu os caminhos e que nas empresas em que passei sempre fiz um bom trabalho, por isso consegui promoções tão rapidamente.

Ele continuou tentando me diminuir e dizendo que minha trajetória era estranha como se fosse "SORTE" começou a falar que pleno é de 3 a 5 anos e sênior disso pra cima, como se fosse uma receita de bolo a carreira das pessoas.

Depois dessa agradeci e parei de responder.

Podia ter falado que minha carreira começou quando fiz meus primeiros websites com 17 anos usando Dreamweaver, quem lembra hahaha.

Só parei pq morava em cidade pequena e não tinha muitas empresas que trabalhassem com isso há 20 anos atrás.

Podia ter falado que quando voltei a programar, veio a pandemia e perdi o emprego, na época de marceneiro, e ao invés de procurar outro decidi estudar o dia todo.

Acordava às 06:00 e ia até às 22:00 as vezes até virava a noite inclusive nos fim de semana.

Fiz isso por 4 meses ininterruptos, aprendi e me desenvolvi demais, detalhe tudo isso em um Intelbras que ganhei da minha mãe.

Fui chamado de volta pra mesma empresa que sai ainda como marceneiro, só que voltei já com a cabeça que ia ser programador.

Riram de mim quando falei que ia ser programador (até hoje não consigo escrever isso sem marejar os olhos).

Além de estudar no horário do almoço, fiz um acordo com minha esposa e filhos que chegaria em casa e ia direto pro estudo, no mínimo das 19:00 as 22:00 todos os dias e sábados pegava o dia todo.

Podia ter falado que fiz mais de 100 cursos nesse tempo, muito mais que 100, pq nem todos davam certificados, fora os que fiz de novo pra guardar bem as informações.

Podia ter falado que pra conseguir minha primeira oportunidade me cadastrei em umas centenas de vagas, que fiz uns milhares de testes de fit cultural, personalidade, logicos e fiz mais de 50 entrevistas.

Tive momentos que pensei em desistir, tive momentos em que achei que programação não era pra mim, tive momentos que duvidei que um dia ia conseguir entrar na área.

Podia ter falado que enquanto eu era júnior, pleno e até hoje que sou sênior continuo estudando cada dia mais e com ainda mais afinco.

Recebi 49 nãos mas eu só precisava de um sim.

Tenho muito orgulho da minha carreira até aqui e tenho a plena convicção de que se não fosse Deus me ajudando, dando forças, clareza e se não tivesse o apoio total da minha esposa e filhos eu não teria conseguido.

Nunca foi sorte, sempre foi Deus.

### Cracking All - Google Interview Questions

https://www.linkedin.com/posts/arslanahmad_google-datastructures-algorithms-activity-7007608063645933568-GeZ5?utm_source=share&utm_medium=member_desktop

### (Currículo) O que falar sobre os certificados

https://www.linkedin.com/posts/marciacastagna_tech-github-recruiters-activity-7007479852299632640-jJPI?utm_source=share&utm_medium=member_desktop

É legal postar certificados aqui no LinkedIn?

Sim, dá orgulho de mais um degrauzinho que subimos. Mas...

... é mais legal ainda (junto com o post do certificado):

1) Escrever o que você aprendeu no curso. Escreva com suas próprias palavras, não precisa copiar do conteúdo programático/ementa

2) Postar o link do seu Github com o projeto que desenvolveu durante o curso, notas de estudos, Notion, Readme, etc... como resolveu algum problema que teve durante o curso (outro coleguinha pode passar pelo mesmo perrengue)

3) Durante o curso você achou algo muito legal? Poste! Pode ser algo que ajude alguém. E nem precisa esperar a conclusão do curso para isso.

Assistiu uma live bem bacana? Edite seu post (para quem tem o hábito de postar qdo tá assistindo a live), escreva o que você aprendeu de mais relevante. Ou ainda, escreva um artigo, um resumo sobre o mesmo.

Leu um livro top? Que tal escrever algo sobre o livro, algo que te marcou?

Enfim, acredito que cada post que trazemos para a rede, temos a oportunidade de:

1) Trabalhar nosso personal branding

2) Compartilhar com outras pessoas esses conhecimentos

3) Para quem é JR, para quem está tentando ingressar na área, isso é muito mais efetivo aos olhos das tech recruiters do que só dizer que você busca uma oportunidade (nada contra, mas se põem no lugar da recrutadora, ela tem centenas de profissionais querendo uma primeira oportunidade, no que você se destaca? qual seu diferencial?).

Já vi uma galera ser contratada mesmo sem experiência, porque mostrou a relevância de seus estudos no Github. Por ter aprendido algo e feito uma série de vídeos aulas no YouTube (criou canal) para ajudar outros aspirantes na área

4) Qto mais escrevemos sobre algo que foi estudado, mais validamos o que aprendemos. Escrever sobre algo, ajuda a internalizar o novo conhecimento ou relembrar algo esquecido

5) Trabalhar o perfil do LinkedIn de forma estratégia. É ótimo estar empregado em um lugar bacana, mas e se amanhã a empresa precisar te desligar por "n" razões? Agora mesmo, a qtde de demissoes em massa que está acontecendo! Como está seu networking por aqui? Como você ajudou o algoritmo do LinkedIn a te rankear?

Acredito que essa rede social tem um potencial incrível. Tem posts chatos? Tem. Mas tem muita coisa ótima! E temos o potencial de agregar mais ainda, com posts recheados de conteúdos que agregam valor.



### (Currículo) - Dica

https://www.linkedin.com/posts/eduardomfelix_carreiras-rh-activity-7007468232248823808-K8v3?utm_source=share&utm_medium=member_desktop

### DE - Relato de curso da XP sobre DE

https://www.linkedin.com/posts/julioszeferino_kubernetes-cloud-arquitetura-activity-7007424392011902978-ZxJ5?utm_source=share&utm_medium=member_desktop

No trabalho pratico da disciplina "Arquiteturas de Dados Escaláveis" do Bootcamp Engenheiro de Dados Cloud da [XP Educação](https://www.linkedin.com/company/xpeducacao/), fomos desafiados pelo professor a subir uma aplicação em um cluster Kubernetes.

Ja ha algum tempo venho criando APIs utilizando o FastAPI e encontrei uma ótima oportunidade de testar uma nova forma de realizar seu deploy.

Com a criação de uma API simples, com apenas um método de requisição GET, foi possível subir uma POC no cluster. Aos poucos pretendo ir incrementando a API com mais funcionalidades.

O repositório do projeto esta no primeiro comentário.

E você, como descobriu o kubernetes? Que projetos você ja desenvolveu com base nessa arquitetura?

Por aqui, sigo estudando e me desenvolvendo! 🚀 📚
Boas analises!







### (Front) - Exemplo de Projeto

https://www.linkedin.com/posts/nairalimac_github-nairalimachome-went-project-went-activity-7007154849137999872-DjPh?utm_source=share&utm_medium=member_desktop

E aí pessoal! 😄

Este é o meu projeto pessoal, o nome dela é: WENT LOGISTIC.

Este projeto começou alguns anos atrás com alguns amigos, e decidi usá-lo como base em meus estudos/portfolio de Front End.



### (DS) Handler missing data

https://www.linkedin.com/posts/danny-butvinik_machinelearning-datascience-activity-7006501447424991232-VREo?utm_source=share&utm_medium=member_desktop

![](https://media.licdn.com/dms/image/C4D22AQHdlgVUw6vZIw/feedshare-shrink_800/0/1670480117583?e=1674086400&v=beta&t=UyytdwQE6ujV1jrnwfNrKdg72MNxDePxL6WbXV1mFB4)

### SQL - dicas de query

Maybe you can WRITE SQL, but are you writing ✨GOOD SQL✨?

SQL is more than just writing a query without errors…

Here’s 10 query optimization tips:

\1. Avoid SELECT * and instead list desired columns

\2. Use INNER JOINs (and abolish OUTER JOINs)

\3. Use WHERE and LIMIT to filter rows

\4. Use WHERE instead of HAVING

\5. Avoid ORDER BY (especially in subqueries and CTEs)

\6. Avoid using DISTINCT (especially when it’s already implied like in GROUP BY & UNION)

\7. Avoid subqueries (especially nested)

\8. Avoid using wildcards at the beginning of a string (‘%jess%’ vs. ‘jess%’)

\9. Use EXISTS instead of COUNT and IN

\10. Avoid complex logic in WHERE clause and JOINs



### TabNews - Como trabalhar remoto

https://www.linkedin.com/posts/filipedeschamps_como-consegui-trabalhar-remotamente-para-activity-7006763077220114432-X3bw?utm_source=share&utm_medium=member_desktop



### Construindo uma Stack Moderna de DE

https://www.linkedin.com/posts/luanmoreno_bigdata-engenhariadedados-stackdedados-activity-7006768697759420416-zcw8?utm_source=share&utm_medium=member_desktop

Coloque em prática o conceito de 𝗠𝗼𝗱𝗲𝗿𝗻 𝗗𝗮𝘁𝗮 𝗦𝘁𝗮𝗰𝗸!

Dia 𝟮𝟬 𝗱𝗲 𝗱𝗲𝘇𝗲𝗺𝗯𝗿𝗼, às 𝟭𝟴𝗵𝟯𝟬, no Workshop “𝘾𝙤𝙣𝙨𝙩𝙧𝙪𝙞𝙣𝙙𝙤 𝙪𝙢𝙖 𝙎𝙩𝙖𝙘𝙠 𝙙𝙚 𝘿𝙖𝙙𝙤𝙨 𝙈𝙤𝙙𝙚𝙧𝙣𝙖 𝙘𝙤𝙢 𝘼𝙞𝙧𝙗𝙮𝙩𝙚, 𝘼𝙞𝙧𝙛𝙡𝙤𝙬, 𝘿𝘽𝙏 & 𝙎𝙣𝙤𝙬𝙛𝙡𝙖𝙠𝙚 𝙣𝙖 𝙋𝙧𝙖́𝙩𝙞𝙘𝙖”, você irá aprender a criar uma solução de ETL/ELT utilizando este conceito, usando as seguintes ferramentas:

▪️ 𝗔𝗶𝗿𝗯𝘆𝘁𝗲 = Ingestão de Fontes de Dados Heterogêneas;

▪️ 𝗗𝗕𝗧 = Processamento de Dados com a Linguagem SQL;

▪️ 𝗦𝗻𝗼𝘄𝗳𝗹𝗮𝗸𝗲 = Data Warehouse para Entrega de Dados;

▪️ 𝗔𝗶𝗿𝗳𝗹𝗼𝘄 = Orquestração do Pipeline de Dados.

### ChatGPT que faz resumo de artigo cientifico

https://www.linkedin.com/posts/maxim-ziatdinov-651aab250_chatgpt-activity-7006802750235627520-kXKV?utm_source=share&utm_medium=member_desktop

I told [#ChatGPT](https://www.linkedin.com/feed/hashtag/?keywords=chatgpt&highlightedUpdateUrns=urn%3Ali%3Aactivity%3A7006802750235627520) to interview me about my recent paper and then write a 'news article' about it. And it did. My mind is officially blown 🤯

(it also writes pretty decent code, solves computational physics problems, and writes movie scripts, among other things)



### ???

https://www.linkedin.com/posts/amandarodriguescruz_im-happy-to-share-that-im-starting-a-new-activity-7006345205373132800-Wn6B?utm_source=share&utm_medium=member_desktop

### Annotations em Spring

https://www.linkedin.com/posts/michellibrito_springboot-spring-java-activity-7006611538006433792-HiwI?utm_source=share&utm_medium=member_desktop

### Exterior - ir para Malta

https://www.linkedin.com/posts/lucasalbuquerquecode_dica-pra-voc%C3%AA-que-tem-o-desejo-de-sair-do-activity-7006678181063606273-9-6R?utm_source=share&utm_medium=member_desktop

Dica pra você que tem o desejo de sair do Brasil.

Encontrar emprego em Malta em tecnologia é rápido. Morei lá e posso te garantir que existem muitas vagas e pouca mão de obra.

O país é muito bonito, tem excelente gastronomia, extrema segurança, ótimos imóveis, hospitais e também um ótimo aeroporto.

Talvez não seja o seu plano número 1.

Mas eu consideraria se estivesse pensando em sair do Brasil.

Se quiser mais informações, me chama no inbox

### Trilha de BI

https://www.linkedin.com/posts/irisdataeanalytics_python-powerbi-businessintelligence-activity-7006602701681635328-bCCk?utm_source=share&utm_medium=member_desktop

Trilha de Business Intelligence 🎯 💻
Links para acesso a conteúdos gratuitos:
Link 1 - https://lnkd.in/g5KSScea ---------Excel
Link 2 - https://lnkd.in/ducVmaqh ---------SQLServer
Link 3 - https://lnkd.in/g3BQkh9B -------- Estatistica
Link 4 - https://lnkd.in/gSUzD7W6 -------- power bi
Link 5 - https://lnkd.in/gv9aPZzK -------- Tableau
Link 6 - https://lnkd.in/gU8CVc_U -------- Qlik
Link 7 - https://lnkd.in/gv_aKX_7 -------- Google DataStudio
Link 8 - https://lnkd.in/gnWuRE3X -------- SAS
Link 9 - https://lnkd.in/gJBjA9HM -------- Storytelliing
Link 10 - https://lnkd.in/gcWrqahM -------- UI/UX
Link 11 - https://lnkd.in/gHxJrnmN -------- OKR
Link 12 - https://lnkd.in/gcFGbzjd -------- KPI no Excel
Link 13 - https://lnkd.in/dbidmETk -------- Python
Link 14 - https://lnkd.in/dgE5uBqT -------- R
Link 15 - https://lnkd.in/gfVTE3QH -------- Python Pandas
Link 16 - https://lnkd.in/g65ew6xW -------- R programando
Link 17 - https://lnkd.in/gMabhWmg -------- O que é BI
Link 18 - https://lnkd.in/gUhA3_JZ -------- A importancia do BI

### Como aprender ingles

Aprendi inglês de verdade aos 34 anos, porém aos 31 fui fazer meu primeiro curso fora do Brasil, nos Estados Unidos e tive que aprender a escutar e a ler.

Pra quem quer aprender a ler e escutar vou contar o intensivão que eu fiz por 3 meses 5h/dia (inclusive sábado e domingo) e me ajudou demais:

\- séries e filmes em inglês com legenda em inglês (meu preferido era o Friends que eu já havia assistido todos os episódios e sabia as falas quase de cor)
\- zerei o [Duolingo](https://www.linkedin.com/company/duolingo/)
\- zerei o [Rosetta Stone](https://www.linkedin.com/company/rosettastone/)
\- zerei o [Pimsleur Language Programs](https://www.linkedin.com/company/pimsleur-language-programs/)

Os dois últimos são pagos. Um pouco caro mas vale muito muito a pena.

E você, também deu seu jeito de aprender sozinho ou sozinha? Conta aí!

Bons estudos.

### KPI



![](https://media.licdn.com/dms/image/C5622AQHO-GQp0Ey4dg/feedshare-shrink_800/0/1670249396251?e=1674086400&v=beta&t=KKx_hnv4kJ--dt9dZCAqnFes7iVyRZIjGuxeLBRGK4U)

### 9 FONTES DE COISAS MUITO BOAS

https://www.linkedin.com/posts/benmeer_9-free-websites-to-accelerate-your-learning-activity-7006251333703892992-F1EE?utm_source=share&utm_medium=member_desktop

### (Currículo) Erros para não cometer no seu linkedin

https://www.linkedin.com/posts/jonathan-mathias_dicas-linkedin-activity-7006194346651746304-6_G3?utm_source=share&utm_medium=member_desktop

### (!!) (Currículo) (ML) Como criar um repositório de ML em 10 passos

https://www.linkedin.com/posts/miguelgfierro_how-to-create-a-data-science-portfolio-in-activity-7006164512290549760-Mcdg?utm_source=share&utm_medium=member_desktop

### DE - CheatSheet de DataEngineering

https://www.linkedin.com/posts/mattmayo13_7-essential-cheat-sheets-for-data-engineering-activity-7005913584467628033-xvDf?utm_source=share&utm_medium=member_desktop

𝟳 𝗘𝘀𝘀𝗲𝗻𝘁𝗶𝗮𝗹 𝗖𝗵𝗲𝗮𝘁 𝗦𝗵𝗲𝗲𝘁𝘀 𝗳𝗼𝗿 𝗗𝗮𝘁𝗮 𝗘𝗻𝗴𝗶𝗻𝗲𝗲𝗿𝗶𝗻𝗴
Learn about the data life cycle, PySpark, dbt, Kafka, BigQuery, Airflow, and Docker.

### Post sobre Modern Data Stack

Olá, pessoal!

Espero que todos estejam bem! 😊

Dias atrás comentei que estava preparando um texto comentando minha visão sobre aplicação de Modern Data Stack como ferramenta impulsionadora da jornada Data-Driven, especialmente para empresas que já acenderam a luz para o interesse na busca da atuação orientada a dados.

https://link.medium.com/DxhJSAo5xvb



### (English) Como aprender inglês de uma vez



Já pensou em trabalhar remoto para o exterior e ganhar em dólar, mas ainda não domina o inglês? 👇


Separe 1h por dia, durante 6 meses para se dedicar ao idioma.

\- Primeiros 30 dias, faça atividades do Duolingo ou outro app equivalente para relembrar gramática e aumentar vocabulário. Faça todas as atividades, lendo em voz alta para começar a ganhar memória muscular.

\- No 31º dia, comece a introduzir podcasts que focam no ensino do idioma. Pode dividir 1h de estudo entre o App e os Podcasts. Isso vai dar um boost no seu listening. Recomendo Happy English ou Daily Easy English Expressions. Repita as expressões em voz alta, se não conseguiu entender, volte e tente acompanhar com a descrição do audio.

\- no 61º dia, comece a acompanhar videos e podcasts, sem legenda. Procure por temas que você gosta, pode ser no youtube, ou twitch.

\- no 91º dia, entre em um grupo de conversação do discord, como o discord[dot]gg/english ou language sloth, ou se preferir, jogos online com chat de audio também funcionam. Substitua 2 dias de estudos por 2 dias de grupo (1h/dia). No inicio você pode entrar apenas para ouvir, e ao poucos começa a falar.

\- No 121º dia, você precisa dar um boost no seu vocabulário técnico, porque vai precisar disso para as entrevista. Então comece a consumir conteúdo como Palestras e posts, somente em inglês, sobre os assuntos técnicos da sua área.

Nessa altura talvez não faça mais sentido você continuar com o App, porque não trará tanta evolução, nem os podcasts de 5min. Foque em consumir o conteúdos técnicos e participar dos grupos de conversação. Se possível, aumente para 3 dias por semana os grupos. Continue focado pelos próximos 60 dias.

Não se engane, manter a rotina de 1h por dia por 180 dias não é fácil. Mas se é isso que está te impedindo de ganhar até 5x mais, vale o esforço!

Tem mais dicas? Comenta aí! 🔥

### DE Project

https://www.linkedin.com/posts/kv-kiran_happylearning-data-dataengineering-activity-7005871643461849088-0WT5?utm_source=share&utm_medium=member_desktop

Stock Market Real-Time Data Analysis Using Kafka

In this project, we will execute an End-To-End Data Engineering Project on Real-Time Stock Market Data analysis using Kafka.

Technology used

 Programming Language - Python 
 Amazon Web Service (AWS)
 S3 (Simple Storage Service),
 Athena
 Glue Crawler
 Glue Catalog
 EC2
 Apache Kafka

### DE - Sobre saber usar as coisa de DE

https://www.linkedin.com/posts/rodrigo-santana-ferreira-0ab041128_dataengineering-activity-7005902415564562432-QXtg?utm_source=share&utm_medium=member_desktop

Algumas considerações após alguns anos no mercado…

\- Saber quando usar Spark é mais importante do que saber sobre amazon EMR.
\- Saber quando usar AWS Glue é mais importante que saber sobre Glue
\- Saber quando trabalhar com Delta Lake é mais importante que saber sobre Delta.
\- Saber quando usar DMS ou Airbyte é mais importante que saber tudo sobre essas ferramentas de ingestão.
\- Saber sobre qual modelo de Machine Learning usar é mais importante que saber sobre o algoritmo estado da arte.
\- Saber quando usar uma tecnologia é mais importante do que saber usar a tecnologia.



### (RPA Python Supreme) Best courses/tools

8 Python frameworks to automate Desktop, Web, Citrix and Mobile Applications

(Don't forget to star the projects on Github to support them):


Selenium with Python for web automations:
https://lnkd.in/d9me3xyy

Pyppeteer for chrome/chromium automation:
https://lnkd.in/dnqfuGsG

BotCity Core for Desktop, Mobile and Legacy automation:
https://lnkd.in/dQkh2tAr

BotCity Web for web automation (supports Computer Vision):
https://lnkd.in/dM85cxRu

PyWinAuto for automating Microsoft Windows GUI:
https://lnkd.in/db4WC7Rw

PyAutoGui for controlling mouse and keyboard:
https://lnkd.in/dvESAF_Z

AutoPy for cross-platform GUI automation (macOS, Windows, X11):
https://lnkd.in/d9GGeRMZ

Appium for mobile automation:
https://lnkd.in/dFy6rjBE

BONUS - Orchestrate them all:

[BotCity](https://www.linkedin.com/company/botcity/) Maestro Orchestrator SDK:
https://lnkd.in/dwpm2kBb

[ARTICLE] Python RPA + Orchestration
https://lnkd.in/dGk6Mmwu

BONUS 2 - Collection of Python libs for automation use cases:
https://lnkd.in/dqzNJH4T

### Pytorch Cheat Sheet

https://www.linkedin.com/posts/ashishpatel2604_pytorch-cheatsheet-activity-7005800148190572544-lxIs?utm_source=share&utm_medium=member_desktop



Arquitetura em dados



![](https://media.licdn.com/dms/image/C4D22AQH0wkPhiI9ZIw/feedshare-shrink_800/0/1670291708276?e=1674086400&v=beta&t=pFerpAu0wDvL9fjYbtixpH1u-XqRt6C1WcDLL4KjiY0)

### Projeto de DE - Ações on Brasil

https://www.linkedin.com/posts/tom-mereles_github-tommerelesacoes-brasil-%C3%ADndices-activity-7005735910835138561-nMxg?utm_source=share&utm_medium=member_desktop

Finalizando a noite com um web scraping afim de praticar um pouco de python com pandas e de quebra olhar a como anda as ações.🤑

[#python](https://www.linkedin.com/feed/hashtag/?keywords=python&highlightedUpdateUrns=urn%3Ali%3Aactivity%3A7005735910835138561) [#pandas](https://www.linkedin.com/feed/hashtag/?keywords=pandas&highlightedUpdateUrns=urn%3Ali%3Aactivity%3A7005735910835138561) [#notebook](https://www.linkedin.com/feed/hashtag/?keywords=notebook&highlightedUpdateUrns=urn%3Ali%3Aactivity%3A7005735910835138561) [#programacao](https://www.linkedin.com/feed/hashtag/?keywords=programacao&highlightedUpdateUrns=urn%3Ali%3Aactivity%3A7005735910835138561)

https://github.com/TomMereles/Acoes-Brasil



### ML - Ultra video de NLP

https://www.linkedin.com/posts/pradipnichite_most-popular-videos-on-my-channel-are-activity-7005500667867885568-VEWE?utm_source=share&utm_medium=member_desktop

Then you've come to the right place! Check out my channel for some great videos on the topic.

\1. Learn How to Build a Custom Named Entity Recognition (NER) model using spacy.
\2. Aspect-Based Sentiment Analysis Using BERT with Code.
\3. How to Make a Chatbot Using Amazon Lex and AWS Lambda (Python) | Conversational AI
\4. Fine Tune Transformers Models like BERT on Custom Dataset.
\5. Data Science Freelance: How Did I Get My First Freelancing Job as Data Scientist?

👇
https://lnkd.in/d_MggePh

### (Front) 10 Fonte de templates de html/css

https://www.linkedin.com/posts/activity-7005480554980618241-SSVg?utm_source=share&utm_medium=member_desktop

### (Currículo) Como deixar recrutadores de queijo caído

Deixe os Recrutadores Internacionais de queixo caído.

Pega essas dicas:

1 - Foque sempre em resultados ao descrever suas experiências. Ao invés de dizer o que você era responsável por fazer, mostre os resultados que entregou.

2 - Mostre o que você usou para chegar naquele resultado.

(Aqui é a oportunidade perfeita pra incluir as palavras-chave que os recrutadores geralmente tentam encontrar para apresentar o candidato para o hiring manager.)

3 - Comece o parágrafo com "action verbs" para dar dinamismo e deixar o texto orientado para o que realizou.

Um template seria mais ou menos assim:

[Action verb] using [skill / technology / methodology / framework] that [result verb (generated, created, decreased, increased)] + [measurable result]

Ex1: Set up new paid media campaigns for Latin America using Google Ads and Meta Ads that increased sales by 80% while still reducing CPA by 15%

Ex2: Tested and launched new acquisition channels: affiliates, influencers, and referrals that increased in 85% the number of conversions.

"Mas Leandro, não sei o impacto direto do que eu fiz na empresa"

Sem problema!

Você pode mencionar o que fez indiretamente:

\>> Developed a new design system used by the company on a new digital product that earned $10M in revenue in the first 3 months.

Ou, se não tiver isso, pode mencionar uma empresa famosa mundialmente como prova social:

\>> Launched 3 new websites using JavaScript frameworks (React + Node.js) for Coca-cola leading brands: Sprite, Schweppes, and Fanta.

E ainda, em último caso, pode contextualizar para os gringos usando um critério relativo que demonstre como o projeto em que você trabalhou era importante localmente:

\>> Implemented the end-to-end product discovery methodology for a new learning program at USP, one of the top 100 best universities in the world and the best in Brazil.

Gostou da dica?

Esse é o nível de conteúdo da nossa MasterClass de Carreira Internacional.

Vai rolar nessa quarta-feira e tá só R$57,00.

Saiba mais aqui: [leandrobpt.com.br](http://leandrobpt.com.br/)



### (Publish Linkedin) O que publicar no linkedin

https://www.linkedin.com/posts/carlosmanoelfreitasdasilva_carreiras-linkedin-rh-activity-7005127948315844608-vS9m?utm_source=share&utm_medium=member_desktop



![](https://media.licdn.com/dms/image/C4D22AQHH-KYaGVHdKg/feedshare-shrink_800/0/1670152650876?e=1674086400&v=beta&t=I-bC_ZdAriLEK_J5UM1LR7-TmUXZ5eDKFiiJ_XEVEOI)



### Técnica de Feynam para aprender qualquer coisa

https://www.linkedin.com/posts/addyosmani_softwareengineering-learning-knowledge-activity-7005114911030722560-DZeh?utm_source=share&utm_medium=member_desktop

The Feynman Technique is great model for learning anything better.

It’s a method of learning and understanding complex subjects by breaking them down into their simplest components and explaining them in plain language, named after the physicist Richard Feynman. 

The technique involves four steps:
\1. Choose a concept or idea that you want to learn about.
\2. ELI5 (Explain It To Me Like I'm 5). Pretend that you are explaining the concept to someone who knows nothing about it. Write out your explanation in simple, plain language, using examples and analogies to make it easier to understand.
\3. Review your explanation and look for any gaps or unclear points. Go back to the original source material (such as a textbook or lecture notes) and fill in any gaps in your understanding.
\4. Simplify your explanations. Test your understanding by trying to explain the concept to someone else, or by asking a friend or colleague to listen to your explanation and provide feedback.

The Feynman Technique can can help you identify any gaps in your understanding and ensure that you have a deep and thorough understanding of the subject. I've found it valuable for retaining crucial information and knowledge and I hope you find it helpful too.

![](https://media.licdn.com/dms/image/C5622AQFQzAs3PYMDsg/feedshare-shrink_800/0/1670149542034?e=1674086400&v=beta&t=CshMrOInI6velpgJwqnRNwof0xZ9iK9MQtRa59x5u5c)



### HPO - tunning parmetros

https://www.linkedin.com/posts/danny-butvinik_datascience-machinelearning-activity-7005131810712006656-TSkV?utm_source=share&utm_medium=member_desktop

Hyperparameter Optimization (HPO) aims to find a well-performing hyperparameter configuration of a given machine learning model on a dataset (including the model, its hyperparameters, and other data processing steps).

In Data Science and Machine Learning, a "hyperparameter" is a parameter whose value controls the learning process. By contrast, the values of other parameters are derived via training.

GridSearch
An exhaustive method measured by cross-validation on the training dataset. It is a simple, time-consuming, and efficient approach with only categorical HPs.

Random Search
Replaces exhaustive search by selecting randomly. It is embarrassingly parallel and more efficient than grid search. It does not consider previous results and is not efficient with conditional HPs.

Bayesian Optimization and Variants
Builds a probabilistic model of the function mapping from hyperparameters values to the objectives evaluated on a validation set. By evaluating a promising hyperparameter configuration based on the current model and then updating it, Bayesian Optimization hopes to get as many observations as possible that show as much as possible about this function and, in particular, where the optimal point is.

Bayesian Optimization-Gaussian Processes (BO-GP)
Converge fast for continuous hyperparameters. However, it has a poor parallelization capacity and is inefficient with conditional hyperparameters.

Bayesian Optimization Tree-structured Parzen Estimators (BO-TPE)
Efficient with all types of hyperparameters and keeps conditional dependencies, but has a poor capacity for parallelization.

Tree-structured Parzen Estimators (TPE)
Sequential Model-based Optimization (SMBO) methods sequentially construct models to approximate the performance of hyperparameters based on historical measurements, and then choose new hyperparameters to test based on this model.

HyperBand
Early stopping-based method that adaptively allocates a pre-defined resource, e.g., iterations, data samples, or several features, to randomly sampled configurations. It enables parallelization but could be more efficient with conditional hyperparameters.

Bayesian Optimization HyperBand (BOHB)
It is a state-of-the-art HPO algorithm. The idea behind the BOHB is based on one simple question – why do we run successive halving repeatedly? Instead of a blind repetition method on top of successive halving, BOHB uses the Bayesian Optimization algorithm. BOHB combines HyperBand and Bayesian Optimization to use both of these algorithms efficiently. It is efficient with all types of hyperparameters.

Successive Halving
Attempts to allocate the most funds to the most promising methods. It assumes all configurations could be stopped early, and a validation score could be obtained. There is a trade-off between how many configurations need to be selected at the start and how many cuts are needed.

![](https://media.licdn.com/dms/image/C4D22AQFqZj9L6ha9LA/feedshare-shrink_800/0/1670153571173?e=1674086400&v=beta&t=SiSESchEUs-s2H2Q0Y6mwBbk-nRNu469rnm8_teFAkc)



### Automatizar criaçao de post no linkeidn

Com poucas linhas de código é possível [#automatizar](https://www.linkedin.com/feed/hashtag/?keywords=automatizar&highlightedUpdateUrns=urn%3Ali%3Aactivity%3A7005173097523785728) diversas tarefas do dia a dia, como um simples post no [#Linkedin](https://www.linkedin.com/feed/hashtag/?keywords=linkedin&highlightedUpdateUrns=urn%3Ali%3Aactivity%3A7005173097523785728) ; )

💡 São infinitas aplicações, desde emissão de nota fiscal, envio de email, elaboração de relatórios automáticos e até recursos de inteligência artificial.

Fico impressionado como a linguagem [#python](https://www.linkedin.com/feed/hashtag/?keywords=python&highlightedUpdateUrns=urn%3Ali%3Aactivity%3A7005173097523785728) é capaz de ser simples e tão poderosa.

🗓 Curtiu esse projeto? Na segunda-feira começa nosso treinamento gratuito de Python. Serão 4 projetos completos (inclusive com recursos como esse).

Para participar é só se cadastrar para receber todos os projetos e aprender muito com a gente: https://lnkd.in/d_j4f9V6

🐍 Meu último post no Linkedin foi feito usando PYTHON!! 😱

Com poucas linhas de código é possível [#automatizar](https://www.linkedin.com/feed/hashtag/?keywords=automatizar&highlightedUpdateUrns=urn%3Ali%3Aactivity%3A7005173097523785728) diversas tarefas do dia a dia, como um simples post no [#Linkedin](https://www.linkedin.com/feed/hashtag/?keywords=linkedin&highlightedUpdateUrns=urn%3Ali%3Aactivity%3A7005173097523785728) ; )

💡 São infinitas aplicações, desde emissão de nota fiscal, envio de email, elaboração de relatórios automáticos e até recursos de inteligência artificial.

Fico impressionado como a linguagem [#python](https://www.linkedin.com/feed/hashtag/?keywords=python&highlightedUpdateUrns=urn%3Ali%3Aactivity%3A7005173097523785728) é capaz de ser simples e tão poderosa.

🗓 Curtiu esse projeto? Na segunda-feira começa nosso treinamento gratuito de Python. Serão 4 projetos completos (inclusive com recursos como esse).

Para participar é só se cadastrar para receber todos os projetos e aprender muito com a gente: https://lnkd.in/d_j4f9V6



### DE Project Exemplo

https://www.linkedin.com/posts/darshil-parmar_dataengineering-dataengineer-python-activity-7005167722925862912-DT66?utm_source=share&utm_medium=member_desktop

📈 FREE Data Engineering Project - Stock Market Real-Time Data Analysis Using Kafka



Real-Time Data Streaming is everywhere and makes your life easier

👨🏻‍💻 Let's take the example of UPI (Unified Payment Interface)

🚖 Consider you are traveling by online cab service and you make payment online.

🧾 You made the payment and the driver did not receive it immediately.

"Bhaiya payment to kar diya hai" (I made the payment)

You want to get a notification instantly and even if there is a slight delay of 30-40sec you'll start losing your mind 😤

🫡 This is where real-time data streaming platforms make our life easier

You do the UPI and another person receives notifications then and there.

There are many other use cases such as Stock Market, Fraud Detection, e-commerce, Google maps, and many more

I just published a video on this topic and created an entire project around it

What do you think you'll learn?
✅ Build a Real-Time simulation app using Python
✅ Understand the basics of Kafka (Broker, Producer, Consumer, Zookeeper, and many more)
✅ How install Kafka on EC2 (or any VM)
✅ Write Producer and Consumer code in Python
✅ Generate a real-time streaming pipeline and store data in S3
✅ Analyze Data in Real-Time using Athena


Here is the video link - https://lnkd.in/d_JyPXNCo

### (!!!) ULTRA - COMO SABER REACT

https://www.linkedin.com/posts/maykonsousa_o-que-%C3%A9-preciso-saber-para-ser-um-front-end-activity-7004917502811992064-xMxm?utm_source=share&utm_medium=member_desktop

O que é preciso saber para ser um front-end JR com React?
Claro que isso é so minha opinião e não necessariamente toda vagas irão cobrar tudo isso mas com certeza, são conhecimentos que você precisa ter para estar pronto para a maioria delas.

Já dominar HTML e CSS. Tags semânticas, SEO, GRID, display, pseudo elementos, pseudo classes, media queries, animation, CSS Modules, SASS etc

\- Ter conhecimentos um pouco mais sólidos em Javascript do que só manipular a DOM. Você precisa entender sobre escopo de funções, diferenças entre let, var e const, entender como funcionam classes, arrow functions, promisses, async/await e JSX,

\- Entender como consumir API's com e sem o Axios, como enviar os parâmetros que o endpoint espera receber, RESTful APIs, GraphQL API's, web sockets, etc

\- Entender sobre estados e propriedades, componentes de classe e de função, ciclos de renderização, SPA, PWA, SSR, Context API e Redux, CSS in JS, eventos e renderização condicional.

\- Conhecer sobre bundlers e compiladores (webpack, babel, vite etc)

\- Conhecer os React Hooks:
useState, useEffect, useRef, useContext (Context API), useReducer, useMemo, useCallback, useDispatch e useSelector (Redux).

\- Entender sobre testes unitários e algumas bibliotecas (Jest, Vitest, React Testing Library, Cypress, Enzyme, Jasmine etc)

-Entender sobre padronização de código (Eslint, Styled Lint, Prettier)

\- Entender sobre versionamento de código (Git, Github, Husky, conventional commits, git flow etc)

\- Ter algum conhecimento CI/CD (deploy contínuo, pipelines etc)

E para finalizar algumas bibliotecas que é quase obrigatório conhecer: React Router, React Query, Axios, React Hook Form, Formik, Styled Components, Storybook, Framer Motion, Tailwind, Chacra-ui, React Bootstrap, Material-ui etc

[EDIT]: fiz esse vídeo explicando o pq dessa lista e deixando claro que o objetivo não é desanimar ninguém e sim dar um direcionamento para que vocês não se dispersem durante os estudos!

https://lnkd.in/dckJ_ESz

### Livro - Python Feature Engineering COokbook

https://www.linkedin.com/posts/ashishpatel2604_featureengineering-machinelearning-artificialintelligence-activity-7004679754024955904-PF4V?utm_source=share&utm_medium=member_desktop

### (DS) PDF sobre pandas

https://www.linkedin.com/posts/jesus-fajardo_data-analytics-with-pandas-guide-activity-7004815173261651968-SSJI?utm_source=share&utm_medium=member_desktop

### Virada de chave no ingles

https://www.linkedin.com/posts/william-moraes-developer_minha-virada-de-chave-no-ingles-recentemente-activity-7004907239337537536-Oc6F?utm_source=share&utm_medium=member_desktop

Minha "virada de chave" no Ingles

Recentemente postei sobre qual alto era o nível de aproveitamento das aulas que eu vinha tendo com um professor particular nativo.
E um dos pontos que eu mais tinha insegurança era sobre errar palavras bobas por dúvida da pronuncia.
Eu não conseguia entender por que a letra A tinha som de "ei" mas também tinha o som de "é".

E a dica que ele me deu foi.
Ingles possui praticamente 2 sons para cada vogal, mas existe uma "regra" que facilita reconhecer qual som iremos usar, mesmo sem nunca ter ouvido essa palavra.

Ou seja, em praticamente todas palavras com apenas uma silaba que possuem 2 vogais, sejam juntas ou separadas, nos ignoramos a segunda.
E essa primeira vogal terá um som diferente.

Left = Left, pronuncia-se o E com som de É, "léft"
Leaf = Lef, pronuncia-se o E com som de i

Cut, pronunciasse 'kãt'
Cute = Cut, porém pronunciasse 'quiute"

Ou seja, ambas possuem a mesma vogal, mas em cada uma delas o som é diferente, e quem 'dita' essa regra é a quantidade de vogais nessa palavra monossilaba.


e detalhe, quando eu questionava meu antigo professor BR ele respondia com
"vamos seguir o conteúdo da apostila, cada palavra tem o seu som e voce vai pegando com o tempo..." Triste 🤣

### (Entrevista) MUITO BOM A SERIE DESSA MULHER, EM INGLES

https://www.linkedin.com/posts/lloydellen_uno-reverse-questions-to-ask-interviewers-activity-7004489431000768512-lO6y?utm_source=share&utm_medium=member_desktop



### DE - Modern Data Stack

https://www.linkedin.com/posts/caique-godoy-578477a1_essa-semana-foi-mais-uma-para-conhecer-novas-activity-7004042806046396416-L2b5?utm_source=share&utm_medium=member_desktop

Essa semana foi mais uma para conhecer novas ferramentas e conceitos na Engenharia de Dados.
O tão falado "Modern Data Stack".

É um conceito que vem ganhando força por sua maior facilidade na construção de pipelines , sua escalabilidade e por ser totalmente "Cloud-based".

Nesse projeto, contruimos uma pipeline completa coletando, transformando e analisando dados sobre a COVID19.

No projeto, utilizamos:

\- Airbyte: Para conexão na fonte de dados, realizando a coleta e ingestão dos dados no seu destino.
\- DBT: Para realizar as transformações dos dados em SQL, com integração com Git
\- Snowflake: Para criação do Data Warehouse e armazenamento dos dados
\- Airflow: Para agendamento e orquestração das pipelines, para realizar todo o processo acima automáticamente
\- Metabase: Para exploração e análise dos dados e criação de dashboards.

Vale ressaltar uma ferramenta que não conhecia e que foi fantástica: O Gitpod.

Todo o ambiente do projeto foi desenvolvido COMPLETAMENTE fora da minha máquina.
Utilizando o Gitpod, que é acessado diretamente do navegador, subi um ambiente completo, com todos os recursos necessários para a criação, teste e execução do projeto, como:

- VS Code
  \- Git
  \- Python
  \- Docker
  \- Curl



### Book - 100 indicadores de Gestão (KPI)



### DE - Projeto do twitter (repo bt)

https://www.linkedin.com/posts/gabriel-f-dos-santos_github-fdsgabrielairflowetltwitterpb-activity-7003870663895605248-wMO9?utm_source=share&utm_medium=member_desktop

Gostaria de compartilhar com vocês um projeto de pipeline de dados que busca tweets de alguns dos principais meios de comunicação do país (+ "Choquei") e os converte para um arquivo CSV dentro de um bucket (S3).

A ideia é coletar tweets dessas contas no Twitter e ter uma noção momentânea de quais são os tweets mais curtidos e/ou compartilhados na rede, consequentemente quais as noticias mais vincularam nela diariamente e/ou semanalmente.


Special thanks to [Darshil](https://www.linkedin.com/in/ACoAAB5QzkIB7H3vliuE1puA21D60J9uTPkTMpw) for inspire me through this project.

https://lnkd.in/dUC8uvNK



### (Currículo) Criador de currículo

https://www.linkedin.com/posts/lucianoresponde_curraedculo-cv-emprego-activity-7003798917943369728-QLyO?utm_source=share&utm_medium=member_desktop

Além de gerar esse currículo na faixa, dá também para fazer um avaliação comportamental (também gratuita) e aproveitar um monte de conteúdo legal que estão trazendo para a ferramenta.

Aqui: https://lnkd.in/guQWBMJ2

![](https://media.licdn.com/dms/image/C5622AQECoYEWDHFWXg/feedshare-shrink_800/0/1669835785544?e=1674086400&v=beta&t=ySdGQXN0aef_xPiU1da8gzI3U58yjqLjlA8qxuQQEXU)



### Necessidade de fazer refatoração de código

[Code smells]
Sinais de necessidade de refatoração do código:

\- Nomes de variáveis, funções, classes misteriosos ou incompreensíveis
\- Código duplicado
\- Função demasiadamente longa
\- Lista longa de parâmetros
\- Dados e variáveis globais
\- Dados e variáveis mutáveis ao longo do código
\- Mudança requer ajuste em várias partes do código
\- Informações distintas em uma mesma classe
\- Obsessão por estruturas primitivas ao invés de criadas
\- Switch case em excesso e repetido
\- Excesso de laços de repetição e estruturas de decisão
\- Comentários sem utilidade
\- Código como comentário
\- Classe grande, com mais de uma responsabilidade

Se você, como profissional que atua com código, seja ele qual for (cientista, desenvolvedor, programador, devops, etc.) e seja lá qual linguagem for, vir estes sinais, fique atentos. São sinais de que existem possíveis melhoras a serem desenvolvidas. Em outras palavras, o código é passível de revisão para melhorar manutenibilidade, legibilidade, performance, etc.

Não deixe passar a oportunidade ímpar de melhorar o código que você encontrou. É até um certo profissionalismo.

### BigMac Index em PBI

https://www.linkedin.com/posts/felipedamascena_print-do-dashboard-em-pdf-activity-7003018467297669121-HTwY?utm_source=share&utm_medium=member_desktop

Esse desafio é a respeito do Índice Big Mac, valor que relaciona o valor da moeda de alguns países com o preço do Big Mac.

A ideia principal do desafio é responder as seguintes perguntas:
-Calcule o Índice Big Mac para cada um dos países.
-Analise a variação desse índice ao longo do tempo de acordo com cada região/continente.
-Qual é a moeda mais sobrevalorizada (cara) e subvalorizada (mais barata) do mundo, de acordo com o Índice Big Mac?
-Considerando o salário mínimo do Brasil ao longo do tempo, hoje conseguimos comprar mais ou menos Big Macs?

Abaixo adicionei prints do meu dashboard e para acessar o dashboard online segue o link: https://lnkd.in/d6d-Dua6

### Exemplo de Site portifolio

https://www.linkedin.com/posts/diego-costa-312ab1198_diego-costa-activity-7003524238724739072-b2wb?utm_source=share&utm_medium=member_desktop

https://portifoliodiegocosta.web.app/



### ML - Score de cŕedito / risco de crédito

https://www.linkedin.com/posts/marcuos_machinelearning-datascience-fintech-activity-7003504684959199232-1bN8?utm_source=share&utm_medium=member_desktop

Tá em dúvida de qual modelo escolher para montar o seu score de crédito (identificar bom ou mau pagador)? 

Aqui vão 5 dicas para você escolher o modelo ideal dado o contexto:

\1. Contexto: interação forte com área de negócio, poucas variáveis, presença de regulamentação e necessidade de auditória (ou seja, necessária uma boa explicabilidade do modelo). 
Modelo ideal: Regressão logística 
https://lnkd.in/dngEk3mY

\2. Contexto: muitas variáveis preditoras, necessidade forte de explicabilidade e necessidade de um modelo simples. 
Modelo ideal: ElastictNet com regularização lasso para seleção automática de features. 
https://lnkd.in/denhKehx

\3. Contexto: datasets gigantes, muitas variáveis, necessidade de atualizações iterativas, necessidade de velocidade.
Modelo ideal: SGDClassifier (com Lasso e Ridge)
Por usar gradient descent, esse modelo possibilita o treino de datasets gigantes por meio de atualizações iterativas em batchs.
https://lnkd.in/d3RfZTny


\4. Contexto: datasets grandes, muitas variáveis, necessidade de desempenho, necessidade de melhor acurácia, necessidade média de explicabilidade.
Modelo ideal: Lightgbm com Shap values. 
Modelos em árvores tendem a ter maior acurácia e os shap values são essenciais para gerar explicabilidade de modelos black-box.
https://lnkd.in/d24TRHWR
https://lnkd.in/dUwjSnXM

\5. Contexto: datasets grandes, muitas variáveis, necessidade de melhor acurácia, necessidade média de explicabilidade, muitas variáveis categóricas.
Modelo ideal: Catboost com Shap
https://lnkd.in/dJ2Yz4cE
https://lnkd.in/dUwjSnXM



### SQL interview Questions

https://www.linkedin.com/posts/theravitshow_60-sql-interview-questions-and-answers-activity-7003344396918165504-t_TL?utm_source=share&utm_medium=member_desktop



### Queda de DS e auento de DA

https://www.linkedin.com/posts/jay-feng-ab66b049_datascience-dataengineering-dataanalytics-activity-7003397062306279425-d7YU?utm_source=share&utm_medium=member_desktop

Data scientists are slowly disappearing from the job market.

We noticed a 26% drop in job postings with the title "data scientist" from October 2021 to October 2022.

But the number of data analysts and data engineers increased by 32% and 14% respectively.

Here’s three reasons why this might be happening:

\1. A “data scientist” is a luxury while a “data analyst” take home is 30% less on average. 

So companies are hiring Data Analysts to do the same job as Data Scientists, but for a smaller salary.

\2. Budget cuts in Amazon, Facebook, and Twitter might be disproportionally affecting data scientists.

FAANG companies prided themselves in hiring a lot of data scientists and have since cut back.

\3. As companies slowly understand the different data science roles, they are correctly re-labeling data scientist into their actual roles like data engineering and data analytics.

It might be time to hone your skills for creating data pipelines, scripting SQL queries, and upgrading your business analysis skills to improve your chances of landing a Data Analyst or Data Engineering job. 

### DE -  Big Data Interview Questions

https://www.linkedin.com/posts/trraveendra_dataengineeringinterviewquestions-activity-7003371698955698177-4j1H?utm_source=share&utm_medium=member_desktop



### Become IBM Certified



\12. Data Engineering and Machine Learning using Spark

🔗https://t.co/ROjOU245qf

\11. Introduction to Big Data with Spark and Hadoop

🔗https://t.co/kUS2Z621Np

\10. Introduction to NoSQL Databases

🔗https://t.co/1rFj5Ch8Fy

\9. Getting Started with Data Warehousing and BI Analytics

🔗https://t.co/tmkiAAYuzG

\8. ETL and Data Pipelines with Shell, Airflow and Kafka

🔗https://t.co/snGMO8NsiM

\7. Relational Database Administration (DBA)

🔗https://t.co/z04mEJGAfO

\6. Hands-on Introduction to Linux Commands and Shell Scripting

🔗https://t.co/W8wFSfZalK

\5. Databases and SQL for Data Science with Python

🔗https://t.co/bDdQj4Rk0l

\4. Introduction to Relational Databases (RDBMS)

🔗https://t.co/xbLLLr01mv

\3. Python Project for Data Engineering

🔗https://t.co/JAcoVj8adj

\2. Python for Data Science, AI & Development

🔗https://t.co/t8s9w0ctIT

\1. Introduction to Data Engineering

🔗https://t.co/M9ZhWSQ2Vx



### OCR - exemplo bom

https://www.linkedin.com/posts/matt-payne-ceo_what-is-intelligent-document-processing-activity-7003122169048145920-78sr?utm_source=share&utm_medium=member_desktop



### 5 hobbies





![](https://media.licdn.com/dms/image/C4E22AQGU5nyeVVH84Q/feedshare-shrink_800/0/1669239538172?e=1674086400&v=beta&t=rltH4XuZ2aoGYKRVi39VRqgjn2SAowMlSVz2odb_wkA)

### Dica para análise de dados

Para todos que pensam que para alguma vaga de analista de dados é necessário ter experiência em cloud, acredite, NÃO é.

A parte de cloud pertinente a análise de dados é exatamente a parte de extração de informações de banco de dados como o SQL, e basicamente a única diferença é como você acessa esse banco de dados, as querys são as mesmas, ou quase as mesmas.

Então pra análise de dados, se você tem experiência em SQL, já está mais que suficiente pra resolver sua vida em cloud, em 99% das vezes.