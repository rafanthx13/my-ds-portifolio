# Yukio (Notas de maio a julho de 223)

## Index

## CUrsos que recomenda

+ DO ITA
+ do instagram @asn.rocks

## Quem seguir

+ Casseie Kozyrkov

## Livros

Recomendaçoes random
+ THink Bayes: Baysian Statistic in Pytohn
+ COmo mentri com estatitiscas - Darrel Huff
+ Analise pratica de séries temporias: Prediçao com estatisica e Aprendizado de maquina
+ O andar do bebado
+ Projetos de ciencia de dados com python - Stephen Klosterman
+ Freakcnomics


## meetup

Os do nubank

## Aprendez

+ Matematica e Estatisica
  - Calculo e Algebra linear da khan academy
  -  "Mathematics for Machine Lerning do Marc Peter Deseniroth
  - Estatistica - O que é e pra que serve - Charles Wheelan
  - AN introduction to Statisticla Learning - Gareth James (eu tenho)
+ Probabildiade
  - Noçoes de probabilidde e estatisca - Marcos Nascimento Magalhaes
  - Probabildiade: Um curso moderno com aplicaçoes do Sheldon ROss
  - PLayLis JB Statitsc sobre distribuiçoes e tesse de hiptese
+ SQL Avançado
  - SQL For Smarties
  - Advanced SQL Programing
  - The art of SQL
  - SQL in Nutshell (mais apra iniciante do que os outros mas pode surpreender)
+ Aprender alg de ML
  - StatQuest with Josh Stamer
+ INferencia de causa
 - Casual INferen and discovery in pytohn

## A minha pergunta

Qual conceito de Estatíst você ahca improtante mas poucas pesosa relamnete ententem

Khan Academy - A ideia por tra do teste de hipotese

## Post interressantes

+ lnkd.in/djCw_xHU (Linkedin da pessoa - Matheus de ALmeida Cantarutti)

## Artigos

+ Porque modelos ensemble sao melhores que redes neuris para dados tabulares
=> arxiv.org/pdf/2207.08815.pdf
=> Why do three-based models still outperform deep learning on tabular data

+ Paper do CHat GPT
  - Attention is all you need

## Para portifolio

+ USE DADOS REAIS QUE NAO SEJA DA KAGLGE OU FEITO POR PIPELINE POR VOCÊ

## O que é entropia

Entropia é uma medida de incerteza. Qunato mais incerteza, mais entropia, ou seja pod ser tabembem medida de variabildaide dos dadoas

## Difenreça entre quem faz o clube de quem nao faz

Candidatos regulares: 
+ "Regressão linear é para obter causalidade entre x e y", 
+ "aí se tiver multicolinearidade a regressão tem predições prejudicadas", 
+ "eu aplico um scaler e one hot encoder, depois rodo uma árvore de decisão", 
+ "se tiver desbalancamento SMOTE resolve" 

Candidatos do Clube de Assinaturas: 
+ "Regressão linear não implica em causalidade, precisaríamos de um desenho específico para aí aplicar um modelo em painel", 
+ "multicolinearidade não afeta predições", 
+ "não preciso de scaler para árvores e one hot encoder vai prejudicar meu modelo", 
+ "desbalanceamento é, na maioria dos casos, uma questão de trade off, mas eu ainda mexo no peso das classes, no threshold da probabilidade e escolho a loss function ideal"
