## Semana 34: Python Pt. 1 (Introdução e Conceitos Básicos)





# 1. Introdução

Fala, rapaziada! Tranquilo? Preparei esse material para vocês aprenderem de verdade a linguagem mais utilizada na área de dados: R… PYTHON! R não!

O material está bem estruturado para quem está saindo do zero. Então, se você nunca ouviu falar em programação, vai conseguir aprender. Teremos uma explicação e uma aplicação em código. Dessa forma, com essa estrutura, você conseguirá aprender tanto os conceitos como já colocar em prática.

E falando sobre colocar em prática, isso é muito importante, viu?! Programação se aprende programando. Não é lendo, não é vendo vídeo aula… é programando! Então, leia esse material com uma tela ao lado onde você consiga executar códigos em Python, como o Jupyter Notebook. Ok?! Tô de olho.

Abraços,

Anwar

## 1.1 O que é Python, para que serve e como instalar?

Para começar o curso, como dizia meu professor de matemática, vamos aprender o que vamos aprender! O Python é uma linguagem de programação de alto nível (está mais próxima à linguagem humana do que a de máquina), interpretada (o código não é traduzido pela máquina diretamente, mas passa por um interpretador, que o lê e executa), orientada a objetos e, confie em mim, fácil de aprender!

Em 1991, Guido van Rossum, o cara da foto abaixo, criou a linguagem Python, que tem como objetivo ser uma linguagem de programação fácil de ler, escrever e manter. Ela é uma linguagem de propósito geral e usada em diversas áreas, como desenvolvimento web, análise e ciência de dados, automação, cunho científico e muitas outras áreas.

Agora, falando sobre “para que serve o Python?”, basicamente ele é uma linguagem que suporta vários frameworks e bibliotecas, por isso acaba sendo usada em diversas áreas. Abaixo, vou citar algumas delas e alguns códigos exemplificando seu uso.

##  

## 1.2 Desenvolvimento web

O Python é muito popular no desenvolvimento web, com os frameworks como Django (desenvolvimento back-end) e Flask (muito utilizado para criação de APIs). Esses frameworks permitem que os desenvolvedores criem aplicações web de maneira muito fácil e rápida, com suporte para tarfas de autenticação de usuários, gerenciamento de sessões, bancos de dados relacionais e não relacionais e muitos outros.

##  

## 1.3 Análise, ciência e engenharia de dados

Entrando na minha área, ciência de dados, temos o Python como protagonista quando se trata de programação, sendo a linguagem mais popular da área. A utilização de bibliotecas como Numpy, pandas, Matplotlib, scikit-learn etc. fornecem uma ampla gama de ferramentas para análise, processamento e visualização de dados. Além de contarem com bibliotecas como Tensorflow, Keras e PyTorch, que tornam o desenvolvimento de modelos de aprendizado de máquina mais fácil e eficiente.

##  

## 1.4 Automação e scripting

Para finalizar os exemplos, o Python é uma ótima opção para automação de tarefas repetitivas, como gerenciamento de arquivos, processamento de dados e envio de e-mails.

##  

## 1.5 Instalação do Python

Tá, já sabemos sua história, sabemos para que serve… mas como instalar o Python? Antes de instalar, é importante escolher a versão correta para o seu sistema operacional e necessidades. O Python possui duas versões principais: a 2.x e a 3.x. A versão 2.x é mais antiga e está caindo em descontinuação, enquanto a 3.x é a mais atualizada e utilizada. Além disso, é importante verificar se a versão do Python é compatível com outras bibliotecas e ferramentas que você pretende usar.

Para baixá-lo, você irá acessar . Lá, você irá encontrar a seguinte janela:

Note que no retângulo em vermelho as opções de download para Windows, Mac e Linux estão disponíveis. Sendo assim, clique para instalar de acordo com seu sistema operacional. Vou seguir o passo a passo para Windows, mas para fazer em Mac e Linux creio que seja bem parecido. Replique os passos adaptando para seu sistema operacional.

Assim que você clicar em baixar, um arquivo começará a ser baixado e, ao final do download, clique duas vezes nele para executar. Depois de clicar, a seguinte janela irá aparecer:

![img](https://lh3.googleusercontent.com/gdl0B6jAcO9YV0ZP9uKrs49ZYCzBlYLESOQkTOprRHvkuEP9DM3Cf_koirCSDiX3z-62v9mbHjs7yj269CYlVLN4EB-fgP95pYuHFMOYN3DUzlNHfXJRD_yLg9a5bewc-7AGfv-o7Vx09rbrKC7ywqc)

Quando clicar em Install Now, uma janela de administrador irá aparecer e é só clicar em "Aceitar". Após isso, aguarde a instalação. Ao final, se tudo ocorrer como o planejado, aparecerá a seguinte tela:

![img](https://lh5.googleusercontent.com/W13fhtlbjevONoZvoRTULH-XUA2DMiJ7s2N659WfIPbcC0GkEmxlVNd1k5ymSV5rLFLPzvgWzp2q67JeyJDgmzjr_byBz6USFj3Js1rwkgwNhpCVBKpe4phJZyJz4GierMMZETZlPhxh82YDR4WMEJ4)

Agora que já instalamos, vamos ver se tudo está funcionando corretamente. Para isso, abra o terminal de comando pressionando, no Windows, Windows + R, digitando cmd e apertando Ok. Quando estiver no terminal, digite python (tudo em minúsculo), pressione Enter e pronto! Se tu estiver certo, você já poderá executar comandos utilizando a linguagem Python. Observe, abaixo, eu escrevendo "Olá, Mundo!" na tela (reza a lenda que o primeiro comando de um programador, no início da carreira, deve ser exibir a frase "Olá, Mundo!" na tela para que ele aprenda a programar).

![img](https://lh4.googleusercontent.com/3yPg9AJSyIOxpoM1RGubpv0PP9qWfwUUPrjqHgfFUQmzMpPfCMASJV673oFewk1U1mYf0Faycwv_Evtfzm66Y-kDUkcW6a52ZyLkntUOmlzsieT3Sj90416H72B-s_mDSRe5h6Vgrq3E6emf8ty2S3c)

##  

## 1.6 Instalação do ambiente de desenvolvimento (Jupyter Notebook)

Para desenvolver nossas aplicações, geralmente utilizamos um ambiente de desenvolvimento chamado Jupyter Notebook. Para baixá-lo, devemos instalar o Anaconda, um pacote e ambiente de gerenciamento grátis que inclui todos os pacotes e bibliotecas necessárias para linguagem Python. Basta [clicar aqui](https://www.anaconda.com/) para baixar. Lá, você irá encontrar a seguinte janela:

![img](https://lh6.googleusercontent.com/OBe_uAAiZQ0loa5y16O5hP-QN27bomV1S_yjKUOeYIERwbbdzFKJcVaDzTIzCdqAcDVFeOjGVk2yw4gBEuGVkJdlZO-ATTdquc_Vbc-049F6EqSk8BzCSovxVHyQOITCXfinY203LQAvcC7IL-FDQNo)

Depois disso, selecione o seu sistema operacional e clique em Download. Quando baixar, clique no arquivo executável. Em seguida, autorize a execução como administrador, clique em Next, I Agree, Next, Next e Install. A partir daí, basta aguardar que a instalação seja concluída.

Depois disso, procure em seu computador, na barra de pesquisas, por Jupyter Notebook. O resultado deverá ser o seguinte:

![img](https://lh5.googleusercontent.com/mWSkCoQ6lMmH82zu5EMGBROja4FDIp-LSdLIWkBuDvageyQj6QRYGWHf8yRUAZWSKAbl2uJa24TaZEwLS3uSz8qT_cRNs4y4F1lfVzTmUEICtXncaQixhuUGBVxA7jS88ziqtcevu883Q6IJNP4PzDA)

Quando você clicar no arquivo do Jupyter Notebook, um terminal de comando irá abrir em seu computador (não o feche) para que, em seguida, abra uma aba com vários arquivos que estão na pasta do seu usuário. Por fim, para gerar um novo ambiente, clique em New e Python 3, como no exemplo abaixo:

![img](https://lh6.googleusercontent.com/lD8z-NygFQkYgZqAczGIB40igKwY8fDr-xcyhsLMZu84aKkmX5zT4nfWzosRtGoOJeTmmSSscO5eh2a34dEXaWion_8dqqxkjjfIq-_gEVcRZsjABEqO2-VSEuWwbqNmCwpI1KI0QdSmCTnmtMXNkXY)

Com o ambiente criado, podemos prosseguir com o material.

#  

# 2. Variáveis e Funções Básicas

## 2.1 O que são variáveis e por que elas são importantes na programação?

Variáveis, no contexto da programação e da linguagem Python, são espaços na memória do computador que armazenam valores que podem ser alterados durante a execução do programa. Elas são importantes porque permitem que os programas armazenem dados e realizem operações com esses dados. No código abaixo, estou atribuindo à variável chamada nome o valor "Anwar".

![img](https://api-club.hotmart.com/file/public/v5/files/9c1f1771-65d4-46cd-a6f6-f96b31cdd42b)





## 2.2 O que são funções e qual a importância delas no Python?

Falando sobre funções, elas são blocos de código que realizam uma determinada tarefa e podem ser chamadas várias vezes ao longo do programa. Elas são importantes no Python porque permitem que o código seja organizado e reutilizável. Abaixo, está um exemplo de função que recebe dois números inteiros e nos retorna o resultado da multiplicação deles:

![img](https://api-club.hotmart.com/file/public/v5/files/ba3778c6-ad9d-41fc-9325-ff8656d5bce3)

Detalhe: você não precisa entender como funciona a função acima, sua sintaxe e como criar funções, por enquanto. Mais para frente no curso de Python aqui do clube, iremos abordar isso.



## 2.3 Variáveis

Vamos falar um pouco mais detalhadamente sobre as variáveis.



### 2.3.1 Regras de nomenclatura

Como podem imaginar, não podemos nomear as variáveis da forma com que queremos. Na verdade, há um conjunto de regras que devem ser obedecidas para a nomenclatura de variáveis. As regras são as seguintes:

- O nome da variável deve começar com uma letra ou o caractere de sublinhado (_)
- O nome da variável não pode começar com um número
- O nome da variável pode conter apenas caracteres alfanuméricos e sublinhados (A-z, 0-9 e _ )
- Os nomes das variáveis diferenciam maiúsculas de minúsculas (nome, Nome e NOME são três variáveis diferentes)
- O nome da variável não pode conter espaços
- O nome da variável deve ser significativo e descritivo

Observe o código abaixo com exemplos corretos e incorretos de nomenclatura:

![img](https://api-club.hotmart.com/file/public/v5/files/237f3c7c-a993-4802-9a6a-b498735491cb)

Se você tentar executar a célula acima, receberá a seguinte mensagem de erro:

![img]()![img](https://api-club.hotmart.com/file/public/v5/files/d8f452ee-4a69-494d-a680-4351a7087470)![img]()![img]()

Claro, há erros de sintaxe no código, o que era esperado. No entanto, se você apagar as últimas 3 linhas, o código rodará perfeitamente e você terá criado as variáveis nome, nome_e_sobrenome, _frase e clichê, tendo atribuído textos a cada uma delas.



### 2.3.2 Atribuição de valores às variáveis

Para atribuir um valor a uma variável, basta usar o operador de atribuição =. Lembre-se de que quando você ler este símbolo em um código, ele deve ser lido como 'recebe' e não como 'igual'. Observe o exemplo abaixo:

![img](https://api-club.hotmart.com/file/public/v5/files/eaffe9be-90d1-4c42-bcd6-6235c71182dd)



Perceba que lemos o código acima da seguinte forma: "número recebe 3", e não "número igual a 3". No próximo tópico, vamos falar de forma detalhada sobre os tipos que as variáveis podem assumir no Python.

##  

## 2.4 Funções básicas

Agora, vamos falar sobre duas funções básicas do Python que iremos utilizar bastante daqui para frente: print() e input().

##  

### 2.4.1 Função print()

Se traduzirmos a palavra print, ela significa "imprimir", o que é basicamente a utilidade dela. A função print() é usada para exibir valores na tela. A sintaxe é print(valor). Observe os exemplos abaixo:

![img](https://api-club.hotmart.com/file/public/v5/files/d7338238-17ea-4667-bc2a-30a820ba210d)



Executando a célula acima, você receberá como output o texto "Olá, Mundo!".

![img](https://api-club.hotmart.com/file/public/v5/files/f83c4aae-386d-426f-955c-e71b106d9e60)

Novamente, uma sintaxe simples da função print(), cujo output será 3.

![img](https://api-club.hotmart.com/file/public/v5/files/2d0eeb54-81ed-4769-860b-311689d6e268)

Output esperado: "Meu nome é Maria".



### 2.4.2 Função input()

Se traduzirmos novamente o nome da função input() para português, significa "entrada", que, novamente, explica bastante a sua utilidade. Afunção input() é usada para obter entradas do usuário. A sintaxe é input("Mensagem"). Observe os exemplos abaixo:

![img](https://api-club.hotmart.com/file/public/v5/files/9205788a-daf1-4db0-bfa3-c3222b309693)

A resposta gerada será de acordo com seus inputs. Por exemplo:



*Qual é o seu nome? Maria*

*Qual é a sua idade? 86*

*Seu nome é Maria e você tem 86 anos.*

Um detalhe importante: a função input retorna uma string! Mais para frente, vamos falar mais sobre isso.

##  

## 2.4.3 F-strings

Agora, vamos falar sobre um tópico que irá ajudar muito quando você estiver trabalhando com strings e variáveis. As f-strings são uma forma de formatar strings em Python. Para utilizá-las, basta colocar um f antes das aspas da string e utilizar chaves {} para inserir variáveis dentro da string. Vou refazer o exemplo do nome e idade acima utilizando f-strings:

![img](https://api-club.hotmart.com/file/public/v5/files/cedc5a7e-86d9-47ed-88e0-4750854d329e)

Qual é o seu nome? Anwar

Qual é a sua idade? 20

Seu nome é Anwar e você tem 20 anos.

#  

# 3. Tipos de Dados

## 3.1 Tipos de dados na programação

Na programação, um tipo de dado define um conjunto de valores que uma variável pode assumir. Por exemplo, um número pode ser inteiro (10) ou decimal (5.68). Saber quais tipos de dados estão disponíveis para utilização em uma linguagem de programação e como realizar operações com eles é um elemento fundamental para qualquer desenvolvedor. Por isso, vamos explorar quais são os tipos de dados básicos na linguagem Python.

Vale ressaltar que há mais tipos de dados do que mencionarei nesta aula, porém teremos aulas específicas para eles mais para frente no curso.

##  

## 3.2 Tipagem do Python

Como sabemos, há linguagens de tipagem estática e dinâmica. Linguagens de tipagem estática devem ser inicializadas com declaração do tipo de dado. Isso significa que para criar uma variável numérica do tipo inteira, devemos especificar que ela é inteira, não sendo possível alterar seu tipo durante a execução do programa.

Linguagens de tipagem dinâmica, como o Python, por outro lado, não exigem declarações de tipos de dados, pois são capazes de atribuir dinamicamente o tipo para cada variável, inclusive podendo alterá-lo durante a execução do programa. Por exemplo, ao escrevermos x = 3, o Python automaticamente entende que x é do tipo inteiro. Se depois escrevermos x = "Olá, mundo!", o Python agora considera x como uma string.

##  

## 3.3 Visão geral dos tipos de dados em Python

Dentro do Python, há diversos tipos de dados. Abaixo, estão os mais comuns:

- Números (int, float)
- Strings (str)
- Booleanos (bool)
- Listas (list)
- Tuplas (tuple)
- Dicionários (dict)
- Conjuntos (set)

Nesta seção, vamos explorar um pouco sobre os números, strings e booleanos. As listas, tuplas, dicionários e os outros serão abordados detalhadamente em aulas futuras. Além disso, podemos checar o tipo de uma variável utilizando a função type().

##  

## 3.4 Números

## 3.4.1 Inteiros (int)

Agora, vamos falar sobre os números inteiros. Em Python, eles são representados pelo tipo int. Sabemos da matemática que números inteiros são aqueles que não possuem casas decimais, ou seja, alguns exemplos de números inteiros são: 11, 0, -5 e 4.

Para criar um inteiro, simplesmente digitamos um número, sem nenhuma marcação especial. Por exemplo, x = 3 cria uma variável chamada x com valor igual a 3.

Podemos realizar diversas operações matemáticas com eles, mas, hoje, abordaremos apenas duas: a soma e subtração, representadas pelos símbolos + e -, respectivamente. Observe o exemplo de código abaixo:

![img](https://api-club.hotmart.com/file/public/v5/files/203dc9a3-fff2-421d-a357-db99878b8a2c)

*Output:
*

*Soma: 7*

*Subtração: -1*



![img](https://api-club.hotmart.com/file/public/v5/files/a571ae5a-c3af-4ae9-8f04-d286d00df916)

*Output:
*

*O valor de x é: 5
*



![img](https://api-club.hotmart.com/file/public/v5/files/44d25905-8034-4471-8e97-24246ffbd84d)

*Output:
*

*O valor de z é: 9*



![img](https://api-club.hotmart.com/file/public/v5/files/1c4532da-f1f0-4cfe-aaae-9da5e80c1e23)

*Output:*

*O tipo de x é: *

*O tipo de y é: *

*O tipo de z é: *

Note que todas as variáveis tem o tipo 'int', ou seja, inteiro.



## 3.4.2 Decimais (float)

Falando sobre os números decimais em Python, eles são representados pelo tipo float. Sabemos da matemática que números decimais são aqueles que possuem casas decimais, ou seja, alguns exemplos de números decimais são: 3.14, -0.8, -119.0 e .4.

Para criar um decimal, simplesmente digitamos um número, com o ponto (.) como marcação especial. Aqui no Brasil, utilizamos a vírgula para separar os números pelas casas decimais. Porém, em Python, é utilizado o ponto (.). Por exemplo, x = 3.14 cria uma variável chamada x com valor igual a 3.14.

Podemos realizar diversas operações matemáticas com eles também, mas, como disse, abordaremos apenas a soma e subtração, hoje. Observe o exemplo de código abaixo:

![img](https://api-club.hotmart.com/file/public/v5/files/38ccd0b1-4c2e-4cc7-881a-70d6cb90a499)

*Output:
*

*Soma: 2.0*

Perceba que .2 é igual a 0.2



![img](https://api-club.hotmart.com/file/public/v5/files/db9f508d-2a44-4a91-bbc2-e8c8bb1ccd4f)

*Output:**
*

*Subtração: 1.6
*

*
*



![img](https://api-club.hotmart.com/file/public/v5/files/96b21384-30bc-436b-bc5a-5844e7b3bb1c)

*Output:
*

*O tipo da variável 'resultado' é: *

##  

## 3.5 Strings

Saindo do mundo dos números, vamos falar sobre as strings. Em Python, elas são representadas pelo tipo str. Basicamente, elas são sequências de caracteres, incluindo letras, números e símbolos.

Para criar uma string, podemos simplesmente digitar um texto entre aspas (simples, duplas ou triplas). Por exemplo, x = "Olá, mundo!" cria uma variável chamada x com valor igual a "Olá, mundo!".

As strings possuem vários métodos e algumas propriedades que vamos explorar em aulas futuras também. Uma delas vocês já viram que é a formatação com f-string, que serve para incluir o valor das variáveis dentro da string.

![img](https://api-club.hotmart.com/file/public/v5/files/c24f0c1a-a482-4810-9e63-e7706eb2098c)

*Output:
*

*Nome: João*

*Sobrenome: Lopes*

###  

### 3.5.1 Utilização de aspas

Agora, quero que você perceba que utilizei aspas simples ' para o nome e aspas duplas " para o sobrenome. Será que tem diferença ou afeta no tipo? Vamos verificar:

![img](https://api-club.hotmart.com/file/public/v5/files/5c9621a6-b3f3-4661-a82f-da0138eff638)

*Output:
*

*Tipo da variável nome: *

*Tipo da variável sobrenome: *

Como podemos ver, o tipo é o mesmo. Então, qual é a diferença entre utilizar aspas simples e duplas?

Para responder essa pergunta, observe o código abaixo:



![img](https://api-club.hotmart.com/file/public/v5/files/9ca6a298-1faf-4153-9844-aceb6979be18)

![img](https://api-club.hotmart.com/file/public/v5/files/32624b34-f834-4388-9e67-5f5cf264a246)

Note que ocorreu um erro de sintaxe. Ele ocorreu porque a frase em si continha aspas simples e estávamos utilizando aspas simples também para definir a string.

Para solucionar isso, basta delimitarmos nossa frase com aspas duplas, ao invés de aspas simples.

![img](https://api-club.hotmart.com/file/public/v5/files/590f1b7a-5b5b-47e0-b061-0800f0a560ab)

*Output:
*

*Frase: Gota d'água*

Note que agora funcionou perfeitamente e o inverso também é válido. Se nossa frase original tivesse aspas duplas, devemos utilizar aspas simples para delimitar a variável.

Agora, vem a questão: e se tivermos, na frase, aspas duplas e simples?

Neste caso, utilizaremos aspas triplas!



![img](https://api-club.hotmart.com/file/public/v5/files/5a030616-223e-49b3-9bee-fbdc39cba9b7)

*Output:
*

*Frase: "É a gota d'água", ela disse.*

Note que a frase possui tanto aspas simples quanto aspas duplas, por isso utilizamos aspas triplas para delimitar a variável.

Além disso, as aspas triplas nos permite escrever em mais de uma linha, como no exemplo abaixo:



![img](https://api-club.hotmart.com/file/public/v5/files/623fedbb-0fea-4ff3-bb51-0e2923b79916)

*Output:**
*

*Frase: Esta é*

*uma frase em*

*linhas diferentes*

Por fim, para simplificar a leitura de strings em variáveis, podemos utilizar o caractere escape ( \ ), que é a barra invertida. Ele nos permite armazenar caracteres que normalmente não podem ser armazenados em uma variável do tipo string, como as as aspas, por exemplo.

Ele facilita muito a leitura e deve ser utilizado sempre que possível. Observe o código abaixo:

![img](https://api-club.hotmart.com/file/public/v5/files/a644c944-14c2-4a36-a986-063bc3a10eae)

*Output:
*

*Frase: "Ele disse: 'você não pode fazer isso.'"*

##  

### 3.5.2 Tratando números como strings

Vou utilizar este tópico para fazer um aviso: se você quiser trabalhar com operações aritméticas como soma, subtração, multiplicação etc., não poderá trabalhar com números em formato de string! Observe o erro do exemplo abaixo:

![img](https://api-club.hotmart.com/file/public/v5/files/c2791906-e99f-4eed-a0a3-9b2eed44e208)

*Output:**
*

*Tipo de n1: *

*Tipo de n2: *

![img](https://api-club.hotmart.com/file/public/v5/files/c9c703ef-ccb5-46bf-97c7-a78594412aee)

*Output:
*

*Soma: 34*

![img](https://api-club.hotmart.com/file/public/v5/files/39bbc623-0be7-4050-8ef1-29eb06ac8384)

![img](https://api-club.hotmart.com/file/public/v5/files/f86db8ac-f511-4de7-b59a-0188f4700da5)

Note que nos dois casos (soma e subtração) o resultado não foi o esperado. No primeiro (soma), esperávamos 7 (3 + 4), porém o resultado foi 34. Isso significa que quando somamos strings estamos, na verdade, fazendo a concatenação delas. No segundo (subtração), obtivemos um erro, visto que strings não suportam a utilização do operador -.

Lembra da função input(), que vimos no módulo anterior? Então, ela retorna uma string. Ou seja, quando solicitamos que o usuário digite sua idade, estamos recebendo uma string, não um inteiro. No final deste capítulo, vamos falar sobre como fazer a conversão entre tipos.



## 3.6 Booleanos

Agora que já falamos sobre os números e os textos, vamos falar sobre os booleanos! Talvez, você não conheça de cara esses caras, porque não são tão comuns quanto números e textos, mas tenho certeza de que vai entender. Em Python, o tipo booleano bool é um tipo de dado que só pode ter dois valores: True (verdadeiro) e False (falso). Eles são muito úteis em expressões condicionais e loops que veremos mais a frente. As regras para lidar com valores booleanos são simples: True é tratado como 1, e False é tratado como 0, uma herança da linguagem C, que tinha o tipo booleano como nativo.

Para criar um valor booleano, podemos simplesmente comparar expressões (que veremos mais à frente) ou definir uma variável com os valores True ou False. Por exemplo, x = True cria uma variável chamada x com valor igual a True.

![img](https://api-club.hotmart.com/file/public/v5/files/c8e94bd1-152a-4571-ad73-19590747e606)

*Output:
*

*V1: True*

*V2: False
*

![img](https://api-club.hotmart.com/file/public/v5/files/8ed941e2-4c7a-4d49-a04e-30f4fbc813e1)

*Output:
*

*Tipo de v1: 
*

*
*

![img](https://api-club.hotmart.com/file/public/v5/files/d954ce81-0d7b-47ec-8ce0-7328b4978113)

*Output:* 

*V3: 1*

Note que o resultado foi 1, visto que v1 é True (um valor especial para o inteiro 1) e v2 é False (um valor especial para o inteiro 0).

##  

### 3.6.1 Verificando a presença de caracteres em uma string usando funções is

As funções **is** em Python retorna True se todos os caracteres de uma string atendem a determinada condição e False caso contrário.

Essas funções podem ser usadas para validar a entrada do usuário ou para verificar se uma string contém um determinado tipo de caractere. Por exemplo, você pode usar a função isdigit() para verificar se uma string contém apenas dígitos, ou a função **isalpha()** para verificar se uma string contém apenas letras. Aqui está um exemplo de código que usa a função isalpha() para verificar se uma string contém apenas letras:

![img](https://api-club.hotmart.com/file/public/v5/files/ae477de8-5f09-457c-8dbf-e5f17b0c9889)

Contém apenas letras do alfabeto? False

Note que retornou False, visto que temos os caracteres '<' e '3'. Abaixo, segue uma lista de algumas dessas funções:

- **isdigit():** Retorna True se todos os caracteres da string são dígitos, e False caso contrário.
- **isalpha():** Retorna True se todos os caracteres da string são letras do alfabeto, e False caso contrário.
- **isalnum():** Retorna True se todos os caracteres da string são alfanuméricos (letras ou dígitos), e False caso contrário.
- **islower():** Retorna True se todos os caracteres da string são letras minúsculas, e False caso contrário.
- **isupper():** Retorna True se todos os caracteres da string são letras maiúsculas, e False caso contrário.
- **isspace():** Retorna True se todos os caracteres da string são caracteres de espaço em branco, como espaço, tabulação ou quebra de linha, e False caso contrário.

##  

## 3. Conversão entre tipos

Na maioria das tarefas do dia a dia, é comum precisarmos converter um tipo de dado em outro. Por exemplo, podemos precisar converter um número inteiro em uma string para exibi-la na tela, ou converter uma string em um número para realizar cálculos matemáticos. Nesta seção, vamos falar sobre a conversão entre os tipos de dados mais comuns: int, float, str e bool, que são inteiros, decimais, strings e booleanos, respectivamente.

##  

### 3.7.1 Inteiro int()

Podemos converter outros tipos de dados em um inteiro utilizando a função int().

### str -> int

Por exemplo, se quisermos converter a string "20" para um número inteiro, podemos reproduzir o código abaixo:

![img](https://api-club.hotmart.com/file/public/v5/files/263ad925-d640-4ee1-bfad-a449b8056859)

*Output:
*

**



![img](https://api-club.hotmart.com/file/public/v5/files/975b785a-6301-471a-8d3a-ae228a05feeb)

*Output:
*

**

*Valor de inteiro: 20*

Neste caso, a variável numero recebeu o número 20, que é a representação numérica da string "20". Entretanto, não conseguimos converter uma frase em um inteiro, por exemplo. 

Observe o erro do código abaixo

![img](https://api-club.hotmart.com/file/public/v5/files/85e67fb0-6d7f-4078-8086-e9806bb807c6)

![img](https://api-club.hotmart.com/file/public/v5/files/0606226e-65b9-4137-ac6c-cca5521fa093)

Uma aplicação da função para converter de string para inteiro é quando recebemos algum valor que era para ser numérico utilizando a função input().

###  

### float -> int

Por exemplo, se quisermos converter o valor 5.6 para um número inteiro, podemos reproduzir o código abaixo:

![img](https://api-club.hotmart.com/file/public/v5/files/edf0271e-578d-429b-b326-a48acbba9b60)

*Output:
*

**

![img](https://api-club.hotmart.com/file/public/v5/files/b2879e27-187a-437f-855c-b32a61b1855a)

*Output:
*

**



![img](https://api-club.hotmart.com/file/public/v5/files/ca99fe64-49cf-45eb-b820-e80be892845e)

*Output:
*

*Valor de 'inteiro': 5*

Note que a conversão de um decimal para inteiro, ao chamar a função int, ocorre com o truncamento do número. Isso significa que ele desconsidera as casas decimais e pega apenas a parte inteira. Ou seja, não é um arredondamento, é um truncamento.

##  

### 3.7.2 Decimais float()

Podemos converter outros tipos de dados em decimal utilizando a função float().



### str -> float

Por exemplo, se quisermos converter a string "0.29" em um número decimal, podemos reproduzir o código abaixo:

![img](https://api-club.hotmart.com/file/public/v5/files/a3095791-2844-47a7-9f8e-ee5e8dcfd271)

*Output:
*

**

![img](https://api-club.hotmart.com/file/public/v5/files/6a5f3e8c-fa24-45a1-bbf4-2d4c8be79475)

*Output:
*

**

*O valor de número é: 0.29*

### int -> float

Por exemplo, se quisermos converter o valor intieor 5 em um número decimal, podemos reproduzir o código abaixo:

![img](https://api-club.hotmart.com/file/public/v5/files/5612c7ea-4008-4cc7-a37d-37ff36441c17)

*Output:
*

**



![img](https://api-club.hotmart.com/file/public/v5/files/dfcb6a89-3fde-4344-9f94-240753d55503)

*Output:
*

**

![img](https://api-club.hotmart.com/file/public/v5/files/03bcb880-be0b-4437-8dcf-65f44d17d034)

*Output:
*

*O valor de 'decimal' é: 5.0*

Note que a única diferença foi a presença do ponto flutuante, ou seja, do .0 após o 5.

##  

### 3.7.3 Strings str()

Podemos converter outros tipos de dados em strings usando a função str(). Por exemplo, se quisermos converter um número em uma string, podemos reproduzir o código abaixo:

![img](https://api-club.hotmart.com/file/public/v5/files/d88ff457-fe83-4a11-aadd-673505286942)

*Output:
*

**

![img](https://api-club.hotmart.com/file/public/v5/files/087f2590-030e-4304-b60f-f346ccfe52c6)

*Output:
*

**

*Valor da variável: 5*



### 3.7.4 Booleanos bool()

Podemos converter outros tipos de dados em valores booleanos usando a função bool().

### str -> bool

Por exemplo, se quisermos converter uma string em um booleano, podemos reproduzir o código abaixo:

![img](https://api-club.hotmart.com/file/public/v5/files/fbf050bd-918e-424f-963b-bee0f429d017)

*Output:
*

**

![img](https://api-club.hotmart.com/file/public/v5/files/95853504-f4e2-4c06-a5c7-5885fb868d95)

*Output:
*

**

![img](https://api-club.hotmart.com/file/public/v5/files/15a3fa08-5e27-4069-aec3-a2ca43de2916)

*Output:
*

*Valor de booleano: True*

Quando convertermos uma string para um booleano, o valor True será exibido quando a string não for vazia. Caso contrário, ou seja, caso a string seja vazia, o resultado será False. Observe um exemplo de retorno False abaixo:

![img](https://api-club.hotmart.com/file/public/v5/files/723cd017-e6fb-46b3-b4f2-40ffc66c1377)

*Output:
*

**

![img](https://api-club.hotmart.com/file/public/v5/files/6b57b5be-bc94-4aad-b923-5e7420f03c76)

*Output:
*

**

![img](https://api-club.hotmart.com/file/public/v5/files/8c715d63-8fea-48c4-a7aa-c8bda2b61c9e)

*Output:
*

*O valor de booleano é: False*

### int | float -> bool

Por exemplo, se quisermos converter um inteiro em um booleano, podemos reproduzir o código abaixo:

![img](https://api-club.hotmart.com/file/public/v5/files/cd5b4845-5219-4fe5-8df0-48fd4d86a306)

*Output:
*

**

![img](https://api-club.hotmart.com/file/public/v5/files/62d6b009-55d2-4834-bbce-631731c16fb2)

*Output:**
*

**



![img](https://api-club.hotmart.com/file/public/v5/files/733d4b61-54b2-4b2b-9bc9-e7048aea17c2)

*Output:
*

*O valor de booleano é: True*

Quando convertemos um inteiro ou um decimal para um booleano, o valor True será exibido quando seu valor for diferente de zero (0 ou 0.0). Caso contrário, ou seja, caso o inteiro ou o decimal seja igual a zero, o resultado será False. Observe um exemplo de retorno False abaixo:

![img](https://api-club.hotmart.com/file/public/v5/files/91392ff4-5c8f-43a7-aacb-c9343503ae53)

Output:

<class 'float'>



![img](https://api-club.hotmart.com/file/public/v5/files/6384d3d8-a4d6-490b-875e-35f0eef88354)

*Output:
*

**

![img](https://api-club.hotmart.com/file/public/v5/files/e9aa0cad-774c-4287-bd18-8b512eaee264)

*Output:
*

*O valor de booleano é: False*

#  

# Conclusão

Então, é isso, pessoal! Espero que tenham gostado desse material. Tentei ser o mais completo, teórico, didático e prático possível!

Abraços!