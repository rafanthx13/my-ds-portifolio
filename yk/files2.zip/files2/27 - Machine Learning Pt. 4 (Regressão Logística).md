## Semana 27: Machine Learning Pt. 4 (Regressão Logística)



## 1. Introdução

A Regressão Logística é fundamental em Machine Learning, sendo inclusive uma ponte entre as técnicas de aprendizagem linear e modelos mais complexos. Como parte de nossa série contínua sobre Machine Learning, este material vai mergulhar nesta técnica estatística poderosa que é bastante utilizada para modelagem de previsão e classificação. Nossos materiais anteriores cobriram diversos métodos de aprendizagem supervisionada e não supervisionada, e agora chegou a hora de explorar a Regressão Logística, um método que brilha na sua simplicidade e eficácia.

O papo começa com uma discussão sobre a função sigmoide, o ponto central da Regressão Logística. A função sigmoide é responsável por converter uma entrada contínua em uma probabilidade, e entender seu comportamento é crucial para compreender o funcionamento da Regressão Logística. Essa abordagem permitirá uma transição mais suave para a compreensão das mecânicas da técnica, desde o seu desenvolvimento até a aplicação em problemas práticos.

Ao longo deste material, não só vamos aprender os conceitos fundamentais e a matemática por trás da Regressão Logística, mas também ver exemplos práticos de como aplicar este método em várias situações. Para tornar sua jornada de aprendizado ainda mais interativa, você vai encontrar uma atividade ao final deste material, ou seja, hora de aplicar os conhecimentos adquiridos! Bora para uma aulinha bem legal e instrutiva de Regressão Logística, ferramenta essencial no arsenal de qualquer entusiasta de aprendizado de máquina!

## 2. Função Sigmoid

Antes de falar diretamente sobre a regressão logística em si, vamos falar um pouco sobre essa função, a função sigmoid, que é fundamental para o nosso modelo de regressão logística.

Lembra que eu disse que o pensamento de associar o termo “regressão” do nome da regressão logística a problemas de regressão fazia sentido? Então, embora utilizamos o termo “regressão” para problemas onde queremos prever valores contínuos, como na regressão linear, ele também é utilizado na regressão logística porque fazemos uma modelação do valor contínuo previsto para se ajustar a problemas de classificação.

E essa modelação é feita justamente pela função sigmoide! Se você nunca a viu, observe a imagem abaixo:

![img](https://api-club.hotmart.com/file/public/v5/files/11b9467d-827d-4d0f-b5e7-37b9a19d551f)

![img](https://api-club.hotmart.com/file/public/v5/files/7764ade0-fd68-41de-a22a-013550aa1ec4)

Calma… se você está achando complicado, vou exemplificar e detalhar o que cada um desses termos significa.

Primeiro, se você não conhece essa letra e na parte de baixo da fração, ele representa o número de Euler e tem um valor constante aproximado de 2,718. Ele é uma constante matemática tipo o pi, sabe? Aquele que vale, aproximadamente, 3,14?

Segundo, o -x que está “em cima” do e é o expoente de e. Se você não sabe o que é expoente, observe o exemplo: 32 = 9. Aqui, o expoente é igual a 2, a base é igual a 3 e o resultado é igual a 9. Esse expoente representa quantas vezes multiplicamos a base . Como nosso expoente é 2, então multiplicaremos o 3 duas vezes, resultando em 3*3 = 9.

Talvez, você esteja pensando: “Ah, Anwar, mas aí o expoente é negativo”. Então, quando o expoente é negativo você simplesmente inverte a base. Ou seja, 3-2 = 1/9. Note que agora o expoente é igual a -2. Então, iremos fazer o mesmo cálculo anterior e, ao final, invertemos o resultado. Antes o resultado era 9, agora será 1/9. 

Dito isso, podemos prosseguir. Vamos fazer um exemplo onde x = 2. Dessa forma, ficaremos com o seguinte resultado:

![img](https://api-club.hotmart.com/file/public/v5/files/88f6d4b7-f4f6-4cd4-81b9-4cda7fe8e54b)

![img](https://api-club.hotmart.com/file/public/v5/files/0c127664-af43-47bd-a4f6-197d69649031)

Observe que ele gerou um número maior do que 0 e menor do que 1 Mas será que isso sempre ocorre?

Para validar nossa hipótese, vamos fazer a seguinte observação. Note que a fórmula possui o número 1 no numerador (parte de cima da fração) e o número 1 + e-x no denominador (parte de baixo da fração).

Além disso, repare que e-x será sempre positivo, visto que o número de Euler é uma constante positiva. Com isso, o denominador será sempre maior que o numerador, ou seja, 1 + e-x > 1. Dessa forma, ele sempre será maior que 0 e menor que 1: nos limites de uma probabilidade. Foi mal o spoiler…

Ok, chegamos a essa conclusão de forma intuitiva e com uma matemática básica do ensino médio. Agora, vamos aprofundar um pouco mais. Se você não entender as explicações a seguir, não se preocupe. Vou chegar na mesma conclusão que chegamos anteriormente: que o resultado da função sigmoid varia entre 0 e 1.

Utilizando um pouco de limites, vamos demonstrar formalmente que os limites inferior e superior da função sigmoid são 0 e 1, respectivamente. Se você se lembra das aulas de cálculo, vamos achar as assíntotas horizontais da nossa função sigmoid. Para isso, utilizaremos limites no infinito.

Primeiro, vamos calcular o limite de x tendendo a +infinito. Ou seja, vamos ver qual valor a função sigmoid gera quando x assume um valor gigantesco (+infinito). Observe a expressão abaixo:

![img](https://api-club.hotmart.com/file/public/v5/files/fce2c7d8-ba22-49f2-8015-09f7dbc64bba)

![img](https://api-club.hotmart.com/file/public/v5/files/68e0ac8a-0d11-47be-85fa-d9c92535ade8)

Note que o número de Euler elevado a -infinito é 1/e^(+inf) = 1/inf = 0. Logo, o resultado final da expressão é 1. Isso indica que quando temos um valor de x muito grande, o resultado da função sigmoid tende a 1.

Por outro lado, quando x tende a -infinito, note que o resultado da função sigmoid tende a 0. Ou seja, quando o valor de x é muito pequeno, o resultado da função tende a ficar cada vez mais próximo de 0.

![img](https://api-club.hotmart.com/file/public/v5/files/35bbec6e-dea8-4c40-9810-eedee0bed39c)

![img](https://api-club.hotmart.com/file/public/v5/files/02cb0c4e-ac7b-4d56-a6b3-4d24b9acdbe4)

Tá, então o que a gente consegue concluir depois dessa conta toda? Podemos concluir que a função sigmoid vai retornar um número entre 0 e 1, ou seja, enquadra-se perfeitamente nos limites de uma probabilidade! Quanto maior o x, mais a função fica próxima de 1 (alta probabilidade). Quanto menor o x, mais a função fica próxima de 0 (baixa probabilidade). E quando o x é igual a 0, temos uma probabilidade igual a 0.5 = 50%. No gráfico abaixo, você pode ver a representação gráfica da função sigmoid.

![img](https://lh4.googleusercontent.com/3ldUatMPncaBS-NLv2s6dxJmTkFkMCvFIBMmZ5NoYlorix11mdzE7t5o5RWx6sk540jyX0h46qeAiTojKVfKrzn5wq4-o5rq-pxkoxakZBxRzJ0_FNd38cEdZU3bwTMjSI27gSdgjlE8fYGS-u-ETbU)

![img](https://api-club.hotmart.com/file/public/v5/files/f0275838-ead6-4bc5-8f34-4748e418d156)

## 3. Funcionamento da Regressão Logística

Tá, agora que vimos tudo sobre a função sigmoid, podemos falar sobre o funcionamento do algoritmo em si. Como disse, assim como um modelo de regressão linear, o modelo da regressão logística irá gerar como saída o somatório do produto das features com seus respectivos pesos mais o bias (viés). Entretanto, esse não será o output final do nosso modelo. O resultado irá sofrer uma “modulação”, na verdade, o termo correto seria uma transformação não linear. 

E essa transformação não linear é feita pela função sigmoide. Ou seja, o y da função abaixo será o x da função sigmoide. Se você não entendeu, observe o exemplo abaixo:

![img](https://api-club.hotmart.com/file/public/v5/files/4a3419ec-4ebf-42d7-8b5c-ddf8f23b9cfd)

![img](https://api-club.hotmart.com/file/public/v5/files/96617aad-ad3d-45b8-949d-36eec5d00604)

Imagine que os pesos w1, w2, w3 e o bias forem, respectivamente, 0.3, 0.9, 0.6 e -5.5. Esses pesos foram encontrados, por exemplo, com o gradiente descendente. Agora, vamos olhar para uma instância específica do nosso modelo. Abaixo, você consegue ver a instância:

![img](https://lh4.googleusercontent.com/cHLy5NyKyr9kOsLqFDuLCdMZAmm0_KcIBci0XzDVSRYr1ac8MX1QHxf56VncVoQ-3sv4sC5SoIIl7Zpzmd5SFPhARjmyoUBvaTGRLWlZa3WsaA5t7X7O1tIjBbRt-AbNFUF5aRvLWbCnqh44F9CZAYo)

Note que multiplicaremos x1 por w1, x2 por w2, x3 por w3 e somaremos com o bias (viés). Ficando com o resultado abaixo:

![img](https://api-club.hotmart.com/file/public/v5/files/90323eac-02fb-48a7-853d-cbf183c1f113)

![img](https://api-club.hotmart.com/file/public/v5/files/b69a0fa8-6b72-4c6c-8bd3-dcf5d7744168)

Realizando os cálculos, chegamos no resultado abaixo:

![img](https://api-club.hotmart.com/file/public/v5/files/590a6b12-c980-46a8-b9a0-397223abf984)

Ou seja, para uma determinada instância, o resultado da nossa regressão foi igual a 2. Entretanto, esse valor não será nosso valor de saída, isto é, o output da nossa função. Na verdade, como disse, ele será o input da função sigmoid (o x). Observe a função abaixo:

![img](https://api-club.hotmart.com/file/public/v5/files/9a55520e-14da-46d9-87b8-4064412434a6)

Agora, iremos substituir o x por 2, que é o resultado da expressão anterior. O resultado da função sigmoid quando substituímos x por 2 é 0.881.

![img](https://api-club.hotmart.com/file/public/v5/files/62d635d8-6c09-46aa-93c2-b9fdc0098e8d)

![img](https://api-club.hotmart.com/file/public/v5/files/b4c76799-2d95-454d-bc1a-1938c70d201a)

Note que ele gerou uma probabilidade igual a 0.881, ou seja, 88.1%, mas o que significa essa probabilidade?

A probabilidade gerada pela função sigmoid representa a probabilidade de pertencer à classe 1. Ou seja, neste exemplo, a instância que fizemos o cálculo possui 88.1% de chance de pertencer à classe 1.

Mas até que valor de probabilidade será aceito como classe 1? Se a probabilidade gerada for 0.2 = 20% ele ainda será da classe 1?

Como vocês podem imaginar, não é bem assim. Jogamos esse resultado da função sigmoid em uma outra função. Pois é, é resultado de função em cima de função, hahahah. Mas calma, essa é mais tranquila. Se o valor da probabilidade for maior ou igual a 0.5 (50%), atribuímos à classe 1. Caso contrário, ou seja, caso o valor da probabilidade seja menor que 0.5 (50%), atribuímos à classe 0. Observe a função abaixo:

![img](https://api-club.hotmart.com/file/public/v5/files/cd0a87e5-392a-4d3f-9c93-860a8e10007d)

![img](https://api-club.hotmart.com/file/public/v5/files/705b8fa3-f549-452f-82f6-c00382ac4e76)

Agora, sim! Temos o resultado final do modelo de regressão logística. Como a probabilidade daquela instância é igual a 88.1%, vamos atribuir à classe 1. 

## 4. Treinamento do algoritmo

Bom, agora que já vimos como o algoritmo funciona, já vimos toda aquela matemática da regressão logística, vamos falar sobre como ele é treinado. Já sabemos que ele associa à classe 1 outputs com altas probabilidades e à classe 0, outputs com baixa probabilidade.

Então, o objetivo do treinamento é encontrar todos os pesos (w1, w2, w3 etc.) tais que a probabilidade seja maior ou igual a 0.5 para as classes iguais a 1 e menor que 0.5 para as classes iguais a 0.

Para uma probabilidade ser maior ou igual a 0.5, basta que o resultado daquela expressão parecida com a regressão linear seja maior ou igual a 0. Analogamente, para uma probabilidade gerada pela função sigmoid ser menor que 0.5, basta que o resultado da expressão seja menor que 0.

Abaixo, você vê a função de perda utilizada frequentemente, a log-loss:

![img](https://api-club.hotmart.com/file/public/v5/files/31d8debe-55d6-4bbf-b430-ac6fc7c82d77)

![img](https://api-club.hotmart.com/file/public/v5/files/f9859d33-e213-4bdd-9742-cdf0a911487d)

Imagine que a probabilidade gerada para uma instância com classe real igual a 1 seja 0.2. Como pode imaginar, nosso modelo errou. O custo desse erro é -log(0.2) = 1.609. Se a probabilidade fosse 0.005, ou seja, 0.5%, o resultado do custo seria -log(0.005) = 5.298. Note que quanto maior o erro, mais o custo irá aumentar.

Para recapitular, “função de perda” é o nome dado à função de custo para apenas uma instância. Quando queremos mensurar o erro de todas as instâncias do nosso dataset, utilizamos a função de custo.

Neste caso, a função de custo será a média da função de perda para todas as instâncias. Além disso, podemos simplificar o cálculo da função de perda com a seguinte fórmula:

![img](https://api-club.hotmart.com/file/public/v5/files/60a5578c-4876-4b61-be29-397cdbcea627)

![img](https://api-club.hotmart.com/file/public/v5/files/14378274-86d8-4356-a618-dcf5f2194701)

Essa é a função de otimização utilizada pelo gradiente descendente para atualizar os pesos da nossa regressão. E vale lembrar que, por ser um algoritmo que utiliza o gradiente descendente, a aplicação de scaling faz com que o algoritmo convirja de forma mais rápida para o mínimo global.

## 5. Conclusão

É isso, pessoal! Espero que saiam daqui com uma outra visão sobre a regressão logística. Na verdade, não apenas uma outra visão, mas também com um artigo explicando o passo a passo, com algum dataset, da regressão logística. 

Fica como desafio (e tarefa) para vocês o seguinte: escolham um dataset de sua preferência, faça todo o pré processamento e as etapas antes da modelagem. Quando chegarem na modelagem em si, implementem, na mão, um modelo de regressão logística. Vai precisar utilizar o algoritmo do gradiente descendente! 

Quando finalizarem o projeto, faça um artigo no Medium explicando o passo a passo do seu projeto (cujo intuito é implementar a regressão logística na unha, então você não precisa de um desempenho extraordinário). E não se esqueça de publicar esse projeto no GitHub!

Para ajudar vocês, abaixo está um exemplo de implementação do algoritmo do Gradiente Descendente que fiz na unha. Complete-o!

![img](https://api-club.hotmart.com/file/public/v5/files/185102d2-e1cc-458d-a234-05b5be8e1fa1)



*Uma pequena dica (Yukio, falando aqui): Você poderia falar com um coleguinha robô aí que anda bem famoso na internet e pedir ajuda para completar, caso não consiga. A gente pode te dar a resposta, claro, é só chamar que tá tudo bem! Mas eu queria muito ver vocês conseguindo andar com as próprias pernas também. Você sabe como pedir ajuda nesses casos à inteligência artificial mais hypada de 2023? Se não conseguir, pode me chamar!*