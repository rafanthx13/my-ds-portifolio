## Semana 33 - Machine Learning pt. 10 (Juntando tudo)



# Introdução

Enfim, chegamos ao fim dos conceitos básicos de Machine Learning. Se você se empenhou nessa caminhada, você está muito acima da média dos cientistas de dados júnior que estão pelo mercado, orgulhe-se disso! Agora, vamos juntar tudo o que aprendemos com mais algumas dicas extras que resolvi trazer de última hora e montar dois modelos, um de regressão e um de classificação! Boa aula!

Ahh e se quiser os notebooks, eles estão em anexo!



## Modelo 1: Regressão com Muitas Features



<iframe width="500" height="281" src="https://www.youtube.com/embed/GizlBH5G7zc" frameborder="0" allowfullscreen="" style="box-sizing: border-box; -webkit-font-smoothing: antialiased; margin-bottom: 30px; position: absolute; top: 0px; bottom: 0px; left: 0px; width: 587.328px; height: 330.359px; border: 0px; max-width: 100%;"></iframe>





##  

## Modelo 2: Classificadores



<iframe width="500" height="281" src="https://www.youtube.com/embed/UYzF3FCshdg" frameborder="0" allowfullscreen="" style="box-sizing: border-box; -webkit-font-smoothing: antialiased; margin-bottom: 30px; position: absolute; top: 0px; bottom: 0px; left: 0px; width: 587.328px; height: 330.359px; border: 0px; max-width: 100%;"></iframe>