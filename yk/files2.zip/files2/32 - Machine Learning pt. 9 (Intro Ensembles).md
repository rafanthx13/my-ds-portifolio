## Semana 32: Machine Learning pt. 9 (Introdução aos Ensembles)



# 1. Modelos Ensemble: Pela união de seus poderes...

![10 fatos e curiosidades sobre o Capitão Planeta!](https://kanto.legiaodosherois.com.br/w760-h398-cfill/wp-content/uploads/2016/04/4a1fa78d4906a75946650a6e9a02a3fb.jpg.webp)

Salve, galera do Clube! Depois de nos aprofundarmos nas métricas de validação, que tal explorarmos um território que diz respeito aos melhores modelos do mundo do Machine Learning? Estou falando dos MODELOS ENSEMBLE. Imagine pegar vários modelos, cada um com suas forças, e juntá-los para criar uma máquina de previsão absurda. Bora entender melhor do que eu estou falando!



## 1.1 DEFINIÇÃO: O QUE SÃO ENSEMBLES?

Modelos ensemble são modelos que combinam as previsões de múltiplos modelos base para gerar uma previsão mais robusta, uma previsão superior ao que conseguiríamos com os modelos 'base'. O objetivo principal é combinar diferentes modelos de aprendizado de máquina para reduzir os erros associados a qualquer modelo individual. Isso é feito de forma a aproveitar as forças e compensar as fraquezas de cada modelo envolvido no ensemble.

Os modelos ensemble são categorizados em diferentes tipos, como Bagging, Boosting e Stacking, cada um com sua própria metodologia e aplicação. Por exemplo, enquanto o Bagging foca na redução da variância dos modelos, o Boosting visa otimizar a precisão ao ajustar os pesos das observações com base nos erros dos modelos anteriores - o boosting trabalha de forma sequencial, daí os "modelos anteriores". O Stacking, por outro lado, combina previsões de diferentes tipos de modelos para criar um "meta-modelo" que oferece uma previsão final mais robusta. Essas técnicas de ensemble são amplamente utilizadas em várias aplicações práticas, desde sistemas de recomendação até diagnósticos médicos e previsões financeiras. Elas são especialmente úteis em cenários onde os dados são complexos e um único modelo não é suficiente para capturar todas as nuances e padrões nos dados.

O uso de modelos ensemble não apenas melhora a robustez das previsões, mas também oferece uma camada adicional de confiabilidade ao tornar o modelo final menos suscetível a overfitting. Isso é crucial para garantir que o modelo seja generalizável para dados não vistos anteriormente, tornando os modelos ensemble uma escolha popular entre cientistas de dados e analistas. Portanto, os modelos ensemble representam uma abordagem estratégica em Machine Learning, permitindo que os praticantes alcancem níveis mais altos de precisão e confiabilidade em suas previsões e análises. Não é à toa que são eles que aparecem no topo de todas as competições do Kaggle, né?



## 2 TIPOS DE ENSEMBLE

## 2.1 Bagging

### 2.5.1 Introdução

Depois de ser introduzido ao mundo fascinante dos modelos ensemble, está na hora da gente colocar o foco nos tipos de ensemble que existem. Vamos começar com uma técnica que é bem simples de entender, intuitivamente, mas que nem por isso é menos efetiva que as seguintes. Prepare-se para conhecer o Bagging, um método que tem tudo a ver com estabilidade e confiabilidade. Você já se perguntou como melhorar um modelo que parece bom, mas ainda sofre com altos e baixos nos resultados? O Bagging pode ser a resposta! 

Então, se você está animado para descobrir como essa técnica pode elevar seu modelo a um novo nível, fique ligado. Nas próximas seções, vamos nos aprofundar nos mecanismos que tornam o Bagging uma opção bastante atraente para seu próximo trabalho que necessitar de modelos preditivos!

###  

### 2.5.2 O que é Bagging?

Bootstrap Aggregating, é uma técnica de ensemble em aprendizado de máquina projetada para aprimorar a estabilidade e a precisão dos algoritmos de aprendizado estatístico. Ao contrário de outras técnicas de ensemble como boosting e stacking, que são mais sofisticadas em sua abordagem, o bagging opera de uma maneira mais direta. A técnica envolve a criação de múltiplas amostras do conjunto de dados original e o treinamento de um modelo específico para cada uma dessas amostras. O resultado final é obtido através da agregação das previsões de cada modelo, que pode ser uma média aritmética no caso de problemas de regressão ou uma votação majoritária para problemas de classificação.

A eficácia do bagging é amplificada quando se utiliza um grande número de modelos, como 50, 100 ou até 1000, para fazer a previsão final. Isso aumenta a robustez do modelo e reduz a variância, tornando o modelo final mais preciso e confiável. Além disso, algoritmos específicos que utilizam bagging, como o Random Forest, introduzem outra camada de aleatoriedade ao selecionar um subconjunto de recursos para cada árvore de decisão construída, o que aumenta a diversidade entre os modelos e, portanto, melhora o desempenho geral.

O termo "Bootstrap" em Bootstrap Aggregating refere-se a uma técnica estatística de amostragem que envolve a criação de múltiplos subconjuntos de amostras do conjunto de dados original, permitindo a reposição. Isso significa que um único ponto de dado pode ser selecionado mais de uma vez para cada subconjunto de amostra, também conhecido como "amostra bootstrap".

###  

### 2.5.3 Como Funciona o Modelo Bagging?

![img](https://api-club.hotmart.com/file/public/v5/files/83f31036-3ffc-464b-9df9-a5d916fe8440)

Fonte da imagem: [Wikipedia - Bootstrap Aggregating...](https://en.wikipedia.org/wiki/Bootstrap_aggregating)

**1. Amostragem Bootstrap:** O primeiro passo no bagging é gerar múltiplos subconjuntos de dados a partir do conjunto de dados original. Isso é feito através de uma técnica de amostragem com reposição, o que significa que um único ponto de dados pode ser incluído em várias amostras.

**2. Treinamento (Paralelamente) de Modelos:** Cada um desses subconjuntos de dados é então usado para treinar um modelo de aprendizado de máquina distinto. Os modelos podem ser do mesmo tipo, como várias árvores de decisão em um Random Forest, ou podem ser diferentes, dependendo dos requisitos específicos do problema que está sendo resolvido.

**3. Votação/Média:** Após o treinamento, as previsões de todos os modelos individuais são agregadas para formar uma única previsão final. Em problemas de classificação, isso é geralmente realizado através de uma votação majoritária, onde a classe que recebe o maior número de votos é selecionada como a previsão final. Para problemas de regressão, a média das previsões de todos os modelos é calculada para obter uma única previsão contínua.

Dessa forma, o bagging consegue mitigar os efeitos de overfitting e aumentar a robustez do modelo, tornando-o uma técnica valiosa para melhorar o desempenho em tarefas de aprendizado de máquina.



### 2.5.4 Vantagens e Desvantagens

**Vantagens:**

\- Reduz a variância e o overfitting.

\- É simples de implementar.

\- Possui maior estabilidade, melhorando acurácia

\- Lida bem com alta dimensionalidade

**Desvantagens:**

\- Possui perda de interpretabilidade

\- Pode ser computacionalmente caro.

\- Não resolve problemas de viés nos modelos base.



### 2.5.5 Exemplo Prático em Python

Suponhamos que você queira usar o algoritmo RandomForest, que é basicamente um exemplo de bagging aplicado a árvores de decisão. Veja como você faria isso em Python:

![img](https://api-club.hotmart.com/file/public/v5/files/d151fc61-8e37-48ae-9a84-ebd21a92b60a)


E pronto! Você acabou de criar um modelo de bagging usando RandomForest. Bora testar esse novo modelo e ver como suas predições ficarão muito melhores?



## 2.2 Boosting

### 2.2.1 Introdução

Salve, turma! Depois de mergulhar no Bagging, bora explorar uma técnica que eleva o conceito de ensemble a novos patamares? Eu sei que falo isso toda hora, mas é que só vai ficando melhor rs. Abra espaço para o Boosting, a técnica mais falada, ou uma das, nas competições do Kaggle! Se o Bagging era sobre coletar informações rodadas em paralelo, o Boosting já entra com uma proposta diferente, mais focada no aprendizado em sequência. O Boosting é uma técnica que não apenas combina diferentes modelos, mas também os otimiza de uma forma que você nunca viu antes. Esta "aula" promete! Vai ser repleta de descobertas que podem revolucionar a maneira como você aborda os desafios em Machine Learning.

Estão animados? Eu estou! Bora! Como diria Senku, ISTO É TÃO EMPOLGANTE! (Nerd alert)



### 2.2.2 O que é Boosting?

Boosting é uma técnica de ensemble sofisticada que busca otimizar o desempenho de modelos de aprendizado de máquina de uma forma bem particular. Ao contrário do stacking ou do bagging, onde os modelos são treinados de forma independente e suas previsões são combinadas no final, o boosting adota uma abordagem mais colaborativa e sequencial. Imagine um time de futebol onde cada jogador observa os erros do jogador anterior e ajusta sua estratégia para evitar cometer os mesmos erros. É mais ou menos assim que o boosting funciona.

Nesta técnica, começamos com um modelo base, que pode ser algo simples como uma árvore de decisão. Este modelo faz suas previsões e, inevitavelmente, comete alguns erros. Em vez de simplesmente descartar esse modelo ou combiná-lo com outros modelos igualmente falíveis, o boosting entra em ação para corrigir esses erros. Um segundo modelo é treinado, mas com um foco especial nos pontos onde o primeiro modelo errou. Esse segundo modelo, então, tenta corrigir os erros do primeiro.

Mas a mágica do boosting não para por aí. Um terceiro modelo entra em cena, observando os erros tanto do primeiro quanto do segundo modelo, e assim por diante. Cada modelo subsequente é uma tentativa de corrigir os erros acumulados dos modelos anteriores. O processo continua até que se alcance um nível predeterminado de precisão ou até que um número máximo de modelos seja treinado. O resultado final é uma espécie de "comitê de especialistas", onde cada modelo é um especialista em corrigir os erros de um ou mais de seus predecessores. As previsões desses modelos são então ponderadas e combinadas para produzir uma única previsão final, que é frequentemente muito mais precisa do que qualquer previsão feita por um único modelo.

Portanto, o boosting é como uma série de ajustes finos, onde cada novo modelo é uma iteração refinada do anterior, com o objetivo de minimizar os erros e melhorar a precisão. É uma técnica poderosa que tem mostrado grande sucesso em uma variedade de aplicações de aprendizado de máquina, desde classificação de texto até detecção de fraudes e muito mais.



### 2.2.3 Como Funciona o Modelo Boosting?

![img](https://api-club.hotmart.com/file/public/v5/files/59185a70-e996-4a07-be79-65577a22d27c)

Fonte da imagem: [A Beginner’s Guide for Gradient Boosting](https://medium.com/@skilltohire/the-beginners-guide-for-gradient-boosting-e5c67584240e)

**1. Modelo Inicial:** Você começa com um modelo simples, também conhecido como "modelo fraco" - em inglês, é mais comum ouvir weak learner, não weak model. Esse modelo é treinado no conjunto de dados original

**2. Correção de Erros:** Depois de treinar o modelo inicial, você identifica onde ele errou. O próximo modelo que você treina se concentra mais nesses erros.

**3. Ponderação:** Cada modelo possui um "peso" com base em seu desempenho. Modelos que fazem previsões mais precisas têm mais "dizer" na previsão final.

**4. Previsão Final:** As previsões de todos os modelos são combinadas com base em seus pesos para produzir a previsão final.



### 2.2.4 Vantagens e Desvantagens

**Vantagens:**

\- Melhora a precisão e reduz o viés.

\- É eficaz com conjuntos de dados desbalanceados.

\- Pode converter modelos fracos em um modelo forte.

**Desvantagens:**

\- É sensível a ruídos e outliers.

\- Tem perda de interpretabilidade

\- Pode ser propenso a overfitting, se não for cuidadosamente ajustado.



### 2.2.5 Exemplo Prático em Python

Vamos supor que você quer usar o algoritmo AdaBoost, que é uma das técnicas de boosting mais populares. Aqui está como você faria isso em Python:

![img](https://api-club.hotmart.com/file/public/v5/files/2c23fb23-3fdf-46fe-85eb-8828fdd13928)


E aí está! Você acabou de criar um modelo de boosting usando AdaBoost. Agora você tem uma ferramenta poderosa que pode transformar modelos fracos em um único modelo forte e preciso. Boosting é uma técnica incrível que pode ser a chave para desbloquear um desempenho superior em suas tarefas de aprendizado de máquina.

##  2.3 Stacking

### 2.3.1 Introdução

Se você chegou até aqui, provavelmente já tem uma boa noção sobre os modelos ensemble e suas técnicas mais conhecidas: Boosting e Bagging. Ambas são extremamente úteis para aprimorar o desempenho dos modelos de aprendizado de máquina, mas não são as únicas estratégias disponíveis. Há uma terceira técnica, conhecida como Stacking, que oferece uma abordagem única para otimizar o desempenho. Stacking não é apenas mais uma técnica; ela apresenta um enfoque estrutural diferenciado que pode ampliar ainda mais o leque de possibilidades na construção de modelos altamente eficazes. Com o Stacking, você não só ajusta e melhora as previsões de modelos individuais, como também integra essas previsões de uma forma inteligente, utilizando um modelo final adicional conhecido como "meta-modelo". Você vai ver que, apesar de não ser a técnica mais usada, ela é uma carta na manga que todo cientista de dados fera tem que ter!



### 2.3.2 O que é Stacking?

Se você já está familiarizado com as outras formas de modelos ensemble, o elemento que realmente distingue o Stacking é o uso de um "meta-modelo". Enquanto Bagging e Boosting ajustam o desempenho dos modelos por meio de métodos como amostragem com reposição ou atribuição de pesos, o Stacking adota uma abordagem diferente. Aqui, você primeiro treina uma variedade de modelos base usando seu conjunto de dados. Cada um desses modelos pode ser eficaz em capturar um aspecto particular dos dados, mas nenhum deles é perfeito. O próximo passo é coletar as previsões de todos esses modelos e usá-las como entradas para um novo modelo, o "meta-modelo". Esse novo modelo é treinado para usar essas previsões múltiplas e combiná-las de uma forma que resulte em uma previsão final mais precisa e robusta. O potencial aqui é imenso. Ao adicionar essa camada adicional de otimização, você está, na verdade, adicionando uma forma adicional de revisão e ajuste que pode ser extremamente valiosa, especialmente em cenários mais complexos e multifacetados.

Essas são as considerações expandidas sobre o Stacking. Com essa abordagem, você não está apenas empilhando modelos aleatoriamente, mas sim orquestrando um processo cuidadoso que permite a cada modelo contribuir com o melhor de suas habilidades para o resultado final. Isso oferece uma gama mais ampla de ferramentas para abordar problemas complexos, melhorando a precisão e robustez das suas previsões e análises.

###  

### 2.3.3 Como Funciona o Modelo Stacking?

**1. Treinamento de Modelos Base:** Primeiro, você treina vários modelos diferentes usando seu conjunto de treinamento. Pode ser uma mistura de regressores, classificadores, árvores de decisão, SVMs, redes neurais, o que você quiser.

**2. Previsões de Modelos Base:** Em seguida, cada um desses modelos faz uma previsão usando o conjunto de validação.

**3. Treinamento do Meta-Modelo:** As previsões desses modelos base são então usadas como recursos para treinar um novo modelo, conhecido como meta-modelo.

**4. Previsão Final:** Finalmente, o meta-modelo faz a previsão final, que idealmente é mais precisa do que qualquer um dos modelos individuais.

###  

### 2.3.4 Vantagens e Desvantagens

Vantagens:

\- Melhora a precisão e a robustez do modelo.

\- Permite a combinação de modelos heterogêneos.

\- Pode ajudar a capturar relações não-lineares nos dados.

Desvantagens:

\- Pode ser computacionalmente caro.

\- Risco de overfitting, se não for feito com cuidado.

###  

### 2.3.5 Exemplo Prático em Python

Vamos supor que você tem três modelos: uma Regressão Logística (`model1`), uma Árvore de Decisão (`model2`) e um k-NN (`model3`). O meta-modelo será uma Regressão Linear (`meta_model`).

![img](https://api-club.hotmart.com/file/public/v5/files/698c74ad-df99-4cd4-b81d-b21b0db51966)

Stacking é uma técnica poderosa que pode melhorar significativamente a precisão do seu modelo de machine learning. No entanto, é crucial entender como equilibrar a complexidade e a simplicidade para evitar o overfitting. Quando feito corretamente, o stacking pode ser a chave para ganhar aquelas competições de Kaggle ou simplesmente melhorar o desempenho do seu modelo no mundo real.



# 3. Considerações Finais

Estamos chegando ao fim da nossa trilha de Machine Learning, contemplando tudo e mais um pouco do que um júnior precisa saber. Eu até me arrisco a dizer que 90% dos plenos no mercado não sabem tudo isso, mas é um chute. Quem seguiu nosso roteiro agora entende não apenas dos principais modelos que todo iniciante deve saber, como aprenderam inclusive modelos mais hardcore, como os ensemble. E, veja, Bagging, Boosting e Stacking não são apenas termos chique para impressionar o recrutador, ein? Pense neles como os elementos invocados pelos Protetores do Planeta antes de gritar "Vai, Planeta!" para convocar o Capitão Planeta. Cada método é como Terra, Fogo, Vento, Água e Coração — todos são incríveis sozinhos, mas quando se combinam, fazem surgir o Capitão Planeta, que tem poderes além da imaginação. É mais ou menos isso que acontece quando você combina diferentes algoritmos em um modelo ensemble: você convoca um supermodelo que é capaz de enfrentar desafios muito mais complexos.

Não quero que vocês pensem que estou menosprezando os modelos de aprendizado de máquina mais simples que aprendemos nas primeiras semanas. Muitas vezes, eles são como o personagenzinho do Capitão Planeta que representava a Água — específicos, fortes e eficazes por conta própria, especialmente em situações que exigem aquele tipo específico de poder. Mas em alguns cenários, especialmente quando você se depara com dados mais complexos e caóticos, você realmente precisa invocar o Capitão Planeta para salvar o dia. É nessas horas que os métodos de ensemble são como ter todos os anéis dos Protetores do Planeta: você pode enfrentar quase qualquer desafio que aparecer.

Aqui teríamos 3 Capitães Planetas, então não sei se foi a melhor analogia. Mas vamos recapitular que o Bagging diminui a variância e traz estabilidade para o modelo, ali, pegamos o resultado de N modelos rodados paralelamente. O Boosting busca reduzir o viés, sempre tentando minimizar o erro com seu aprendizado sequencial. E o Stacking? Bem, o Stacking é capaz de combinar diferentes modelos, aproveitando o potencial de cada um, formando um supermodelo que é mais do que a soma das suas partes.

Nossa jornada ainda não chegou ao fim, teremos ainda mais um material muito legal e muito mão na massa, quero garantir que todos os que chegaram aqui consigam rodar bons modelos no mercado e não fiquem perdidos em suas primeiras experiências. Quero que vocês cheguem com os 2 pés nas portas! Fechado? Então bora aplicar o que aprendemos hoje! Tem dataset de sobre no Kaggle para testar seus conhecimentos, bora!!!!