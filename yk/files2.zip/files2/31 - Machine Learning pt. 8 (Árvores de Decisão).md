## Semana 31 - Machine Learning pt. 8 (Árvores de Decisão)



# 1.Introdução

Fala, rapaziada! Vamos começar agora a nossa aula sobre árvores de decisão! Hoje, vamos falar sobre todo o funcionamento das árvores de decisão. Qual métrica ela usa para fazer as divisões, qual é a diferença de um problema de classificação para um de regressão, quais são os hiperparâmetros mais importantes etc..

**Se você quiser dar uma olhada numa introdução bem superficial de árvore de decisão, recomendo a leitura do material da semana 4, quando introduzimos o algoritmo pela primeira vez!** **Esta leitura vai facilitar muito sua introdução no mundo das árvores, que contemplam boa parte dos algoritmos de Machine Learning, principalmente os famosos ensemble, os mais poderosos em termos preditivos. Não deixe de dar uma passada naquele material antes de continuar esta leitura!*****
***



# 2. O que são Árvores de Decisão?

Para começar a falar sobre as árvores de decisão, é importante destacar que elas são um algoritmo de Machine Learning capaz de realizar ambas as tarefas de aprendizado supervisionado: classificação e regressão. Esse algoritmo consegue aprender tão bem com os dados que, se você não tomar cuidado, pode facilmente overfittar.

Para deixar mais claro o que é uma árvore de decisão, vamos pegar um exemplo como guia. Vamos utilizar um dataset de classificação de vinhos [obtido do próprio scikit-learn](https://scikit-learn.org/stable/modules/generated/sklearn.datasets.load_wine.html)*, onde temos 3 possíveis classes. Abaixo, você pode ver as primeiras features do dataset. Vamos treinar uma árvore de decisão bem simples para tentar classificar um vinho em classe 0, 1 ou 2.

![img](https://lh6.googleusercontent.com/lFPALkwx4Fom0tt6pcdvjllaDuYZVXbhVrHr6kvEnGBnQXwZsOTJsc2e3OU2Fwa_qNhvndXdXDNVm2pDm9rkmcXH5WGYnetbVf39WQNT5Ie9z4ssOeEfGxbu7KiproikkXPDM_adIsI_Wi8Kxn8KsAg)

Com o modelo treinado, podemos visualizá-lo abaixo. Olhando assim, você pode pensar que é a coisa mais complexa do mundo, mas, na verdade, é bem simples de entender. Note que a estrutura de uma árvore de decisão é bem parecida com um fluxograma, onde respondemos “sim” ou “não” para uma determinada pergunta.

\* Se tiver dificuldade ao lidar com o dataset, basta notar que "data" contém os dados e "feature_names" os nomes das colunas:



![img](https://api-club.hotmart.com/file/public/v5/files/77471071-7a95-4f3b-a58a-32d343c3207e)



# 3, Como as Árvores de Decisão fazem as predições?

Antes de começar a fazer um exemplo para demonstrar como modelos em árvore fazem as predições, quero ressaltar um detalhe em relação aos termos que usaremos. Veja a árvore de decisão desenhada abaixo e que começa pela variável Proline. Cada um dos retângulos que vocês estão vendo na árvore é chamado de “nó”. Cada um dos nós possuem exatamente 1 pai e 2 filhos. Quando um nó não possui um pai, o chamamos de nó raiz. Quando ele não possui filhos, chamamos de nó folha.

Vamos criar um exemplo começando pelo nó raiz. Como podem ver, se “Proline” for menor ou igual a 900.5, vamos seguir o caminho da esquerda. Como nossa instância possui “Proline” igual a 760, que é menor ou igual a 900.5, seguiremos o caminho da esquerda.

![img](https://lh3.googleusercontent.com/2zd1ftPIe8fSbvB_KR7OgJFP-JusRO1gudIg_wSK4DsoTdyorIkqd9MLhDzDHyUclgekDQ3LzWNQywhF_rGCvZ1kYwp_5NlO-1M1PFLBMWp63IgcLBrrIUknBqVxiK05_gx0PSbEmmaO6HUAtd-8otY)

Após isso, vamos verificar se “color_intensity” é menor ou igual a 3.97. Como nossa instância possui um “color_intensity” igual a 5.10, ou seja, maior que 3.97, seguiremos o caminho da direita.

Agora, verificaremos se “Flavanoids” é menor ou igual a 1.4. Como nossa instância possui um “Flavanoids” igual a 3.04, ou seja, maior que 1.4, seguiremos o caminho da direita.

Por fim, verificaremos novamente a “Proline”. Dessa vez, se ela é menor ou igual a 679. Como nossa instância possui uma “Proline” igual a 760, ou seja, maior que 679, seguiremos o caminho da direita. Agora, caímos em um nó folha, ou seja, um nó que não possui filhos.

Os nós folhas são os responsáveis por fazerem a classificação em uma árvore de decisão. Quando sua instância chega nesse nó, ela é classificada. Vamos observar o nó folha que nossa instância de exemplo caiu.

![img](https://lh3.googleusercontent.com/ono28VySZGev1PPvwJ6tFOoyPK7lVeP4gXuX8QwoKHbS5vGRSC3G_Kk63uVjTBut1jiHtzkQBwrPKxHFLa7zERBz5TUeuadmcu5ABjh6xGUlvDmDCPnHH0O6KIabDmODWF4NVSNhus7FqD_9QqUnFAs)

Vou falar sobre esse termo “gini” depois, segura um pouco aí. O termo “samples” indica a quantidade de instâncias que, no treinamento, também caíram nesse nó folha. Se você for olhar alguns outros nós folhas da árvore, verá que alguns possuem mais de 40 instâncias nele. Esse array “value” indica a quantidade de instâncias de cada uma das classes que caíram nesse nó folha. Note que caíram apenas 4 instâncias da classe 0 e nenhuma outra mais. Por fim, o termo “class” indica qual a classe a nossa árvore irá atribuir às instâncias que caírem nesse nó folha. 

Podemos também retornar as probabilidades de uma determinada instância pertencer a uma classe. Note que basta apenas dividir o número de instâncias de cada classe pelo número total de instâncias naquele nó. Nesse caso, temos 4 instâncias no total e 4 instâncias da classe 0, 0 instâncias da classe 1 e 0 instâncias da classe 2, resultando em probabilidades iguais a 100%, 0% e 0%, respectivamente.

Agora, vamos analisar um nó que não seja folha. Aqui, na primeira linha, temos a condição a ser satisfeita para um determinado caminho ser seguido. Nesse exemplo, se “color_intensity” for menor ou igual a 3.97, seguiremos o caminho da esquerda. Caso contrário, o caminho da direita. Sobre o “gini”, segura mais um pouco. No próximo slide falarei sobre ele. Aqui, “samples” igual a 100 indica que 100 instâncias caíram nesse nó durante o treinamento. Dessas 100 instâncias, como podemos ver em “value”, 6 eram da classe 0, 56 da classe 1 e 38 da classe 2. Como não é um nó folha, não faremos a classificação aqui.

![img](https://lh3.googleusercontent.com/ono28VySZGev1PPvwJ6tFOoyPK7lVeP4gXuX8QwoKHbS5vGRSC3G_Kk63uVjTBut1jiHtzkQBwrPKxHFLa7zERBz5TUeuadmcu5ABjh6xGUlvDmDCPnHH0O6KIabDmODWF4NVSNhus7FqD_9QqUnFAs)

Pronto, agora que já falamos sobre todos os termos, podemos falar sobre esse tal de “gini”! Ele calcula a impureza de um nó. Um gini = 0 indica que aquele nó é puro, como você pode observar no nó folha que está aparecendo abaixo, que nós analisamos. O nó ser puro significa que todas as instâncias de treinamento que foram atribuídas àquele nó pertencem à mesma classe, seja ela qual for. Nesse exemplo, temos um total de 4 instâncias que foram atribuídas a esse nó. Dessas 4 instâncias, todas são da classe 0. Logo, é um nó puro. 

Para calcular a impureza de cada nó, utilizamos o Coeficiente de Gini, que pode ser calculado com a fórmula abaixo. Aqui, p2i, k é a relação de instâncias de uma determinada classe k entre as instâncias de treinamento daquele nó em específico (i-ésimo nó).

![img](https://lh6.googleusercontent.com/oFYrwB5hnmvYIZtqleNSL3vB83dijdaFm0Ki3E816rOrcTXWcKQzCZqCP0vZoi-iBvHTkGBJzX0t609TGe7h-rfaqtsnfNIwotwLk02X8OBrbp71X55F4UPb5opNUEy5opzME0SH37u6Tx5KmqMBr8I)

Fazendo o exemplo do nó que não é folha - o nó esquerdo de profundidade 1 -, temos a expressão abaixo. Note que p2i, k é simplesmente a proporção ao quadrado de instâncias de uma determinada classe. Temos 100 instâncias no total para aquele nó e 6 instâncias com classe igual a 0, então fazemos (6/100)². Depois, temos 56 instâncias com classe igual a 1, então fazemos (56/100)² e por aí vai. Somamos todos esses resultados e subtraímos de 1, resultando em 0.5384. 

![img](https://lh3.googleusercontent.com/5qFIIyCbOvSMx33E73yHiMCbgrhYrJSuoKJ08t5Bg6oq6fWtLSAjrmwLVfVAKQQIXI9p4_HDPlpVKFCmKCDSsvLpcJ6yS956WVWncGRLcKHvrM7ZEQPVysTjS-L4rJdPq_ZjOWVL38wf-I1IwiLw1iQ)

![img](https://lh5.googleusercontent.com/Z4yUXS4oB36xOVYZiHCPs4RzTkAGPwMhIWMC9Ywq5dmZvQsL_RTkwyIp83PaC3SDfey2Jg1xj-FjDGFwn2mZ6j3Q-CrXj8RDU6VFY2EJqw2VEKfp1yLdS7pkdWLMKsYuSff5AeYwov2uCkhp2Mgszr8)

O gini é utilizado como referência para fazer os splits em cada nó. O objetivo é fazer uma divisão com o menor grau de impureza possível, ou seja, separando ao máximo as classes. Note que o nó direito de profundidade 1 possui um gini = 0.046, isso porque temos 42 instâncias no total, mas 41 da classe 0 e apenas 1 da classe 1, por isso esse nó é quase puro. Assim como ele, todos os splits visam tornar o nó folha puro.

![img](https://lh3.googleusercontent.com/ono28VySZGev1PPvwJ6tFOoyPK7lVeP4gXuX8QwoKHbS5vGRSC3G_Kk63uVjTBut1jiHtzkQBwrPKxHFLa7zERBz5TUeuadmcu5ABjh6xGUlvDmDCPnHH0O6KIabDmODWF4NVSNhus7FqD_9QqUnFAs)

Além dessa métrica, também podemos utilizar uma outra: a Entropia. Por padrão, as árvores de decisão utilizam como critério para fazer os splits o coeficiente de Gini, porém podemos alterar mudando o parâmetro “criterion” para “entropy”. Se você já estudou um pouco de física, lembra que entropia é uma medida de desordem. Ela se aproxima de 0 quando as partículas estão em ordem, ou seja, possui uma desordem muito baixa.

Assim como o coeficiente de Gini, a entropia será zero quando o nó tiver instâncias de apenas uma classe. Para calcular a entropia, utilizando o mesmo exemplo que calculamos o coeficiente de Gini, utilizamos a fórmula abaixo. Aqui, pi é a mesma coisa que vimos no coeficiente de gini: a proporção de instâncias de uma determinada classe.

![img](https://lh3.googleusercontent.com/HT78sDBBolN5F-QEvt1lQomGW3nlmCcaNKm4daQJnTdzBjDIQ0RaZ4sA-TE3tzO2K-_siYwZRTI4fyGMnHhxzK3HCYIf7G0MbJH8DO1b55F3sSzPpHIrmLZle6slE9fTV8HlldGmCZJrn0sYM57rLqk)

Note que iremos considerar apenas as proporções onde temos o número de instâncias maior que zero de uma determinada classe. Dito isso, fazendo o exemplo, chegamos na expressão abaixo. Note que temos as mesmas frações que anteriormente. No entanto, agora, vamos utilizar a função logaritmo na base 2. Realizando todos esses cálculos, chegamos em uma entropia igual a 1.242.

![img](https://lh5.googleusercontent.com/Y-c1ksLZ7vvT9S8Mo4UadgzrEi6cUeO21yqmk1UbZaX542MVFvOvdq2GL-Nc6Mtv1ho2vQbHvAJcGKrsQrPzcFTUPXQpZd1VA7tKyXxUdgnYFHVosGjTxa82UdU_MGBpvD2EqaCrPAHamUkU-zMyGFs)

![img](https://lh4.googleusercontent.com/2pjYbbSo5n0VRqUHhnMAe5D6xkWmqBUiDFMS47V0p8c2Cv8Vig6wov_wY3xkYcruB8ExBijVStxf5zugIV_THbu0Zp7dff0UmRKSYjlNJ2_TpIx-Ogd9THqtg8bMq8n6X0L_seGfX5Ab356E_DMlUjI)

Vendo isso, você pode pensar: “Qual a diferença entre usar Gini ou Entropia?”. Sinceramente, o resultado final na árvore não é tão diferente assim. Embora o intervalo do coeficiente de gini seja de 0 a 0.5 e a entropia de 0 a 1, a árvore resultante das duas métricas são bem parecidas. Há uma pequena diferença na velocidade do cálculo, visto que ao calcular a entropia temos o logaritmo na base 2, o que pode deixar o cálculo um pouco mais lento, mas nada que interfira tanto assim.

Para finalizar, como vimos, os modelos em árvore são bem fáceis de serem interpretados. Por isso, chamamos esses modelos frequentemente de modelos caixa branca. Por outro lado, veremos mais para frente alguns modelos onde não conseguimos interpretar tão bem o que acontece por trás dele, e por isso são chamados de modelos caixa preta. 



# 4. Hiperparâmetros

Agora que já vimos como esse modelo funciona, vamos falar um pouco dos hiperparâmetros dele. Começando pelo max_depth, ou profundidade máxima, ele representa qual será o nível máximo de profundidade da árvore. O nó raiz representa a profundidade 0, os dois filhos do nó raiz representam a profundidade 1 e por aí vai. No modelo anterior, se definirmos o max_depth como sendo igual a 2, teremos a seguinte árvore:

![img](https://lh3.googleusercontent.com/K9KYXEjZIJcJfoS6uzHokNDkgC1qvoOfo7ovqTOSRG0wSJHC-nlgq2R7cwhwCtXE5FK3LtnOsccwohl-QrGPYXnI2S98VUIy4Td67pSsO-v5wzuh_5pc5apHnBgwu0W7zniPv3pWyejOAdsPix9d4Ys)

Note que ela tem uma profundidade máxima igual a 2. Além disso, alguns nós folha possuem o gini diferente de zero, ou seja, as classes não estão perfeitamente separadas. Talvez, você já possa imaginar que quanto mais aumentamos o max_depth mais o nosso modelo irá se adaptar aos dados e acertar as predições, mas será que isso não causa overfitting? Já adiantando: sim, causa overfitting. Porém, veremos como tratar isso depois.

O segundo hiperparâmetro que veremos é o min_samples_split. Ele representa o número mínimo de instâncias que um nó deve ter para fazer um split. Se definirmos esse número como sendo 90 e mantermos o max_depth igual a 2, por exemplo, obteremos a árvore abaixo:

![img](https://lh3.googleusercontent.com/wLNzOaVTZmzkvQJBBetlcp4Q34NjnEHaGyryn7Ec1zpdoLZsv6e6SSzT6UekguGT_C5lpM_VI4aGoJ74ce2_gq1KIWBEQso4kD0oycm6nfoawuk-Cj0JC_NjcJCu5mAzxSm4kC_OnZ8rgMiRWV9xLWg)

Note que ele não fez o split do nó direito com profundidade 1. Isso é porque ele tem 42 instâncias, e o mínimo para fazer um split, como definimos, é 90. Se reduzirmos esse número de 90 para 41 (que é menor que 42), teremos a árvore abaixo. Agora, ele fez o split do nó direito com profundidade 1, porque o número do min_samples_split é menor que o número de instâncias do nó. Note que a árvore é idêntica àquela onde definimos apenas o parâmetro max_depth como sendo 2.

![img](https://lh6.googleusercontent.com/QyyJt_SfGie_xoJz4fhS2-sruefmF49uSfrLDdvCe-vbKk5Di9zFOb_TwdCdOxGkavoyKghJWN9EsnmHdvI-HFxu44TpfNvlBt8n8lV4VKf7LhQiE3GOEMYuCtmja5cLFyeIxjaJafUlwImK6k-bZ8s)

O terceiro hiperparâmetro é o min_samples_leaf, que representa o número mínimo de instâncias em um nó folha. O nome é bem intuitivo, né? Se definirmos esse parâmetro como sendo 10, por exemplo, teremos que ter, no mínimo, 10 instâncias em um nó folha. Ou seja, na árvore do exemplo passado, o nó folha mais à direita, com apenas uma instância, não seria criado, pois o mínimo são 10 instâncias.

Se quisermos acabar com os nós folhas o nó direito com profundidade 1, podemos setar o min_samples_leaf como sendo 43. Note que o máximo de instâncias que temos é 42, dessa forma eles não poderão ser criados. Fazendo isso, obtemos a árvore abaixo. Como disse, os nós folhas sumiram. 

![img](https://lh6.googleusercontent.com/VHkLkirNRCtffsrxw36sAFmMBfm6U7LsvNYdvYs4xBw_rE1wVRp2DIFzsZ8uW6CIR4YyU68RqSF3Xsgjyv3KeV-gVdh9acPmCXHfPa3gVcB5AABQB6CEAvSZP6XT8KqPMASdRdBqOiMBkk5IF0mxGHY)

O quarto, e último parâmetro, é o max_leaf_nodes. Como o próprio nome diz, é o número máximo de nós folha. Para demonstrar como ele funciona, vamos voltar à árvore com apenas o hiperparâmetro max_depth. Agora, ao invés de colocá-lo igual a 2, vou colocá-lo igual a 4, resultando na árvore abaixo.

![img](https://lh5.googleusercontent.com/cimGxEthas-Idr-JADHTSBbEoLBDIGq1nhGkhfmzrx_Qv1M3MS6X6rKv1yxeD45DLG4LTg4dq0e4nwOSlEBa52oPhBqkZQkzvDyFmJHDVCErYkmzokjDSssUsjuho56kDqH2FDrzl2SsUlNfXNX5CMI)

Note que a profundidade máxima da árvore é 4 e temos 8 nós folha. Ao definirmos o max_leaf_nodes como sendo 4, iremos transformar essa árvore na que está abaixo. Note que mesmo a profundidade máxima sendo 4, temos apenas 3 níveis de profundidade. Além disso, agora temos 4 nós folha, ao invés de 8. 

![img](https://lh5.googleusercontent.com/eoyAURp1u45f8EVtl4pzL3r6lTzOMFwi0YKjfH8_rlYV8Z2FJnf0fG_n_smXZlol1ZHwCDvsXHNgNPZvp-IEr1D3K_rMyGTaiDr8ByeaXVFuHZQe1p5IJvi1v7srYdQ35q5haxJruWFcH_3emfghk34)

Obviamente temos mais hiperparâmetros, mas esses são os essenciais e o resto você consegue aprender de forma bem intuitiva. Para ler o que significa cada hiperparâmetro de uma árvore de decisão, execute o código abaixo no Jupyter Notebook. 

![img](https://api-club.hotmart.com/file/public/v5/files/c63747ae-5abb-4b63-bb73-8a0d0c225d41)

Para finalizar a parte de hiperparâmetros, vamos falar como podemos manipulá-los para controlar o overfitting desses modelos. Como disse anteriormente, é bem provável que se você não passar nenhum hiperparâmetro para sua árvore, ela irá overfittar. Para regularizar modelos que possuem hiperparâmetros com “max…” ou “min…”, fazemos o seguinte: aumentamos o valor do hiperparâmetro “min…” ou reduzimos o valor do hiperparâmetro “max…”.

Por exemplo, se reduzirmos o max_depth, significa que a árvore não será tão profunda e é bem provável que ela não se ajuste excessivamente aos dados, porque terá mais instâncias por nó folha. Além disso, quando aumentamos o min_samples_leaf, por exemplo, forçamos o modelo a ter um maior número de instâncias por nó folha, o que aumenta a diversidade de exemplos, reduzindo o overfitting. 



# 5. Árvores para problemas de Regressão

Se você entendeu bem as árvores para modelos de classificação, com certeza entenderá as árvores para regressão! A ideia geral é a mesma, mas os nós folha possuem um pequeno detalhe. Para exemplificar, vamos utilizar o dataset abaixo, que representa características de uma pessoa e um valor contínuo como target. 

![img](https://lh3.googleusercontent.com/lkROvAfsfuuN84csNM2FNARSBuHso9n2gKHUnYZ0XkCApi8h9ij3UVWx05XZjWmUJswMZb9IQs0lAVWL2nh8SpEnXddMFcuj9tOXB8jYLWiNDSN9s3yuBE66NmrfNDGLNM1tqX9oqtW8zN42DPQinDs)

Após isso, vamos construir uma árvore de regressão (sem parâmetros definidos), resultando na árvore abaixo.

![img](https://lh3.googleusercontent.com/nco3L9Qqb-lTfJ2JSwjwU_SsZGDQD3z4dC3OWl5sPaQLWHWQ1e9RWdTOCytA14Dt0elwPEelnXh39Q08Cqe6nGwcxYGuIzPa7no-Sw0D-sEpocY2KXdShGFweNmxQEjKMCDIxtqm2H3FGFKZESTHg4U)

Aqui, ao invés de utilizar o Coeficiente de Gini ou entropia como medida para as divisões, ele utiliza o MSE. Além disso, a outra diferença é o valor de “value”, que é a média de todas as instâncias daquele nó. Quando uma nova instância chega a um nó folha, ela assume o valor da média de todas as instâncias de treinamento daquele nó folha. 



# 6. Detalhes sobre as Árvores de Decisão

Agora, vou falar alguns detalhes sobre as árvores de decisão para aprofundar o seu conhecimento nesse modelo tão conhecido e usado. Até agora, com certeza o seu conhecimento já está além do da maioria dos cientistas de dados. Porém, esse tópico será o responsável por aumentar a distância de você para os concorrentes.

Vamos começar com o algoritmo CART de treinamento. Aqui, CART significa “Classification And Regression Trees”. Nós sabemos que uma árvore começa com um nó raíz, sendo que o nó faz um split utilizando uma determinada feature e um determinado limiar k. Por exemplo, utilizando aquele dataset de diabetes, vamos supor que ele comece com a feature age menor ou igual a 0.004. Porém, como ele escolhe a feature age e o limiar 0.004?

Bom, como vimos, ele sempre vai procurar o split que resulta em nós mais puros. Como em outros algoritmos temos uma função de custo que queremos minimizar, aqui na árvore de decisão não será diferente. Abaixo, você vê a função de custo para árvores de classificação e regressão. Nessas fórmulas, m é o número de instâncias (sendo que mesquerdo é o número de instâncias do nó filho esquerdo), G é o coeficiente de Gini e MSE é a métrica MSE.

![img](https://lh4.googleusercontent.com/FYuP4OcfS5MpIOigSWt912k1reedWtUk6jTE9qcaCYGnrxQ-c3myFvE_60S5jmA7HJHYKXk8Npw6BstrncXA44jBzci3fhlVQZIHI-GwaJohxToVJoPgjaYsdiUu2uBqt2Cwh2t0RQtPziXTZm7GENw)

![img](https://lh3.googleusercontent.com/jIhd7RD0DXVvhs0smswgVTeRTmzDVc69ZLCH2etrXzH52urrjiNY906bmyPeJhm4PkeMdNTeVPk6x2YP2o21Fvhl9e9fUUCGZbC6Yjk4s1H0qq1OYrYNUpZEwr3CLXu-CQz77SHH6fUKHNLPUWSpPpY)

Calculando o custo do split do nó raíz do exemplo de regressão, temos a expressão abaixo. Note que temos 240 instâncias no lado esquerdo do split, 113 no lado direito e 353 no total. Além disso, o MSE no lado esquerdo é 4113.098 e, no lado direito, 4168.562. Realizando os cálculos, o custo é igual a 4130.853. Foi a combinação que mais reduziu o custo do split.

![img](https://lh5.googleusercontent.com/HnPugX0zE24kciUfYKI6r7kzzZxBFgWqO4YweYpnWhARO8_y0sTYbQdPPurhDsRWoViSByYiI8e92ismpGVp6d3d4k1l1X-CJCAAvSeoTJ6lWuuFFFgleyIn4uMaerxtGb5TA83GuIiysSut1pexCFE)![img](https://lh4.googleusercontent.com/A2EHxNJpiLae8vkedtRul3SR-1UnrqBLBe07r3AhEVI3vy2BplBKrDNMlbWxl4IOgudvbz95UxUwcvazp0zvJULEh3P106oJ6HEfDb-kCdJ3VUMxBX6D-WjgV9_e-d00E9MQU_SEy8YsoLMlj4XfVxE)

Note que o algoritmo CART busca uma divisão satisfatória, porém não ideal. A busca por uma solução ideal levaria muito tempo, o que é inviável para aplicações reais. O algoritmo de treinamento compara todas as features (dependendo do hiperparâmetro max_features) em todas as instâncias em cada um dos nós. 

Agora que já falamos do algoritmo de treinamento CART, vamos falar um último detalhe sobre as árvores de decisão: a desnecessidade de escalonamento. Quando estamos trabalhando com modelos baseado em árvore, como a própria árvore de decisão, o escalonamento das features não é necessário. 



# 7. Conclusão

Pronto, pessoal! Chegamos ao fim de mais um material aqui no clube. Espero que tenham gostado e não se esqueçam de montar um portfólio excelente com esse material. Aproveitem e façam artigos sobre o tema, faça um projeto explicando e mostrando as árvores para cada variação de hiperparâmetro (utilize a biblioteca graphviz). Espero que tenham curtido.

Um abraço,

Anwar.