# Semana 26: Machine Learning Pt. 3 (Inferência com Regressão Linear)

## 1. INTRODUÇÃO

Normalmente, quando se fala de Machine Learning, estamos tratando de modelos com foco na predição. Entretanto, você pode sim fazer ajustes ao seu modelo de forma que a inferência faça parte da sua solução, ou até se torne o foco principal. Tá, mas qual a diferença de inferência e predição? 

A definição estrita dos 2 termos seria:

**- INFERÊNCIA:** Em Lógica, inferência ou ilação é operação intelectual mediante a qual se afirma a verdade de uma proposição em decorrência de sua ligação com outras proposições já reconhecidas como verdadeiras. Consiste, portanto, em derivar conclusões a partir de premissas conhecidas ou decididamente verdadeiras. (Resposta do Wikipedia)

**- PREDIÇÃO:** Ato ou efeito de predizer, de afirmar o que vai acontecer no futuro; profecia, previsão, vaticínio. (Resposta do dicionário Oxford)

Apesar do significado estar correto e inferência significar isso até mesmo dentro da estatística, quero fazer uma pequena alteração informal para que vocês entendam duas abordagens diferentes dentro da modelagem de Machine Learning / Econométrica:

**- INFERÊNCIA:** Este é um processo matemático que permite aos cientistas de dados tirar conclusões a partir de conjuntos de dados, compreendendo a relação das características observadas nos dados. Por exemplo, imagine que você tenha em suas mãos dados relacionados a compras de um supermercado. Você possui em cada linha a informação de algum cliente, como valor gasto, dia da semana em que a compra foi feita, forma de pagamento, profissão do cliente, se o cliente é cadastrado no sistema do mercado, cidade em que a compra foi feita, se a pessoa comprou produto de limpeza, etc. Você poderia simplesmente criar um modelo para prever quanto a pessoa vai gastar, mas você pode também criar um modelo para entender qual a relação dos gastos com as outras variáveis. Entender a relação seria a abordagem que chamaremos de inferência. Você vai notar que, neste caso, as pessoas sequer dividem os dados em treino e teste, é uma abordagem bem distinta.

**- PREDIÇÃO:** Refere-se ao processo de usar um modelo estatístico ou algoritmo de machine learning para gerar um resultado provável baseado em dados de entrada. Os modelos de previsão são treinados em um conjunto de dados históricos e, em seguida, usados para prever os resultados futuros ou desconhecidos quando fornecidos com novos dados. Veja a diferença para o caso da inferência, ali, queremos entender a relação entre a variável-alvo (target) e as variáveis explicativas (features). Aqui, o que importa é simplesmente prever os gastos dos clientes, prever o target. Inclusive, quando a intenção é predição, é preciso que parte do dataset seja separado para validar se o modelo preditivo realmente funciona. Esse "pedaço" que deixamos separado são os dados de teste.

Vejamos outro exemplo: você trabalha no Quinto Andar e possui um dataset em que cada linha é um apartamento e as colunas são as características desse apartamento. Dentre as características, temos o preço do aluguel, metragem, número de banheiros, número de quartos, bairro, andar, se está ou não mobiliado e se possui ou não suíte. Se nossa intenção for criar um modelo com uma visão mais inferencial, então estaríamos buscando entender a relação do número de banheiros, quarto, etc com o preço do aluguel. Se, por outro lado, só quiséssemos prever o preço do aluguel de um apartamento, então teríamos um modelo preditivo.

Expliquei esses conceitos porque, hoje, nosso modelo será focado em fazer uma boa inferência! I.e., queremos entender a relação das features com o target!

###  

## 2. INTUIÇÃO POR TRÁS DA REGRESSÃO LINEAR 

A regressão linear é um dos modelos mais importantes em Machine Learning e estatística, sendo a base de muito do que vemos na hora de fazer previsões e inferências. A lógica por trás dela é bem simples, queremos explorar a relação de uma ou mais variáveis, chamadas de explicativas (também chamadas de features, principalmente por quem atua em Machine Learning) e uma outra variável, chamada de variável resposta (também chamada de target). Essa relação é determinada por uma reta, daí o nome do algoritmo, e a variável resposta é um valor contínuo.

Vamos ilustrar melhor isso com um exemplo! Imagine que você queira entender qual a relação entre o PIB per capita (em dólares) e um determinado índice de qualidade de vida. Para examinar a relação, você busca dados de diversos países ao longo dos últimos anos e traça esses dados num gráfico de dispersão:

![img](https://lh4.googleusercontent.com/Y3gXp7IXewGkRNcI4H6P4aHzHbTCykufp65FpFYXeiDDm8t-27sgq3VToFsoHNjCr8v9iKDZt5lbnUMqxfrpaXEW5G6PyK2qaGkvEBSjF9ijMoB3c0UNAt5qJkx7hSTeltotVtQWB2srWAbiCCnem-M)

Veja, o gráfico acima é apenas o histórico dos dados (x, y) para cada observação em nosso histórico, onde x é o PIB per capita observado e y é o índice de qualidade de vida para tal PIB. Podemos ver, por exemplo, que temos uma observação cujo PIB per capita é de 30 mil reais e o índice de qualidade de vida é de 1.0. Também há uma observação, um país em determinado ano, cujo PIB per capita é de 30 mil reais e o índice de qualidade de vida é quase 1.2, talvez seja algo próximo de 1.17.

Bom, seguindo para nosso algoritmo, podemos tentar traçar por estes pontos diversas retas:

![img](https://lh5.googleusercontent.com/BfD5WYO1TjxPyGgTyfYpGpisWTCI4c-lN3Uq3Wg4bGW3WdOBSKxHLDMtVZper24_RB6xN-T49hPc5utBk9F4WWu2o8GapwO0a7ggEKHRmZ-Kd91RjkAQU_HsvTuOKDYa_FNHzDWplwIeqVt_Yv1Tl-A)

Como dito no início deste material, a regressão linear é uma reta que descreve as relações de duas ou mais variáveis. Olhando para nossos pontos, podemos tentar explicá-los com alguma reta. No gráfico acima, temos algumas das retas que poderiam explicar a relação de PIB per capita com índice de qualidade de vida. Note que nenhuma reta cruza todos os pontos, afinal, é impossível ter um fenômeno que seja perfeitamente descrito por uma reta. O que a gente busca é algo que se aproxime da relação observada. O problema é que várias das retas passam próximas aos pontos, ou seja, várias poderiam explicar a relação das duas variáveis. O que fazer? Qual reta escolher?

**A reta escolhida será a que mais se aproximar dos pontos, a que "erra" menos - conforme falado em materiais passados.** Mais uma vez, veja, é claro que nenhuma reta passará por todos os pontos, pois temos outliers e distúrbios naturais no mundo real. A gente nunca conseguirá explicar um fenômeno totalmente. Entretanto, podemos chegar muito próximo disso em determinadas relações e com as variáveis certas sendo utilizadas.

Agora, você lembra de como é a função de uma reta? Se não sabe, vale dar um google rapidinho!

Por se tratar de uma reta, a equação dela é dada por:

##### ![img](https://api-club.hotmart.com/file/public/v5/files/1a540824-c7cc-421f-8e35-0789cd8f2e49)

Onde, a letra **'b'** determina a inclinação da reta, a letra **'a'** determina o ponto em que a reta cruza o eixo x e a letra **'X**' é nossa variável independente, o PIB. Encontramos os valores de **'b'** e **'ab'** ao determinarmos qual reta mais se aproxima dos valores que temos para x e y em nosso histórico.

Imagine que você acabe por obter a seguinte reta:

##### ![img](https://api-club.hotmart.com/file/public/v5/files/24c1d4a2-dfd3-41dd-a31e-41fcffebccf7)

Isso significaria que para cada unidade adicional de PIB per capita a gente veria um adicional de 0.03 no índice de qualidade de vida. Além disso, também saberíamos que para um país com PIB per capita igual a zero, teríamos um índice de qualidade de vida de 0.05.

**Desafio: Suponha que o Brasil tenha um PIB per capita de aproximadamente 7.500 USD e o México de 10.000 USD. Qual a diferença esperada no índice de qualidade de vida entre os dois países?**

Agora, note que estamos partindo do pressuposto de que esses coeficientes são válidos. **P****orém, para que os coeficientes façam sentido, precisamos que a regressão linear cumpra uma série de premissas. O cumprimento delas garante que a gente tenha estimadores chamados de BLUE, best linear unbiased estimators (melhores estimadores lineares não-viesados).** Falaremos disso mais a frente, mas vamos antes entender um pouquinho mais dessa equação…



## 3. EQUAÇÃO E INTRODUÇÃO FORMAL DOS CONCEITOS 

Como dito acima, estamos buscando uma reta que se aproxima dos pontos, o que resultaria numa equação deste tipo:

![img](https://api-club.hotmart.com/file/public/v5/files/2c1571c3-5fb2-4a02-a0eb-c66fe1b0c102)

Entretanto, vamos aumentar um pouco a dificuldade aqui?

Há duas coisas que eu gostaria de acrescentar:

- **Outras variáveis independentes:** Raramente, a gente cria modelos de regressão linear somente com uma variável, pois é interessante controlarmos o efeito de outras variáveis que podem confundir a relação entre a variável independente de interesse e a variável dependente. Isso significa que é possível isolar o efeito específico de uma variável controlando outras variáveis relevantes.
- **Termo de Erro:** Volte ao exemplo do PIB e dê uma olhada nas retas que passam pelos pontos. Veja que a gente nunca conseguirá uma reta que passa exatamente por todos e está tudo bem. No mundo real, a gente sempre olha para o comportamento médio das observações, pois sabemos que é impossível obter uma equação que consiga modelar exatamente o que acontece nos eventos. A gente vai chegar próximo dos valores, mas sempre pode existir uma pequena oscilação para cima ou para baixo. Essa diferença do mundo real para o que nosso modelo estima é o termo de erro.

Se a gente quisesse manter a mesma notação, teríamos algo mais ou menos assim:

![img](https://api-club.hotmart.com/file/public/v5/files/977fd2d2-9134-42d2-88fc-8a44c5889e20)

Onde cada **b** representa uma variável independente e a gente teria **"n" **variáveis independentes. Para quem não vem das exatas, este **"n"** é só uma forma de dizer que há várias variáveis independentes, um número qualquer que a gente desconhece, mas que pode ser **1, 2 ou 10**. O último termo, o **"e"** é o erro. Ou seja, b1 é um coeficiente e x1 é uma variável independente, b2 é outro coeficiente e x2 é outra variável independente e por aí vai. Se tivéssemos, por exemplo, uma equação assim:

![img](https://api-club.hotmart.com/file/public/v5/files/b41c91fd-7c4e-4e5f-b131-8325477983ab)

Neste caso, x2 seria 0.01 e b2 seria a população. Sei que parece bobagem, mas é essencial que você consiga acompanhar as notações daqui para frente. Inclusive, porque agora vou trazer mais uma pequena complicação. Veja, a gente quer simplificar, mas sem fugir das notações tradicionais. Sendo assim, vamos já adotar a notação mais tradicional, passando a adotar letras gregas para nossos coeficientes:

##### ![img](https://api-club.hotmart.com/file/public/v5/files/a13cadb7-badc-4a7b-9488-198caf30e638)

Onde:

- y é a variável dependente (~target)
- β0 é o intercepto, ou seja, o valor de y quando as variáveis independentes são zero
- βn é a n-ésima variável independente (~feature)
- e é o resíduo, a diferença entre o valor previsto pelo modelo e o valor observado

Colocando isso num problema real, vamos imaginar que queremos prever o preço do aluguel de um imóvel a partir de 3 características: sua metragem, número de quartos, número de banheiros e vagas na garagem. Neste caso, teríamos que os x's seriam as 3 variáveis independentes e o y seria o valor do aluguel. Os betas seriam os coeficientes encontrados quando achássemos a reta que mais se aproxima das observações.

Se você está tendo dificuldades de visualizar na prática, vamos imaginar juntos. Imagine que chegou um dataset com as seguintes informações:

| Metragem do imóvel | Número de banheiros | Número de quartos | Valor do Aluguel |
| ------------------ | ------------------- | ----------------- | ---------------- |
| 100                | 2                   | 2                 | 3500             |
| 50                 | 1                   | 1                 | 1500             |
| 60                 | 1                   | 2                 | 2000             |
| ...                |                     |                   |                  |

Apesar de estarmos visualizando apenas 3 observações, imagine que a gente tenha uma base com 200 apartamentos. Para encontrar a reta, faríamos o mesmo processo visto lá no início do material, teríamos que traçar os pontos e encontrar a equação da reta que mais se aproxima deles. Veja que estamos falando de inferência aqui, ou seja, estamos buscando entender as relações entre as variáveis. Sua intenção aqui é saber como cada variável afeta o aluguel. 

Bom, então vamos imaginar que a gente jogou as informações no Python e ele estimou a seguinte equação da reta:

![img](https://api-club.hotmart.com/file/public/v5/files/4e0bb210-ab91-462c-8de5-2a964c0f0c54)

Vamos ver se entendemos todas as notações:

- **Qual é a variável dependente e por qual letra ela está denotada na equação?**
  É o preço do aluguel e denotamos por y.
- **Quais são as variáveis independentes?**
  São a metragem, o número de banheiros e o número de quartos. Na equação, elas seriam denotadas por x1, x2, x3.
- **Qual é o resíduo em nosso problema?**
  Para encontrar o resíduo, precisaríamos calcular, para cada observação, a diferença entre o valor observado e o valor previsto pelo modelo. Vamos fazer para um dos imóveis:
  Valor previsto = 100 x 20 + 300 x 2 + 400 x 2 = 3400
  Valor observado = 3500
  Resíduo = 100

------

***DISCLAIMER: ERROS VS. RESÍDUOS\****
*

*Você verá muitos textos utilizando os conceitos de erro e resíduo de forma intercambiável, principalmente no mercado, onde existe menos rigor sobre notações e termos específicos. Entretanto, vale avisar de que erro e resíduo são coisas levemente distintas. Assim, não acho que alguém vai te cobrar isso, então é quase um "fun fact", não gaste muita energia nisso.* 

*Em resumo, o resíduo é a diferença entre o valor observado e o previsto pelo modelo. Agora, erro seria a diferença entre o valor observado e o valor "real". Aqui vai complicar um pouco, mas vamos com calma. Primeiro, valor real aqui seria o valor dado por um modelo que determinasse, no nosso caso, o valor do aluguel em relação àquelas 3 variáveis. Mas este modelo não existe no mundo real, sempre há algum distúrbio. Por isso dizemos que o erro não é observado. Resumindo: o erro seria a diferença entre o valor observado e o valor real, o valor dado por um modelo "perfeito" (termo que não existe nos livros, mas achei que ajudasse no entendimento rs).*

*Discussões sobre a distinção de erro vs. resíduo:*

- *[https://stats.stackexchange.com/questions/133389/what-is-the-difference-between-errors-and-residuals#:~:text=An%20error%20is%20the%20difference,value%20(by%20the%20model)](https://stats.stackexchange.com/questions/133389/what-is-the-difference-between-errors-and-residuals#:~:text=An error is the difference,value (by the model)).* 
- *https://stackoverflow.com/questions/56754560/what-is-the-exact-difference-between-error-and-residual*
- *[https://stats.stackexchange.com/questions/408734/i...](https://stats.stackexchange.com/questions/408734/is-the-difference-between-the-residual-and-error-term-in-a-regression-just-the-a)*

------

## 

### 4. PREMISSAS DE UMA REGRESSÃO LINEAR

Conforme falamos anteriormente, para que os coeficientes de uma regressão linear sejam válidos - e, aqui, válido deve ser entendido como o melhor linear e sem viés -, precisamos garantir 5 premissas: linearidade nos parâmetros, amostragem aleatória, média condicional do termo de erro igual a zero, ausência de multicolinearidade perfeita e homocedasticidade. 

Todas essas premissas foram explicadas detalhadamente na live de 27/05/2023: https://youtu.be/5W8xhnL39dw . 

O Jupyter Notebook utilizado no encontro está anexado e, inclusive, tem os códigos para validar as premissas no Python.

**IMPORTANTE: O fato de sua regressão linear não cumprir alguma das premissas não invalida seu modelo, muito menos a previsão realizada. Lembre-se de que o impacto está nos coeficientes!**

![img](https://lh5.googleusercontent.com/gEBZ7L36xxctattXeuk986F0e90pBiMieSI_LQxL2y8BgKgdUy-tpWEAxViQHQZj8OqEd4UuZ-RwZ3JSyx6-vNIwJENdwZNIck8q-GpozVF_FOKzMIIg75M-P45U6_kM7roTqHWbTImmRuqv2Xf3ZUI)



## 5. INFERÊNCIA VS PREDIÇÃO (RECAP.) 

Muitos alunos que tentam se aprofundar na regressão linear ficam confusos com os materiais que encontram. Por exemplo, é comum ver exemplos de econometria onde o autor não divide os dados em treino e teste. Digo mais, se você pegar estes modelos econométricos e tentar fazer previsões, elas provavelmente vão errar e muito. Por outro lado, no Kaggle, encontramos diversos modelos, modelos que fazem ótimas previsões, mas que não validam as premissas de Gauss-Markov. O que quer dizer toda essa confusão?

Aqui é muito mais uma opinião pessoal e juntando diversos materiais, há muita confusão e mistureba no mundo dos dados, pois temos pessoas vindo de econometria e pessoas vindo da computação. Os primeiros, focam muito nas relações, possuem premissas rígidas e são os que costumam falar das premissas que vimos acima. Os últimos, são os que vemos principalmente no Kaggle, usando dados de treino e teste, nem sempre validando as premissas. Ou seja, os primeiros são os que buscam inferência, estudar as relações dos x's e do y. Os demais, são os que querem fazer previsões, ou seja, querem saber qual o valor dos y's novos. Por exemplo:

- **INFERÊNCIA:** Quando falamos do problema de aluguel de imóveis, as pessoas que validam as premissas da regressão linear são as pessoas que estão buscando os melhores estimadores. Posto de outra forma, elas querem entender como o número de banheiros impacta no preço do aluguel, ou se morar perto de um bar deixa o aluguel mais caro. Como o modelo segue este rigor e está focado em inferência, não há a necessidade de dividir os dados em treino e teste. Aqui, a ideia é entender as relações das variáveis e o alvo (no caso, o preço do aluguel).
- **PREDIÇÃO:** No caso do nosso problema do aluguel de imóveis, um problema de predição focaria apenas em prever os preços dos apartamentos com base nos dados de banheiro, quarto e outras informações. Tudo bem se houver alguma pequena confusão entre a origem dos efeitos, o que vale aqui é prever o aluguel corretamente. Por isso, o que importa aqui é validar que o modelo funciona em novos dados. O que importa aqui é que o modelo funcione bem nos dados de teste. 

É estranho pensar que um modelo possa funcionar bem inferencialmente, mas mal em termos preditivos e vice-versa. Mas, como eu disse, um jeito fácil de fazer isso é pegar um modelo de um paper qualquer de economia e tentar fazer previsões com ele. Você vai ver que mesmo o modelo sendo aceito por um grande journal, ou seja, que a relação entre a variável independente e a variável dependente é razoável, a predição não vai funcionar. Por outro lado, você pode pegar modelos com multicolinearidade perfeita, modelos sem validação das premissas de Gauss Markov e ainda ter ótimas previsões.

Para finalizar, vou deixar aqui uma discussão sobre uma questão próxima desse assunto, uma das dúvidas que fez eu começar essa investigação para entender porque alguns modelos funcionam sem validar premissas, porque algumas pessoas não dividem em treino x teste, etc. e juntar as peças que juntei aqui: https://www.linkedin.com/posts/thiagoestatidados_treino-teste-validacao-activity-7074849901972471808-ZBxU/?utm_source=share&utm_medium=member_ios



## 6. EXEMPLOS PRÁTICOS 

Os exemplos abaixo foram adaptados do livro "Introductory Econometrics" do Jeffrey Wooldridge (2ª Edição).

#### 6.1 LOG DO SALÁRIO

Utilizando 526 observações de trabalhadores, obtivemos a seguinte equação:

![img](https://api-club.hotmart.com/file/public/v5/files/e26211f5-16ed-4bcb-b3a0-aa2b2b9b4a70)

onde:

- log(salário): log do salário do trabalhador, na base e
- educ: anos de escolaridade
- exper: anos de experiência no mercado de trabalho

O que podemos interpretar dessa equação é que, tudo o mais constante, a cada ano de educação o log do salário aumenta em 0,092, o que é aproximadamente 9,2%. Em outras palavras, se tivermos duas pessoas com o mesmo tempo de experiência e tenure, para cada ano de experiência de diferença, teremos uma diferença salarial esperada de aproximadamente 9,2%.

Veja que, na explicação acima, utilizei a expressão "tudo o mais constante". Essa famosa expressão também pode ser apresentada para você como Ceteris Paribus e é muito comum de se ouvir no campo da econometria. Basicamente, quer dizer que aquela mudança é o que veremos se o restante das variáveis se mantiver constante. Ou seja, é o efeito advindo unicamente daquela variável.

#### 6.2 PERFORMANCE DAS ESCOLAS

Imagine que você tenha a seguinte equação:

![img](https://api-club.hotmart.com/file/public/v5/files/5099f677-b5fd-4a30-9cfd-6273c3d88f67)

obtida a partir de um dataset com 408 escolas e com as seguintes variáveis:

- math10: percentual de alunos aprovados no exame de matemática feito pelo governo de Michigan
- totcomp: média da soma do salário e benefícios (anual) dos professores
- staff: número de funcionários para cada mil alunos
- enroll: número de alunos matriculados

Olhando para a regressão obtida, tente responder as perguntas abaixo:

a. Ter mais alunos matriculados é benéfico ou prejudicial para a escola, em termos de aprovação no exame de matemática?

b. Qual o impacto que o número de funcionários tem nas aprovações dos alunos no exame de matemática do governo?

c. Qual o percentual de aprovados esperado numa escola com média anual de salários e benefícios em torno de 100 mil dólares, com 100 funcionários a cada mil alunos e com 10 mil alunos matriculados?

Respostas:
a. Prejudicial. Podemos ver que o coeficiente de enroll é negativo. Ou seja, quanto maior o número de alunos, menor o percentual de aprovados no exame de matemática.
b. Para cada funcionário por mil alunos temos um ganho de 0.048 no percentual de aprovados no exame.
c. 2.274+0.00046*100000+0.048*100-0.00020 * 10000​ = ~51.07%



## 7. AVALIANDO UMA REGRESSÃO LINEAR 

Agora que você já sabe como funciona uma regressão linear visando inferência, conhece suas premissas, sabe como interpretá-la, vamos entender como rodar o modelo no Python e quais são as métricas que a gente costuma olhar quando estamos buscando entender as relações entre as variáveis! Como não conseguimos fazer este exemplo no encontro, vai ser importante passar por cada detalhe**!
**

#### 7.1 REGRESSÃO LINEAR EM PYTHON

Vamos começar praticando com um dataset contendo informações referentes às notas dos alunos no SAT, um exame feito nos EUA para entrar nas universidades do país. Estes exemplos, assim como os feitos na seção 6, fazem parte do livro "Introductory Econometrics", do Jeffrey Wooldridge, e podem ser acessados pela biblioteca wooldridge do Python. Além desta biblioteca, você também deverá instalar o [statsmodels](https://www.statsmodels.org/stable/index.html), cuja utilidade será explicada mais a frente.

![img](https://lh5.googleusercontent.com/4-iUmse4whE0gQ2nJ8bXqPJKP0fqrwVKh3yhl-btSd4k7-RAb2pNXR1bd8ipvYS9N2c0Rp4uvaR1E2aYiYXky8Rhhd7RM20qqbYysGmn7ioDgA0RYfmFh5HrLQEgDklaYH74dp1zcTDOGO_3vpiEXIA)

![img](https://lh5.googleusercontent.com/uiKtA8iEP3KLe6bZU3mWV6vFkeff0Y4GEYW2loO7QZMG-mPcQkF2a-zAzP_qUJxrpW6VYSuxSBiB8Mh5p4xPqVbN0jRSE1egRF7PgxLiCUw0FY0jj_8v6pItTrtZhJy4cBWhFf7Ugfwv5-3mwHMiJbQ)

Os dados são de uma universidade de médio porte. Em outras palavras, são dados de alunos e que provavelmente podem nos prover alguns insights a respeito de como as notas dos alunos se relacionam com suas características.

Abaixo, as colunas do dataset:

- sat: pontuação SAT combinada
- tothrs: total de horas até o semestre de outono
- colgpa: GPA após o semestre de outono
- atleta: =1 se atleta
- verbmath: pontuação SAT verbal/matemática
- hsize: graduação de tamanho. classe, 100s
- hsrank: classificação na graduação. aula
- hsperc: percentil do ensino médio, do topo
- feminino: =1 se feminino
- branco: =1 se branco
- preto: =1 se preto
- hsizesq: hsize^2

GPA é um acrônimo para Grade Point Average. Este é um número calculado a partir das notas que você obtém ao estudar em uma universidade dos EUA. Quando você estuda em uma universidade dos EUA, seu GPA está em uma escala de 0,0 a 4,0, sendo 4,0 o mais alto que seu GPA pode atingir. Já o Scholastic Aptitude Test, ou SAT, é um teste globalmente reconhecido que permite a admissão de estudantes em faculdades e universidades em todos os Estados Unidos.

Vamos verificar como a posição do aluno durante o colégio (hsperc) e sua nota do SAT se relacionam com seu GPA. Queremos entender se existe relação entre desempenho na adolescência tem relação com desempenho na faculdade, se o aluno ter ido bem na escola e no "vestibular" tem relação com desempenho na universidade. Ou seja, queremos estimar a seguinte equação:

**![img](https://api-club.hotmart.com/file/public/v5/files/333d47ca-2235-46f4-bab9-cc1d7b0288f3)**

O sklearn é a biblioteca mais popular do Python para Machine Learning, mas vamos lembrar que não estamos falando de um trabalho tão usual da área e sim de algo mais voltado para econometria. Neste caso, vamos utilizar o **statsmodel**, pois seu output está organizado para quem quer verificar as principais métricas de inferência - é possível obter as mesmas informações pelo sklearn, mas é muito mais trabalhoso. Para rodar uma regressão linear no statsmodels, você pode utilizar a função **ols** e escrever a equação que você especificou acima. No entanto, ao invés de usar o símbolo de igual, vamos utilizar o **'~'** e a equação será colocada dentro de aspas simples. Há várias formas de se escrever a equação, optei por essa - talvez seja um vício dos tempos de usuário de R rsrs. Além disso, vamos passar o parâmetro **data**, com o dataset utilizado. Por fim, basta treinar o modelo com **.fit()**: 

![img](https://lh3.googleusercontent.com/b3w5OWyRNPPdhOxI3GJJWiDuIykhxegfuHsnxpaICO3QhRzjSlo1hNi44oEMXoKhPIQw5ozob95nCJqltonQXBEIn_oFo-xnWze2cgM3CLpunlBCpmN-KJpxBXnCFScjgyF5htk_wIbToBlx7JNgsNs)

Como output, temos a seguinte tabela:

![img](https://lh4.googleusercontent.com/7Y-E0gazkarxLoVnfLNF9L_x8u8ftgDDAQ3rY0YB60AfC9sjZlnn0AX7AwiUR9Ko6sJq8ybCUY8Aup1BM2X3gWPthLd7l5pNjrJ2zvE2sbMQO4aw2Ud9FoFU-hxGyE1UWONinrwzqL8tgdjIyZbUxGM)

####  

#### 7.2 EQUAÇÃO ENCONTRADA

Há diversas informações na tabela da seção 7.1, desde as variáveis com os respectivos coeficientes, até métricas de desempenho do modelo. Uma das primeiras coisas que costumamos observar na saída do modelo são os coeficientes encontrados. Claro, como estamos buscando compreender o efeito das variáveis independentes (~features) sobre a variável dependente (~target), precisamos verificar qual a equação encontrada! Para isso, olhamos a coluna **coef** de cada variável, o que nos leva a seguinte equação:

**![img](https://api-club.hotmart.com/file/public/v5/files/714cc31c-1156-42d7-bceb-47158e9e7da7)**

Você já está apto a ler esta equação. Portanto, responda às seguintes questões:

- Se 2 alunos tiveram 10 pontos de diferença na pontuação deles do SAT, tudo mais constante, quanto esperaríamos que fosse a diferença do GPA deles?
- O coeficiente de sat é positivo. O que significa isso?
- Qual o GPA para quando tivermos hsperc=20 e sat=1050?
- Mantendo hsperc fixo, qual a diferença na pontuação SAT que levaria a uma colgpa diferente em 0.5?



#### 7.3 AVALIANDO NOSSA INFERÊNCIA

Agora sim, vamos para as métricas que nos permitem entender nossa regressão. 

**a. P-VALUE: SIGNIFICÂNCIA DOS COEFICIENTES**

P>|t|: Esta é a medida estatística que representa o p-valor associado a cada coeficiente estimado em nosso modelo. Veja que temos uma estatística t ao lado dos coeficientes e, em seguida, temos o respectivo p-valor para nos dizer a significância daquele coeficiente.

Este p-valor indica a probabilidade de obter um resultado igual ou mais extremo do que o observado, assumindo que a hipótese nula seja verdadeira. A hipótese nula geralmente afirma que não há relação ou efeito significativo entre a variável independente associada ao coeficiente e a variável dependente. Em outras palavras, nossa regressão possui diversos testes de hipóteses cuja hipótese sendo testada é que aquele coeficiente possui algum efeito na variável independente. Caso o p-valor seja superior a 0.05, estaríamos dizendo que nós fizemos um teste e não conseguimos determinar que aquele coeficiente realmente é diferente de zero. 

Vou deixar mais uma leitura, caso você queira explorar mais o tema: [Understanding the p-value in regression](https://medium.com/analytics-vidhya/understanding-the-p-value-in-regression-1fc2cd2568af)

**b. R-QUADRADO: "QUANTO DO TARGET É EXPLICADO"**

R-squared: O R-quadrado aparece logo no canto superior direito e é uma das métricas mais importantes quando estamos falando de inferência. Também chamado de coeficiente de determinação, é uma medida estatística usada para avaliar a qualidade de ajuste do nosso modelo. Ele varia entre 0 e 1 e descreve quanto da variância da variável dependente que é explicada pelas variáveis independentes da regressão. Em outras palavras, R-quadrado é a porcentagem da variância da variável dependente que as variáveis independentes explicam coletivamente. 

Um R-quadrado de 100% indica que todas as mudanças na variável dependente são totalmente explicadas pelas mudanças nas variáveis independentes. No nosso caso, 27,3% da variância do colgpa é explicada pelas variáveis que utilizamos no modelo.

A fórmula matemática do r-quadrado é dada por:

![img](https://api-club.hotmart.com/file/public/v5/files/f2444a5c-6c8b-4004-a0de-9a28c22d8875)

Sendo que:

\- R2 é o coeficiente de determinação, i.e., o próprio r-quadrado.

\- SSRes (Soma dos Quadrados dos Resíduos): representa a soma dos quadrados das diferenças entre os valores observados e os valores previstos pelo modelo de regressão. Essa métrica mensura a variabilidade não explicada pelo modelo, ou seja, a parcela de variabilidade que não pode ser explicada pelas variáveis independentes incluídas no modelo. Quanto menor for o valor de SSR, maior será a capacidade do modelo em explicar a variabilidade nos dados.

\- SSTot (Soma Total dos Quadrados): representa a soma dos quadrados das diferenças entre os valores observados da variável dependente e a média dos valores observados. Essa métrica mensura a variabilidade total da variável dependente, independente do modelo. Em outras palavras, ela representa a variabilidade que existe nos dados antes de aplicar qualquer modelo de regressão.

**c. R-QUADRADO AJUSTADO: O PROBLEMA DO R-QUADRADO**

Adj. R-Squared: O r-quadrado tem uma "falha" que é a de que ele aumenta (ou mantém) seu valor na medida que aumentamos o número de coeficientes. O R-quadrado ajustado, por outro lado, leva em conta o número de preditores no modelo. Aumentará apenas se a nova variável melhorar o modelo mais do que seria esperado por acaso. Ele diminuirá quando uma variável não útil for adicionada.

Fórmula matemática:

![img](https://api-club.hotmart.com/file/public/v5/files/8ae39606-3be8-4f4c-8121-f8b3db4738ad)



**d. AVALIANDO O MODELO COMO UM TODO**

F-Statistic: Significância do modelo. A estatística F é uma medida estatística utilizada na análise de regressão linear para avaliar a significância global do modelo. Ela é calculada a partir da comparação entre a variabilidade explicada pelo modelo e a variabilidade não explicada. A F-statistic representa o valor calculado da estatística F, enquanto a Prob (F-statistic) é o p-valor associado a essa estatística. O p-valor é usado para testar a hipótese nula de que não há relação entre as variáveis independentes e a variável dependente. Se o valor p for menor que um determinado nível de significância (geralmente 0,05), rejeita-se a hipótese nula e conclui-se que o modelo é estatisticamente significativo.

**e. OUTRAS DISCUSSÕES**

Discussões interessantes a respeito de dúvidas que podem aparecer para vocês em relação a essas métricas:

- [Model with a significant coefficent and R2 close to Zero?](https://stackoverflow.com/questions/64706759/how-can-i-interpret-a-model-with-a-significant-coefficent-p-value-close-to-zero)
- [R-Squared vs Adjusted R-Squared](https://stats.stackexchange.com/questions/353807/which-is-better-r-squared-or-adjusted-r-squared)
- [What to do when the p-value is not significant?](https://stats.stackexchange.com/questions/572924/what-to-do-when-the-p-value-is-not-significant)

## 8. DESAFIOS DE REGRESSÃO LINEAR 

Já tivemos alguns desafios ao longo do material, agora é hora de dificultar um pouco mais! Vamos ver o quanto você conseguirá responder das perguntas em negrito abaixo!

1. Você é o CEO de uma empresa e está avaliando como os gerentes de venda estão sendo remunerados pelo diretor. Para isso, pede que seja feito um levantamento das vendas feitas e dos salários de cada gerente que atingiu a respectiva venda. Você então decide estimar a elasticidade do salário em relação às vendas. Em outras palavras, quanto que o salário aumenta em relação ao aumento de vendas.

   Para modelos de elasticidade, costumamos perseguir equações com o seguinte desenho:
   log(salario)=0+1log(vendas)+u

   Digamos que você tenha estimado a seguinte equação:
   log(salario)=4.822+0.257log(vendas)+u

   **Quanto um aumento de 1% nas vendas impactará no seu salário?**

   

2. Um levantamento foi feito para avaliar como as horas de determinadas atividades afetavam as notas de matemática dos alunos de Ensino Médio. A seguinte equação foi obtida através das observações de 7.500 alunos de 9 escolas diferentes:
   nota = B0 + B1*videogame + B2*esportes + B3*kumon + B4*musica + u
   (Lembrando que o símbolo de asterisco é o da multiplicação)
   **a) Se o estudo identificasse que vídeo-game e esportes não beneficiam o aumento nas notas de matemática, o que poderíamos dizer de B1 e B2?
   **b) Além disso, imagine uma situação em que aulas de música aumentassem as notas dos alunos, mas só até um determinado número de horas. Após isso, observaríamos as notas caírem. **Como isso poderia ser um problema na nossa regressão linear?**
   c) **O que é B0?**

   

3. Em um estudo, buscamos identificar como certas variáveis comportamentais do aluno se relacionavam com seu desempenho acadêmico na universidade. Para isso, estimamos a seguinte equação:
   GPA = B0 + B1*estudos+B2*sono + B3*trabalho + B4*descanso + u
   Cada coeficiente diz respeito ao quanto o aluno gasta de tempo na respectiva atividade. Ou seja, B2 vai nos dizer o quanto ter mais ou menos horas de sono impacta a nota do aluno na universidade.
   **Se B3 for negativo, o que isso significa?
   ****Se voltarmos lá para as premissas de Gauss Markov, podemos ver que este modelo está violando uma das premissas. Você consegue dizer qual delas e por qual motivo?**

   

4. Abaixo, temos a distribuição dos resíduos em relação aos valores observados. O que está acontecendo? **Que premissa está sendo violada neste gráfico?**

![img](https://lh4.googleusercontent.com/jGTYENHVSM3jsmKiy5jwt41JqEv24GDoK7SnHzN4o_LuvGfoqw327CC-C7tJLyC8r40Y4ZzG0_cmO5hBlGH7yOL7oaWL14_7LXDFauRIsGF4R9Y-SZFcKyE0Piyfi1gIpKZJVtKDMTpuzCKBecfuADQ)



E agora, que tal tentar aplicar o que aprendeu? Você pode explorar qual o impacto de certas características do indivíduo nos[ custos do plano de saúde](https://www.kaggle.com/datasets/mirichoi0218/insurance), entender [o que impacta o preço de uma casa](https://www.kaggle.com/datasets/harlfoxem/housesalesprediction), como se forma [o preço de um laptop](https://www.kaggle.com/datasets/muhammetvarl/laptop-price), dentre outros problemas que você pode explorar!

Bons estudos!!!