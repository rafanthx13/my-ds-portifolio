## Semana 25: Machine Learning Pt. 2 (Modelagem na Prática)



Hoje, nós vamos construir nosso primeiro modelo! Vai ser bem mão na massa, então já prepara o Python aí!

Antes, vamos ver como você se saiu nas perguntas da semana passada:

## Que tal verificarmos se você entendeu tudo?

1) O que é um modelo de Machine Learning?

  a) Um programa de computador que aprende a jogar xadrez.

  **b) Um algoritmo que analisa os padrões em um conjunto de dados e usa esses padrões para fazer previsões.**

  c) Uma ferramenta que ajuda a visualizar grandes volumes de dados.

  d) Uma base de dados bem estruturada.

2) O que é um target em um modelo de Machine Learning?

  **a) O resultado desejado que o modelo está tentando prever.**

  b) O conjunto de dados sobre o qual o modelo está treinando.

  c) A taxa de erro aceitável para o modelo.

  d) A variável que determina a complexidade do modelo.

3) Como seria a representação dummy de uma variável categórica com dois valores possíveis, como a presença de um mestrado em um modelo que prevê salários?

  **a) 1 para candidatos com mestrado, 0 para os sem mestrado.**

  b) 1 para candidatos sem mestrado, 0 para os com mestrado.

  c) 1 para todos os candidatos, independentemente da presença de um mestrado.

  d) 0 para todos os candidatos, independentemente da presença de um mestrado.

4) Como a Loss Function impacta o aprendizado do modelo de Machine Learning?

**Resposta: A Loss Function é uma medida que quantifica o quão bem o modelo está se saindo em suas previsões, comparando-as com os valores reais do conjunto de dados. O objetivo do modelo é minimizar essa função de perda, o que significa que ele está tentando reduzir os erros entre suas previsões e os valores reais. Escolher a Loss Function correta é crucial, pois diferentes problemas requerem abordagens diferentes.**

**Por exemplo, em problemas de regressão, a Mean Squared Error (MSE) é comumente utilizada como função de perda - ainda que existam outras, como a Mean Absolute Error (MAE)..**

**A escolha da Loss Function pode impactar a convergência do modelo durante o treinamento, bem como sua capacidade de generalização em dados não vistos. Uma função de perda inadequada pode levar a resultados indesejados ou ao overfitting (quando o modelo se ajusta em excesso aos dados de treinamento, mas não generaliza bem para novos dados).**

5) Utilizando a equação (1) da seção Loss Functions, qual a previsão salarial de alguém com 0 anos de experiência? E com 3 anos de experiência? Ainda utilizando a mesma equação, quanto um ano de experiência adicionaria de salário anual?

**Resposta: A equação (1) era:**

**(1) salario (anual) = 500 + 10000 \* anos de experiencia
**

**Ou seja, alguém com 0 anos de experiência receberia um salário tal que:**

**salario (anual) = 500 + 10000\*0 = 500+0 = 500**

**Já alguém com 3 anos de experiência:**

**salario (anual) = 500 + 10000\*3 = 500+30000 = 30500**

**A cada ano de experiência, o salário anual aumenta em 10000, que é exatamente o coeficiente da variável anos de experiência.**

6) Durante os estudos de loss function, aprendemos a mean squared error com função perda de uma regressão linear, que nada mais é do que tomar a diferença entre o que o modelo prevê e o que realmente aconteceu, elevar ao quadrado e dividir pelo número de observações. Entretanto, se o objetivo da função perda é ajudar a localizar o modelo com melhor poder preditivo, por que não podemos simplesmente tirar a diferença do que o modelo previu pelo que foi observado? Qual a necessidade de elevar ao quadrado, tirar raiz, etc?

**Resposta: Ao elevar ao quadrado as diferenças entre as previsões e os valores reais, os erros negativos não anulam os erros positivos, resultando em uma medida de perda sempre positiva. Isso é importante porque, ao otimizar o modelo, queremos minimizar a função de perda, e muitos algoritmos de otimização são projetados para minimizar funções positivas. Se fossemos utilizar os valores sem esse ajuste, acabaríamos encontrando modelos que erram bastante, mas com função perda igual a zero, enganando o cientista de dados.**

**Além disso, elevar ao quadrado aumenta o peso dos erros maiores, tornando o modelo mais sensível a grandes desvios, o que pode ser desejável em alguns casos. No entanto, também pode tornar o modelo mais sensível a outliers, sendo importante ter cuidado ao usar a MSE em conjuntos de dados com outliers significativos.**

**A raiz quadrada é frequentemente aplicada à MSE para obter a Root Mean Squared Error (RMSE), que representa o erro médio de previsão em unidades originais da variável de saída. Isso torna a métrica mais interpretável e alinha-se melhor com a escala dos dados.**

7) Você quer construir um modelo de fraude no cadastro de uma empresa de telefonia. A ideia é pegar todos os clientes que abriram contas, mas apenas para fraudá-las no futuro. Sendo assim, você precisa descobrir na primeira semana como clientes fraudadores agem. A auditoria das contas suspeitas deve ser feita sempre 7 dias após a data de cadastro. Sendo assim, você decide construir um modelo preditivo de fraude. Você inicia com um levantamento de variáveis disponíveis no DW para construir este modelo de fraude. Discuta quais variáveis podem fazer sentido neste modelo, como você construiria este dataset, quais variáveis teriam que ser modificadas para serem usadas no seu modelo e como você as modificaria. Apesar da empresa ter vários tipos de produtos e serviços, você só se interessa pela fraude no cadastro do serviço de celular.

Fuçando o DW, você possui 4 datasets, um com as contas de todos os clientes, outro com os dados de cadastro e outro com a marcação de fraude.

Variáveis do dataset de contas (mensais): chave de cadastro do cliente, data da conta, valor da conta, data de pagamento, tipo de pagamento (cartão, débito automático, boleto, etc), tipo de conta (pré, pós, controle)

Variáveis de consumo (diárias): consumo de internet, consumo de ligações.

Variáveis do dataset de cadastro: nome, idade, chave de cadastro do cliente, CEP, data do cadastro, gênero, e-mail de cadastro, serviço contratado.

Variáveis do dataset de fraude: chave de cadastro do cliente, dummy indicando fraude (1: sim, 0: não).

**Resposta: Para criar este modelo, boa parte das variáveis elencadas seria útil, entretanto, é importante sempre lembrar que teremos que pegar tudo o que é feito nos primeiros 7 dias, que é quando o modelo irá rodar. As variáveis acima que com certeza ficariam de fora são as das contas do consumidor, pois ainda não teriam se passado 30 dias para a criação delas. Portanto:**

**- Features:**

**- Consumo de internet e de ligações (apenas dos 7 primeiros dias).**

**- Idade.**

**- CEP.**

**- Data do cadastro: poderíamos utilizar o mês. Inclusive, mesmo sem considerar esse tipo de dado (sazonalidade), precisaríamos para saber quais os 7 primeiros dias do usuário e coletar as informações de consumo referente a esses dias.**

**- Gênero: Aqui, é importante observar se a legislação em vigor permite e se o modelo não terá nenhum viés perigoso. Essa variável requer bastante cautela.**

**- Serviço contratado.**

**- Se considerarmos o que vai unir as tabelas, a chave de cadastro também entraria, apenas para isso.**

**- Target: Dummy indicando fraude.**

## Agora, vamos aplicar o que aprendemos! 

O notebook utilizado no vídeo se encontra em anexo. É só baixar para utilizá-lo enquanto assiste!

Espero que tenham gostado deste material! Forte abraço e bons estudos!



 Marcar como concluída

<iframe width="500" height="281" src="https://www.youtube.com/embed/vAM2W6OXj-8" frameborder="0" allowfullscreen="" style="box-sizing: border-box; -webkit-font-smoothing: antialiased; margin-bottom: 30px; position: absolute; top: 0px; bottom: 0px; left: 0px; width: 587.328px; height: 330.359px; border: 0px; max-width: 100%;"></iframe>











