## Semana 29 - Machine Learning pt. 6 (Classificadores na Prática + Class Weight + Trade Offs de Problemas Reais)



Sejam bem-vindos a mais uma semana de Clube! Voltando, depois de um bom tempo, às aulas em vídeo! Hoje, vamos olhar classificadores na prática, meter a mão na massa, discutir questões que aparecem em problemas reais, tradeoffs, dentre outras coisas. Espero que curtam!

Antes de mais nada, se você ainda não conhece pipelines e column transformer, veja o seguinte vídeo:

## Pipeline Em dados

<iframe width="500" height="281" src="https://www.youtube.com/embed/pmdM9wD_VHI" frameborder="0" allowfullscreen="" style="box-sizing: border-box; -webkit-font-smoothing: antialiased; margin-bottom: 30px; position: absolute; top: 0px; bottom: 0px; left: 0px; width: 587.328px; height: 330.359px; border: 0px; max-width: 100%;"></iframe>

roc_auc, precision_score, recall_score, f1_score, accuracy_score













**Descrição do Vídeo Pipeline de Dados**

O tutorial de hoje é pra galera que é pilhada em modelos de Machine Learning. Se você não conhece pipelines, esse vídeo vai mudar sua vida. De verdade, veja até o fim e implemente pra ontem nos seus códigos!

Notebook apresentado no vídeo: https://github.com/yukioandre/youtube/blob/master/pipeline_tutorial.ipynb

Dataset utilizado (também consta no Github): https://www.kaggle.com/datasets/uciml/german-credit

Post com o modelo de classificação de estilo musical: https://estatsite.com.br/2020/12/18/modelo-de-classificacao-de-estilo-musical/

Mais exemplos de pipelines: https://estatsite.com.br/2020/09/15/exemplos-pipelines-usando-scikit-learn/

Qualquer dúvida, fique à vontade para comentar ou entrar em contato.

E se quiser saber mais de ciência de dados, machine learning, Python, R, SAS e SQL, é só acessar www.estatsite.com.br.

Ouça também meu podcast FUTURISTANDO. Disponível no Spotify, Deezer, Apple Podcasts, Google Podcasts e demais agregadores.

Se você já viu o vídeo acima ou já conhece pipelines, aí sim, bora para o material da semana!!!


<iframe width="500" height="281" src="https://www.youtube.com/embed/B8U4eFPxrzE" frameborder="0" allowfullscreen="" style="box-sizing: border-box; -webkit-font-smoothing: antialiased; margin-bottom: 30px; position: absolute; top: 0px; bottom: 0px; left: 0px; width: 587.328px; height: 330.359px; border: 0px; max-width: 100%;"></iframe>






  
