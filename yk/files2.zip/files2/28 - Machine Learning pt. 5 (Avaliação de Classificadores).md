## Semana 28 - Machine Learning pt. 5 (Avaliação de Classificadores)



# 1. Introdução

Como você notou, acabamos de aprender a rodar odelos de classificação em Machine Learning! Basicamente, estamos falando de algoritmos que se propõem a classificar observações em duas ou mais classes distintas. Um exemplo clássico de classificador é realizar uma previsão de um evento tipo sim ou não (ex.: previsão de compras ou de churn), estamos falando de duas classes. Esses modelos são diferentes dos modelos de regressão, que preveem um valor contínuo, como a previsão do preço de uma casa ou do salário de um funcionário. Mas precisamos saber se estamos fazendo previsões corretas ou incorretas, ou entender o quanto estamos errando. Em outras palavras, precisamos avaliar nossos modelos de classificação, para entender quão bem o modelo está desempenhando e identificar áreas para melhorias. A seguir, vamos explorar as várias métricas de avaliação que são comumente usadas com modelos de classificação.



# 2. MÉTRICAS DE AVALIAÇÃO

## 

## 2.1 Acurácia

A acurácia é a métrica mais simples e direta, sendo ela simplesmente a proporção de previsões corretas feitas pelo modelo em relação ao total de previsões. Ou seja, é o % de acertos!

Imagine que você tenha criado um modelo para prever se uma pessoa deixará ou não de ser assinante de sua empresa de telefonia (churn). Você tem 100 clientes nos dados de teste, dentre eles, 70 tiveram a previsão feita corretamente pelo modelo. Logo, seu modelo tem 70% de acurácia.

Abaixo, temos o código em Python para calcular a acurácia de um modelo. Entenda **y_true** como sendo os **valores reais** dos dados usados para validar o modelo e **y_pred** são as **previsões** feitas pelo nosso modelo. A função **accuracy_score** compara ambos e verifica o quanto estamos errando nas previsões.

![img](https://api-club.hotmart.com/file/public/v5/files/833d0f50-8deb-4cfa-b6ca-f6917ba1c576)

Em suma, você terá **acurácia = acertos nas previsões / total de previsões**

A lógica da acurácia é simples e complexa ao mesmo tempo. É simples porque é uma métrica intuitiva e que buscamos sempre atingir um número mais alto. Falar que teve 90% de acurácia é o mesmo que falar que seu modelo acertou 90% das previsões. É ótimo, não? Hmmm, mais ou menos...

Primeiro, no mundo real, é raro encontrarmos modelos tão bons assim. Quando temos, por exemplo, algo como 95% de acurácia, logo suspeitamos de que há algo de errado no modelo. Talvez um data leakage, talvez tenhamos overfittado no teste mesmo, há muitas possibilidades. Além disso, existe um problema claro **e que é bom você gravar, porque costuma aparecer nas provas de procesos seletivos para cientista de dados: avaliação de classificadores em dados desbalanceados.
**

Dados desbalanceados são confusos e sua avaliação pode ser enganosa. Por exemplo, suponha que você tenha um modelo para prever fraude. A maioria das transações de cartões de crédito são transações regulares, não possuem fraude alguma. Entretanto, 0,5%* das transações são fraudes. Vamos repetir: 99,5% não são fraudes (target = 0) e 0,5% são fraudes (target = 1). Imagine agora, um modelo dummy que simplesmente diga que todos os clientes são não fraudadores. Sabe qual será a acurácia desse modelo? De 99,5%! Ele é um bom modelo? CLARO QUE NÃO!

O principal ponto de ter um modelo preditivo de fraude é capturar as fraudes. Se o seu modelo simplesmente diz que toda transação é regular e não há nenhuma fraude, ele é uma porcaria de modelo. Mesmo assim, por conta do desbalanceamento dos dados, tivemos uma acurácia de 99,5%. **Em outras palavras, avaliar um classificador com a acurácia não é uma boa ideia!**

*número fictício

## 2.2 Matriz de Confusão

A matriz de confusão é uma tabela que mostra as frequências de classificação para cada classe do modelo. Ela é dividida em quatro partes: Verdadeiros Positivos (VP), Falsos Positivos (FP), Verdadeiros Negativos (VN), e Falsos Negativos (FN). Tá, vamos dar uma viajada agora, pelo bem do ensino...

Imagine que você está organizando uma festa na sua residência em Indaiatuba, e resolve enviar convites para seus amigos do grupo do Discord da Universidade dos Dados. Acontece que você não conhece todo mundo e saiu buscando os nomes no Linkedin. Como vários nomes no Discord eram na verdade nicknames e não realmente nomes, você teve que inferir os nomes das pessoas, buscar no Linkedin e tentar pegar o e-mail da pessoa. Isso deu o maior rolo e você acabou mandando algumas mensagens para e-mails errados. Isso causou uma confusão, né? Alguns amigos receberam os convites e outros não, e ainda teve gente que nem foi convidada recebendo convite. Vish, muita treta, vish! 

Mas não foi de todo o mal, porque agora temos um exemplo para o Clube! Agora, pense que essa confusão toda de convites é meio parecida com o que acontece quando você está tentando classificar algo usando um modelo de machine learning. Você faz uma previsão, e às vezes acerta, outras erra. Se você pensar nas possibilidades de um modelo prever, por exemplo, um churn, você vai ver que tem 4 resultados possíveis também: o modelo prevê churn e o cliente dá churn, o modelo prevê churn e o cliente não dá churn, o modelo prevê que o cliente não vai dar churn e o cliente não dá churn, o modelo prevê que o cliente não dá churn e o cliente dá churn. A matriz de confusão é uma visualização dos resultados possíveis, tanto da sua lambança com convites, quanto do churn. Em outras palavras você vai conseguir visualizar todos os resultados nela! Veja abaixo, o exemplo dos 4 resultados possíveis de um modelo de churn:

![img](https://api-club.hotmart.com/file/public/v5/files/cfaf317e-4a90-43fe-944b-7be93e38494c)

Imagem de: https://www.mdpi.com/2076-3417/12/6/2795

Lembra que a matriz vai mostrar todos os resultados possíveis do que nosso modelo previu, acertou e errou. Veja que no eixo horizontal temos as previsões (predicted label) e no vertical temos os valores reais (true label). Veja o primeiro quadrante, com 22.820 clientes. Este é o número de clientes que tem rótulo real **NÃO CHURN** e que nosso modelo previu que era **NÃO CHURN.** Ou seja, ali temos 22.820 clientes que nosso modelo acertou a previsão. Você conseguiria dizer, após essa breve introdução, quantos erros nosso modelo cometeu?

Se você respondeu 29.247 (15.348+13.899), você acertou! Veja, no segundo quadrante, temos 15.348 clientes que nosso modelo previu que seriam churn, mas que na realidade (o rótulo verdadeiro, o true label) é na verdade não churn. Na sequência, temos 13.899 clientes que são churn, mas que nosso modelo previu que não eram churn. E temos 38.614 clientes que são churn e que nosso modelo previu que eram churn.

Olha que interessante, aqui, nós temos uma visão por classe! Ou seja, aquele caso que mencionamos na última seção, do modelo dummy que iria prever todo target como sendo não-fraudador não adiantaria aqui, nós veríamos que o modelo não está prevendo corretamente.

**Apesar de não ser a melhor métrica, fica um desafio para você: Qual a acurácia do nosso modelo de churn acima?
**

Vamos a outro exemplo rapidinho, só para fechar o tema. Suponha que você está construindo um modelo para detectar se um email é spam ou não, aquele modelo introdutório de todo livro de Machine Learning. Basicamente, existem quatro coisas que podem acontecer:
\- Você prevê que é spam, e acerta (é como enviar o convite certo para o amigo certo!).
\- Você prevê que é spam, mas erra (é o convite certo, mas para o amigo errado).
\- Você prevê que não é spam, mas erra (é como esquecer de enviar o convite!).
\- Você prevê que não é spam, e acerta (é como mandar o convite errado para o amigo errado, ou não enviar convite para quem não deveria mesmo ser convidado).

Passamos brevemente pela nomenclatura, mas vamos reforçar:

![img](https://api-club.hotmart.com/file/public/v5/files/2cc746ae-bc47-433d-aecc-953d17757430)

Imagem de [https://diegonogare.net/2020/04/performance-de-mac...](https://diegonogare.net/2020/04/performance-de-machine-learning-matriz-de-confusao/)

No nosso exemplo, seria:

**- Verdadeiro Positivo (VP):** Você acertou ao prever spam.
**- Falso Positivo (FP):** Você errou ao prever spam.
**- Falso Negativo (FN):** Você errou ao prever não spam.
**- Verdadeiro Negativo (VN):** Você acertou ao prever não spam.

Peço desculpas pelas repetições, mas vocês precisam gravar bem tudo isso!

Vamos verificar a aplicação no Python:

## ![img](https://api-club.hotmart.com/file/public/v5/files/3a96bd0a-9727-4c28-94b4-f13e308ee48c) 2.3 Precision e Recall

Precision é a proporção de previsões corretas positivas em relação ao total de previsões positivas (VP / (VP + FP)). É uma medida de qualidade das previsões positivas. Ou seja, estamos verificando **dentre as previsões positivas, quais estão corretas.
**

Por outro lado, o recall, ou Sensibilidade, é a proporção de previsões corretas positivas entre as observações positivas reais (VP / (VP + FN)). É uma medida de capacidade do modelo de encontrar todos os casos positivos. Ou seja, estamos olhando **dentre as observações que são positivas, quantas nosso modelo capturou.
**

Repare que as métricas não dizem a mesma coisa, uma olha as observações que realmente são positivas e a outra olha o que o modelo previu de positivo. Imagine a situação em que você criou um modelo para prever possíveis compradores e você quer estimulá-los com um desconto. Porém, seu chefe não quer de jeito nenhum gastar mais do que deve, então é importante que **se o modelo disser que a pessoa é compradora, ela realmente tem que ser. Neste caso, você vai focar em otimizar seu modelo olhando para o precision.** Por outro lado, imagine que estejamos trabalhando com um modelo cujo target é saber se uma pessoa está doente. Neste caso, não podemos perder nenhum doente, isso seria trágico. Sendo assim, **precisamos que se a pessoa seja positiva, o modelo a identifique,** mesmo que isso custe outros erros (como acusar de doente alguém saudável). Veja que escolhemos qual métrica otimizar de acordo com o custo do erro. O custo de culpar um inocente é maior, na maioria das legislações, do que o de inocentar um culpado. O custo de acusar que uma pessoa saudável está doente é menor do que o de dizer que um doente está saudável. Guarde isso para sua carreira: **modelagem é sobre tradeoff!!!**

**Qual o precision e qual o recall do nosso modelo de churn exemplificado na matriz de confusão? Você consegue resolver esse dilema?
**

**Vamos tentar responder o desafio...
**

Com base no texto, temos:

- TP = 38.614
- FP = 15.348
- TN = 22.820
- FN = 13.899

Agora, podemos calcular a precisão (precision) e recall:

**Precision (Precisão)** = TP / (TP + FP) = 38.614 / (38.614 + 15.348) = 38.614 / 53.962 = 0.7156 ou 71.56%

**Recall (Sensibilidade)** = TP / (TP + FN) = 38.614 / (38.614 + 13.899) = 38.614 / 52.513 = 0.7355 ou 73.55%

**Assim, a precisão do modelo é de 71,56% e o recall é de 73,55%.**

Bom, para fechar, como de costume, vamos ao código em python:

![img](https://api-club.hotmart.com/file/public/v5/files/0a4d3e11-24ac-441d-ac07-e33e79ebeda6)

##   2.4 F1-Score

O F1-Score é uma métrica que combina Precision e Recall em um único número, utilizando a média harmônica:

![img](https://api-club.hotmart.com/file/public/v5/files/36f4d33e-5a0b-41bc-aeaf-152d912953a9)

Caso você não lembra muito da média harmônica, dá uma passada [neste link aqui.
](https://pt.economy-pedia.com/11040415-harmonic-mean)

Com os valores de Precision e Recall acima, o F1-Score seria F1= (2x(0,7156x0,7355))/(0,7156+0,7355)=0,7255=72,55%

E o código em Python:

## Editar![img](https://api-club.hotmart.com/file/public/v5/files/d6cc4b0a-4695-4fca-b154-7ca1e76b9467) 2.5 Curva ROC e ROC AUC

Agora pode ficar confuso para alguns, então tentarei ser bem prolixo, espero não soar muito repetitivo. Bora entender MUITO BEM a curva ROC!

A curva ROC é uma curva que mostra o desempenho de um modelo de classificação em todos os limiares de classificação possíveis, isto é, ela demonstra o desempenho da curva para diferentes probabilidades escolhidas. Ela traça dois parâmetros:

\1. Taxa de Verdadeiros Positivos (Sensibilidade ou Recall) no eixo vertical.
\2. Taxa de Falsos Positivos no eixo horizontal.

![img](https://api-club.hotmart.com/file/public/v5/files/eedbb216-5f4a-40cf-a22a-7833b094cc2c)

Imagem de [https://towardsdatascience.com/roc-curve-in-machin...](https://towardsdatascience.com/roc-curve-in-machine-learning-fea29b14d133)

Na imagem acima, temos as diferentes probabilidades em cada um dos eixos e para cada probabilidade temos um ponto. Ao unirmos todos os pontos, obtemos a curva azul. Por enquanto, preste somente atenção nisso e pode ignorar a curva laranja, usada apenas para referência.

Lembrando que:

- Taxa de Verdadeiros Positivos (TPR): É a proporção de positivos reais que foram corretamente identificados pelo modelo.
  TPR = TP/(TP + FN)
- Taxa de Falsos Positivos (FPR): É a proporção de negativos reais que foram incorretamente identificados como positivos.
  FPR = FP/(FP + TN)

**Como assim definir diferentes probabilidades?
**

Se você chegou aqui confuso, fique tranquilo, vou explicar melhor o que está acontecendo. Veja, um modelo de classificação tem como saída também probabilidades. O que acontece é que muitas vezes as ignoramos, apenas definimos que se a probabilidade for maior ou igual a 50%, o target é 1 (sim), e se for abaixo de 50%, então é 0 (não). Ou seja, voltando lá no nosso modelo de churn, na verdade, a saída que tivemos eram várias probabilidades e, a partir delas, tivemos uma saída de churn ou não churn. Um indivíduo que teve uma probabilidade de 20% na saída, foi definido como não churn. Um indivíduo que teve 70% foi definido como churn. Isso significa que para diferentes cortes, podemos ter um desempenho diferente do modelo. Se você mudar de 50% para 90%, seu modelo praticamente não vai errar as pessoas que ele classificou como churn, porque ele está indo só em quem tem probabilidade muito alta de churn. Ou seja, se ele disser que é churn, então é churn! O problema é que surgem vários outros erros. Vai ter gente que é churn e que ele não vai pegar, porque você quis ter muita convicção. Brincar com essa probabilidade é interessante, a depender da situação.

Voltando a curva ROC, para criá-la você ajusta o limiar de decisão do seu modelo. Isso significa decidir a que ponto uma previsão será classificada como positiva ou negativa. Ao mover esse limiar, as taxas de TPR e FPR mudarão, e um novo ponto será plotado no gráfico. Ao traçar todos esses pontos, obtemos a curva ROC. O racional por trás dessa estratégia é exatamente o que expliquei acima, mas vou reforçar para quem não entendeu (sim, serei repetitivo): Imagine que você tem um modelo que prevê se um e-mail é spam ou não (voltamos ao exemplo clássico de todos os livros de ML). Se o modelo estiver muito confiante de que um e-mail é spam, ele o classificará como spam. Mas e os e-mails sobre os quais o modelo não está tão confiante? Onde colocamos esse "limite" para decidir se é spam ou não? Esse "limite" é o que chamamos de limiar.

- Se definirmos o limiar muito baixo, o modelo classificará muitos e-mails como spam, incluindo muitos e-mails que não são spam (falsos positivos).
- Se o ajustarmos muito alto, ele perderá muitos e-mails que são de fato spam (falsos negativos).

A curva ROC nos ajuda a visualizar como o modelo se comporta em diferentes limiares e a escolher o que é melhor de acordo com nossas necessidades. Ela nos permite ter uma métrica de avaliação do modelo que independe dos limiares, a área sob a curva (AUC - Area Under the Curve). Veja que essa área nos mostra o quanto o modelo consegue separar as classes do target:

 

![img](https://api-club.hotmart.com/file/public/v5/files/8cb79afb-2452-4c1e-a077-ac89c74fb614)


E não podia faltar, código Python:







![img](https://api-club.hotmart.com/file/public/v5/files/13386e72-982a-4644-877b-61e27d06c7fc)





Agora você não apenas sabe construir um modelo de classificação, como você sabe avaliar bem seu desempenho! Bora aplicar o que aprendemos hoje no seu portfólio???

Forte abraço e bons estudos,

Yukio!