## Semana 30: Machine Learning pt. 7 (Avaliação de Regressão)



# 1. Introdução



Apesar do Clube já ter coberto todo o conteúdo básico de Classificadores, acabamos olhando a regressão mais sob a perspectiva de inferência, que nem é a mais visada em Machine Learning, e acabamos esquecendo da predição! Apenas para lembrar aos mais desatentos, modelos de regressão são uma parte crucial do aprendizado de máquina. A gente utiliza esses modelos para prever um valor contínuo, algo como o preço de uma casa ou a temperatura em um dia/local. Diferentemente dos modelos de classificação, que a gente viu sob a figura da regressão logística, que separam os dados em categorias distintas, os modelos de regressão trabalham com valores que estão em um contínuo. Avaliar a qualidade dessas previsões é essencial, claro. 

Assim como o modelo de classificação, nem sempre "só ver se acertou" serve. Vimos no material de regressão linear que não conseguimos apenas ver a diferença entre o previsto e o que realmente aconteceu. Afinal, imagine que o modelo subestime a primeira predição em 30 unidades e superestime a segunda em 30 unidades. Em um caso, a diferença foi +30 e em outro -30. Se a gente só somar as diferenças teremos zero como resultado. Ora, mas isso não quer dizer que nosso modelo não errou nada. Pelo contrário, ele errou os dois valores! É por isso que apenas pegar os erros e somar não funciona num modelo de regressão. Vamos ver as métricas que podemos utilizar na regressão e, claro, o código Python!



# 2. Métricas de Validação

## 2.1 Mean Absolute Error (MAE)

O Mean Absolute Error, abreviado como MAE e traduzido como Erro Absoluto Médio, é uma das métricas mais simples de se ler numa regressão. Ele mede o erro absoluto, ou seja, desconsiderando os sinais dos erros (as direções). Alguns podem dizer que é o erro médio "para cima, ou para baixo".

Lembra do nosso exemplo em que o modelo errou +30 e -30?

O MAE daquele modelo é 30!

Claro, nem sempre será exatamente um erro para baixo e para cima. Imaginemos um caso mais complexo, onde nosso modelo subestima muito os valores reais por algum motivo qualquer. No caso, temos:

Valores reais: 40, 50, 35, 50, 44

Valores preditos: 39, 40, 30, 45, 40

O MAE será: 

![img](https://api-club.hotmart.com/file/public/v5/files/b26b360a-fc9e-4cf4-81dd-9b721eb0913b)

Repare que o erro médio absoluto foi 5, mas os erros oscilaram entre 1 e 10. Apenas para mostrar que pode ser interessante combinar a métrica com algumas outras ou com alguns gráficos.



## 2.2 Mean Squared Error (MSE)

O Mean Squared Error, frequentemente abreviado como MSE e traduzido como Erro Quadrático Médio, é outra métrica crucial para avaliar a performance de modelos de regressão. Ao contrário do MAE, que se concentra no erro absoluto, o MSE foca no erro quadrático. Isso significa que ele penaliza erros maiores de forma mais severa do que erros menores. Pense nisso como uma forma de dizer: "Quão longe estamos, em média, ao quadrado?"

Lembra daquele exemplo onde o modelo errou +30 e -30? No MSE, esses erros seriam elevados ao quadrado antes de serem médios. Portanto, o MSE daquele modelo seria 900!

Vamos a um exemplo mais detalhado, usando os mesmos valores reais que mencionamos anteriormente:
Valores reais: 40, 50, 35, 50, 44
Valores preditos: 39, 40, 30, 45, 40
O MSE será:

![img](https://api-club.hotmart.com/file/public/v5/files/d26a8306-6cf7-4b64-b3e8-e15fffba53b1)

Note que 26 está bem aquém até mesmo do maior erro que temos, que é 10. E, com certeza, não representa o restante dos erros, que são 5, 4 e 1. Ele é um valor bem alto, claro, afinal, estamos lidando com as diferenças elevadas ao quadrado somadas. Isso se torna um problema de interpretação, já que este valor é meio difícil de se levar em conta, pois entra numa escala diferente do problema em questão. Por este motivo, temos o ROOT MEAN SQUARED ERROR!



## 2.3 Root Mean Squared Error (RMSE)

O Root Mean Squared Error, comumente abreviado como RMSE e traduzido como Raiz do Erro Quadrático Médio, é uma métrica que nos dá uma perspectiva mais "humanamente interpretável" dos erros de um modelo de regressão. Se você já se perguntou: "Ok, o MSE é útil, mas como posso interpretar esse valor em termos do meu problema original?", então o RMSE é a resposta!

O RMSE é simplesmente a raiz quadrada do MSE. Ao fazer isso, ele traz o erro de volta à escala original do problema, tornando-o mais compreensível e comparável com o MAE.

Lembra do nosso exemplo do MSE, onde o valor foi 900 para os erros de +30 e -30? Para o RMSE, pegaríamos a raiz quadrada desse valor, o que nos daria 30! Isso nos dá uma ideia mais clara do erro médio do modelo.

Vamos usar o mesmo exemplo que usamos para o MSE:
Valores reais: 40, 50, 35, 50, 44
Valores preditos: 39, 40, 30, 45, 40
O MSE, como vimos, foi 26. Agora, o RMSE será a raiz de 26, que é aproximadamente 5.1.

Veja como o RMSE, neste caso, é um pouco maior que o MAE, mas ainda está na mesma escala do problema. Ele nos dá uma ideia de "quão longe estamos, em média", mas levando em conta a penalização dos erros maiores, como o MSE faz. É uma métrica poderosa e, muitas vezes, preferida por analistas e cientistas de dados por sua interpretabilidade e capacidade de destacar grandes erros no modelo.



## 2.4 Mean Absolute Percentage Error (MAPE)

O Mean Absolute Percentage Error, ou MAPE, traduzido como Erro Percentual Absoluto Médio, é uma métrica que expressa o erro como uma porcentagem. É especialmente útil quando queremos entender o erro em relação ao valor real, dando-nos uma perspectiva percentual do quão longe estamos.

Para entender melhor, vamos pegar o exemplo anterior:

Valores reais: 40, 50, 35, 50, 44

Valores preditos: 39, 40, 30, 45, 40

O MAPE será:

![img]()![img](https://api-club.hotmart.com/file/public/v5/files/1d3b96f0-d9c1-4f51-a5dd-58c950b0f4d5)![img]()![img]()

Isso significa que, em média, nosso modelo está errando em 11% em relação ao valor real. O MAPE é uma excelente maneira de entender o erro em termos relativos. Assim como o MAE, costuma ser uma métrica intuitiva para a maioria das pessoas!



# 3. Exemplo Prático: Avaliando Regressão no Python

Que tal a gente olhar como avaliar uma regressão na prática? E já que estamos dando mais um passo bacana aqui, poderíamos fazer isso já tentando dar um salto, que tal? Que tal usar um algoritmo mais poderoso?

Estou falando do LightGBM, um modelo baseado em árvore que tem ganhado corações (e competições) por sua eficiência e precisão. Vamos ver como rodar esse monstro em Python e avaliar o quão bem ele está se saindo!

Se você não entende de árvores de decisão, dê uma olhada no conteúdo do encontro do dia 26/08/2023! Porém, aqui, não será necessário entender o algoritmo. Queremos apenas aprender como avaliar um modelo de regressão. Por enquanto, entenda apenas que temos um algoritmo de regressão sendo executado!

Voltando ao nosso modelo...

Vamos começar baixando o dataset Medical Cost Personal Datasets, [neste link aqui.
](https://www.kaggle.com/datasets/mirichoi0218/insurance)



[![img](https://api-club.hotmart.com/file/public/v5/files/5f2b506c-c387-4de8-90ed-13b5ef9ee9f8)](https://www.kaggle.com/datasets/mirichoi0218/insurance)


O dataset é composto de informações a respeito de gastos com saúde. A variável target se chama **​charges**​, tradução de **cobranças**. Vamos ver se conseguimos prever os custos com saúde de uma pessoa com base nas informações dela!

Vamos começar importando a biblioteca **pandas,** para lidar com os dados. Aproveitaremos e já importaremos o dataset para dar uma expiada no que temos nele:

![img](https://api-club.hotmart.com/file/public/v5/files/76b5b601-6faa-4501-a7cb-60fe415d6c47)

Veja que temos várias informações que se relacionam com a saúde de uma pessoa, como idade, IMC (chamado de BMI em inglês), dentre outras features. Não são muitas, mas talvez nos sejam suficientes!

Na sequência, faremos duas coisas: (1) divisão em treino e teste, já no começo, evitando fazer qualquer bobagem com os dados de teste - que simulam nossos dados em produção. Fazemos isso e damos uma olhada no shape dos datasets resultantes. (2) Antes de entrar no pipeline, vamos separar categóricas de numéricas e ver se deu certo!

![img](https://api-club.hotmart.com/file/public/v5/files/d81ea707-f333-4d38-9b68-f99157b09db2)

Veja que bacana, temos 1070 observações para treinar o modelo e 268 para validar! Conseguimos separar variáveis categóricas de numéricas sem muito esforço, apenas separando variáveis do tipo "object" das demais.

Agora, precisaremos ir para a parte mais difícil, o **pipeline!** Se você pulou as últimas semanas, recomendo dar uma olhada ao menos no material que antecede este! Seria legal você entender o pipeline, pois faremos transformações específicas para cada tipo de variável!

Começamos importando alguns módulos do scikit-learn que serão necessários para a etapa. Além disso, específicamos, através do ColumnTransformer, qual tratamento deve ser feito para cada grupo de variáveis:

![img](https://api-club.hotmart.com/file/public/v5/files/40601115-2262-4f48-ac80-0551443f9143)

Agora que temos as especificações de tratamentos, podemos construir um pipeline com o objeto que contém as transformações, chamado de ***preprocessor***, e o algoritmo de treinamento:

![img](https://api-club.hotmart.com/file/public/v5/files/dbd24870-b302-4645-9977-ed8c3b2994a8)



Pronto! Nosso modelo foi treinado, ou seja, encontramos um padrão que conecta as features ao nosso alvo, i.e., as características das pessoas aos valores cobrados. Mas será que a gente realmente mapeou direito? Precisamos validar isso!

![img](https://api-club.hotmart.com/file/public/v5/files/274a25e6-6b91-4005-a5c7-e8769e598b16)

Como podemos ver, o modelo não saiu tão bom, mas ainda pode ser melhor do que muitas regras de negócio baseadas em achismos. Nosso MAPE é de 34%, o que é alto, é um erro absoluto de 34%. Já o MAE é de 2608.68, ou seja, um erro absoluto de quase 3 mil 'dinheiros' (não sabemos a unidade usada, mas deve ser dólar).

Podemos visualizar como as predições e os valores reais estão num gráfico de dispersão:

![img](https://api-club.hotmart.com/file/public/v5/files/5e1090fd-1f14-4761-9fec-bcf3fac87658)

![img](https://api-club.hotmart.com/file/public/v5/files/ebaede12-ea08-482c-952f-07ffe74fed33)

Veja pelo gráfico que não estamos tão mal assim! Quanto mais próximos da diagonal nossos pontos, melhor nosso modelo em termos de capacidade preditiva! Há alguns pontos intermediários que fogem, mas nosso modelo foi capaz de capturar uma série de observações muito bem!

Sendo essa apenas uma versão inicial, não está tão mal assim, não é?

Que tal tentar o desafio de melhorar ainda mais essas métricas?

E é isso, pessoal! Com o LightGBM e essas métricas, você tem uma ferramenta poderosa para fazer regressões em Python. E o melhor de tudo, você não só sabe como rodar o modelo, mas também como avaliar e visualizar seus resultados. Agora é com você: experimente, ajuste e divirta-se com seus dados! Até a próxima, galera do Clube!



# 4. Inferência vs Predição

Não se esqueça de que o que estamos fazendo neste material é separar um pedaço das observações para ver se nosso modelo está fazendo boas previsões. Em outras palavras, estamos fazendo um trabalho puramente preditivo, bem diferente daquele que falamos da primeira vez que vimos Regressão Linear. Quando se fala de inferência, há mais pressupostos a serem observados e o nosso foco é na compreensão das relações entre as variáveis independentes (as features) com a variável dependente (o target). No caso de trabalhos focados em inferência, a abordagem costuma ser diferente, não há sequer essa divisão de treino e teste (basta você pegar qualquer paper de economia e ver isso). É importante que você, como profissional de dados, aprenda a lidar com essas distinções!



# 5. Conclusão

Ao longo deste material, exploramos a importância dos modelos de regressão no campo do aprendizado de máquina e como avaliar a qualidade de suas previsões. Através das métricas apresentadas - MAE, MSE, RMSE e MAPE -, podemos quantificar o desempenho de nossos modelos de regressão. Cada métrica tem suas peculiaridades e fornece insights diferentes sobre os erros cometidos pelo modelo:
\- O MAE nos dá uma visão direta do erro médio, independentemente da direção do erro.
\- O MSE penaliza erros maiores, tornando-se uma ferramenta valiosa quando grandes erros são particularmente indesejáveis.
\- O RMSE traz o erro de volta à escala original do problema, facilitando a interpretação e comparação com o MAE.
\- E o MAPE nos oferece uma perspectiva percentual do erro, sendo especialmente útil quando lidamos com grandes variações nos valores reais.

*(Habitue-se com as siglas, é como nós usamos no dia a dia)
*

Ao escolher a métrica certa para avaliar o desempenho do modelo, é crucial considerar o contexto e os objetivos específicos do problema em mãos. Em algumas situações, pode ser benéfico combinar várias métricas para obter uma visão mais holística do desempenho do modelo.

Em resumo, a avaliação correta do desempenho de um modelo de regressão é fundamental para garantir que ele atenda às expectativas e forneça previsões precisas e confiáveis. Com as ferramentas e conhecimentos adquiridos neste capítulo, você está bem equipado para enfrentar os desafios do mundo real e otimizar seus modelos de regressão para obter os melhores resultados possíveis.

Por fim, vou deixar alguns problemas para você praticar. Com o que já aprendemos, será tranquilo trabalhar modelos preditivos para os problemas abaixo:

- Criar uma regressão linear simples: [Practice Dataset](https://www.kaggle.com/datasets/tanuprabhu/linear-regression-dataset)
- Prever o preço de uma casa: [House Prices - Advanced Regression Techniques](https://www.kaggle.com/competitions/house-prices-advanced-regression-techniques)
- Prever gastos com saúde: [Medical Cost Personal Datasets](https://www.kaggle.com/datasets/mirichoi0218/insurance)
- Prever o preço de uma casa nos EUA (King County): [House Sales Prediction](https://www.kaggle.com/datasets/harlfoxem/housesalesprediction)
- Prever o preço de uma casa: [USA Housing](https://www.kaggle.com/datasets/vedavyasv/usa-housing)

Além disso, que tal ir lá no material de Pricing que fizemos na semana 10 e refazer, aplicando todo seu conhecimento agora?

Apenas se lembre, neste último exemplo, de fazer precificação com outro dataset, caso deseje usar como portfólio. Evite usar materiais públicos como se fossem seus, pois você pode incorrer em 2 problemas (1) as pessoas duvidarem da sua capacidade, pois não sabem se você copiou ou fez do zero; (2) pode parecer um tipo de plágio. A internet não tem isso claro, mas veja a quantidade de brigas que acontecem quando um usa material feito por outro sem dar créditos. É problemático usar material da internet ou de curso como se fosse seu, tenha cautela. Você pode postar como forma de estudos, se for bem transparente.

Forte abraço e bons estudos!