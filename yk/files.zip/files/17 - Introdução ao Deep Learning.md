# Semana 17: Introdução ao Deep Learning

**O QUE É DEEP LEARNING?**

Antes de falar diretamente qual é a definição de Deep Learning, ou aprendizado profundo, vale ressaltar que a maioria das aplicações que vemos no dia a dia tem a ver com ele. Quando desbloqueamos nosso celular apenas direcionando a câmera para o nosso rosto, o sistema de reconhecimento facial que está sendo executado é totalmente baseado em Deep Learning. Além disso, o próprio ChatGPT que todos nós conhecemos foi desenvolvido utilizando Deep Learning. Por isso, é um tópico muito importante a ser estudado e tenho certeza de que você irá gostar bastante.

Agora, vamos definir realmente o que é Deep Learning:

Deep Learning, ou Aprendizado Profundo, é um tipo específico de aprendizado de máquina caracterizado por camadas profundas de cálculos matemáticos. 

E é justamente por esses modelos possuírem essas camadas profundas de cálculos matemáticos que os tornam super poderosos para encontrar padrões escondidos nos problemas mais difíceis do mundo real.

Há vários tipos de aprendizado profundo, mas as redes neurais foi o que mais se destacou. Devido a sua escalabilidade e poder, elas se tornaram o modelo padrão de definição de Deep Learning. Talvez você esteja se perguntando o porquê de o nome ser redes neurais, e é justamente porque esse tipo de modelo tenta simular o que acontece no cérebro humano. 

Um modelo de rede neural artificial é composto por diversos neurônios, onde cada neurônio realiza seu próprio cálculo matemático, e a maneira com que eles se conectam é que define sua complexidade e seu poder em diversas tarefas. 

Por serem altamente utilizados, os modelos de redes neurais vão ser o foco deste material. Sendo assim, vamos começar pelos “tijolos” que constroem as redes neurais: os neurônios.

**A UNIDADE FUNDAMENTAL DE UMA REDE NEURAL: O NEURÔNIO**

Como disse, vamos começar pela unidade fundamental de uma rede neural: o neurônio. Observe a imagem abaixo para ver a representação de um neurônio recebendo dados de entrada:

![img]()![img]()

![img](https://api-club.hotmart.com/file/public/v5/files/1f1f88fb-5558-4038-8449-173ffa5f59d1)



Aqui, temos o dado de entrada x que é multiplicado por w quando “entra” no neurônio. Sempre que um dado de entrada flui para o neurônio, multiplicamos seu valor pelo peso de sua conexão com o neurônio (neste caso, por w). E o aprendizado da rede neural é justamente devido aos reajustes dos diversos pesos w’s de vários neurônios. 

Já o valor b é um tipo especial de peso que chamamos de viés. Ele não tem um dado de entrada associado. Porém, para fins de representação, colocamos o número 1, visto que 1 vezes qualquer número é o próprio número. 

Portanto, note que o neurônio possui um sinal de adição nele, isso significa que ele vai multiplicar os dois valores que estão chegando até ele (x*w e b) e somá-los. Sendo assim, temos que y = x*w + b, ou seja, uma função linear. 

Apesar de um neurônio ser parte de um conjunto maior de outros neurônios, ou seja, de uma rede neural, podemos começar o entendimento com apenas um neurônio. 

Para entender melhor, vamos treinar um modelo utilizando o dataset [80 Cereals](https://www.kaggle.com/crawford/80-cereals), do kaggle, tendo como dado de entrada apenas a quantidade de açúcares (sugar) e, como saída, a quantidade de calorias (calories). Ou seja, o x será a quantidade de açúcares e o y a quantidade de calorias. Treinando o modelo, chegaremos em um resultado onde w = 2.5 e b = 90. Logo, podemos representar as calorias da seguinte forma: calorias = açúcares*2.5 + 90. Observe o esquema abaixo:



![img](https://api-club.hotmart.com/file/public/v5/files/6358f1c7-523f-4db8-b3f9-f8e17a6b5816)



Porém, sabemos que no mundo real os problemas não contêm apenas um valor de entrada. Na verdade, podemos ter milhares (até milhões) de valores de entradas, dependendo do problema. Então, vamos fazer uma adaptação nessa representação para múltiplos valores de entrada:

![img]()

![img](https://api-club.hotmart.com/file/public/v5/files/1a194c55-d964-404f-b75d-59a7a0906a04)



Aqui, poderíamos ter N valores de x, indo de x0, x1, x2… até xN. No exemplo que fizemos anteriormente, poderíamos ter x0 sendo os açúcares, x1 as proteínas, x2 as gorduras e por aí vai. Note que cada um dos “x” tem seu respectivo peso. Logo, o resultado final seria:



![img](https://api-club.hotmart.com/file/public/v5/files/8727aec7-c101-4b67-8630-14fd0a9aa7ba)



Porém, note que essa representação é bem extensa e, quando temos muitas entradas (milhares ou milhões), representar y seria impossível. Sendo assim, utilizaremos a representação matricial. Abaixo, temos a representação matricial dos valores de entrada (X) e dos pesos (W):

![img]()

![img](https://api-club.hotmart.com/file/public/v5/files/71951b35-bbb9-41ec-99f7-9c8a1e1e4638)



Temos que dar um jeito de relacionar essas duas matrizes para chegar na expressão de cima. Note que X é uma matriz Nx1, ou seja, possui N linhas e 1 coluna, assim como W. Como sabemos das aulas de Álgebra Linear, apenas podemos multiplicar duas matrizes quando o número de colunas da primeira for igual ao número de linhas da segunda, como tanto X quanto W possuem dimensão Nx1, não podemos fazer essa operação. 

Porém, caso fizéssemos a transposição de uma das matrizes, isto é, permutar o número de linhas com o número de colunas, teremos uma matriz 1xN (transposta) e outra 1xN, com isso, poderíamos realizar a multiplicação. Dessa forma, vamos transpor a matriz dos pesos:



![img](https://api-club.hotmart.com/file/public/v5/files/b5b5a3cf-28ff-442e-9834-6ad55ad67276)



Agora, sim! Note que a dimensão de W é 1xN (1 linha e N colunas). Portanto, podemos realizar a multiplicação das duas matrizes. Como queremos gerar um escalar (número) como resultado, vamos fazer a multiplicação de W por X, dessa forma, teremos como resultado uma matriz 1x1 (1xN * Nx1 = 1x1). Se fizéssemos a multiplicação de X por W, obteríamos uma matriz NxN, que não é o que queremos. Por fim, após fazermos a multiplicação dessas duas matrizes, vamos adicionar o valor do viés b, resultando no seguinte:



![img](https://api-club.hotmart.com/file/public/v5/files/42191fbd-0f80-47d1-8315-4cb5e1f627fd)



Aqui, temos a representação matricial de y. Observe que é uma maneira bem mais simples de fazer essa representação!

**IMPLEMENTAÇÃO EM PYTHON**

Ok, vimos toda a parte conceitual e matemática do neurônio. Chegou a hora de implementar tudo o que aprendemos em Python! Para isso, vamos utilizar a biblioteca tensorflow! Se você não tem ela ainda, execute o seguinte código no terminal do seu computador:



![img](https://api-club.hotmart.com/file/public/v5/files/00b4ea19-f3ec-4ac2-ad7c-9e6dad5dc259)



Com isso, podemos começar! Vamos importar as bibliotecas e carregar o dataframe:



![img](https://api-club.hotmart.com/file/public/v5/files/36ac2add-6f75-40d0-9f60-64dbd105bb6e)



Esse código vai nos retornar a seguinte tabela:



![img](https://api-club.hotmart.com/file/public/v5/files/87c48b12-a72f-41ce-a9f4-972812c6239b)



Note que temos várias colunas que podemos utilizar para prever as calorias, como protein, fat, cups, fiber etc.. Porém, para simplificar, vamos selecionar algumas dessas variáveis e construir nosso modelo. 

![img]()![img](https://api-club.hotmart.com/file/public/v5/files/ad0db27d-4f62-4539-986d-a0908455f7f6)

Note que selecionei algumas variáveis do meu interesse e montei um esquema com nossas variáveis preditivas e a variável alvo. Seguindo para o próximo passo, vamos fazer a divisão dos dados em treino / teste e padronizá-los. 



![img](https://api-club.hotmart.com/file/public/v5/files/46becee4-4553-4b92-ab2e-1d5279af1cab)



Agora, podemos partir para a construção do modelo…

O jeito mais fácil de criar um modelo utilizando o TensorFlow é através do tensorflow.keras.Sequential, que cria uma rede neural com várias camadas. Podemos criar modelos de redes neurais como este utilizando camadas densas, ou dense layers. 



![img](https://api-club.hotmart.com/file/public/v5/files/54919aa9-c019-40b5-82a2-1196fac8c5a9)



Provavelmente você nunca teve contato com essa biblioteca, certo? Então, vou explicar o que cada um desses termos significa. Primeiro, importamos as classes e funções que iremos utilizar. Depois disso, criamos a nossa rede neural com o keras.Sequential e, dentro dele, criamos algumas camadas densas (quantas quisermos). Neste caso, vou criar uma camada densa que irá nos retornar 1 output, representado pelo parâmetro units e teremos 5 entradas, representadas pelo parâmetro input_shape. Note que lá eu passei o tamanho do vetor features, justamente porque teremos como dados de entradas todas aquelas variáveis.

Um detalhe importante: observe que passamos o input_shape em formato de lista, mas por que isso? Bem, neste caso estamos resolvendo um problema simples, onde os dados de entrada são dados tabulares. Porém, em problemas mais complexos, como classificação de imagens, áudios etc., podemos ter os dados de entrada como sendo [altura, largura], por exemplo.

Assim, você criou o seu primeiro modelo de deep learning! Agora, vamos verificar os pesos e o viés, que falamos tanto anteriormente. Para isso, execute o seguinte código:



![img](https://api-club.hotmart.com/file/public/v5/files/cd0b7c18-a353-49a7-adcb-70be33a43531)



Executando esse código, veremos que ele nos retorna um objeto muito parecido com um array do numpy. De fato, é muito parecido, mas o tensorflow possui o seu próprio tipo de array, chamado tensor, que é um objeto melhor para tarefas de deep learning (inclusive, uma das coisas mais importantes é que os tensores são compatíveis com GPUs). Internamente, ele representa os pesos e o viés de uma rede neural com tensores. Como ainda não treinamos o modelo, ele irá nos retornar pesos que foram inicializados de forma aleatória. 

Para treinar nosso modelo e fazê-lo calcular quais são os parâmetros ideais (pesos e viés), precisamos de mais duas coisas: uma função de perda (que quantifica o quão bom o nosso modelo está sendo) e um otimizador (que diz à rede neural como atualizar os pesos). 

Não vou entrar em detalhes sobre as funções de perda, visto que já temos materiais aqui no clube sobre elas e, inclusive, no último encontro falamos sobre elas (confere lá). Dessa forma, vamos falar um pouco mais sobre os otimizadores.

Nós descrevemos o problema que queremos resolver, mas agora precisamos dizer COMO resolver o problema. E basicamente esse é o trabalho do otimizador: ele é um algoritmo que ajusta os parâmetros para minimizar o erro. Isso te lembra algo? Claro, o algoritmo do gradiente descendente! Praticamente todos algoritmos de otimização utilizados em deep learning são baseados no algoritmo do gradiente descendente estocástico. Observe o GIF abaixo para entender seu funcionamento: 

![img]()![img]()![img](https://api-club.hotmart.com/file/public/v5/files/582e784d-c263-476f-8b66-313ed54eb943)

(Se o gif der problema, você pode ver este gráfico neste excelente tutorial: [https://medium.com/swlh/introduction-to-deep-learn...](https://medium.com/swlh/introduction-to-deep-learning-using-keras-and-tensorflow-part2-284746ab4442))

Note que à medida que a reta vai se ajustando aos dados (gráfico à esquerda), o resultado da função de perda para os dados de treinamento vai se reduzindo (gráfico central) e os parâmetros vão se aproximando dos valores ideais (gráfico à direita). Não vou me aprofundar no funcionamento do algoritmo do gradiente descendente porque nosso último encontro foi inteiramente sobre ele! Então, confira lá. 

Um outro ponto que acho válido ressaltar é que iremos enxergar este problema sob a ótica de um problema de regressão, mesmo que nossa variável alvo tenha apenas 11 valores distintos (verifique isso utilizando y.nunique()). Observe o código abaixo, onde adicionamos a função de perda e o otimizador ao modelo:



![img](https://api-club.hotmart.com/file/public/v5/files/4ff81408-8db5-4366-85ae-5611b3511918)



Talvez, você esteja em dúvida sobre o que é esse ‘adam’ que coloquei como sendo o otimizador. Basicamente, adam é um algoritmo do gradiente descendente estocástico que é chamado de ‘self tuning’, ou seja, ele vai adaptando os parâmetros mais importantes de um algoritmo de gradiente descendente, o learning rate e o tamanho dos batches de treinamento, por conta própria. Sendo assim, não precisamos fazer aquela tunagem de hiperparâmetros de forma manual. Além disso, coloquei a função de perda como sendo o erro percentual médio absoluto (mean absolute percentage error - MAPE). 

Agora, vamos treinar nosso modelo!



![img](https://api-club.hotmart.com/file/public/v5/files/4f996243-a7b4-4134-8bc9-1b5027c00fdf)



Note que utilizei todo o dataset de treinamento como tamanho de cada um dos batches. Isso é porque nosso dataset é bem pequeno, temos apenas 53 instâncias de treino e 24 de teste. Além disso, epochs é a quantidade de vezes que o nosso modelo irá ver todas as instâncias de treino para atualizar os parâmetros (pesos e viés).

Quando executamos esse código, o seguinte resultado aparece na tela:



![img](https://api-club.hotmart.com/file/public/v5/files/659e7229-3572-4eb7-bedd-5eb9cbeb22cc)![img]()



Aqui, perceba que o nosso erro (loss), no conjunto de treinamento, é de 98% e no conjunto de teste, 97%! É muita coisa. Isso se deve ao fato de que temos poucos dados para treinamento. Geralmente, modelos de deep learning aprendem em grandes conjuntos de dados, com várias instâncias.

Dessa forma, finalizamos a primeira parte de Deep Learning! Mas repare o quanto você já sabe de um tema tão complexo!