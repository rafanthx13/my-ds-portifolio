## ANÁLISE COHORT 



Já tem um tempo desde que vimos um projeto aplicado de Python, demonstrando como utilizar nossas skills para solucionar um problema de negócio. Já vimos isso para realizar a precificação de produtos e também na análise de Recência, Frequência e Valor. Hoje, vamos demonstrar como fazer uma análise de [COHORT](https://blog.croct.com/pt-br/post/cohorts-no-marketing). 

A análise de hoje é simples, mas muito útil, principalmente para quem trabalha com retenção de clientes. A ideia é mapear a entrada e saída da sua base, para entender a retenção ao longo do tempo. A tabela abaixo é o produto final de uma análise Cohort, feita em dias:

![img](https://lh6.googleusercontent.com/HmZLiwML0ie1GE4MZ1Q7FupxrRBzeSkUZ4dfH8aTz3SJXdKauAHiY3rYlUJioXZDW50ucAygSHg3Qr43rLeyKoscA7cfKCD2EWxc0KcKUh-LEZv5QMzWH0qXhotpFzCEIS5QpiVu0S134FTEu72J6Jo)

Fonte da Imagem: https://clevertap.com/blog/cohort-analysis/

No exemplo acima, estamos falando do lançamento de um aplicativo, no qual 1.098 entraram no dia 25 de janeiro e, destes, 33.9% continuavam no dia seguinte; 23,5%, dois dias depois; 18,7% três dias depois e assim em diante. Fazemos isso diariamente, sempre registrando a entrada de clientes naquele dia e quantos permaneciam nos dias seguintes. Com isso, sabemos como anda a retenção de clientes. A depender do tipo de produto, a análise pode ser mais eficiente em meses. 



**COMO CONSTRUIR UMA COHORT?**

Primeiro de tudo, você precisa ter uma tabela contendo algum tipo de recorrência de seus clientes. Por exemplo, quando fizemos nosso RFV, utilizamos um dataset de um e-commerce contendo as compras dos clientes. Aquele é um exemplo interessante para aplicar a análise que aprenderemos aqui. Para não repetir o dataset, vamos utilizar um dataset parecido, infelizmente vou apelar para um que já é um pouco manjado, mas pelo menos deixamos o do RFV para vocês validarem o entendimento obtido neste material. Você pode baixar o dataset deste material clicando [aqui](https://www.kaggle.com/datasets/jihyeseo/online-retail-data-set-from-uci-ml-repo):

![img](https://lh4.googleusercontent.com/8B7Jziotu7Mblb5y2jJ7UUkGpuBnKZBTUSs18w-ZEVIoW76vc9X_lZOCuGDCO2LRjXBxeoMaidKK1qcYoh6fbM1iKjdvXxUXNZ3w47fHcqJK4R9T13_L0PVWSGExEX3Vf6HgAEWsLiTzWB0PtCKMJqo)

Comece carregando o Pandas e os dados:

![img](https://lh5.googleusercontent.com/IwDB_QSIctzv9yfInJnIzLzNOQLlWFHqbTipjIrYmukX3RDbJy0PSwE7ztLGu1mZOV36YbbEm4CGo3zm51U859xwZCz_TxjrzGEndFP5zUpAdbeg-KTma6Z0JTfE-HYQ-4JGbfqxKDNChfGQU4--6NQ)

![img](https://lh6.googleusercontent.com/IA7LH6bw-hrR5DwkzmTjFWzegdDZtrbDW3d77xK2qEpzgMC9YosiycICo-vU2AMAaXlSDNpyYKeWhsi5hVZ7CYeGiZa1Ug7oDFiEzIja0rMgk4l0LTV21jT8pwzNyoKZEPRDrShy7hoqOi3QyjimqlM)

Temos no dataset, na ordem da primeira à última coluna: o código numérico que identifica a compra, o código numérico que identifica o item, a descrição do item em texto, a quantidade comprada, a data da compra, o preço unitário, a chave numérica de identificaçã

o do consumidor e o país da compra.

Se não conseguimos identificar o cliente, não vamos conseguir acompanhar seu comportamento ao longo do tempo. Por causa disso, vamos excluir linhas que não possuem a variável CustomerID preenchida.

![img](https://lh6.googleusercontent.com/KpadApyyNUxRyKjc9y3PLMy-IbMKic3LBY3BLuNakyqkNIAHIvEpKuQbxPD48WuQ99n16kBlqfWbOKGyW2ZbjPieUqXle4X8NjD9x7sIC1RK51rzf0_5EdlsF71gF7M8POFPFjrqT7kgknDrB9MtnmU)

Não há muito o que a gente consiga fazer aqui, mas é interessante verificar como o dataset mudou de tamanho:

![img](https://lh6.googleusercontent.com/Z_OhAA1bRuerscltIDS_MyE36eVejplZlRWcv2hem3uzEE_-p0CO27jcfSUWM33SuJ-nt920B1f3ytkhk5uHyhfLnjNLiqgImcHYXMkTgnUfmMTU8x1VSub5UiwD5Ylq63nEHuVtLi3EeZHUNFGuMqA)

Perdemos uma quantidade razoável de linhas no dataset, cerca de 25%. Isso, no mundo real, é preocupante. Já vi projetos seguirem dessa forma, mas é o tipo de problemas de qualidade dos dados que deveria preocupar a equipe. Como aqui não temos muita ação sobre este problema, vamos apenas dar sequência.

Podemos realizar diversas análises dos dados, antes de começarmos efetivamente a gerar as cohorts. Geralmente, você verá as pessoas entendendo um pouco os dados, o que passa pela estatística descritiva das colunas:

![img](https://lh5.googleusercontent.com/_yIimYg94GEovMuUft9-STFlWWxKo4YW_s1JQNEVfS69a2i7oDRmRcCrTGHNMb6ySbcesQSfycdU7iaz65a0pQJiLIwytbsKsn_qbumHcUV6ysP9dqcdhQOio_BMuPlAQQrcBTme_sF9Od5my8d5RKE)

![img](https://lh3.googleusercontent.com/yDJTH7wT4A4e3BBQ4r44gpkl8PSzr2wNJRY0E4CwfpWUuip-0mGL2qRP824k887u_LB631PABRNV-vMc0ikghP7b8xmoQ298Owiyusx914vanF803WR4J9WrYHdMjqkhv_1QWY2dJdgG3258TrIirNU)

Veja que a quantidade média de itens por compras é em torno de 12, enquanto a mediana indica 5. Ou seja, temos uma distribuição bastante assimétrica. 

Mais importante do que entender a visão geral, precisamos pegar as visões por consumidor. Afinal, se a demanda é de uma análise Cohort, é porque estamos entendendo nossos clientes. Sendo assim, como será que é a distribuição de compras feitas por nossos clientes? Quantas compras cada cliente fez?

Para responder à pergunta, basta contar quantos invoices cada cliente tem:

![img](https://lh5.googleusercontent.com/WCpctZI1wf-Vp-zUZQBgQlecvRf30CeB-VEurDZRgxWYcXpbN5VH9GqpEO3d-394Gujomn4_FMngK_b9deEcL2NDRiyxQGLa5Ariz0FuFphEak6XNJDR61sCHbhlRFiWANa_o7N8mkCd4hoCxQJSmc4)

Note que utilizamos nunique() e não size(). Isso foi feito porque queremos pegar quantos códigos de invoice, quantos números diferentes de invoice, cada cliente tem. Se utilizássemos size(), pegaríamos quantas linhas existem, e teríamos

 um número bem maior porque o dataset possui repetições de invoices, cada compra pode ter mais de um item e isso faz com que tenhamos o mesmo número de invoice aparecendo diversas vezes.

![img](https://lh6.googleusercontent.com/wlZQro9yxEhUfcybwTB6coMyizKQAE7ZnNP6R-ttOSUc6JzKZN1MDB4saGhvvOxqfrnyQdMgh5xbW0VnhqFGIL_56AscCXTbzIHSJ52-hVHyqYlpZrprHrLh96HrCxrhlFVS99U2sPxzdhhizex3R6o)

![img](https://lh5.googleusercontent.com/mRlplR2bRzx_Q5dCcR2mDIbm5fsIuO6hPlANG-aajqFWxw2kCWA8SwvzGUomWJNPllQV6eQMYzMKXNc8ufICOFW7LZefY1WgL7GytMbbMev0RwTm9MrYNzFC6a8VkiL6vonFuNkWPp8B9_4a0Nevso0)

Podemos ver que há muitos clientes com poucas compras e alguns poucos com muitas compras, claramente assimétrica a distribuição de invoices pelos consumidores. Podemos ver o comportamento pelo histograma também:

![img](https://lh5.googleusercontent.com/8c9MS4D0rjo_4JSgR_Spkz3Cv-qTLcuhoQWyBU9UQysPDFmAsBpxt8GwoX3spWmcPP-ly6fLmVC2DhzG7ypuDwRCQyBp9NQhuOUkv2fV8CWEXKEtp2IEtFQ0WZGT_-n1wdyLNj_8MIvlLOJvVCDoYkg)

![img](https://lh5.googleusercontent.com/fC2sWS117zIeIHu2mJI_Fmf5hLbooSmpgq4Y_Th9Fhjd7BUhvdOb2_SomkPw_7t1D42oiCG9a_VvNpcj7-N7wyuOMUbXZKogAdb6sWeu-ycaKDnAV__xiRA54DkCQo1DSxuI6pBxgung05tlwxIBJc4)

É bem sutil, mas note que existem consumidores com 50, 100 e até 200 compras. Mas a maioria se encontra entre 0 e 5 compras.

Bom, agora podemos finalmente avançar para a cohort, já sabendo que podemos esperar pouca retenção. Lembra que a cohort é uma análise feita para verificar a retenção de clientes. No nosso caso, vamos identificar os clientes que seguem 

realizando compras mensalmente. Sendo assim, o agrupamento será pela chave de identificação do cliente, a chave de identificação da compra e a data da compra:

![img](https://lh6.googleusercontent.com/_dddGeJ5H6SxP9rSj9jko8Z7x94qth1BoXx3v7xVb7fZiIeblO76k3n-Wcm-8F4LrAyDPBWa3hyzNI9BR7PeGVNuxHy4oDOjFSvo4yS_cYktX8_bK9pG0qs4TL0AeQYxwlgJL4ur-cSSOJkjeP4p72E)

Tendo feito essa limpeza inicial, vamos começar a organizar nossas cohorts. Como faremos cohorts mensais, precisaremos identificar os meses em que o cliente fez compras. Sendo assim, vamos criar um campo para o mês da compra:

![img](https://lh6.googleusercontent.com/Jcyj8FnT1zZTRjHbMDl3JjTsMJMDwl_5o3oNUPtnKYy6iZoWYtyv5fuFURi0Utd2j1Z5wjk-_VIcTPrGmCphkVyzOIleky4mS9Pgrf-3YybDKPTY6GwvJbabDlobvjbVW8A6wkWILwK1reH-I95GYDM)

Além disso, precisamos das datas das cohorts. A cohort de cada cliente se inicia no mês em que ele entrou na base da empresa como um consumidor, ou seja, na primeira compra:

![img](https://lh3.googleusercontent.com/i3HRc60ovISQcGL9XLnWo9aVAfscnSdRnDpPghDUzv3AjeGQz4SZ4Rop3ar_OtAkedW9cBT-iTH2cWePe_0Moj19lzsfA48e82OQDgoaudKkb-M8V_CfxyVKC0ci57xvoWlKJaviwBHp8FhRc6Y0UWc)

Utilizamos o transform() para criar a menor data de compra para cada cliente sem perder a estrutura original dos dados. Se não tivéssemos incluído o transform(), os dados ficariam agrupados como na visão do groupby. Depois de pegar a menor data, precisamos pegar o ano e mês dela, pois essa é a cohort. Caso contrário, não conseguiríamos colocar numa mesma cohort todos os clientes, cada um ficaria num dia diferente. Para visualizar melhor o que foi feito, podemos rodar retail.head() e exibir as primeiras linhas do dataset:

![img](https://lh6.googleusercontent.com/4zyVLsbYptU2YWu4vJxnoNX3SpnTJitBYB8ixc2iVyGg-nQ1Kgf_qtqqQmPni6CXbHe7gtNzZ6jfu-mImwi3iAQZk96DU7KIpP7siaiXIpiPMWPGgR_YHKgm3XddtgyUDnKhNS1mBNL7G1OpU7_glIw)

Note que o consumidor com a chave 17850.0 entrou na cohort de dezembro/2010, mas teve duas compras em 01/12/2010. Essas duas compras não nos importam muito, nós precisamos apenas saber que ele estava nessa cohort e identificar em quais outros momentos ele aparece. 

O que a gente precisa fazer, no fim das contas, é contar quantos consumidores aparecem no início de cada cohort e quantos deles estão nos meses seguintes. Façamos o seguinte então: vamos agrupar por cohort e por mes de Invoice:

![img](https://lh5.googleusercontent.com/Xp5goQtEhb3-RrlilmNyR-oFQa_X2bVUi6_XPeuGX-3YnD39_FcCCQh8MeXbBp3ug5jrF-VoPozfBEp9QjZ4d0wfqGFHuesCPt_PdXBxQn1VJVjrT0OoRofNU628onhZ9FoQm8-ZsmKrptTxQmPn0xc)

![img](https://lh6.googleusercontent.com/0y9---DQyTbCh5u92eXhcgKFmbVLqmfSoQPhwVIRAbvaPMGl99GIq6JdMUJmeelOWpPy71SpgBz3zPYetfUypgFVv5uJW49p7GvBMEFK-MKZvQpdIOYcIZLIrUxRESy1_HmowqbDU8VkVdAgyM8KUXw)

Repare que boa parte da análise já está resolvida, temos todas as cohorts e sabemos quantos clientes permaneceram nos meses seguintes a suas entradas. Para facilitar a construção da matriz, vamos criar uma coluna com a numeração de cada período após o início da cohort. Por exemplo, se a cohort se iniciou em dezembro de 2010, o mês de janeiro de 2011 será o número 1, enquanto fevereiro será o 2 e assim em diante:

![img](https://lh5.googleusercontent.com/cNOV-culbCORtRNgq8apFbF2Wzc6nUx01H2aHFOeOo6t081tYujpGecO6_DABQ5KvfPyHQU9J_b4KxX3MyZNS25mUH8G91CZDIA7KB1DgR1zvkXracO4n3V9aUBEAJs4aLiOnUBCMJVIqPf4SpWWnN4)

![img](https://lh6.googleusercontent.com/4bInbFrP5uBjO6zdwwh4t6uiY3yKaV2MQ3Q2P6SMpvrmYweq-xdbp2iSiPdGzF2HfWdbwXjKCYCPw3dhWnBtuYHnyUty0c2Ws3AyQT4RBfc3vsUm1cIdXbDndIxSz78oheViyGaXALMXijMGWSzFD28)

Se você é usuário de Excel já sacou qual a solução aqui: usar uma tabela dinâmica! Ou, do inglês, uma pivot_table:

![img](https://lh4.googleusercontent.com/TTxD6inXLU3PZmLVEkixI59Ovf78fbYJwlxPyY8OzIrcxw2jL0JkVyEkszz2AwvraOLtliLQHpuueyP3T93MaAEQ4PV9WLtb_2IgHFO16pehjeWGVyskFYZ2-Xxzep04LtaMQvPh_YwzduYZsSRSV7Q)

![img](https://lh5.googleusercontent.com/Zdk0s3-rHpz-Wrpk59mL_sMkBs-yhI4tIYQjX3BHopwgizxq5YxE9ckaq9JUOzTL14ibYkXNP1VslVAcfc1dPQ165dzP2SMgGTGCE5qfnnZUEX6zjC1siveAt3URMPOjIB4F5OHPNW_IFNeKug3SpE8)

Se você não entendeu o funcionamento da Pivot Table, dê uma olhada neste tutorial: https://www.vooo.pro/insights/pivot-table-em-pandas-explicado/

Agora, estamos perto de finalizar, o que falta solucionar é: colocar os valores em percentual e criar um mapa de calor com os percentuais obtidos!

Pode ignorar o NaN por enquanto, vamos ver como pegar os percentuais que queremos. O que precisamos é simples, pegar os primeiros valores, localizados na primeira coluna e depois aplicá-los numa divisão como denominador da respectiva coluna. Para pegar os valores da primeira coluna, utilizaremos o iloc:

![img](https://lh3.googleusercontent.com/SDqVxZKHHvjBSe5tY5OKARSdZxjVCDGn5MWy3K2vP6C_uAVFicJhKfcqy0QInCXxnvQ8w8SJgaOvri7rVr_cNsci-Oa2rnpKMFDYlizc3e_1F7wEs8jLgeYiMTo7dr81i31DlB1QplBInrJMvvYFpKI)

![img](https://lh4.googleusercontent.com/kPWTJuaTjakpIB-gMBK6TvPm5ELgNlrIl2AmtPBdIXa7yEsCS6frFkkIUiXM0vS20zz8ZmQMfr0KZ4OCUcvIJ2ec2LVGmryrlrl5fm9XmTvGIa1yiI3nk9RDamAC1XLT9ZKKd_FWnS2bUjSJsj8ReCg)

Primeiro passo feito com sucesso, sobrou fazer a divisão dos números das outras colunas pelo valor da primeira coluna de sua linha. Para isso, podemos aplicar o método divide do próprio Pandas e especificar que utilizaremos a divisão pelos valores da mesma linha, ou seja, incluímos o parâmetro axis=0:

![img](https://lh6.googleusercontent.com/j7Ss_9dHfgurai4P60xi10136ka-PHXaypLaqqxH0DNw_vo2BMbG54LAg0DbGla1W7hNpmN6GQjk9_c-P_inWggtLwnrnKhgz02yVDasIJexvolP3stlVrFpIgI6WtBmp-PEClTXDzFISgtzTKoLxjE)

![img](https://lh4.googleusercontent.com/baivFrrgyVxlC-vdmymrrjr2PbqDg3BR4hibC4NQlTy3zzjhK6L7aRF1_kXro9IXlkrfod7y7AFjXc4s1MsmYwbPYa6-8yyc6CnVTd6I_4NlfDiTcPs_BUnQby888QGFUFpF_PGa4FzsUVUYFTYgJfQ)

Para fechar, vamos construir finalmente construir nosso mapa de calor final:

![img](https://lh6.googleusercontent.com/skeIRBAjYTiu-Qph8x6qVVJ2xP5QtKHOUFwYO_BYhxLVfn4QMjK9G6dXbxuOetjhzmU2FDout_0yLmLV0jqThWRD8Q2OaGOj-Tic86EVDix05kflvj3hsQ1lHeCDoi4A3jIrBzPbWnQxZFs2UAL8ZoA)

![img](https://lh4.googleusercontent.com/vPHrGvPzFf7jugTRlwacNFg18L3O5X-NB8aUpiIfueB3NiaQR_xgXk33FeBoXylTWYz7oSF-PiDWQ6bi1Wz_x41sHfSX2mjlO3SxmAE2I019kuE2gJoDrGcBJZ6QLS68XNbiBQt3zr4vJ9naXN1e-2E)

Para fechar, vamos entender passo a passo de como a matriz foi gerada:

O código em Python acima cria um gráfico de heatmap utilizando a biblioteca Seaborn e Matplotlib. Vamos analisar em detalhes cada parte do código:

- **_ = plt.subplots(figsize=(12, 8)):** Cria uma figura com uma única plotagem (subplot) com tamanho de 12 por 8. O resultado é atribuído a uma variável não utilizada `_`, indicando que não estamos interessados no retorno específico dessa função. Em outras palavras, o underline colocado aqui e no restante do código vai evitar aqueles textos que costumam sair junto com o desenho do gráfico. Poderíamos utilizar ';' no fim da linha, mas eu me acostumei com este método porque o método de ponto-e-vírgula é retirado quando usamos %load_ext nb_black, que é um método que eu uso muito para ajustar a formatação do código.

- _ = sns.heatmap(...): 

  Cria um heatmap utilizando o Seaborn, cujos parâmetros são:

  - **data = retention_matrix:** Especifica os dados a serem plotados, neste caso, a matriz de retenção retention_matrix.
  - **mask = retention_matrix.isnull():** Mascara os valores nulos na matriz, ou seja, oculta as células que possuem valores nulos.
  - **annot = True:** Adiciona anotações (valores) nas células do heatmap.
  - **fmt = '.0%':** Formata as anotações para exibirem como porcentagem sem casas decimais.
  - **cmap = 'RdYlGn':** Define a paleta de cores utilizada no heatmap, neste caso, a paleta "RdYlGn", abreviação de RedYellowGreen (vermelho, amarelo, verde).

- **_ = plt.title('Matriz de Retenção', size=14):** Define o título do gráfico como "Matriz de Retenção" com tamanho de fonte de 14.

Agora, ficou fácil de você acompanhar como anda a entrada e saída de clientes. Normalmente, os produtos possuem um certo padrão, então você vai acabar vendo valores parecidos para a saída de clientes. Se você identificar alguma anomalia, pode ser evidência de algum evento anormal acontecendo no período. 

Quem quiser testar a análise Cohort com os dados que utilizamos no RFV: https://www.kaggle.com/datasets/carrie1/ecommerce-data

A análise RFV foi feita na semana 11, caso você tenha pulado o material. O código completo também se encontra no Kaggle: https://www.kaggle.com/code/andreyukio/rfv-analise-pt-br