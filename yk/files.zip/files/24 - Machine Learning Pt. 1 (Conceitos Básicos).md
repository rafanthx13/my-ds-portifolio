## Semana 24: Machine Learning Pt. 1 (Conceitos Básicos)



Não é a primeira vez que falamos de Machine Learning por aqui. Nós já tivemos encontros cobrindo Gradiente Descendente e Regressão Linear, também já explicamos o que é um modelo e passamos por alguns de seus conceitos básicos nas semanas 2 e 3. Agora, é hora de fazer um apanhado geral por tudo que precisamos saber na hora de fazer um modelo de Machine Learning! Vamos aprender TODOS os conceitos essenciais e não deixaremos passar nada, é hora de matar esses conceitos de uma vez por todas!



## O que é um modelo?

Um modelo de Machine Learning, que também chamamos de modelo preditivo (porque serve para, claro, predizer/prever algo) é uma representação matemática que busca capturar os padrões e relações presentes nos dados para realizar previsões. Ou seja, o que a gente faz, na prática, é olhar para um grupo de dados, entender os padrões que existem ali e, a partir disso, conseguir fazer previsões. Esses modelos são criados a partir de algoritmos e técnicas de aprendizado de máquina.

Parece besta entender esta parte, mas é essencial para quando você estiver no mercado criando seus próprios modelos. Por exemplo, imagine que você acabou de entrar numa empresa de aluguel de imóveis. Vocês criaram a empresa e saíram coletando dados do mercado. A partir disso, você quer prever os preços dos aluguéis dos apartamentos que vocês conseguiram cadastrar. Veja, você só vai conseguir decidir um preço legal com Machine Learning se nos dados que vocês coletaram tiver informações suficientes para isso. Se vocês tiverem apenas 50 imóveis no dataset, entre casas, studios, kitnets, de diferentes tamanhos e perfis, talvez você não consiga encontrar as relações que você procura. Não entendeu? Espera que vai ficar claro!

Imagina que você tem 10 alunos na sua base de dados e você sabe quantas horas por dia cada um estuda. Você não vai conseguir prever a nota deles no vestibular a partir disso. Provavelmente, vão ter 3-4 alunos que estudam o mesmo número de horas, mas possuem notas muito distintas. Claro, há outras coisas influenciando, como a situação familiar de cada um, o nível da escola, a carga horária por disciplina. Mesmo se você tiver todas essas informações, fica difícil fazer uma previsão. Imagina que vai ter um aluno que estudou 5 horas por semana, mora numa família estruturada, estudou num colégio bom e estuda 10h/semana matemática. Suponha que este aluno tirou 90 no vestibular. Aí tem outro que estuda 2 horas por semana, mora numa família desestruturada, estuda num colégio ruim e estuda 4h/semana matemática. Se chegar alguém que estuda 5 horas por semana, mas mora numa família desestruturada e estuda num colégio bom, você não vai conseguir desenhar este perfil, certo? Afinal, você só tem ali poucas combinações, é difícil quando elas se misturam.

Isso para mostrar que muitas vezes é necessário tanto um número razoável de features, quanto um número razoável de observações. Ah e tudo depende também da complexidade do problema. Prever que o Palmeiras vai ganhar uma partida é fácil, prever o preço de uma criptomoeda é difícil. Cada evento possui sua complexidade, o que pode demandar mais, ou menos dados ou observações. 

É importante também entender como é a construção de um modelo. Veja, você olha o que aconteceu no passado e, a partir daquele desenho, vai projetar o futuro. Ou seja, imagina que você quer saber como vai ser a demanda de produtos do seu supermercado se vocês investissem 100 mil reais em marketing. Entretanto, vocês historicamente SEMPRE investiram 50 mil reais. Ora, se não teve NENHUMA oscilação no investimento, como você vai saber o quanto que variar esse valor vai impactar na demanda? Pois é, você não vai saber... ao menos, não com as técnicas que estamos lidando aqui.

Imagine que você trabalhe em recursos humanos. Você precisa fazer propostas salariais para os candidatos e decide fazer isso com Machine Learning. A ideia é simples, encontrar a relação entre anos de experiência e salário. Veja, a gente sabe que no mundo real isso seria impossível, já que o salário é definido por várias outras variáveis. A questão aqui é apenas uma simplificação. Bom, você roda um modelo chamado de Regressão Linear e obtém o seguinte:

![img](https://api-club.hotmart.com/file/public/v5/files/1df9ba0e-db9a-4a81-8499-f436c167c035)

A regressão linear encontrou um padrão entre anos de experiência e salário que é dado pela seguinte equação:

salario (anual) = 500 + 10000 * anos de experiencia

Veja o que o modelo faz: ele olha para o que temos de histórico e encontra um padrão. A partir desse padrão, quando tivermos novos dados, poderemos fazer previsão:

\- Se chegar um candidato com 10 anos de experiência, ofereceríamos um salário anual de 100.500 reais. Isso porque salario = 500 + 10.000*100 = 100500

\- Já para um candidato com 3.5 anos de experiência, ofereceríamos um salário anual de 35.500 reais. Novamente, porque salario = 500+10.000*3.5 = 35500

O salário aqui é o que chamamos de target e os anos de experiência é a feature. Poderíamos desenhar um problema diferente onde tentamos definir o salário a partir de anos de experiência, curso de graduação, se tem mestrado ou não, se tem doutorado ou não, número de demissões e idade. Neste caso, temos 6 features, sendo que:

\- Três são numéricas: anos de experiência, número de demissões e idade.

\- Uma é categórica com diversos valores possíveis: curso de graduação.

\- Duas são categóricas com 2 valores possíveis, sim e não. Essas costumam ser representadas nos dados como dummy, 0 ou 1. Neste caso, 0 é utilizado para NÃO, 1 utilizado para SIM. É importante assimilar essa informação, pois ela vem da programação, onde 0 é false (falso), 1 é true (verdadeiro).

Bom, agora você já tem bastante contexto e sabe como um modelo

##  

## Como um modelo funciona? 

Como eu te disse, cada algoritmo funciona de uma forma, sendo que nem sempre encontraremos uma equação linear, como no caso demonstrado acima com anos de experiência e salário. Entretanto, há algo em comum nos diferentes algoritmos existentes, pelo menos nesses que possuem um target: a função perda (loss function. 

Primeiro de tudo, volte para a reta lá do começo do material. Você notou que ela não passa por todos os pontos?

Claro que não, é impossível encontrar uma reta que defina certinho a relação entre anos de experiência e salário. Mas não é apenas uma reta que é impossível de definir essa relação. Não importa qual modelo a gente use, e qual relação features x target estejam sendo investigadas, é impossível achar um modelo que acerte tudo. Afinal, no mundo real existem outliers, existem observações que fogem à regra. Ter faculdade ajuda a ganhar um salário maior, mas há pessoas que possuem um bom diploma e não são bem remuneradas. Treinar bastante vai trazer músculos, mas há pessoas que treinam corretamente, mas têm menos músculos do que o esperado. No mundo real, a gente consegue identificar um comportamento médio, algo para prever próximo do que vai acontecer, mas a gente não consegue acertar 100%. Tenha isso em mente!

Agora, pense comigo, qual o objetivo de um modelo que quer prever corretamente? Não seria acertar o máximo possível das previsões?

Ora, se eles precisam acertar, isso quer dizer que nosso modelo vai tentar encontrar padrões que correspondam à relação entre features e target, que chegue perto disso. Posto de outra forma, nosso modelo vai tentar **errar o mínimo possível**. Falando de forma mais formal, o nosso modelo tenta minimizar o que chamamos de **loss function, ou função perda.**

**
**

**O QUE SÃO LOSS FUNCTIONS?**

As loss functions são funções matemáticas que medem a diferença entre as previsões feitas pelo modelo e os rótulos reais dos dados de treinamento. Uai, mas você pode estar pensando assim: "como assim medir o erro, é só olhar o que foi previsto e o que aconteceu, tirar a diferença e já era".

Não é bem assim! Imagine que o modelo fosse escolhido sem função coisa nenhuma, só verificasse a diferença entre o que foi previsto pelo modelo e o que aconteceu. Vamos voltar ao nosso modelo de salário, mas agora ignore os dados que tínhamos na seção anterior. Vamos imaginar que estamos construindo um modelo daquele tipo, para prever salário com base nos anos de experiência, mas o Python está treinando o modelo, verificando várias retas possíveis para decidir qual a melhor. Em certo momento, ele chega na equação abaixo:

(1) salario (anual) = 500 + 10000 * anos de experiencia

No seu histórico, as seguintes observações estão sendo usadas para treinamento, onde S é salário e A é anos de experiência:

A: 1, S: 11.000

A: 2, S: 20.000

A: 2.9, S: 30.000

A: 5.5, S: 55.000

Vamos fazer as previsões com a reta encontrada:

Modelo 1: 10.500, 20.500, 29.500, 55.500. 

Erro do Modelo 1: (11.000-10.500)+(20.000-20.500)+(30.000-29.500)+(55.000-55.500) = 0

Ora, seu modelo está perfeito! Não precisamos mais procurar outro, pois ele acertou todos os pontos! Está correto isso? Acertamos tudo?

Você deve ter notado que não. Este é o problema de apenas olhar a diferença da previsão para o que aconteceu, nem sempre isso vai nos dar uma dimensão do que está acontecendo. Não acredita? Vamos para um novo exemplo!

Agora, estamos construindo um modelo para prever se uma operação é ou não uma fraude. Entretanto, no seu histórico, você tem 99% de operações regulares e somente 1% sendo fraude. Imagine que você construiu um modelo que diz que tudo é regular. Mais uma vez, vamos apenas comparar o que aconteceu com o que o modelo previu?

Opa, seu modelo teve 99% de acertos, afinal, ele disse que tudo está regular e no histórico temos 99% das observações sendo regulares!

Mais uma vez, não é verdade que chegamos ao melhor modelo. Neste caso, o que a gente precisa é justamente prever as fraudes. De que adianta um modelo que diz que tudo é regular?

É por isso que precisamos da **loss function**! Essas funções realmente nos dão uma dimensão da qualidade dos modelos!

A escolha da loss function depende do tipo de problema que está sendo abordado. Existem diferentes tipos de loss functions, como a função de erro quadrático médio (mean squared error, MSE) para problemas de regressão, a função de entropia cruzada (cross-entropy) para problemas de classificação binária ou multiclasse, entre outras.

O objetivo é minimizar a loss function durante o treinamento, ajustando os parâmetros do modelo de maneira a tornar as previsões cada vez mais precisas. No fundo, é quase como se estivéssemos realmente fazendo a comparação do que aconteceu com o que o modelo previu, só que a gente faz de maneira inteligente.

Um exemplo fácil antes de avançarmos: lembra que a diferença entre o que nosso modelo previu com o que aconteceu não funcionou para a regressão?

Isso pode ser resolvido se elevarmos ao quadrado, neste caso, não teremos valores negativos:

Soma dos quadrados: (11.000-10.500)^2+(20.000-20.500)^2+(30.000-29.500)^2+(55.000-55.500)^2 

O único problema isso resultaria em 1.000.000, um valor muito alto, já que tudo foi elevado ao quadrado. Sendo assim, uma coisa que fazemos para trazer de volta para a mesma grandeza é aplicar a raiz quadrada. E como a gente quer ter um senso da MÉDIA dos erros, a gente precisa dividir pelo número de observações. Afinal, a raiz de 1000000 é o erro de todos somados, mas a gente quer um "erro médio". Essa conta que eu acabei de descrever, onde tiramos as diferenças, elevamos ao quadrado e dividimos pelo número de observações é uma loss function famosa para regressões, chama-se MEAN SQUARED ERROR:

![img](https://api-club.hotmart.com/file/public/v5/files/07351bb9-8c00-415b-a6d0-23a08aca1bde)

Ei, nada de se assustar com as notações, ein!?

Veja, o símbolo que temos ali é o da somatória que vai de i até n. Ou seja, a gente vai pegar cada diferença de valor observado e predito, elevado ao quadrado e ir somando, da observação 1 até a observação n (a última). Depois, dividimos por n, exatamente como fizemos no nosso exemplo!



## Como construímos um modelo na vida real?

Imagino que tudo o que foi dito acima já seja suficiente para te dar um norte de como construir um modelo na vida real. De qualquer forma, vamos tentar estruturar este pensamento? Bora ordenar isso tudo?

**1.** **Comece definindo o problema****:** Para muitos, isso ou parece bobagem, ou eles sequer notam a importância desta parte. Compreender claramente qual é o objetivo da modelagem preditiva e o que será feito é essencial. Por exemplo, se seu chefe quer muito definir um preço que maximize o lucro, isso significa que temos um trabalho 100% preditivo, focando em acertar qual o preço independente do quanto de interpretabilidade for necessária. Agora, se você estiver fazendo um modelo de riscos, que precisa obedecer a normas de um órgão regulador, aí a história é outra e talvez você precise de um modelo cujos coeficientes sejam claros. Coeficientes, aqui, significa o peso de cada feature, quanto cada uma impacta. Você aprenderá no futuro que isso é mais claro em alguns modelos do que em outros.

Mas, veja, isso não é tudo. É importante entender o que está sendo feito, pois a vida real não é o Kaggle, as variáveis não estão prontas. Se eu te disser: queremos prever a probabilidade de alguém comprar nosso produto, você saberia como construir essa base?

Se você já foi afobado dizer que sim, eu posso afirmar que você já errou. Afinal, para construir isso, precisamos saber a probabilidade de comprar em um certo período de tempo. Precisamos saber se é para prever a chance de compra nos próximos 7 dias, ou nos próximos 30 dias. Isso vai ser importante, afinal, você vai ter que montar uma base de dados pegando a compra do cliente e o que ele fez nos últimos X dias, podendo esse X ser 7, ou ser 30. Entende meu ponto?

Vamos olhar um outro problema de desenho: você trabalha no Ebay e quer fazer um modelo para prever se um produto será vendido num leilão. Sem pensar muito no problema, você sai juntando dados dos últimos 6 meses. Você coleta dados de todos os leilões, o target é se o produto foi vendido ou não, bem simples, vai ter uma coluna marcando 1, para quando foi vendido, e 0, para quando não foi vendido. Você começa a levantar as informações dos leilões, para usar como features, coisas como tipo de produto, preço de abertura do leilão, número de clientes cadastrados naquela categoria do produto, dias que o produto levou para ser lançado e custo do frete. Só que tem um problema, a ideia de ter um modelo de previsão de venda é para saber como recomendar o produto. A ideia de seu chefe é que no momento que o produto for lançado, ele seja divulgado na página inicial, a depender da chance ser alta ou baixa dele vender. Agora, imagine o seguinte, você criou o modelo, aí chegou um produto e ele vai ser colocado no modelo em produção para calcular a probabilidade de venda, de repente: ERROR! Ora, como o modelo vai rodar, se no momento do lançamento, você não tem nem o número de dias que levou para vender, nem o custo do frete? Temos um problema e só fomos perceber depois de muito tempo perdido trabalhando, que pena...

Então guarde este item: você precisa saber o que você quer prever e como o modelo vai funcionar!

**2. Coletar e preparar os dados:** Obter os dados relevantes e realizar preprocessamentos, como limpeza, tratamento de valores missing, normalização e codificação de variáveis categóricas. Tratar os dados é importantíssimo! 

Imagine que você tem um algoritmo que pega os valores das features e observa a distância delas, um algoritmo que verifica quais pontos estão mais próximos. Veja, se o algoritmo depende de distância, ele vai olhar a distância de alguém com 60 quilos para alguém com 61 quilos e vai achar muito maior que a distância de alguém com 1,50m para alguém com 1,90m. Afinal, no peso, a distância é de 1. Na altura, a distância é de só 0,5. Poxa, mas é muito óbvio para nós que alguém de 1,90m está muito mais distante de alguém com 1,50m do que alguém de 60k estaria de alguém com 61kg. O problema foi a grandeza das variáveis! Mais uma coisa que você vai ter que aprender a lidar! Mas não esquenta não, isso é coisa para o futuro. Nem todos algoritmos são impactados pela grandeza das variáveis, é apenas para dizer que você precisa coletar e tratar os dados.

**3. Separe um pedacinho para validar seu modelo:** Vamos imaginar que você tem dados de janeiro a julho. Estamos na primeira semana de agosto e você está construindo um modelo. Nisso, você usou todos os dados para treinar o modelo. Como a gente sabe que este modelo está bom? Como você garante que o que ele aprendeu vai funcionar em novos dados? Acertou, você não sabe! Pelo menos, não se usar todos os dados para construir o modelo!

Sempre que criamos um modelo, a gente pega nosso dataset e separa um pedacinho para validar o modelo. Este pedaço é chamado de **dados de teste**. Ele simula os dados que teremos quando o modelo estiver **em produção - este é o termo que usamos para dizer que o modelo está em funcionamento. os dados de teste são uma simulação de dados no mundo real, ou seja, você não pode usar nenhuma informação deles durante o treino do seu modelo!** Por isso, nós não encostamos nesses dados antes do momento de validar o modelo!

**
**![img](https://api-club.hotmart.com/file/public/v5/files/44a6e4f5-2b53-4c51-9f07-64ee4ea97342)

Fonte da imagem: [https://maquinasqueaprendem.com/2020/04/13/overfitting-desafio-capital-para-aprendizagem-de-maquina/](https://maquinasqueaprendem.com/2020/04/13/overfitting-desafio-capital-para-aprendizagem-de-maquina/)

Às vezes, nós ainda fazemos mais uma separação, a gente pega os dados de treino e separa em treino e validação, só para garantir que quando a gente ficar indo e vindo na construção do modelo - você vai ver que a gente constrói, teste, vê se está bom, aí volta e mexe, aí teste de novo, etc. Sendo assim, esta etapa 3 você pode gravar como sendo o momento de separar os dados em conjuntos de treinamento, validação e teste. O conjunto de treinamento é usado para ajustar os parâmetros do modelo, o conjunto de validação é usado para ajustar hiperparâmetros e tomar decisões de modelagem, e o conjunto de teste é usado para avaliar o desempenho final do modelo. Mais para frente explico melhor os conceitos de parâmetros e hiperparâmetros, entenda-os como sendo a construção do modelo por enquanto.

![img](https://api-club.hotmart.com/file/public/v5/files/9b6b71f5-edfc-48c3-b329-86d233e844b3)

Fonte da imagem: [https://stanford.edu/~shervine/l/pt/teaching/cs-229/dicas-truques-aprendizado-maquina](https://stanford.edu/~shervine/l/pt/teaching/cs-229/dicas-truques-aprendizado-maquina)

**4. Escolher um algoritmo/modelo:** Uma vez que já separamos os dados, vamos escolher um algoritmo e aplicá-lo! No primeiro exemplo do material, demonstrei como funciona uma regressão linear, que nada mais é do que um modelo que busca uma reta que passa o mais próximo possível de todos os pontos. Existem diversos outros algoritmos disponíveis, inclusive já vistos nesses materiais, como a árvore de decisão e o k-means. Que tal dar uma revisitada neles?

**5. Treinar o modelo:** Uma vez escolhido o modelo, é hora de fazer o treinamento. Lembra de como vai funcionar, certo? Ele vai buscar os parâmetros que minimizam a função perda! Os parâmetros seriam como os coeficientes da equação que nós demonstramos no início do material, no problema do RH. 

**6. Validar e ajustar o modelo:** Avaliar o desempenho do modelo usando o conjunto de validação. Se necessário, realizar ajustes nos hiperparâmetros do modelo, como taxa de aprendizado, número de camadas, regularização, etc., para obter melhores resultados.

**7. Avaliar o modelo final:** Após o ajuste final do modelo, avaliar o desempenho usando o conjunto de teste. Métricas como acurácia, precisão, recall, F1-score ou erro médio quadrático podem ser usadas, dependendo do tipo de problema.

**8. Implantação e monitoramento:** Implementar o modelo em um ambiente de produção e monitorar seu desempenho ao longo do tempo. Reavaliar e reajustar o modelo periodicamente conforme novos dados se tornam disponíveis.



## Data Leakage

Data leakage ocorre quando informações do conjunto de dados de teste ou validação vazam para o conjunto de treinamento durante o pré-processamento ou modelagem, ou quando informações do target vazam para as features. Nessas situações, o que vai acontecer é que você vai ver um modelo muito bom, mas isso será ilusório, pois o seu modelo "roubou" para ter o resultado bom. Veja, se as features possuem informação do target, então é fácil prever o target com elas. Já quando o teste/validação possui informação dos dados de treino, na hora de realizar a validação, seu modelo vai performar super bem, já que os dados de teste não estão funcionando como dados nunca vistos, pois foram usados no treinamento.

Para evitar o data leakage, é importante seguir práticas como:

1. Dividir os dados em conjuntos de treinamento, validação e teste antes de qualquer pré-processamento. Eu sei que ainda não estamos praticando, nem colocando a mão na massa nesse material, mas eu quero que você faça uma nota bem grande no seu material, ou cole um post it na tela do seu notebook, escrito: 
   1. **NÃO SE APLICA ENCODER, INPUT DE MISSING OU SCALER ANTES DA DIVISÃO EM TREINO/TESTE.**
   2. **APLICAMOS FIT_TRANSFORM NO TREINO E APENAS TRANSFORM NO TESTE.**
   3. **SE EU PREENCHER O MISSING NOS DADOS DE TREINO, EU DEVO USAR A MÉDIA DA COLUNA DE TREINO. SE EU FOR PREENCHER O MISSING NOS DADOS DE TESTE, EU VOU USAR TAMBÉM A MÉDIA DO TREINO!
      **
      Semana que vem, veremos um modelo de Machine Learning na prática e explicarei tudo isso! Pode me cobrar!
2. Aplicar o pré-processamento apenas nos dados de treinamento e, em seguida, usar as mesmas transformações nos dados de validação e teste. Isso é basicamente continuação do que eu disse em (1).
3. Evitar usar informações do conjunto de validação ou teste para tomar decisões de modelagem, como ajuste de hiperparâmetros. Novamente, você terá que guardar isso para quando colocarmos a mão na massa.
4. Tomar cuidado com a construção das features e do target. Imagine o seguinte, você trabalha no Ebay e deseja prever se um leilão terá sucesso ou não. Você decide construir o dataset, ou seja, pega dados de leilões antigos e diversas features para cada um deles. Você levanta o preço de abertura, o tipo de produto, o dia de lançamento, o número de lances que o produto teve, dentre outras coisas. Ora, eu aposto que você teria 100% (ou 99%, 98%, algo bem alto). Afinal, se teve lance, provavelmente o produto foi vendido! Ocorreu um vazamento, pois ter lances é quase uma garantia de que o produto foi vendido. Vazamos informações da feature para o target!



## Formas de validar um modelo 

Lembra do que falamos sobre um modelo preditivo? Sobre aquele papo de "deixar um pedacinho" dos dados para verificar se um modelo está funcionando bem?

Isso é o que chamamos de **validação do modelo.** A validação de um modelo é essencial para garantir que ele vá funcionar bem no mundo real, que ele vá funcionar em produção. A gente quer que nosso modelo generalize bem o aprendizado para novos dados, quer que ele tenha realmente aprendido os padrões corretos para que acerte o máximo possível quando chegar dados novos. Existem várias técnicas de validação que vão além dessa ideia de deixar um pedaço do dataset para verificar se o modelo treinado realmente vai funcionar quando subirmos em produção, como:

**- Holdout:** Os dados são divididos em conjuntos de treinamento e teste. O modelo é treinado no conjunto de treinamento e avaliado no conjunto de teste. Existe o holdout em que dividimos os dados em treino e teste, como já explicamos anteriormente, e aquele em que dividimos em treino, validação e teste. A divisão em treino e teste geralmente é feita em 70-30% ou 80-20%, mas a escolha é subjetiva.

**- Validação cruzada (Cross-validation):** Os dados são divididos em k partes iguais. O modelo é treinado k vezes, cada vez usando k-1 partes como conjunto de treinamento e a parte restante como conjunto de teste. Os resultados são médias das métricas de desempenho obtidas em cada rodada.

![img](https://api-club.hotmart.com/file/public/v5/files/88214d52-880b-4ad3-8246-1b1953f2b362)

Fonte da imagem: [https://scikit-learn.org/stable/modules/cross_vali...](https://scikit-learn.org/stable/modules/cross_validation.html)

**- Validação cruzada estratificada:** Semelhante à validação cruzada, mas mantendo a proporção de classes ou distribuição de variáveis categóricas em cada parte, garantindo uma melhor representatividade dos dados.



**- Leave-one-out:** Uma forma especial de validação cruzada em que cada exemplo é usado como conjunto de teste uma vez, enquanto o restante é usado para treinamento. Útil para conjuntos de dados pequenos, pois, como você já deve ter imaginado, haja memória para fazer esta validação!

![img](https://api-club.hotmart.com/file/public/v5/files/9688a114-f94d-406b-b5a0-0b64ae6afa26)

Fonte da Imagem: 

Fonte da Imagem: [https://sebastianraschka.com/blog/2016/model-evalu...](https://sebastianraschka.com/blog/2016/model-evaluation-selection-part2.html)

Cada técnica tem suas vantagens e desvantagens, e a escolha depende do tamanho do conjunto de dados, do número de observações, da representatividade das amostras, entre outros fatores. Além disso, é possível combinar diferentes técnicas. Eu, por exemplo, acho suficiente utilizar cross-validation com holdout para garantir uma boa validação. É possível também deixar ainda um pedaço dos dados, uma parcela mais recente, fora de todo o processo de treino e validação, algo chamado de "out-of-time".



## Overfitting vs. Underfitting  

O overfitting e o underfitting são problemas comuns em modelos preditivos:

**Overfitting:** Ocorre quando o modelo se ajusta muito bem aos dados de treinamento, mas não consegue generalizar para novos dados. Ou seja, o modelo funciona muito bem no treino, mas na hora que testamos em novos dados, ele falha em fazer uma boa predição. É como se ele tivesse decorado os dados, mas não realmente aprendido seus padrões. O modelo se torna excessivamente complexo e captura até mesmo o ruído presente nos dados de treinamento.

Sabe aquele aluno que decorou a lista de exercícios, fez tudo certinho, mas reprovou na prova? Esse aluno "overfittou"! 

A principal forma de capturar o overfitting é na validação. Por exemplo, se o seu modelo foi muito bem no score de treino, mas foi muito mal no teste, isso é um baita indícido de overfitting! Existem formas de mitigar esse risco, além da validação, existem técnicas como a regularização que ajudam a contornar o problema. Veremos isso em materiais futuros!

**Underfitting:** É exatamente o oporto do overfitting, ou seja, ao invés de capturar todo movimento dos dados (incluindo o erro), aqui estamos falando de quando o modelo não é capaz de capturar adequadamente os padrões presentes nos dados. O modelo é muito simples e não consegue aprender com eficácia os relacionamentos nos dados de treinamento.

Neste caso, você provavelmente já observará o problema no score dos dados de treino, pois o modelo underfittado não performa bem nem nos treinos, nem na validação. Para lidar com o underfitting, pode-se considerar a seleção de um modelo mais complexo, o aumento na quantidade de features ou na melhoria dos pré-processamentos.

Veja abaixo a representação gráfica do overfitting x underfitting:

![img](https://api-club.hotmart.com/file/public/v5/files/1de5e977-be19-4728-a4f9-e58f42f11c65)

Fonte da imagem: [https://medium.com/greyatom/what-is-underfitting-and-overfitting-in-machine-learning-and-how-to-deal-with-it-6803a989c76](https://medium.com/greyatom/what-is-underfitting-and-overfitting-in-machine-learning-and-how-to-deal-with-it-6803a989c76)

Encontrar um equilíbrio entre overfitting e underfitting é um desafio e requer ajustes adequados no modelo e na estratégia de validação. A busca por este equilíbrio é o ponto chave da modelagem preditiva em Machine Learning, aqui temos o que chamamos de **TRADE-OFF VIÉS x VARIÂNCIA.**

**Viés (Bias):** O viés é a diferença entre a previsão média do nosso modelo e o valor correto que estamos tentando prever. Modelos com alto viés são muito simplificados e assumem muitas suposições sobre os dados, o que resulta em um ajuste ruim aos dados de treinamento e teste. Este é um caso típico de underfitting.

Por exemplo, se tentarmos ajustar um modelo linear simples a um conjunto de dados que é na verdade quadriculado, nosso modelo provavelmente terá um alto viés - ele está assumindo uma linearidade que simplesmente não existe nos dados.

**Variância (Variance):** A variância é a variabilidade das previsões do modelo para um dado ponto de dados. Modelos com alta variância prestam muita atenção aos dados de treinamento e não generalizam bem para os dados que não foram vistos antes. Este é um caso típico de overfitting.

![img](https://api-club.hotmart.com/file/public/v5/files/fb85f3f9-c4b9-495e-a5ad-7ebbc9459276)

Idealmente, queremos um modelo que tenha tanto o viés, quanto a variância, baixos. No entanto, você vai ver que isso é bem difícil. Se a gente aumentar muito a complexidade do modelo, temos um modelo que captura até ruídos, até variações que não são explicadas. Agora, se o modelo for simples demais, também não conseguimos prever muito bem os fenômenos existentes, que sempre possuem uma certa complexidade. Por isso, falamos de trade-off (troca) entre o viés e a variância.

Guarde isso, modelos muito simplificados, com problema de underfitting, possuem alto viés e não se ajustam bem aos dados, perdem informações relevantes no aprendizado. Já modelos muito complexos, com problema de overfitting, possuem alta variância e capturam ruídos além do necessário. Estamos sempre em busca de um equilíbrio, de um balanço, onde o modelo possui complexidade apenas suficiente para entender os padrões existentes, mas sem observar ruídos como sendo esses padrões.

Uma maneira comum de lidar com o trade-off viés-variância é usar técnicas de validação cruzada para estimar o erro de teste de um modelo, e então selecionar o modelo que minimiza este erro. Isso nos permite encontrar um bom equilíbrio entre o viés e a variância.

A fonte das duas últimas imagens acima é um bom tutorial, caso ainda não esteja claro o conceito do trade-off entre viés e variância: https://medium.com/data-hackers/o-que-é-bias-variance-tradeoff-a5bc19866e4b[](https://medium.com/data-hackers/o-que-é-bias-variance-tradeoff-a5bc19866e4b)

## Que tal verificarmos se você entendeu tudo? (Respostas no próximo material)

1) O que é um modelo de Machine Learning?

  a) Um programa de computador que aprende a jogar xadrez.

  b) Um algoritmo que analisa os padrões em um conjunto de dados e usa esses padrões para fazer previsões.

  c) Uma ferramenta que ajuda a visualizar grandes volumes de dados.

  d) Uma base de dados bem estruturada.



2) O que é um target em um modelo de Machine Learning?

  a) O resultado desejado que o modelo está tentando prever.

  b) O conjunto de dados sobre o qual o modelo está treinando.

  c) A taxa de erro aceitável para o modelo.

  d) A variável que determina a complexidade do modelo.



3) Como seria a representação dummy de uma variável categórica com dois valores possíveis, como a presença de um mestrado em um modelo que prevê salários?

  a) 1 para candidatos com mestrado, 0 para os sem mestrado.

  b) 1 para candidatos sem mestrado, 0 para os com mestrado.

  c) 1 para todos os candidatos, independentemente da presença de um mestrado.

  d) 0 para todos os candidatos, independentemente da presença de um mestrado.



4) Como a Loss Function impacta o aprendizado do modelo de Machine Learning?

5) Utilizando a equação (1) da seção Loss Functions, qual a previsão salarial de alguém com 0 anos de experiência? E com 3 anos de experiência? Ainda utilizando a mesma equação, quanto um ano de experiência adicionaria de salário anual?

6) Durante os estudos de loss function, aprendemos a mean squared error com função perda de uma regressão linear, que nada mais é do que tomar a diferença entre o que o modelo prevê e o que realmente aconteceu, elevar ao quadrado e dividir pelo número de observações. Entretanto, se o objetivo da função perda é ajudar a localizar o modelo com melhor poder preditivo, por que não podemos simplesmente tirar a diferença do que o modelo previu pelo que foi observado? Qual a necessidade de elevar ao quadrado, tirar raiz, etc?

7) Você quer construir um modelo de fraude no cadastro de uma empresa de telefonia. A ideia é pegar todos os clientes que abriram contas, mas apenas para fraudá-las no futuro. Sendo assim, você precisa descobrir na primeira semana como clientes fraudadores agem. A auditoria das contas suspeitas deve ser feita sempre 7 dias após a data de cadastro. Sendo assim, você decide construir um modelo preditivo de fraude. Você inicia com um levantamento de variáveis disponíveis no DW para construir este modelo de fraude. Discuta quais variáveis podem fazer sentido neste modelo, como você construiria este dataset, quais variáveis teriam que ser modificadas para serem usadas no seu modelo e como você as modificaria. Apesar da empresa ter vários tipos de produtos e serviços, você só se interessa pela fraude no cadastro do serviço de celular.

Fuçando o DW, você possui 4 datasets, um com as contas de todos os clientes, outro com os dados de cadastro e outro com a marcação de fraude.

Variáveis do dataset de contas (mensais): chave de cadastro do cliente, data da conta, valor da conta, data de pagamento, tipo de pagamento (cartão, débito automático, boleto, etc), tipo de conta (pré, pós, controle)

Variáveis de consumo (diárias): consumo de internet, consumo de ligações.

Variáveis do dataset de cadastro: nome, idade, chave de cadastro do cliente, CEP, data do cadastro, gênero, e-mail de cadastro, serviço contratado.

Variáveis do dataset de fraude: chave de cadastro do cliente, dummy indicando fraude (1: sim, 0: não).