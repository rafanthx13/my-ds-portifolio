# Redes Neurais Profundas

No capítulo anterior, vimos a estrutura básica de uma rede neural. Agora, vamos montar uma rede neural mais complexa, capaz de aprender relações profundas dos dados. A principal ideia é construir redes neurais complexas a partir de unidades simples (neurônios), que fizemos no capítulo anterior. Então, vamos falar um pouco mais sobre as camadas.

Como disse, redes neurais são formadas a partir de camadas de neurônios. Quando temos neurônios que compartilham os mesmos dados de entrada, temos uma camada densa. Observe o exemplo abaixo:

![img](https://api-club.hotmart.com/file/public/v5/files/3c6e2a7a-c446-49f5-b652-61a41c87b331)

Observe que os dados de entrada x0, x1 e 1 vão tanto para o neurônio azul quanto para o neurônio vermelho. Logo, como eles compartilham os mesmos dados de entrada, temos uma camada densa. Cada camada de uma rede neural faz uma certa transformação. Quando temos modelos muito complexos, com várias camadas, podemos pensar que cada uma das camadas fazem um tipo de transformação que nos aproxima cada vez mais do resultado.

Entretanto, pense o seguinte: por que teríamos duas camadas densas uma seguida da outra sendo que poderíamos apenas adicionar mais neurônios à primeira? É justamente por isso que vamos falar, agora, sobre as funções de ativação.

Note que o output que temos em cada neurônio é uma relação linear entre os pesos e os dados de entrada, correto? Dessa forma, nossa rede neural consegue apenas detectar relações lineares nos dados, o que é péssimo! Para corrigir isso, adicionamos ao final de cada neurônio uma função de ativação.

Basicamente, a função de ativação é uma função que aplicamos para cada output de cada neurônio. A função mais comum é a max(0, y). Note que quando o output for negativo, a função retornará 0. Quando for positivo, retornará o próprio valor. Observe o gráfico abaixo:

![img](https://api-club.hotmart.com/file/public/v5/files/f2f786e0-167b-446c-b886-85eb569f9a9d)

Comumente chamamos essa função de ativação de ReLU (Rectifier Linear Unit). Dessa forma, aplicando a função ReLU ao output de cada unidade linear (neurônio), podemos formar camadas mais densas que irão se diferenciar e detectar padrões não lineares. Observe a representação de um conjunto de camadas densas para fazer transformações complexas:

![img](https://api-club.hotmart.com/file/public/v5/files/2b461177-9916-467f-8cc7-66d9bdb43012)

Agora, observe dois pontos interessantes:

\1. As camadas após a de entrada (inputs) e antes da de saída (output), são as chamadas hidden layers, ou camadas escondidas. Elas têm esse nome porque não vemos seu output diretamente.

\2. Não há uma função de ativação na última camada (de output), visto que estamos lidando com um problema de regressão. Em problemas de classificação, uma outra função de ativação na última camada seria necessária.

**IMPLEMENTAÇÃO EM PYTHON**

Agora, vamos fazer a implementação do que vimos nesse capítulo em Python! Eu não vou treinar o modelo novamente, apenas construí-lo com o keras.Sequential e com o layers.Dense. Vamos reproduzir a rede neural do esquema acima em Python:

Note que temos duas camadas densas: a primeira, que recebe dois inputs (x1 e x0), possui 4 neurônios (unidades lineares) e função de ativação R

![img](https://api-club.hotmart.com/file/public/v5/files/9ffdd469-cb18-470b-ab26-0dca0d632fed)

Note que temos duas camadas densas: a primeira, que recebe dois inputs (x1 e x0), possui 4 neurônios (unidades lineares) e função de ativação ReLU. A segunda camada possui 3 unidades lineares e função de ativação ReLU em cada uma delas. Note que não temos o parâmetro input_shape a partir da primeira camada, visto que os dados de entrada (nessa arquitetura de rede neural, entra apenas na primeira camada das hidden layers. Por fim, temos a unidade linear de saída, sem função de ativação.

**TÉCNICAS PARA EVITAR OVERFITTING E UNDERFITTING**

Quando estamos estudando modelo de Machine Learning tradicionais, como Regressão Linear, Random Forests etc., volta ou outra lidamos com o overfitting / underfitting.

Para recapitular, sabemos que underfitting é quando nosso modelo não se adequa bem aos dados de treino e teste, com erros grandes nos dois conjuntos de dados e com um modelo de baixa complexidade. Já o overfitting é quando os dados se adequam de forma quase perfeita aos dados de treino e, consequentemente, de forma ruim aos dados de teste, com modelos muito complexos. No overfitting, o modelo aprende o ruído dos dados. No underfitting, ele não aprende quase nada sobre os dados. Com isso, temos uma variação do erro de forma diferente nos dados de treino e teste, observe a imagem abaixo:

![img](https://api-club.hotmart.com/file/public/v5/files/e9d9962a-403c-4f7f-8995-51009854e48d)

Aqui, você pode perceber que quando aumentamos o número de épocas durante o treinamento de um modelo, a tendência é que o erro gerado pelos dados de treino vão diminuindo e os de teste vão diminuindo até um certo ponto e depois voltam a subir. Ele volta a subir quando o modelo começa a aprender o ruído dos dados. O ponto ideal seria pararmos o treinamento do modelo quando o erro nos dados de teste fosse mínimo.

**CAPACIDADE DO MODELO**

Assim como nos modelos tradicionais, podemos ter modelos bem complexos e simples no mundo do Deep Learning. Quando falamos sobre capacidade do modelo, falamos sobre o tamanho e complexidade dos padrões que ele está hábil a aprender. No mundo do deep learning, sua complexidade basicamente se resume à quantidade de neurônios ele tem e como estão conectados. Ou seja, caso seu modelo esteja “underfittando”, você pode corrigir aumentando sua capacidade, ou seja, com mais neurônios para camadas já existentes (deixando a rede neural mais ampla) ou adicionando mais camadas a ele (deixando a rede neural mais profunda). Redes neurais mais amplas tem um tempo de aprendizado menor para relações lineares, enquanto redes neurais mais profundas têm um tempo de aprendizado menor para relações não lineares.

Abaixo, temos dois modelos com o mesmo número de unidades lineares, porém um é mais amplo e outro mais profundo:

![img](https://api-club.hotmart.com/file/public/v5/files/5a1f3bbf-e80d-447b-a1fb-6478549a1134)

**EARLY STOPPING**

Agora, vamos falar sobre Early Stopping. Vimos que o ponto ideal para interrompermos o treinamento de um modelo é quando o erro dos dados de teste é mínimo. Então, se notarmos que o erro está começando a subir novamente, podemos interromper o treinamento de forma antecipada. E é justamente isso que é o early stopping.

A partir do momento que notamos que os erros dos dados de teste estão subindo, interrompemos o treinamento e atualizamos o valor dos pesos e do viés de quando o erro foi mínimo. Então, basta colocar um número de épocas além do que você precisa e deixar que essa técnica interrompa o treinamento quando for necessário. Abaixo, está uma implementação do early stopping em Python:

![img](https://api-club.hotmart.com/file/public/v5/files/0cd51095-acaf-4f36-8b52-f3fb38a402a3)

Note que incluímos o early stopping através de um callback. Um callback é uma função que você quer executar de vez em quando durante o treinamento do modelo. No nosso caso, a early stopping irá executar uma vez a cada época.

Os parâmetros que colocamos no early stopping dizem mais ou menos o seguinte: “olha, se não tiver uma melhora de 0.001 nos erros dos dados de teste nas últimas 20 épocas, pode parar o treinamento e reestabelecer os parâmetros encontrados na melhor época.”

**DROPOUT & BATCH NORMALIZATION**

Como vocês podem imaginar, o mundo do Deep Learning é muito mais que apenas hidden layers. Na verdade, podemos ter camadas de vários tipos, como Convolucionais, LSTM, Recorrentes, Dropout e Batch Normalization. Algumas camadas fazem conexões entre neurônios, como as camadas densas que vimos até agora, outras camadas podem fazer pré processamento ou transformação de outros tipos nos dados. Nesta seção, vamos falar dos últimos dois tipos de camadas: dropout e batch normalization. Nenhuma delas possuem neurônios, porém agregam valor ao nosso modelo.

Primeiramente, vamos falar sobre a camada dropout, que ajuda muito no overfitting! Basicamente, quando nosso modelo está “overfittando” é porque temos combinações de pesos e vieses em alguns neurônios que se adequaram aos ruídos dos dados. Então, se retirarmos esses neurônios, nosso modelo tende a voltar ao “normal”, sem overfitting. E é justamente essa a ideia por trás da camada dropout: nós, de forma aleatória, retiramos um conjunto de neurônios de entrada a cada etapa do treinamento, fazendo com que torne o aprendizado de ruídos muito mais difícil. Na verdade, ao contrário de aprender ruídos, a rede neural irá aprender padrões gerais dos dados. Observe o GIF abaixo:

![img](https://api-club.hotmart.com/file/public/v5/files/276a189c-aad0-4b2a-a318-4cc8ba285fd0)

Você pode imaginar essa técnica de dropout criando uma espécie de modelo ensemble. As predições não serão feitas por uma rede neural, mas por várias redes neurais. No fim, é como se fosse uma random forest, composta por várias decision trees. Abaixo, segue uma implementação em Python:

![img](https://api-club.hotmart.com/file/public/v5/files/a6f1e552-f4f4-4464-bc47-d6f73ad5a825)

Sempre colocamos a camada de dropout antes da camada que queremos aplicar a técnica. Neste exemplo, estamos retirando 20% dos neurônios a cada etapa de treinamento.

A próxima camada especial que iremos ver faz uma normalização nos dados, como o próprio nome diz: Batch Normalization. Ela pode ajudar a deixar o treinamento mais rápido ou estável. Em redes neurais, é uma boa prática deixar todos os dados em uma mesma escala. Como o algoritmo de otimização utilizado são, geralmente, variações do Gradiente Descendente Estocástico e esse algoritmo é baseado em distância, alterar a escala dos dados pode nos ajudar bastante.

Podemos deixar os dados na mesma escala utilizando algumas bibliotecas da Scikit-learn como StandardScaler, MinMaxScaler etc. antes de iniciarmos o treinamento. Porém, também podemos normalizar os dados DURANTE o treinamento do modelo. Ou seja, adicionar uma camada que faz a normalização a cada iteração de treinamento.

Ela funciona da seguinte forma: a cada conjunto de dados que entra durante a etapa de treinamento, ele faz a normalização desses dados olhando para sua própria média e desvio padrão. Depois disso, coloca os dados em uma nova escala com dois parâmetros para refazer essa escala. Abaixo, segue um exemplo de implementação em Python:

![img](https://api-club.hotmart.com/file/public/v5/files/351578ab-728c-4d05-a1f3-bd6627ab20ed)

Note que adicionei a camada de normalização após a primeira camada densa. Porém, poderíamos adicionar essa camada de normalização como sendo a primeira camada, para normalizar os dados antes de eles “entrarem” na rede neural.

Agora, vamos fazer um exemplo de modelo com dropout e batch normalization:

![img](https://api-club.hotmart.com/file/public/v5/files/2e6f6c51-95a8-440c-a5bb-1d5e9c4a4221)

Como vocês podem ver no exemplo acima, podemos misturar as camadas da forma que julgarmos melhor para o nosso modelo. Aqui, adicionei duas camadas de normalização e 2 de dropout.

**PROBLEMAS DE CLASSIFICAÇÃO**

Até agora, vimos apenas a aplicação para problemas de regressão. Lembre-se de que nossa última camada previa um valor contínuo (layers.Dense(units = 1)). Além disso, disse que para transformar em um output condizente a um problema de classificação, bastava adicionarmos uma função de ativação nessa camada, lembra? Além disso, precisamos mudar a nossa loss function quando utilizamos o (modelo.compile()). Então, vamos começar falando sobre a função de custo (loss function) que iremos ver: cross-entropy.

Nosso objetivo em problemas de regressão é reduzir a distância entre o valor previsto e o valor real. Em problemas de classificação, utilizamos a função de custo cross-entropy para medir a distância entre a probabilidade de classe prevista e real. Observe seu gráfico e fórmula abaixo:

![img](https://api-club.hotmart.com/file/public/v5/files/ad6f71e1-d2b8-4dbd-b072-9eab258c0c79)

Aqui, yi é a classe prevista (0 ou 1) e pi é a probabilidade de saída de uma outra função. Geralmente, utilizamos duas funções: softmax ou sigmoid.

Tanto a função sigmoid quanto a softmax geram como saída um número entre 0 e 1 (probabilidade). Porém, a função sigmoid é usada para problemas de classificação binária e a softmax para problemas de classificação multiclasse. Abaixo, está o gráfico das duas funções:

![img](https://api-club.hotmart.com/file/public/v5/files/c2e7082d-e115-43d4-8830-0149643b5a7b)

Note que ambas são limitadas inferiormente por 0 e superiormente por 1. Dessa forma, nosso output sai em um formato probabilístico. Por fim, colocamos um valor limite para a probabilidade de definir cada classe. Por exemplo, podemos colocar como limite o valor 0.5 para que o exemplo seja classificado como positivo. Ou seja, todo valor de saída que for maior ou igual a 0.5 será classificado como classe 1 e todo valor que for menor que 0.5 será classificado como classe 0. Abaixo, está uma implementação em Python:

![img](https://api-club.hotmart.com/file/public/v5/files/be867fb4-059b-4154-9248-174fcfa389ea)

Agora, compilamos o modelo da seguinte forma:

![img](https://api-club.hotmart.com/file/public/v5/files/25230350-ddf4-4fff-9485-59d204090c80)

Note que adicionei como função de perda a entropia cruzada para problemas binários. Além disso, como métrica de avaliação, coloquei apenas a acurácia. Poderíamos colocar outras, como Recall, Precision, ROC AUC etc..

**MATERIAIS COMPLEMENTARES**

3Blue1Brown Neural Networks series:



<iframe width="500" height="281" src="https://www.youtube.com/embed/aircAruvnKk" frameborder="0" allowfullscreen="" style="box-sizing: border-box; -webkit-font-smoothing: antialiased; margin-bottom: 30px; position: absolute; top: 0px; bottom: 0px; left: 0px; width: 587.328px; height: 330.359px; border: 0px; max-width: 100%;"></iframe>

B-3pi



Neural Networks explained by StatQuest:



<iframe width="500" height="281" src="https://www.youtube.com/embed/zxagGtF9MeU" frameborder="0" allowfullscreen="" style="box-sizing: border-box; -webkit-font-smoothing: antialiased; margin-bottom: 30px; position: absolute; top: 0px; bottom: 0px; left: 0px; width: 587.328px; height: 330.359px; border: 0px; max-width: 100%;"></iframe>

E1



Site para manipular redes neurais (SEM CÓDIGO): [http://playground.tensorflow.org](http://playground.tensorflow.org/)