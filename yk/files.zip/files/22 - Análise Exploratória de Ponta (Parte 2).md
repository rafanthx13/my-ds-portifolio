# ANÁLISE EXPLORATÓRIA DE PONTA (PARTE 2) 

Depois de uma pausa para o conteúdo massa sobre KS, voltamos a nossas análises exploratórias. Hoje, vamos ver uma análise exploratória na prática, vamos colocar a mão na massa juntos! A ideia é implementar algumas ideias que já vimos nos outros materiais, enquanto também aproveitarei a oportunidade para trazer mais novidades ainda! Afinal, nada melhor para o aprendizado do que usando ele numa situação real!



## ESCOLHENDO O DATASET 

Para começar, é preciso escolher um dataset. Eu não vejo motivos para muita enrolação aqui, é simplesmente baixar um dataset e começar a análise, principalmente se for sua primeira ou segunda análise. Depois disso, é interessante você sair do básico, esquecer o do Titanic, o do Pokemon ou de quaisquer outros datasets populares.

Uma boa escolha é ir na Base dos Dados ou buscar algo diferente no Kaggle. Por exemplo, eu fui ao Kaggle, cliquei em datasets e, na busca, digitei "Brazil". Ali, já havia filtrado dados menos populares. Vasculhando um pouquinho, encontrei uma raspagem dos dados do site do Quinto Andar feita em Março de 2023. Ou seja, dados de um site famoso, pertencentes a um período bem recente, parece uma boa pedida! Para baixar o dataset, [clique aqui](https://www.kaggle.com/datasets/renatosn/sao-paulo-housing-prices).

![img](https://lh5.googleusercontent.com/aMBsYplF9_Nz3NShU5cwpN0521-Vbk9djrOksuv74lbm9E-nPoHTcYzBSdHZI1P6WMA1MP2INW5BNd0ZV-xPkEuxvmYyoIELKwmioN01k2sqNdJ5WNsgFN7hWPF8lLiQ-YO4VBEW_qFimBv8UpAVx98)

Também achei uma boa escolha para nós, pois vejo muitos alunos com dificuldade de extrair informações dos datasets. Geralmente, fazem uns 3-4 gráficos e travam na evolução da análise, principalmente se não tiver inúmeras colunas para brincar. Vamos ver se conseguimos bolar estratégia para nosso caso, que conta com somente 8 colunas, sendo duas delas categóricas com muitas classes, o que muitas vezes parece tornar a coluna mais descartável ainda.

Será que vai sair bastante coisa dessas 8 (ou apenas 6) colunas?



## ANÁLISE EXPLORATÓRIA NA PRÁTICA 

Agora, é hora de você começar sua análise. Se você estivesse no trabalho, provavelmente receberia uma demanda do seu gestor. Claro, aqui eu já sugiro que você não seja apenas um apertador de botão, pergunte qual o objetivo da análise e veja se cabe sugestões. Como não estamos numa empresa, há duas possibilidades aqui:

1. Você começar explorando os dados, fazendo descobertas e só depois você organizaria o jupyter de forma que o storytelling fique legal e coerente.
2. Você bolar algumas hipóteses ou perguntas a serem exploradas e já iniciar a análise atrás delas.

Cada uma tem seu ponto forte e fraco. A primeira, permite que você explore mais os dados, faça inúmeras descobertas que talvez você ainda não consiga visualizar no início. Entretanto, a organização final vai dar trabalho e pode ser que algumas análises tenham que ser excluídas para o arquivo ficar coerente. Já a segunda, apesar de facilitar o storytelling, pode acabar limitando um pouco a criação das hipóteses a serem exploradas.

De qualquer forma, vamos partir de algumas perguntas para construir nossa análise, acredito que o custo-benefício dessa estratégia seja melhor. 

Se quiser ver o Jupyter Notebook por completo, baixe o arquivo em anexo. Ali, você vai ter uma visão melhor de como ficou nossa análise.

Antes de criar as perguntas, vamos olhar nossos dados:

![img](https://lh5.googleusercontent.com/VpLWb49OUcaGAwlj1pk7rPZ8S7I7D8qmZ_nouz2UY_VGj2K0bi0a4GhRic8zpROX1PH0pyb0ymn1zj-cN-9Vhw9YMEjczUgWQ2hRUMzFlfJ2olJWklt7hWuW69BnkBz58vId32kjj2NbjM20lvuC8ww)

Olhando para os nossos dados, veja que conseguimos responder perguntas sobre o tipo de imóvel, endereço, metragem, número de quartos, garagem, aluguel e o custo total do imóvel (aluguel + outros custos):

- Quais os bairros mais caros de São Paulo? 
- Quais os bairros com os maiores apartamentos?
- Existe correlação entre tamanho do apartamento e o seu preço? E entre o número de banheiros? E o número de vagas?
- Qual a característica de cada tipo de imóvel, em relação a preço, metragem, etc.?
- O que parece influenciar a diferença entre o aluguel e o custo total? Qual característica do imóvel?

Eu aposto que a gente vai descobrir tanta coisa interessante ao longo da análise, que nem precisaríamos de todas essas perguntas. Inclusive, eu nem vou colocá-las no início do Jupyter Notebook. Vamos deixar para incluir as perguntas respondidas apenas no final da análise. Quando você fizer o seu portfólio, abra o ReadMe com um texto incluindo uma introdução e uma conclusão tipo a que vamos fazer aqui. Assim, quando alguém for ver sua análise no Github, vai ter uma ideia do contexto do problema e dos achados da análise.

Hora de botar a mão na massa e entender os nossos dados!

Daqui para frente, pense em cada seção como um pedaço do Jupyter Notebook, uma seção de nosso relatório. O que é título aqui, será título lá (usando '#' lá, para que o título se destaque). Diferente dos outros materiais, colocarei prints do Jupyter, pois quero comentar o que estamos fazendo, por que estamos fazendo e mostrar o resultado do raciocínio todo. A ideia é que você entenda as escolhas aqui feitas e saiba o que é necessário colocar numa análise. Lembre-se de que o portfólio é seu principal cartão de visitas, é ele que vai determinar se você merece ou não uma chance no processo seletivo de uma empresa.



##### SEMPRE DÊ ALGUM CONTEXTO -> INTRODUÇÃO 

Toda boa análise exploratória precisa de um trecho introdutório e aqui não será diferente! É importante você indicar para o leitor, seja ele o recrutador ou algum profissional da área, o que está sendo feito. Se a pessoa chegar lá e não tiver nada sobre o que está sendo feito, ele provavelmente vai deixar seu trabalho de lado, já que seria muito difícil de entender o que está sendo feito, o que faria aquela leitura ser apenas uma perda de tempo.

Veja como iniciamos o Jupyter Notebook de nosso estudo:

![img](https://lh5.googleusercontent.com/547L29ruWp91ZPBNmr2XPz_KgrirD0ZWQgDgmRg2xctQsUFyhmEAe9p_yaXJl74ReFF6zYzEVE2WfAevRODApWVl7gZualRUl4Srl9KKS0twJQB0fHtDugU5DbGCNtSwo372es9GSqfsqYBoQhUl6fk)

Começamos falando de uma maneira macro sobre o setor imobiliário e encerramos detalhando o que continha em nosso dataset. Quando você fizer uma análise deste tipo e for subir no Github, crie uma introdução deste tipo no ReadMe do projeto!



##### O BÁSICO DE TODO NOTEBOOK -> BIBLIOTECAS 

Comece carregando as bibliotecas principais, como Pandas, Numpy, Matplotlib, Seaborn e Plotly! As duas primeiras para tratar os dados e as 3 últimas para gráficos. Além disso, vamos configurar este notebook para não apresentar warnings, formatar automaticamente as quebras e espaçamentos (com [nb_black](https://pypi.org/project/nb-black/)), utilizar o estilo de gráfico do ggplot (com plt.style.use), configurar o notebook para exibir até 15 linhas de um dataframe do Pandas e exibir todas as colunas do Pandas.

![img](https://lh3.googleusercontent.com/dRIGfyVzfXCHmXaRm3uQYEae92j7bbaRt5HkQcFTukSPmlbafMxpsRutbY85zM9Xm7qe2l453YQJwNrvsK-BphroVT1qlT9PbnUVbireNnT2sCcq5XDRNpVg26ks3WJ07X0VdHMPV7Jrn8KWfuGFY-w)

Esta é uma das células que eu acredito que a gente possa dar uma exagerada de leve nos comentários. Existe uma boa prática de alguns programadores que diz que um bom código é autoexplicativo, não precisa de comentários. Esta é daquelas que eu concordo e não concordo. Concordo, no sentido de que o código precisa ser bom o suficiente para a pessoa ler e entender. Não concordo, no sentido de que inserir alguns comentários não me parece o fim do mundo. De qualquer forma, na célula de bibliotecas, eu sempre incluo comentários como os feitos acima. Você vai notar que no Kaggle é comum se deparar com esse estilo de célula no início de notebooks.

Boa parte dessa célula é bem óbvia, mas aqui vai uma explicação mais completa, principalmente para as últimas linhas:

- As primeiras duas linhas de código não comentadas **importam as bibliotecas pandas e numpy**. Pandas é uma biblioteca para manipulação e análise de dados. Numpy é uma biblioteca para operações numéricas eficientes em Python.
- Na sequência, temos quatro linhas de código não comentadas usadas para **importar bibliotecas dedicadas à visualização de dados**. Matplotlib e Seaborn são bibliotecas para criação de gráficos estáticos e Plotly (tanto express quanto graph_objects) é uma biblioteca para criação de gráficos interativos.
- Em seguida, temos duas linhas não comentadas para **configurar a não exibição de warnings**. Warnings são mensagens que podem aparecer durante a execução do código alertando sobre possíveis problemas ou mudanças futuras na sintaxe de determinadas funções. Neste caso, optamos por suprimi-los, já que são alertas e não geram nenhum tipo de obstrução ao código. Aqui, pode ser mais seguro o iniciante não fazer esta escolha, pois alguns programadores acham imprudente ignorar avisos.
- O **plt.style.use()** configura o estilo dos gráficos criados com Matplotlib para imitar o estilo do ggplot, um popular pacote de visualização de dados do R. Há outras escolhas bastante populares dentre programadores de Python, como o fivethirtyeight, por exemplo. 
- **pd.set_option()** serve para configurar o Pandas. No nosso caso, optamos por mostrar 15 linhas (display rows = exibir linhas) Essa linha configura o pandas para mostrar no máximo 15 linhas quando exibir DataFrames e por exibir todas as colunas possíveis (display columns = exibir colunas).
- **nb_black** é uma extensão que serve para formatar códigos de forma automática no Jupyter Notebook. Ela irá formatar automaticamente as células do notebook para seguir a convenção de estilo do Black, uma popular convenção de estilo de código Python. A extensão é carregada usando a sintaxe de comando mágico do IPython (os comandos que começam com % ou %%).

#####  

##### QUE COMECEM OS JOGOS -> HORA DE OLHAR OS DADOS! 

Agora, vamos para a parte divertida da coisa, hora de olhar os dados! Começamos importando o dataset com a função pd.read_csv() do Pandas e exibimos as primeiras linhas, para entender com o que estamos lidando:

![img](https://lh3.googleusercontent.com/Gkqw0mqaRIx1ucJmDYOlbAbqEwQvbkVesXsEoRP7_ipH1qGl8_Wv6Lf3YpOjERJippZwO7F6b9eYBlQrD9v9X3kQgh4KYV8rWKa8dhtASpp_cnnJORzpHY-AlgdM1aGAZLRfUdeRdhw3qy-WJ1c9GLQ)

Ainda não é necessário comentar nada, pois é tudo bem intuitivo. Como já demos o contexto da análise lá em cima, não há o que falar. Quando eu digo comentar aqui, estava me referindo a comentar o código, usando '#', mas vale também para a análise, ainda não é necessário.

Antes de avançar para explorar os dados, vale ver o básico do dataset, como a quantidade de linhas e colunas. Porém, ao invés de usar o .shape sozinho, vamos deixar uma mensagem direta ao leitor

, você vai ver muito disso nos notebooks do Kaggle. O f-string é uma ótima escolha aqui:

![img](https://lh3.googleusercontent.com/9q5sW2ljErjo9ArFtr8Ik9u6gjYmi2iMTpaojnPdaz3kMPiBC7Gfu-shnNLkCfZmMfVJc5XBDkGbgBTLo446HDQQWegCajzDlVk0kgVrGtmg1zPbd4DSYQ58rIh5PAt5R3EKszmSAY1V0vVm_VLctOk)

Veja que deixamos um pequeno comentário a respeito do dataset também. Nada muito chique, nem essencial, mas acho que vale para não deixar o notebook muito vazio.

**Sobre a sintaxe:** Para quem não conhece, p f-string é uma maneira eficiente de formatar strings em Python. É uma maneira de incluir o valor de variáveis ou expressões dentro de uma string. Ou seja, se você tiver uma variável qualquer que tenha sido definida no código, fora da string (claro), e deseja usá-la dentro de uma string, você pode aplicar o método f-string colocando um 'f' antes das aspas que iniciam o texto e colocando a variável (ou qualquer expressão Python) dentro de chaves. Veja outros exemplos:

![img](https://lh5.googleusercontent.com/bYCTrdJ0KiZNEX9gh8_XYg3tCpYMID1kW2bK9GRQSJfm1VItTsynql_3PRy-qj1EhFlYyExqon0PEw11Tu52g59WlwK0_K-xYMNNmIBp05xoCrDKuW8ODrhACTzu7JfMH3xHhxQWTa2sTqHTpga2fFY)

Seguindo com a análise… 

Lembre-se de que o portfólio é uma forma de você demonstrar não apenas sua capacidade de storytelling e de lidar com dados, mas também suas habilidades em Python. Sendo assim, que tal mostrar que você domina bem as funções do Pandas enquanto explica a estrutura do dataframe? 

Vamos separar variáveis numéricas de não numéricas e ver quantas colunas temos de cada tipo:

![img](https://api-club.hotmart.com/file/public/v5/files/6ba0a55d-91d2-4485-bc50-578e98db4b8d)

Colunas numéricas e não-numéricas costumam receber tratamentos diferentes. Conseguir separar o dataframe de uma maneira ágil, sem ser "na unha" é sempre uma boa ideia! Aliás, você poderia usar outras estratégia ali, como trocar o 'numerics' por 'np.number'. Também há quem prefira separar entre numéricas e categóricas, seja usando essa mesma estratégia, seja verificando a contagem de valores únicos e determinando um corte (por exemplo: se tiver menos de 15 valores únicos, considero variável categórica). Para esta última alternativa, você poderia usar o seguinte:

![img](https://lh5.googleusercontent.com/QbCbrrt8Fy16eFnmbwAQqdh54K9qTllHOEIldF7MV_XE4AvQC7JD9O2xmGMXVecpviIjHQ_1m8UIswmjMfPnjX08PvLx4EjzJbbZpbYB3b8sUn9zPYHkJ1wqoXgQVaJ2Jq7ZplFC9-aWc_XFxzN_FY8)

Bom, retomando a análise, vamos para a cereja do bolo, a tal da EDA, EXPLORATORY DATA ANALYSIS!



##### SEU MAIOR TRUNFO -> A ANÁLISE EXPLORATÓRIA! 

Aqui, é onde você começa a conquistar o recrutador. Sua análise exploratória vai dizer muito de você, sua capacidade de interpretar os dados, sua habilidade de storytelling usando dados, sua organização, capricho, TUDO! Bora explorar nossos dados?

Se você olhar minhas dicas sobre análise exploratória, vai ver que eu sempre indico a mesma coisa, análise univariada, seguida da bivariada e, se necessário, avançar para a multivariada. É importante começar pela análise univariada, mesmo que ela não gere insights para responder às questões que levantamos no início do material, pois a análise univariada pode apontar alguma inconsistência nos dados, além de deixar você mais por dentro do perfil do público que está em análise.

Vamos começar explicando que é importante entender o perfil do público em análise e vamos começar olhando para a variável que provavelmente será o foco do nosso projeto: o preço!

![img](https://lh4.googleusercontent.com/727y7qqOPTJFR22DhzoV4UMJ0vfBheO_g1fBVny_cOaqoYk2OE-VGF8tL_0NqHnWbplnQaj8tqQVCQaSUnMpKmo-lFwg2ODVljQrs4dICLBNgLBr_HJtvsYK-9nXp10iUo0kYgHmnpIoC5H8rzpg11E)![img](https://lh5.googleusercontent.com/jhRgAyAnunpmuTlUC6zwOYBUt1YBBEkOiOW8bY4yn7f_kKOQynKOxikpYm5-zWZfIpDsE9ToFazSTOdLcwGTfd4UJwo5tYs6WBBVXA8R-60sNRZRSgZdq7bcD3LVk-vahslxIjXqQGsrP27nxh1eZQ8)

O gráfico ficou simples demais, mesmo colocando título e o layout do ggplot. Portanto, vamos adicionar um pouco mais de detalhes aqui:

![img](https://lh6.googleusercontent.com/vjInE5onjiy9QGD4zBbceICa_Zke0pP0HMJphMMK8LW7wsS9B0iMlOtCF20yA7qsZ1RCdticwAxtoiYmMWqDC8Ntz2RVb7PPomr0R-WYmdpuT6kHUZTGkVaEAT1yCx8nyLbCbf5g-W07g9ienDa_ne0)

![img](https://lh5.googleusercontent.com/JCbuEDsUPa59jns_w2NKkOmxacv-880myvN-B3lxaSXEs5RCV4I2yYseF_kx2hlmrDJOaXPdQzjys4p7zNYSR2WW8SjE54bwThs2drSHnwSKINMbyBCRKUYxnIPQwxNFoakHfevNYpVpYXyRYsc4oIk)

Lembrando que este código está no jupyter notebook em anexo e é normal que você leve um tempo para entender cada trecho dele. Entretanto, veja que a gente sabe tudo o que está ali, já aprendemos sobre as questões do eixo e da figura na parte 1 da "Análise Exploratória de Ponta"!

Outro alerta que vale fazer é que eu decidi incluir vários comentários acima, mas não é necessário fazer isso nas suas análises e eu vou até diminuir o uso deles ao longo do material, fechou? Você já consegue ler o código mesmo se não souber absolutamente tudo, vai!

Abaixo, concluímos o que observamos e adicionamos mais um gráfico, apenas para facilitar a vida do eleitor que pode preferir ler histogramas:

![img](https://lh3.googleusercontent.com/j8Y162lEhzSN098gc4C2jWPc875iKkQMyFvhBE8zj4xLWcTRvbj7jecrOHD2U798685m4utvbaHL-9EL9-W1UgIJsLlDnbRjSwoZklWJ65llbV8lknix_lpYQVlZKGecxYBo5t7g2ehLSSoVcW-LhJU)![img](https://lh4.googleusercontent.com/LH5GIYTjc6spndLVQHfVjQnnfYZoVi6g2hrpEc0lMiGBzTmHNsNqpbkTcwkjYNZXi_90_NveVMOquLAVfenvFVInZ6MZOah4NFuOi95aAFxn1gxyXh0zBYYKxsb52sjaT5a-S4fH-mryWGLSPWnB2qY)

Ficou legal, mas eu queria usar um pouco mais do Plotly, que não tem uma curva tão rápida, mas é uma biblioteca de visualização de dados muito mais interessante, capaz de criar gráficos bem bonitos. Vamos trocar o histograma acima por um no Plotly:

![img](https://api-club.hotmart.com/file/public/v5/files/769cbd4a-4127-4fc7-a88c-38da463a80cf)



![img](https://lh3.googleusercontent.com/LbBKz2_WalxB6BRVhf7yscus7ZpxzX1VuY2Ko-1T-nvJxr9tK-rUI83XC1wdqbd6K_bqzlftqpYgXOJbhbBuIH34M6knbnorD0vebcoQduf8ScPUv0tRh6O-aCowU4L6_fmk-gG6BHWHm4gXREXWDxg)

Bem mais bonito, ein? Imagina a moral que você vai ganhar com o gestor da vaga!

Dificuldades em entender o código? Calma, jovem! Vem comigo:

- **import plotly.graph_objs as go:** Essa linha importa o módulo graph_objs da biblioteca Plotly como go. O graph_objs contém todas as classes e funções para gerar objetos gráficos. Já havia carregado no início do notebook, mas como eu acabei colocando mais uma vez e já dando a explicação, decidi não apagar. Mas você não precisaria carregar duas vezes, claro rs.
- **mediana_rent = aptos.rent.median():** Essa é bem intuitiva, apenas calculamos a mediana do aluguel (rent) e armazenamos no objeto mediana_rent, pois precisaremos para traçar a linha verticar (rent_median acho que seria um nome melhor).
- **mediana_rent_format = ("R$ {:,.2f}".format(mediana_rent).replace(",", "v")...:** Formatamos a mediana para usar o símbolo do real (`R$`) e duas casas decimais. A sequência de replaces é para alterar o delimitador decimal para a vírgula (o padrão br). 
- **data = [go.Histogram(x=aptos.rent, nbinsx=50, marker=dict(color='blue'))]:** Esta linha cria um histograma do aluguel, com o número de bins (intervalos / barras de frequência) definido para 50 e a cor do marcador definida como azul.
- **line = [go.Scatter(x=[mediana_rent, mediana_rent], y=[0, 2200], mode='lines', line=dict(color='lightblue', dash='dash'), showlegend=True, name=f"Mediana = {mediana_rent_format}")]:** Aqui, um gráfico de dispersão é criado para representar a mediana do aluguel. Isso é feito traçando uma linha vertical na posição da mediana. A linha vai de y=0 até y=2200, tem cor azul claro, e é desenhada em traços.
- **fig = go.Figure(data=data+line):** Esta linha cria uma figura Plotly que inclui o histograma e a linha da mediana.
- **fig.update_layout(title_text='Histograma do Aluguel', xaxis_title='Aluguel',    yaxis_title='Contagem', autosize=False, width=900, height=500):** Aqui, o layout da figura é atualizado para adicionar títulos ao gráfico e aos eixos x e y, e para definir o tamanho do gráfico.
- **fig.update_yaxes(range=[0, 2200]):** Essa linha define o intervalo do eixo y para ir de 0 a 2200.
- **fig.show():** Finalmente, essa linha exibe o gráfico. O gráfico resultante é um histograma do aluguel com uma linha vertical indicando a mediana do aluguel.

Ainda com dificuldades? Bom, meus parabéns, você acabou de ganhar um conteúdo extra! Esta semana é 2 em 1, além deste tutorial, fiz um material curtinho, bem mão na massa, de Plotly: https://www.kaggle.com/andreyukio/plotly-tutorial-rapido-pt-br. Dê uma pausa, leia o material, teste seus conhecimentos em Plotly e volte na sequência!

***Aliás, que tal escrever um breve tutorial de Plotly no Medium? Ou criar um post rápido de Plotly no Linkedin?\*** 

Poderíamos ir para os outros campos, certo?

Claro, até poderíamos, mas ainda há algumas coisinhas para se verificar nos custos dos imóveis, como as estatísticas descritivas:

![img](https://lh3.googleusercontent.com/HnsvSmSUH9qtU2kzHiqFXGjqwxkggMyHdqWeHmjzwxmJfGk_wtG_3Q7Fw9LHPVshU5zZlBM3iv71G-Akw52T_7g7F8eTfYyR6P76_SyH9XFr-6_FjCjsvwuA9SZ9iGsyR1NS0EgJ6ndG_t2kalXrJ_k)

Veja que eu acabei optando por transpor a matriz com a estatística descritiva. Fiz isso para ocupar menos espaço, não é uma tabela que eu quero dar muito destaque e também gosto da leitura desse jeito. É apenas uma escolha subjetiva, não existe a necessidade de fazer isso. Mas veja que interessante, quando olhamos para esses dois valores, notamos a diferença entre o aluguel e o preço total. Isso é algo que você poderia explorar, será que a diferença é mais ou menos a mesma para todos os imóveis? Como será que é a distribuição dessas diferenças? Será que é diferente os imóveis cuja diferença entre aluguel e total é grande em comparação com os que a diferença é pequena? Viu, como não é difícil ter ideias para a análise do seu portfólio? É só ir explorando as variáveis!

Bom, por enquanto, vamos continuar nossa análise univariada e não faremos nenhum comentário a respeito da diferença entre os 2 valores,

Vamos seguir olhando para as variáveis restantes:

![img](https://lh5.googleusercontent.com/vTUP5NOz_Tp0IOyZ158IOeLzSNJ3VL4Ps61xjENwvFLfzal-CRC5MUD5xz9yAiRoaiSrplpLwOza98XIKmIMQWRn9WdVFwvPE6hovoCYoXvJRBsh0i2zrOsOYenOXMNx3q4XxhNhE1pcf8an1xUsPVs)

Hmm, muito simples também, não é? Vamos jogar umas cores nessas barras!

![img](https://lh3.googleusercontent.com/LAxjAFxXqGFbo0QimJb-EKoroSO7DoZ5tmoxHRJ-5rlZ_9FyTJuoQ9k5lwvjOVwxi1zzFEUQWfIqdZeUnG0B9VhquumuovRiXGhD3f3xfFHNTt9wAUGNkNIqu_r2oMYAMkufmrY-xY1dengEhO7WArw)

Para esse gráfico, achei interessante fazermos alguns comentários, afinal, temos insights relevantes aqui:

![img](https://api-club.hotmart.com/file/public/v5/files/f71a616c-f382-4f22-9598-6bb1c8593775)

Se você tiver outros insights, resultado de conhecimentos que você tem da área imobiliária, você pode até deixar a análise mais robusta ainda!

Dando sequência, também podemos olhar para o número de quartos e vagas na garagem, já introduzindo no nosso Notebook o **subplot** do Plotly:

![img](https://lh3.googleusercontent.com/PlSvfY80LT-FWGvHtYoe6imzKyRYFGbCRHld2Ft4RgA3mrKevpVuAjnNnSrYW-DVUkXWi6Zqu9F-FBOCxeb5z9bMc0lG-4rl-VvmjuDTU0UWh8llZHSLJKpfXWRT7eI20iFJHUmTHql8Gr0mmBUip2c)

![img](https://lh3.googleusercontent.com/dGNwusZTUI8kCHp32DmD8DSBH8_E_zRHvrS7mOMruh3fHVVeRn_UodNdObtjfZkQQI7XLLhRgkcTHOBrnMXQaviD12TIgQsfVPCa5PhGhv5M3azq08W_Z4wBpcfJxMR-gwXBbeg7B7jr9ah6BlVdDPI)

Mais uma vez, vamos explicar linha a linha:

- **from plotly.subplots import make_subplots:** Importação básica, trouxemos make_subplots do módulo subplots do Plotly. Essa função é usada para criar múltiplos painéis em um único plot, conhecidos como subplots. Em outras palavras, conseguimos criar gráficos lado a lado, ou mesmo um abaixo do outro.
- **fig = make_subplots(rows=1, cols=2):** Essa linha cria um objeto de figura com dois subplots organizados em uma única linha. Você pode pensar nisso como uma grade 1x2 de gráficos vazios.
- **fig.add_trace(go.Bar(x=aptos['bedrooms'].value_counts().index, y=aptos['bedrooms'].value_counts().values, name='Bedrooms'),row=1, col=1):** Aqui, um gráfico de barras é adicionado ao primeiro subplot. O eixo x do gráfico de barras é definido como os valores únicos de 'bedrooms' e o eixo y é definido como a contagem desses valores únicos.
- **fig.add_trace(go.Bar(x=aptos['garage'].value_counts().index, y = aptos['garage'].value_counts().values, name='Garage'), row=1, col=2):** De maneira semelhante, um gráfico de barras é adicionado ao segundo subplot. O eixo x do gráfico de barras é definido como os valores únicos de 'garage' e o eixo y é definido como a contagem desses valores únicos.
- **fig.update_layout(title="Distribuição de Quartos e Garagens"):** Essa linha atualiza o layout da figura para incluir um título. Como você já viu antes, o Plotly tem essa coisa de "atualizar" layout, que é basicamente adicionar informação.
- **fig.update_xaxes(tickmode='linear'):** Essa linha é a mais estranha para você até agora, creio eu. Aqui, estamos garantindo que todos os ticks no eixo x sejam exibidos em um intervalo linear. Fiz isso porque o Plotly omite alguns rótulos do eixo, caso contrário. Você pode até rodar sem essa linha e ver o que ocorre, seria interessante para o aprendizado!
- **fig.show():** Finalmente, a linha que exibe a figura com os dois subplots.

Excelente! Agora, para fechar, vamos olhar a variável área do imóvel. Novamente, vamos tentar surpreender o leitor, trazer novas habilidades para demonstrar que podemos facilmente lidar com dados no Python, independente do objetivo! Vamos trazer um pouco mais de estatísticas para quem for ler, o que você acha?

![img](https://lh4.googleusercontent.com/bjNmYxX-LZndBh5fKhX4MkT2VNQQ_YLQWSu2ihFPFS-_U9HzDWf3XO9JaZ5CWcG2V2X5ZSGABPyf29kcbLZBO0RjZxyby0fburEbM8pKLXN-WHSgUNG839Q06OVCzfP--1J49nRPHQ1TAhmMQAsHAY0)

Como nossa análise já ganhou corpo, mas temos feito poucos comentários, vamos tentar escrever um pouco mais, que tal? 

Veja abaixo a célula que decidi incluir logo abaixo da estatística descritiva:

![img](https://lh5.googleusercontent.com/mSPU5t1JprW2ptaLwT0lfqqVls2PYKxuiVArsGMlqTCzaI9j9IxA5LOIIio5SbD8aujoYe-ibZ98kulb543JYJ0MLPylsR-TROovTikvk-mKp6AHUqaENwuoZq_lVVGf_K4Dij5dV-EzCj3JojXnvcA)

Falando nisso, como estão suas outras análises, de outros projetos? Você já tem algo em andamento que falta alguma constatação interessante? Pense sempre nisso, o leitor quer insights bacanas, veja o que você consegue extrair dos gráficos e tabelas que não seja tão óbvio.

Enfim, como foi dito acima, temos um problema! Não é possível apartamentos de 0 metros quadrados. Na verdade, mesmo apartamentos de 2 metros quadrados, por exemplo, seria interessante. Sendo assim, vamos verificar quantos apartamentos temos com menos de 10 metros quadrados, onde estão localizados e outras métricas que conseguirmos observar. Primeiro, a contagem:

![img](https://lh3.googleusercontent.com/Re654-c7NY36HLfFRK_eeUNlP7Q_cgF8Bz6YGsIj3zHubwHhBZlZk7eQFA6PKjxQHd1unIobN3vDzrhsUZXRBwbjB71__Hgj2ePumJwWU83BUNiK702PEp08RWLKQa4LIr9AWM8fqnw_lfv5wbZ-Xm4)

Identificamos 7 apartamentos. Vamos olhar suas métricas:

![img](https://lh6.googleusercontent.com/OgmBATnwql4PXvzcHl_F5p0qkspE9kAjV5zlXQRkPwQywlpRyjSowIIl47alTGUa67hRwXs5SwMDXdbHOSR-Sl9ZN1_qQcIjIlNY_y82WWTQAr4VntmO8Sxgd_5mhV3Xhjzhu2LE6U9fyAFBrwGPfqE)

Parece que há algo estranho nesses valores de metragem, poderia ser o caso da área de algumas observações estarem em diferentes unidades de medida, mas isso não explicaria os imóveis de 0 metros. Olhando os preços de aluguel, alguns estão até acima da média e da mediana. Normalmente, poderíamos acionar alguém que mexesse com as bases da empresa, ou um engenheiro de dados, ou um DBA, ou até mesmo nós, cientistas/analistas, poderíamos investigar. Aqui, não existe esta possibilidade. Sendo assim, a opção será excluir essas observações para não trazer muita sujeira para a análise, embora já seja esperado que a gente tenha problemas de qualidade dos dados. Veja abaixo como ficou nosso Jupyter Notebook:

![img](https://lh3.googleusercontent.com/ODUKVFyqVQbD8wbAOcM6pKOsfLIiMyiK8QrdmGc-FGMOIymIBjgspXXL6luIebcQyR6mZDiSPMerhNu6GeH1w6u6oTG0hNzdZZMKrVtWKchO-bXijbankWI-pgb6FEOcsyU5CQfXKoRWQOzp1vvE1Go)

Como a análise já está ganhando um corpo razoável, podemos começar a responder algumas perguntas e nos aprofundar em alguns campos específicos. Vamos começar pelos bairros! Mas isso vai ficar para a parte 2 dessa análise! Já tem conteúdo para caramba para você ler, isso vai consumir umas boas horas de estudos! Lembrando que estudo sem aplicação não adianta de muita coisa, né?

Depois que finalizar esta leitura, aplique o que aprendeu em seus projetos! Dá uma revisada no que você já fez, veja se cabe alguma dessas análises, tente trocar seus gráficos pelas visualizações que aprendemos no Plotly, coisas assim!

Espero que tenha gostado! A gente se vê na próxima semana!

Forte abraço,

Yukio!