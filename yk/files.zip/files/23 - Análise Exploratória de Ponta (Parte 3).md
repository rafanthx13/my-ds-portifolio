# ANÁLISE EXPLORATÓRIA DE PONTA (PARTE 3) 

No nosso último papo, paramos a análise exploratória na seção de análise univariada. Nossa análise já está ganhando um corpo razoável, podemos começar a responder algumas perguntas e nos aprofundar em alguns campos específicos. Vamos começar olhando para os bairros, pois teremos muitas coisas para ver ali!

Aliás, antes de começar, todo o material que está sendo apresentado, incluindo as imagens utilizadas, estão no arquivo em anexo!

Começando pelo básico, precisamos saber quantos bairros possuem aquele dataset e quais parecem mais relevantes, no que diz respeito a quantidade de aparições (i.e., número de imóveis na localização):

![img](https://lh4.googleusercontent.com/IQo2Hxtkpjn3_FQbxdEVuOA5EUUwcy4Ns_Wq82Q7ihYakbFrH2qhirSu1ZSe3TiqBic0aKzhfx9COumZt7YdCSbiFdAWjLDAcLoFRqwjF_WCszr3XU46AXyacwoagmXVWgQYjbC4JvJ0RmUynOQdTC8)

Veja que ainda estamos com análises univariadas. Agora, que tal avançarmos? Vamos à pergunta óbvia: quais os bairros que poderiam ser taxados de "bairros de ricos"? Ou, mais formalmente, quais bairros possuem imóveis mais caros, o que significaria também que estamos falando das classes mais altas da população?

Veja no print abaixo que eu encerro o tema de cima com um comentário sobre os bairros que mais aparecem no dataset e inicio o próximo tema. A gente evita comentar absolutamente tudo, mas é interessante ir conduzindo o leitor em nosso storytelling:

![img](https://lh6.googleusercontent.com/B55ZbtI978ZYrZYXjeamlbvNpj8qZZzTzQAS_zfHEASb5hip-cF2Q15FW6amh4GYi9F7Y6EdI50u3_j0YvFkLUluToub5JqsxptrSEGQfzT8p8-BTHBZU7zc_JiEcy3hsJwNDh3RgDw7oWoOM3dIuqE)

Vou explicar a primeira linha do código, pois acho que pode confundir alguns:

\1. Separando por partes, veja que partimos de **aptos.groupby("district")**, onde a função groupby() agrupa os dados pela coluna district. Ou seja, ao invés de termos as linhas para cada imóvel, temos agora um novo layout em que cada linha seria um distrito. O output, no entanto, é um objeto groupby - e não um dataframe, como estamos acostumados a ver. Este objeto pode (e costuma) ser usado para calcular estatísticas para cada grupo distinto - no nosso caso, podemos extrair as métricas por distrito.

\2. Na sequência, temos **['rent'].mean(),** onde estamos justamente aplicando uma estatística descritiva, a média, para cada distrito. Claro que precisamos pontuar alguma métrica para ter sua média calculada, e, no caso, pegamos o aluguel (rent). É uma sintaxe bem simples! 

ATENÇÃO: Se você quiser agrupar por mais de uma categoria, lembre-se de usar colchetes para pontuar as classes que serão agrupados e duplo para as variáveis que terão a estatística calculada:

aptos.groupby(['district', 'type'])[['rent', 'total']].mean()

\3. Para ordenar, do maior ao menor aluguel, usamos **.sort_values(ascending=False)**. É importante especificar que a ordem é decrescente, para isso, usamos ascending=False.

\4. O '**[:10]'** é apenas um fatiamento que seleciona apenas os 10 primeiros valores, ou seja, as 10 maiores médias de aluguel.

\5. Por fim, resetamos o índice da Series, pois isso vai transformá-la num DataFrame. Fazemos isso com **.reset_index()**.

Depois disso, apenas renomeamos as colunas, alteramos o formato da coluna "Média de Aluguel" para usar "R$" e finalizamos exibindo o resultado.

Sem grandes surpresas para quem conhece São Paulo, temos Alphaville em primeiro lugar. Entretanto, algo me incomodou aqui, que foi ter uma lista resultante com vários "Alphavilles" nela, tirando outros bairros que poderia ser interessante de ter no resultado. Este é o tipo de coisa que a gente espera que a pessoa que faça a análise questione, entende? É esperado que desperte uma curiosidade nela, questionamentos do tipo "o que será que tem além de Alphaville" ou "se ignorar Alphaville, como fica esse ranking". E foi isso que fizemos:

![img](https://lh4.googleusercontent.com/ctiCDqvoOYkDjdSxYzps9M0ZFfhNVGTX5i-xqZy0YUq5nAPTcCrWgLiacAdtaqqH6Tbiq0386taIn14tRiGfoM3CGu_cvV1VauDdJ9qFFU8xwyOET_9IfdMIrQ16RSWa8bsdSG8ZPMohMKWLO4_JcMg)

Veja que temos muito mais informação agora! Isso melhorou muito a análise e ainda deixamos claro ao gestor que estiver avaliando nosso portfólio que a gente consegue manipular os dados em Pandas sem grandes dificuldades. Como o código já é intuitivo o suficiente, com nomes adequados e sem grandes malabarismos, dispensa comentários explicando a sintaxe. Podemos adicionar ainda uma visualização, mesmo que seja redundante:

![img](https://lh5.googleusercontent.com/_axDfUzwvP9eLKREBnmJlOPgxy7QerN5rbb03gXdocj3cU0I6zFtJv5b3CzlUXzPl4xMu1DLfIojvBI375-wWGhVE-YemeUxQ09iUL1Tj6uUOk3tK8l85souJxO9whqCgFHkznyvN1jV88tMfuUWDEk)![img](https://lh4.googleusercontent.com/PhLQdOqI1gyvEaVb_SXAYmQMKMRvlj4QNY3-jcM3psmLztS6alVLBuGovT0xXWHv6EH5jc_fbJdSc9HUxzArLGeXsh2Ee52wnO0kCf0ORL8MgGOOVI_jM_C0EXOtvh2S6jefC8qkwGj0IgxCBNsIK-I)

**DESAFIO: Que tal você gerar mais agrupamentos antes mesmo de seguir com nosso portfólio? Teste o quanto você entendeu até agora! Ou ainda, faça filtros que possam ser de seu interesse, você poderia, por exemplo, olhar dados do bairro em que você mora! O importante é se manter praticando e garantir que entendeu tudo!**

Nossa análise está ficando bastante interessante, trazendo informações relevantes sobre os imóveis de São Paulo. Como a gente é bastante proativo, não vamos ficar refém somente do que consta no dataset, bora buscar informações fora dele. Vou comentar um pouco sobre o que sabemos desses bairros, trazendo algumas informações das zonas de São Paulo, ver o que podemos inferir a partir dos dados vistos até agora. Antes, vamos gerar uma descritiva dos aluguéis, pois esses números vão ajudar a entender um pouco mais deste

 top 10:

![img](https://lh5.googleusercontent.com/OUs7-HrcaDE2OD34raayLyNKnM3L9sRmA9NdbGpnEo1ynVuZh7uxCEveSEA65iknSDggfDbCXG7sUvM7jB62OqOKXRx2paGFn_s2-64oBgQJvvfT2GuBtvS1l11rMmEKklxvqXrJcF7Pdj-FeLI2_8U)

O que achou dos comentários? Dava para escrever mais? Já vai pensando no que você faria!

Seu portfólio só será chamativo se você não resumir seus materiais a apresentar os dados, mas também fazer considerações. Neste momento, você tem meio que uma janela de oportunidade, um local para mostrar ao leitor - seja ele um colega de profissão, ou um gestor que está recrutando para sua equipe - o que você é capaz de gerar de valor, o quanto você consegue inferir dos dados e até correr atrás de mais informações para tirar algum insight interessante. Lembre-se sempre que seu portfólio é a oportunidade de você demonstrar também seus conhecimentos gerais e sua proatividade, então não precisa limitar os comentários ao que está no dataset.

Antes de explorarmos mais dos top 10, é de se imaginar que o leitor deste estudo também queira entender o top 10 dos bairros com aluguéis mais baratos. Afinal, é legal saber o que tem no top 10 mais caros, mas isso é mais interessante quando temos um comparativo (perfil dos baratos x perfil dos caros). Sendo assim, nada mais óbvio do que também gerar o top 10 dos mais baratos:

![img](https://lh5.googleusercontent.com/c-VHuHypcBBvyAV3cvmIDPWTO1KvOOknA2i-RhBZGxhyRQgYv1V_Q4A6Q8T0yRl7sNzseuelD5AUhKkAx8EJEdfTWQ__r6q1Q4vXWZYOzMwXHG53xzBL6weVVXPo6FvpBhzoXu-DA7iIFMW3keNeb3U)

![img](https://lh5.googleusercontent.com/cNxUt9BKXLK52Lry2a58jjzdxPCXxX-0Kt54poPki1imxBde41pXhrwW6rldjxx6ES7GwNFMx8YFsuzq55nUYfujs30NaAzcxYx6TcAtJtbiox6CS6nazwF5jWAplGhz012PjIpmRSLG1oUSOZN5vmQ)

Talvez o mapa de cores pudesse mudar um pouco, já que vínhamos usando cores suaves nos outros gráficos. Mas deixemos isso para um outro momento, por enquanto, vamos dar sequência à nossa análise!

Assim como fizemos para os bairros mais ricos, vale a pena esmiuçar um pouco as informações dos bairros mais pobres:

![img](https://lh4.googleusercontent.com/suWaPrBC5MHyegfvgQzOlBjRDgXzzm2FeW45WRSFQbaGPuu8pjuVPAhhHKeRxQsMwdqc9-c5aG4ba6rvkQ7lNDnV3wb8L7ZfFeL3NqxobXOgPapQIaDcOCQ2a6dRZXtoQ4RIG0mPWK1gM8dRKU-Yrw0)

Até o momento, o que a análise mais tem evidenciado é o tamanho da desigualdade dentro da cidade de São Paulo, uma desigualdade existente até dentro dos subgrupos. Agora, seria interessante destrinchar melhor como essa desigualdade ocorre, olhando para os detalhes dos imóveis. Entretanto, um top 10 me parece uma amostra muito pequena para uma análise robusta. Vamos utilizar pelo menos um n = 50:

![img](https://lh5.googleusercontent.com/tPqYO3XF5ZZNLPY0rpLl4zbAtqRtyXPmcLfakz-i5M07gHv8xjPj7XvciaWwTGK4S8m1Ra1r8Q78qunP0WJYtafZylU-uiIg6XXAYf60yAmhXEfpfYJAmpbjvymkbMMf1KexRlA3IrAFhBwEVGG0tr8)

Pronto, agora podemos comparar os imóveis! Primeiro, vamos checar o quão distantes são os valores de aluguel:

![img](https://lh6.googleusercontent.com/WwvOWYl00IMB-PdcCmdP05LkAP_dLCZwjRCChbKVMQjMUZU8NTtw7fi2uks3EVe8_G-x8duCGB4uW34dmmFK4UfyTmYWltnoLjaEh4o3U62Jf-ZksQZS7GQ0BVgra7rryJyArhwKZIszruHo58a3Kas)

![img](https://lh3.googleusercontent.com/fXWpM2glIqUmWfsloJuh8Duqem8d6Nqp9NQOMp2CyLZ111HmGpJ_QHaZ3udzo1pC8f7K_3xbuPt2kGODEfqdCqZAk7DNSyyLR7dAGrSyw4YW2R0fufKMyn4laJzuU7tLkhie5pCebGZFDBSmHbqA2Tk)

Para quem está confuso com o código - insisto nisso, porque eu demorei para pegar o jeito no Plotly -, vamos de explicação linha a linha, mais uma vez:

- **top_aptos["class"] = "Upper"` e bottom_aptos["class"] = "Lower":** Aqui, estamos adicionando uma nova coluna chamada "class" aos dataframes top_aptos e bottom_aptos. A ideia é ter uma coluna que separe os imóveis caso a gente juntasse os dataframes. Aliás, a escolha de nome, **aptos**, não foi muito feliz, já que o dataframe não é composto somente de apartamentos, mas todos os tipos de imóveis. Um pequeno vacilo, mas vamos dando sequência para não perder o foco. Como dizíamos, criamos a coluna "class" e ela foi preenchida com os valores "Upper" para o dataframe top_aptos e "Lower" para o dataframe bottom_aptos. 
- **fig = go.Figure():** Criamos uma figura vazia utilizando a função go.Figure(). Essa figura será usada para adicionar os elementos do gráfico do Plotly.
- **fig.add_trace(go.Box(x=top_aptos["class"], y=top_aptos["rent"], name="Upper", boxpoints="outliers")):** Aqui, adicionamos um trace (traço) ao gráfico utilizando a função go.Box(). A ideia é que no Plotly, nessa estratégia escolhida, a gente inicia uma "figura" (tipo um quadro em branco) e vamos acrescentando elementos a ela. No caso, o elemento é um boxplot. Neste elemento gráfico, go.Box (o boxplot), configuramos o eixo x como os valores da coluna "class" do dataframe top_aptos e o eixo y como os valores da coluna "rent" do mesmo dataframe. Definimos o nome do trace como "Upper" e configuramos o parâmetro boxpoints como "outliers" para exibir apenas os pontos que são considerados outliers.
- **fig.add_trace(go.Box(x=bottom_aptos["class"], y=bottom_aptos["rent"], name="Lower", boxpoints="outliers")):** Similar ao passo anterior, adicionamos outro traço, i.e., outro boxplot, à figura, ao "quadro em branco". Desta vez, utilizando os valores do dataframe bottom_aptos. Configuramos o eixo x como a coluna "class" do dataframe bottom_aptos e o eixo y como a coluna "rent". Definimos o nome do trace como "Lower" e configuramos o parâmetro boxpoints como "outliers".
- **fig.update_layout(xaxis=dict(title="Classe"), yaxis=dict(title="Aluguel"), title="Aluguel dos Imóveis por Classe", showlegend=True):** Atualizamos o layout do gráfico utilizando a função update_layout(). Configuramos o título dos eixos x e y como "Classe" e "Aluguel", respectivamente. Definimos o título do gráfico como "Aluguel dos Imóveis por Classe" e configuramos o parâmetro showlegend como True para exibir a legenda.
- **fig.show():** Por fim, utilizamos a função show() para exibir o gráfico. É análogo ao plt.show() do Matplotlib.

Resumindo, o código cria um gráfico de boxplot utilizando o Plotly. Ele adiciona dois boxplots, um para a classe "Upper" e outro para a classe "Lower". Os valores de aluguel ("rent") são exibidos no eixo y, enquanto a classe ("class") é exibida no eixo x. Os pontos considerados outliers são exibidos nos gráficos. O gráfico possui títulos nos eixos e um título geral, e também mostra a legenda.

Bom, mas mais interessante do que olhar sob a perspectiva de duas variáveis, é olhar sob a de 3: Qual o valor médio do Aluguel por tipo de imóvel, para cada "classe" de imóvel (Alta/Upper x Baixa/Bottom)?

![img](https://lh3.googleusercontent.com/2UsSjwsjbZBMWgi-6NycmMFOT_-iejzT6AS7BNXFnZ6GVoSONi3hgjZjHM7fm2X695GBAtHfE0ILSww8bPnbqALoJZCRbfxCJaRGiWRqTtuHqz5QPHQ_7t7bu5XVNMMZzBL_GpKkk-VDwA5nPLjzJpw)![img](https://lh4.googleusercontent.com/8l_H8oP_GOsUti7X22VUBRP00WKPL5nm1LhRYa1GeJuwU6NdnPld0fKtGBBNqjtdgXwFiYn4wiYp_ElbPZKrHGKN2-wP3TprXf_k6TqDhlXVfpGLieX_qQvKmN4SyLA-wGk8jjMIJCf0D7eTC9ELozA)

É interessante olhar que a distância do valor do aluguel das casas em condomínio e das casas fora de condomínio dos imóveis nos bairros nobres para os dos bairros de classes sociais mais baixas é parecido, enquanto o valor dos apartamentos se aproxima um pouco mais e dos studios e kitnets ficam mais próximos ainda. Isso parece sinalizar que os tipos de imóvel influenciam muito no preço e possuem um limite para o quão caro podem ficar, enquanto as casas provavelmente podem subir muito mais o valor. Em outras palavras, não há como um studio num bairro nobre atingir valores 10x maiores que os de bairros mais pobres, mas isso não acontece para as casas.

![img](https://lh6.googleusercontent.com/0b-FIJ6vha141JU-sz5f2jICL8BbZmu51Cx_SV9i3VVfSAHnkf8p5sON-pD0nONsRnm9PcXJ-iz5nI9m_v8j8zQvkJSbO0CXmi3oyXsRsQKFIVvW7-cIGmfJNYTslUcutdo69GfWO9GUs025sipKxvY)

![img](https://lh6.googleusercontent.com/sSFRmH8Wtv6KfvwK8pM7PsXwlfyH92jqv-Z2H3O3m8zq82F11XOY-D3ZZKwd0yeCgNeISgdYCkxGGOQeV5dvVx5gUuhT7mQgMnD4dYZmX_AA5txG8sLW_na0nXTen59KP5I4Nx_ObOgBWzR8cNUYmyI)

**Desafio: Depois de tantos gráficos em Plotly, será que você já pegou o jeito? Que tal fazer um teste? Pensem em algumas hipóteses a respeito dos imóveis e tente validar usando gráficos em Plotly! Ou ainda, pegue um notebook antigo seu e tente trocar o gráfico do Seaborn / Matplotlib por um do Plotly! Vale usar o Google, o site do Plotly ou até o ChatGPT, o importante é garantir que você vai conseguir se virar sozinho depois!**

Seguindo com a análise…

Conforme mencionamos antes, a diferença nos preços das casas em bairros de diferentes classes sociais é muito maior devido a dois fatores principais. Primeiro, a localização privilegiada, que é um elemento significativo incluído no preço. Segundo, o tamanho das propriedades, que também tem seu impacto, e é bastante relevante. Esses fatores combinados contribuem para uma disparidade mais acentuada nos preços das casas, em comparação com imóveis como apartamentos, estúdios e kitnets. Veja que a gente foi guiando o leitor contando a nossa historinha sobre a diferença dos bairros, que tem sido o foco da análise.

Uma dica, se você não tem muita noção das hipóteses, não existe nada de errado em buscar no Google e consultar colegas. Além disso, vale ter em mente que a análise de dados passa por isso, por questionar as hipóteses que estão sendo analisadas. Logo, é interessante lidar com dados que você tem alguma familiaridade. Lembra do diagrama de Venn do cientista de dados, temos estatística, programação e negócio / expertise na área.

Seguindo com a análise, ainda poderíamos olhar para muitas variáveis, mas creio que podemos finalizar simplesmente olhando para as características de cada grupo, em relação ao tipo de imóvel, número de quartos e número de vagas na garagem:

![img](https://lh3.googleusercontent.com/J8xp-vFAyPa-oY4wBp35yu19XFDSD1l55-6rU749n7LYVgyDqzc0b28IqF3DP9lSUM9zCuruL010ny_FSKOkVgKvzquapJ8rXo7a3btgnPq8ff7ty5Lvzxy64U99VfglowQOHgSpAImRDtiYb5DxpWg)![img](https://lh6.googleusercontent.com/E3Z6p0rsBSJsyM5TqzbhEHG_KYUSjlxlBjtT4enEk8QCtfK3torqf4EOVGpZGUWm0IIb2byGk3rAePfhpWlW2XvI3CzBf8tG1C6CzKcNvkDDrUAM-MNjdX-DYUFQQ4Am75uPOg5KfZTi5dlg6xNTXc4)

![img](https://api-club.hotmart.com/file/public/v5/files/bc119b89-cd5d-4789-aabc-fa5f309ca536)

![img](https://lh6.googleusercontent.com/furY71TMPZxNQllpJip8SeYItU1l_4dvx8_-ISkP-XKCdFA5IU6yfpeOrEG6zsrPkVQWXQLTlbR8h79d6oLXqNvRGZrZ2_5iVW41ULOEWoz8WBZNWjsIQ2gji7zSSDz0NsaNRV0-JyBIFwYUN-QgO8o)

Correndo o risco de irritar quem já domina o Plotly, trago, maaaaais uma vez, a explicação linha a linha:

- **top_aptos_garage = top_aptos["garage"].value_counts().reset_index():** Nesta linha, estamos criando um novo DataFrame chamado top_aptos_garage. Veja, a gente primeiro faz um value_counts() para pegar quantas observações (no caso, imóveis) temos por cada número de vagas, depois aplicamos o reset_index() para redefinir os índices e transformar o resultado num dataframe de duas colunas, index e garage.
- **top_aptos_garage.columns = ["Nº de Vagas", "Quantidade"]:** Aqui, repetimos o que já fizemos em outras ocasiões, renomeamos as colunas do DataFrame. Quando fazemos .columns, estamos com os nomes de todas as colunas do dataframe. Logo, estamos atribuindo["Nº de Vagas", "Quantidade"] como nomes das colunas do dataframe top_aptos_garage. Fizemos isso para deixar mais intuitivo.
- **top_aptos_garage = top_aptos_garage.sort_values(by="Nº de Vagas", ascending=True):** Nesta linha, estamos ordenando o DataFrame top_aptos_garage com base na coluna "Nº de Vagas", em ordem ascendente. 
- Repetimos os 3 passos iniciais para os imóveis mais baratos, que chamamos de bottom_aptos. Mais uma vez, peço perdão pelo nome, deveria ser bottom_imoveis ou algo do tipo, seria mais adequado rs
- **fig = go.figure():** Iniciamos uma "figura" vazia. Como já explicado anteriormente, é como se tivéssemos criado um quadro em branco e chamado ele de fig. Neste quadro, vamos adicionar os gráficos.
- **fig.add_trace(go.Bar(x=top_aptos_garage["Nº de Vagas"], y=top_aptos_garage["Quantidade"], name="Top Aptos")):** Nesta linha, adicionamos um trace (basicamente, um desenho) de gráfico de barras ao objeto fig usando fig.add_trace(). Configuramos o eixo x como a coluna "Nº de Vagas" do DataFrame top_aptos_garage e o eixo y como a coluna "Quantidade" do mesmo DataFrame. Definimos o nome deste gráfico como "Top Aptos".
- **fig.add_trace(go.Bar(x=bottom_aptos_garage["Nº de Vagas"],y=bottom_aptos_garage["Quantidade"],name="Bottom Aptos")):** Da mesma forma que antes, adicionamos outro trace de gráfico de barras ao objeto fig. Configuramos o eixo x como a coluna "Nº de Vagas" do DataFrame bottom_aptos_garage e o eixo y como a coluna "Quantidade" do mesmo DataFrame. Definimos o nome deste trace como "Bottom Aptos".
- **fig.update_layout(title="Quantidade de Imóveis por Nº de Vagas", xaxis_title="Nº de Vagas", yaxis_title="Quantidade"):** Nesta linha, atualizamos o layout do gráfico usando fig.update_layout(). Definimos o título do gráfico como "Quantidade de Imóveis por Nº de Vagas" e fornecemos os rótulos dos eixos x e y como "Nº de Vagas" e "Quantidade", respectivamente.
- **fig.show():** Finalizamos exibindo o gráfico.

Se você ainda estiver com algma confusão sobre "add_trace" e as atualizações de imagens no Plotly, recomendo a leitura deste trecho documentação: [https://plotly.com/python/creating-and-updating-figures/#:~:text=modifying%20its%20properties.-,Adding%20Traces,adds%20it%20to%20the%20figure](https://plotly.com/python/creating-and-updating-figures/#:~:text=modifying its properties.-,Adding Traces,adds it to the figure). 

Importante: Não é necessário se manter com a mesma biblioteca por toda a análise exploratória. Eu, particularmente, acredito que melhora um pouco o visual, não causando nenhuma distração desnecessária no leitor. Mas a gente poderia ter criado os mesmos gráficos que criamos acima utilizando o countplot() do Seaborn, que é bem mais direto:

![img](https://lh3.googleusercontent.com/ZxNdGm7-VbS4zN9p7UAax7BKzkmg7a40QSPE3YAGx2WaglkoMVEPcPmfcaBCfESEYRTBgkGgghX7B6JIAymzPbmBT1vjSajXrDNHtvauKIJjrzNAXOI3_LUMTKeF0vYl4QLk3R0t6X09KSe6r5Jxcag)

Fica como dica, caso você realmente não se adapte ao Plotly. O grande problema, para mim, é que o tempo economizado com a sintaxe do Plotly vai ser utilizado no plt.text() quando você quiser colocar os valores numéricos nos gráficos do Seaborn e Matplotlib, já que não é uma sintaxe tão direta também!

Para encerrar nossa análise, vamos explorar as relações entre as variáveis:

![img](https://lh5.googleusercontent.com/rKBpW1007pPy2uJFhLVRi2Nu6tcsP03LTw3DsAJ3wSSo3-wMOOwhB-1otlSQeuQUMqAndoYHwoy1F_Y3qzUMyAGMYIG-_HKtilfhDKsyDqUcwv0oHg9wW6Jc0c-4vIJPpj8L_ivAqK6Ly0M5URwML58)![img](https://lh4.googleusercontent.com/O8z6zeNwW0y7Aa-EL-Nvnx38E8xcDt308Y33fXTnfdYT4qwLaoSOlCzdtGzjd8fjC30kOmclLE-eleVwa0_s8EtADTquyw39FIhkfx9TiZf3HEm2tUAoIpUZ2QQeYpzKM_JqVF0GSgHCAZuyw8X9ujY)![img](https://lh6.googleusercontent.com/bVX-1GLCC-dzC1EqwAxiOFnWWzmS2YA4g-5z2Ncau-_T9sAc_McjmpneVxXsmWGJM_gjdf_jETdek6PgHtCAxXa1rHOEbMkZuu2kYYyk_Pytl8PEvznJusOQowPkNJrhIk5GJF_uZj-M1WH8wdGYbm8)![img](https://lh6.googleusercontent.com/pQTn2kBhwmLz-XtVfbf-W4eng3B3X2VG9oB6BLjvml50ePEAKzGYE7JJmCH0DWAHI2RphICBIAZ6OFvKvL0J4vjBPU1CpttA2y1KEDHeeJqhDkjWyuR70ARZCB1dpbZlKr0KgEyd4n8OxL-QVXCtQZM)

![img](https://lh6.googleusercontent.com/D5s9qcyxnqGvBbiw8uP25aQpngMP-7W6UkmjxbSZkA7gnsLu6zidI6CfyhMd1MvhL1G88EnPyOxNGj7Jzj0KajIp_3MjhZh6Yh8myVjzfoKotYwtlJp-M-FYdq48d1-yuCvA3wc5I1iwsESpeCIKR_k)

![img](https://lh5.googleusercontent.com/P0m4v3We1Y127-jjXuqjVSImVaFP5pnAG8l9FYyWfusr61FUjQgjVEzZhPsdus4uRRX3zp1maaGh2CeQiLcyr36V6yeAaNd7RcI9rOPFKzNfcazLjKJ5V5pNJjtfZLOOEftlVmZOjRFO6slJzFRF6SI)

Complementamos com mais alguns comentários e dados, já que os boxplots por tipo de imóvel são pouco claros:

![img](https://lh5.googleusercontent.com/ug7REEam5XeST_gvgtmNEmJ4jx_s091JwPKWT-OHQw1LA7t0w5dVZUTRZ4-ZAjdPfZdlQthoe2878V5IBq1gPG93HpyuICzTQOH3bmZADFRpln3EZTFfPkrgJe__2U7x4HV-Zib_7GlVApRHYSigtqs)

E enfim encerramos nossa análise, bem robusta, com gráficos detalhados, insights e até referências externas para ajudar na análise. Para fechar, precisamos de uma conclusão:

![img](https://api-club.hotmart.com/file/public/v5/files/53193833-245f-429c-bd33-b539d360365d)



Não dá para dizer que é o melhor reporte que eu fiz, ou o mais detalhado, pois havia mais a ser explorado (que você pode dar continuidade, inclusive). Adicionalmente, a gente poderia ganhar alguns pontinhos se tivéssemos utilizado dados de fora do Kaggle, já que a plataforma é considerada por alguns profissionais algo longe da realidade (algo que eu discordo, mas é papo para outro dia). De qualquer forma, eu duvido que algum gestor ficaria insatisfeito se isso estivesse no portfólio de um júnior e não utilizamos nada de novo, tudo aqui está ao alcance de qualquer um no Clube.

Nas próximas semanas, voltaremos a falar de modelagem e ainda teremos materiais de estatística. Se você pegar a ideia da análise exploratória e incrementar com o que está por vir, pode ter certeza de que seu portfólio vai ficar muito a frente do que de seus concorrentes!