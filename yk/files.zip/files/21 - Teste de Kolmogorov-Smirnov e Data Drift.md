# TESTE DE KOLMOGOROV-SMIRNOV E DATA DRIFT  

## INTRODUÇÃO 

Fala, pessoal do clube! Tudo tranquilo? Hoje, vamos falar sobre um tema que irá diferenciar o seu portfólio. Só pelo nome dá pra saber que não é qualquer assunto, né? Na verdade, é um tópico extremamente importante na estatística que, hoje, vocês irão aprender. Vou dar uma breve introdução ao tema e, logo depois, irei aprofundar.

O teste de Kolmogorov-Smirnov é uma técnica estatística que utilizamos para verificar se uma amostra de dados segue uma distribuição específica ou se diferente de forma significativa dessa distribuição.

Como sempre gosto de dar um exemplo para esclarecer, imagine que você esteja realizando uma análise de dados e uma das variáveis é a altura da pessoa. Analisando os valores, você quer verificar se as alturas seguem uma distribuição normal. Para isso, você pode utilizar o teste de Kolmogorov-smirnov. 

Além disso, o teste de Kolmogorov-Smirnov pode ser utilizado para detectar a ocorrência de data drift, que se refere a alterações na distribuição dos dados ao longo do tempo. O data drift ocorre quando a relação entre as variáveis mudam em relação à distribuição originalmente observada. 

Fazer a detecção de data drift é extremamente importante, visto que mudanças significativas na distribuição dos dados podem invalidar um modelo de Machine Learning previamente construído. Logo, realizar a detecção de data drift pode salvar um possível prejuízo das empresas, e uma das maneiras de detectar é utilizando o teste de Kolmogorov-Smirnov.

Ao aplicar o teste KS em diferentes momentos ao longo do tempo, é possível comparar a distribuição dos dados em cada período com a distribuição original (distribuição que o modelo foi treinado). Se houver uma diferença significativa, é um bom indício de data drift.

Em resumo, o teste de Kolmogorov-Smirnov é um teste estatístico para fazer a comparação de duas distribuições. Então, uma das aplicações úteis desse teste é realizar a verificação de data drift, sendo importante para monitorar e manter o desempenho de modelos de Machine Learning ao longo do tempo.



## DATA DRIFT 

![img](https://lh4.googleusercontent.com/9fBqJf86YIBDf_J2QUkGKTmJEseGLtDHNaPjugJOhwaIGPj5L4HooZhf7Jj61OGnGC59tHeQAuRKZXHfnuRNXxh2ekHqKPYrKa6_DgYuX6jHsQbrKmXXU7ba5zVf0FzMAUUWUCZH9sC7qYSCw7WlRfk)

Antes de falarmos do teste com nome difícil, vamos aprofundar em um conceito extremamente importante que nos ajuda a entender a invalidação de um modelo de Machine Learning ao longo do tempo: Data Drift. 

Sabemos que quando vamos treinar um modelo, ele detecta os padrões por trás dos dados e, com esse padrão “em mente”, gera outputs com base nesses padrões. Porém, imagine que ao longo do tempo as características desses dados mudem. Com isso, o padrão que o modelo detectou tempos atrás já não é mais o mesmo.

Para exemplificar, imagine que você esteja desenvolvendo um modelo para prever se um usuário irá comprar em um e-commerce ou não. Porém, algum tempo depois, o e-commerce faz uma mega promoção de black-friday. Será que esse modelo treinado com dados de épocas “normais” irá performar de forma satisfatória para essa nova época? Com certeza, o comportamento de compra dos clientes mudou. Clientes que, anteriormente, compravam uma peça de roupa, por exemplo, estão comprando três. Clientes que ficavam, em média, 1 minuto e meio no site, estão ficando 7. Observe que há uma diferença significativa nos padrões dos dados e, talvez, nosso modelo não consiga se sair bem nessa nova época.

E é justamente esse o conceito de Data Drift, é uma situação em que a distribuição dos dados de entrada para o modelo muda ao longo do tempo. Em outras palavras, a maneira como os dados são coletados, suas características ou suas relações podem se alterar periodicamente.

Visto isso, temos que primeiro detectar quando esse fenômeno está ocorrendo e, depois, se necessário, treinar novamente o nosso modelo.



## DETECÇÃO DE DATA DRIFT 

Para detectar, há diversas técnicas. É muito comum utilizar testes estatísticos para obter um certo valor e compará-lo a um valor crítico ao longo do tempo. Algoritmos tradicionais de detecção de data drift geralmente precisam de todos os dados originais para calcular esses valores, mas sabemos que sistemas em produção geralmente possuem uma quantidade de dados gigantesca, então acaba tornando-se uma tarefa inviável. Uma alternativa a isso seria realizar o teste estatístico com uma amostra dos dados originais, mas podemos perder informações importantes, como outliers significativos que podem afetar a confiança do resultado.

Uma outra alternativa a esses métodos ditos anteriormente seria fazer uma varredura nos seus dados detectando algumas propriedades estatísticas dele, como métricas de distribuição (skewness, kurtosis etc.), média, moda, mediana, valores faltantes e várias outras características dos dados. Após isso, podemos usar essas propriedades estatísticas para aplicar novas técnicas de detecção de data drift. E, dando um spoiler, essa técnica de utilizar propriedades da distribuição é justamente o que o teste de Kolmogorov-Smirnov faz.

Para detectar quando houve um data drift temos que ser cautelosos, pois há alguns tipos de desvios. O primeiro, que eu disse anteriormente, é a mudança sazonal ou cíclica, ela acontece quando os dados se desviam de forma sazonal, ou seja, de tempos em tempos. Lembre-se do exemplo da Black Friday. Todos os anos há uma mudança no comportamento de compra dos clientes devido a esse evento.

Depois da mudança sazonal, temos mais dois tipos: quando a mudança ocorre de forma súbita (quando acontece “do nada”) ou quando a mudança da distribuição acontece de forma gradual. O primeiro caso é caracterizado por mudanças repentinas que acontecem “do nada”. Um ótimo exemplo seria um modelo que detecta ataques a um sistema. Vamos supor que de 1 milhão de casos, 1 deles é um ataque. Note que o modelo está acostumado com um certo padrão de dados (usuários comuns), mas, do nada, surge um ataque que possui um padrão completamente diferente.

O segundo caso - da mudança gradual - é o mais comum de ocorrer. Ele ocorre naturalmente. É inevitável. Ao longo dos anos, o comportamento das pessoas muda. É completamente normal e é influenciado por vários fatores. Um exemplo disso é um modelo de propensão de compra para um certo produto. Antigamente, as pessoas não consumiam tantos acessórios quanto hoje. Então, a reconstrução do modelo ao longo do tempo é fundamental para acompanhar o comportamento das pessoas.

![img](https://lh4.googleusercontent.com/qVvSh0-SQhO5FjlnLl1jNA27_EwraJCj0_1-AuVxLbC_v0SzLduy83me7WxHYWOif-cmDzMyJVsaNIH_u04xwQz6mykP6TiMrMgofZZfmU253OQ9igpZO5ZRmSfJUPZ5OLodUsoRfzd0KwxAoyEPVyg)



## RECONSTRUÇÃO DO MODELO 

Ok, agora que já detectamos que os nossos dados estão sofrendo algumas alterações (seja de forma gradual, repentina ou cíclica) precisamos ajustar o nosso modelo, correto? Na verdade, nem sempre. Há alguns casos em que não precisamos fazer mudanças no nosso modelo. 

Um exemplo seria um modelo de detecção de catarata (problema visual). Note que ele pode sofrer algumas alterações de paciente para paciente, mas é muito difícil isso impactar no resultado final e no padrão dos dados, porque é uma doença que não varia tanto de paciente para paciente.

Além disso, podemos re-treinar o modelo de forma periódica. Podemos pegar dados mais recentes para re-treinar e aprender com os “novos padrões”, por exemplo. Uma outra saída seria treinar vários modelos e selecionar o adequado para fazer as predições para um tipo específico de dados. Por exemplo, pense naquele modelo para e-commerce. Para não precisar fazer manutenções constantes, você constrói dois modelos: um para a Black-Friday e outro para períodos fora da Black-Friday. Assim, durante esse período específico, você utiliza o modelo mais adequado.

É isso, pessoal! Fechamos a parte de data drift. Agora, vamos mergulhar nesse teste “do nome esquisito”, ou teste de Kolmogorov-Smirnov!



## TESTE DE KOLMOGOROV-SMIRNOV 

Já fizemos a definição do teste de forma mais simples, para qualquer um conseguir entender. Agora, vamos utilizar alguns termos mais técnicos para vocês poderem entender bem e se aprofundarem no assunto!

O teste de Kolmogorov-Smirnov é um teste de igualdade entre duas distribuições de probabilidades. Ele pode ser utilizado para comparar a distribuição de uma amostra com uma distribuição de referência ou com outra distribuição de outra amostra. Como falamos sobre data drift, o interessante seria aplicar esse teste de Kolmogorov-Smirnov para detectá-lo, certo? Então, vamos focar em comparar a distribuição de duas amostras. No caso, seria a distribuição dos dados originais (que o modelo foi treinado) e os dados que temos agora. Dessa forma, podemos verificar se a distribuição mudou significativamente e, portanto, houve um data drift.

Quando comparamos essas duas distribuições de amostras distintas, estamos tentando saber qual é a probabilidade de essas duas amostras pertencerem à mesma distribuição de probabilidades. E uma vantagem de utilizar esse teste é que ele é não paramétrico, ou seja, ele não exige que saibamos exatamente qual é a forma da distribuição dos dados. Isso é extremamente útil porque, na vida real, muitas vezes não temos informações detalhadas sobre a distribuição dos dados que estamos analisando.



## A MATEMÁTICA DO TESTE DE KOLMOGOROV-SMIRNOV 

Vamos entrar agora em uma parte que particularmente gosto bastante: a matemática por trás das coisas! 

Lembre-se que disse que teremos um valor gerado pelo teste e devemos compará-lo a um valor crítico, né? Pois é, agora, vamos ver a fórmula para calcular esse valor, que chamamos de D.

![img](https://api-club.hotmart.com/file/public/v5/files/c4073a2b-c405-45ad-8535-d61ab3b21552)

A fórmula acima representa a fórmula para calcular o valor de D, que chamamos de estatística KS (estatística Kolmogorov-Smirnov). Mas o que ela significa?

Vou explicar de uma forma mais simples, porque quero que todos aqui entendam. Imagine que estamos construindo um modelo e, nele, uma das features é a nota do aluno para uma determinada prova. Algum tempo depois, queremos fazer a verificação se há um data drift, ou seja, se a distribuição das notas dos alunos, ao longo do tempo, mudou para essa prova. 

Para responder a essa pergunta, utilizaremos a fórmula acima. Ela compara a forma como as notas estão distribuídas com os dados originais (que o modelo foi treinado) e com os dados de hoje, considerando a probabilidade acumulada até um certo ponto. Em outras palavras, ela analisa como as notas estão “espalhadas” nas duas provas.

A estatística KS vai nos retornar um valor numérico que representa a maior diferença absoluta entre as distribuições acumuladas das notas. Por exemplo, se o valor for 0.1, significa que há uma diferença de 0.1 entre as distribuições. Quanto maior for esse valor, maior é a diferença entre as distribuições, o que indica que o desempenho dos alunos, ao longo do tempo, sofreu uma modificação em seu padrão, logo, há uma grande chance de ter ocorrido um data drift. Essa distância pode ser vista na imagem abaixo:

![img](https://lh4.googleusercontent.com/y9H_u7ZBRVJd174cDs9BWWiyJR2NoZ4OB9Faq3Fc2QMnfU2SW3aDHYj8bbWt6svvE3Afn5yy7UtCMSs-3SnEmC0y-AUOaBPhtvqY-OGs8VUzz57o8T2K-ygjuep1vfUREwuN7s511Qym6-ky4lJq8sQ)

Vamos supor que a linha vermelha representa a função acumulada das notas originais dos alunos e a linha azul a função acumulada empírica, construída a partir das notas que temos hoje. A seta preta representa a diferença entre as duas funções acumuladas, ou seja, a estatística KS (D).

Para deixar mais simples ainda, imagine que a estatística KS seja uma régua que mede a diferença entre essas duas distribuições. Quanto mais distante a régua estiver de zero, maior é a diferença entre as notas antes e depois.

Ao utilizar essa estatística, podemos fazer um teste estatístico para avaliar se as duas amostras de notas são realmente diferentes, ou seja, se houve data drift ou se podem ter mantido o padrão. Para isso, comparamos o valor obtido com um valor crítico (geralmente, 0.05). Se o valor estiver abaixo desses limites, é bem provável que as notas não possuam a mesma distribuição.

Já que estamos falando sobre testes estatísticos, vamos falar um pouco sobre a hipótese nula do nosso teste estatístico. Nossa hipótese nula aqui é que as notas dos alunos hoje e as notas usadas para treinar o modelo são retiradas da mesma distribuição. O p-valor nos ajuda a avaliar o quanto os dados que observamos são compatíveis com o que esperávamos com base em nosso modelo estatístico. Se o p-valor for muito baixo, isso significa que há uma grande diferença entre os dados observados e as expectativas do modelo (notas originais). Por outro lado, se o p-valor for alto, aceitamos a hipótese nula, ou seja, as notas dos alunos hoje e as notas usadas para treinar o modelo são retiradas da mesma distribuição.

Para calcular esse valor, leva-se em consideração a estatística KS (o valor D) juntamente com o tamanho das amostras de ambas as distribuições. Os valores críticos para rejeitar a hipótese nula, ou seja, para dizer que as notas não foram retiradas da mesma distribuição, são de 1% a 10% (geralmente, utilizamos 5%), o que significa que qualquer p-valor menor ou igual a esses levaria à rejeição da hipótese nula.

Por exemplo, imagina que tenhamos 100 notas dos alunos hoje e treinamos o nosso modelo com 100 notas também. Calculamos a estatística KS com base nessas duas amostras e obtemos um valor de 0,08. Em seguida, calculamos o p-valor correspondente (utilizamos a tabela abaixo), que é de 0,03. Como esse valor é menor que o valor crítico de 5%, rejeitamos a hipótese nula. Isso significa que há evidências estatísticas de que as notas dos alunos hoje e a que treinamos o modelo não seguem a mesma distribuição, ou seja, que houve data drift.

![img](https://lh5.googleusercontent.com/WpMLlHkbKRscF_pZy0MSaEp2tcczEZoTWttq_IwfCMAXrDY93ZFnryLaRSewXVDNgkZ9RASK704mHcUkdKCSUtquMgkWBfdTmnJoSQ8bIAZCMJgXKaQsXL1rpaMhZohI7eGzjxPOEJQMagVitHEBLsE)



## IMPLEMENTAÇÃO EM PYTHON 

Agora que já vimos toda a parte teórica, vamos realizar esse teste de Kolmogorov-Smirnov em Python!

Para implementarmos e verificar a existência de data drift nas notas dos alunos, podemos utilizar biblioteca scipy que inclui diversas funções estatísticas, incluindo o teste KS.

Abaixo, vamos importar as duas bibliotecas que usaremos:

![img](https://lh6.googleusercontent.com/NiDrNc3Od0hEO557b7xd4U39042yLHUoGg7CPdRW-wCxzFsdCCfWDwBfKr0YdVOQMe4Eq7K_T1jeJn02mCo65KA_OAN-UpX_Gnfv60GGz8KJZxVtrf4sH11GtEnJjnKsdCgXED3i32Drd_qQhVCDT9k)

Agora que já importamos as bibliotecas, vamos criar duas listas: a primeira, representando as notas dos alunos hoje e a segunda, as notas dos alunos, para a mesma prova, quando o modelo foi treinado.

![img](https://lh3.googleusercontent.com/jnvzCyoqnX3-3kbfR-uMBqp96BcA2fjG09KnKZDGvSTaqyc-WGNplkScoon6hKjBgcvW2027nrxps9QvScB_nwfW0tUy1UpO7sKvemLOR4IUTZ3tzt61D8MCFwEgeTPZbBEh2kr3oEbgmfwoAsWZrsY)

Agora, vamos executar o teste de Kolmogorov-Smirnov para comparar as distribuiçoes das duas amostras:![img](https://lh4.googleusercontent.com/2coA0PQqT2Q3sT4_-pbF3fbkjYotbNsagq4IJOA31sKibW_pR0L-RZuQaes6smRHtq1alesXQs1whRGSaN7AlQ7nXxBrkxJ9Jnrz8We_Uq9bj3FM8nBXw9SLNNnKS8l7bPGQa_z--WSqlEEcqZmaUZc)

Quando rodamos este código, obtemos a estatística KS (neste caso, com valor igual a 0.2) e o p-valor (neste caso, com valor igual a 0.9945). Como esse valor de 0.9945 é maior que 0.05, o valor crítico, então não há evidências de data drift. Ou seja, as distribuições das notas são estatisticamente similares.

Abaixo, observe as duas distribuições comparadas:

![img](https://lh4.googleusercontent.com/QuQTHBnXcwugxNTYYR0336HJHfOfcKdKm0Rtcr20-0LKhhgXl_eoxXnmof_ECi__t8yHhhzrxsbSlbsaiJ8bBH7sUu8p_uDaNbcd12XdiTkTLagx13Z7Jy_WSvZVgPrIy3CVvo36PtplQLxkKuspUPY)

## CONCLUSÃO 

Então, é isso, galera! Hoje o material foi mais denso, mas espero que tenham curtido. Não se esqueçam de construir vários projetos em cima disso, vários artigos e posts no LinkedIn. É um tópico que raríssimas são as pessoas que falam sobre isso, portanto, façam para se destacarem!

Abraços,

Anwar.



# Perguntas



==>  PERGUNTA

Quando devo utilizar o teste de Kolmogrov e quando devo utilizar the Mann-Whitney U?   Poderia esclarecer as diferencas? e como priorizar?

==> RESPOSTA

Fala, Leandro!  Pergunta interessante, sendo sincero, nunca tinha parado para pensar e até por isso vou deixar as fontes que usei para garantir que não vou falar nenhuma besteira. Até onde eu entendo, o KS será adequado para comparar as distribuições, a forma delas, enquanto o Mann-Whitney U vai comparar as médias (ou medianas) de duas distribuições. Aqui estão algumas orientações gerais para ajudá-lo a escolher entre esses dois testes: Se você estiver interessado em comparar as médias de dois grupos, o Teste de Mann-Whitney U é geralmente a melhor escolha. Se você quiser verificar se uma amostra segue uma distribuição teórica específica, use o Teste de Kolmogorov-Smirnov. Se você quiser verificar se duas amostras vêm da mesma distribuição, você pode usar o Teste de Kolmogorov-Smirnov. Se as amostras são pareadas, a versão pareada do teste de Wilcoxon (também conhecida como teste dos sinais de Wilcoxon) é uma opção melhor do que o teste de Mann-Whitney U.  Dos materiais abaixo, oh o que dizem "O teste de Kolmogorov-Smirnov destina-se a averiguar se uma amostra pode ser considerada proveniente de uma população com uma determinada distribuição". Ou seja, estamos comparando as distribuições de 2 grupos. No mesmo material, temos a seguinte sentença "O teste de Mann-Whitney é apropriado para averiguar se são iguais as medianas ux e uy de duas populações contínuas e independentes...". Então creio que essa seja a conclusão mesmo! Eu acabei me empolgando e mergulhei em vários materiais que acho que você poderia dar uma lida também, porque vai te ajudar a ganhar mais compreensão de tudo. Pode até gerar uns materiais para seu portfólio, fazer um artigo no Medium usando estes textos como inspiração, algo do tipo (só uma sugestão mesmo): 

- http://www.mat.uc.pt/~cmtm/ECwww/TestesNP.pdf 
- https://stats.stackexchange.com/questions/530924/what-difference-between-mann-whintey-u-test-and-kolmogorov-smirnov-test-on-trunc 
- https://www.graphpad.com/guides/prism/latest/statistics/the_results_of_a_mann-whitney_test.htm 
- https://www.youtube.com/watch?v=oENvta9jtLk