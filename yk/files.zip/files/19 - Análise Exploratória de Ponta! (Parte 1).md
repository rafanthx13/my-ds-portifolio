## ANÁLISE EXPLORATÓRIA DE 1ª CATEGORIA (PARTE 1) 

Nesta semana, trouxemos um material top para dar aquele upgrade no seu portfólio! É hora de elevar suas habilidades em análises exploratórias no Python, de sair do básico e realmente chamar a atenção do recrutador, vamos aprender a caprichar de verdade nos gráficos! Afinal, tá na hora de usar todas as armas para chamar a atenção do recrutador, né?

Desta vez, a gente vai muito além dos gráficos simples do Matplotlib e Seaborn. Hoje, você vai mergulhar em detalhes que fazem a diferença. Prepare-se para adicionar textos, caixas de mensagens, dentre outros detalhes nos seus gráficos. É hora de subir o nível mais uma vez, bora!



## COMEÇANDO PELO BÁSICO 

Antes de darmos início aos exemplos mais básicos, precisamos baixar o dataset que será utilizado de exemplo ao longo do material:

![img](https://lh3.googleusercontent.com/Sv2n3w8OWcf-jPd7Tc_vULkZvxnfh_igLlS5rirOSHmgPF1E6M9t3xRlfMCikbONtdwq8eYHA3vtQTq2XswhF7Lg1zVQl3WXyjItLSOZUchPX0P7vj4Tw7G4avWX_k7VZIcCIGKz6gfignHnfeezTsQ)

Os dados dizem respeito a gastos com planos de saúde e podem ser baixados [aqui](https://www.kaggle.com/datasets/mirichoi0218/insurance).

Vamos começar importando os dados e olhando as primeiras linhas do dataset:

![img](https://lh3.googleusercontent.com/DDO98fEOtZZHvpv-QIUzog1a_V_tnX1zlok-gVWwbSxzeuUOTvQBdbyp2VXVgAGSNk1spywQBbz22CquWkCONefoycgQNszQYqvibIkX34RAt02SmFWdMTQvlL9P4WgxsnI08LzShixa0AGGi01pI8M)

O output:

![img](https://lh3.googleusercontent.com/QQbruZDfQxT1hNPOviRKva1InG9dC4bLPthKTxlhrEqqsSgbthXsu7Y_7Wffw--skt-W2LeCi49nMQKxA3wz4l5XwO6sHe7MTKP9sxxhB3Q_-2tEwbLM-Vqk2ej3iMhmEDMpY-yk5880fTzBtv6RNE8)

Veja que dataset interessante para seu portfólio, ele possui diversas informações a respeito da pessoa, sua idade, sexo, IMC, quantos filhos possui, se é fumante, a região em que vive e os custos com plano de saúde. 

Bom, ignorando por enquanto as possibilidades de modelagem, vamos ver como poderíamos fazer uma boa análise gráfica. Por padrão, muitos iriam utilizar funções mais tradicionais e simples do Matplotlib, como o scatter:

![img](https://lh6.googleusercontent.com/29LL8IveE7Bq0pLZti4GKR_oZ1FSQ3ZxQwyj04nK9bOW1IDkxGKponsbbJ_etr_sAwy6r8uQIaowOPhX8T9AYnuovPf8NmppM1AGxYQh_X02NWg3dzu27wx7JeRwIDwBbnk6sb4db4Zo4KwI5lPwR1Q)

![img](https://lh3.googleusercontent.com/_4Jce8dw2HwtXRPQNEip962sBxnEbfz8YP7JGK5WvVTX5O-wHMwUQsGQxSeGn3EEhKavMCu4NtmYt5LWBbDoMxg9Fije5TRYT1A0MTxfWgfVZAbeKM49DBmPwjhOzwJNnwTy2m1XxtKsKA__Pdgyj1s)

Ou o histograma:

![img](https://lh5.googleusercontent.com/aStVogMWHcIZKqZ8W8WWAjjnUAr49yFt6qIxmx7UL6QRju2gkarB11ggnl1r7og6xVFdRPaf4ZVxRyRJqdEwpZETzscHK9k_hIVjmA0TJ58BXoeCBX4g5Wd0oE0byYuZwQ-_ACgxcZzZ7IzNJI6Y0_c)

![img](https://lh4.googleusercontent.com/76XydDetJXZIE70xa7rq2MkojCcO5RPaO6ndbKUZR1XdPQPQPk_3VY0M0vtPRhwZ15-VLO95HGR_9ssSx40aBEDp3z3uXtw-Lqh2SG1n5v0FEo_Oj96VV6gjeFV9scSFupDzE0wchRk0XQWC6OLhA54)

Ou ainda, um gráfico do Seaborn, como o de contagem:

![img](https://lh5.googleusercontent.com/b9gQVR0e1aDLuyTJ0yIxWSGwJX3J178XWUYPHESa60exGuVK5N7-1H7Ki5vyiMDb4yguLEEq4dmWPaJTDBmtzvEjdzCP9n6kNs5RQYycrPBb0UJzHU8r8_Bl9kjBP99l9CxN0YoWDxNDpbWsmCUbDo8)

![img](https://lh6.googleusercontent.com/4AmbWcdVfpooFAfY03pSsa7onCrxFZuCbciRwfi3YsjyDR0-XmS6Jp184Si7JcaGIJonxhKsBnDp92LL-6bFW2kGuGLtxwCbL62t4gl-L0zZ0tuovItQXkHa7IgGUcR3wxBniagQMOJGR00WiHEgJos)

Claro, os gráficos passam informações interessantes. Podemos ver, por exemplo, que há muito mais não fumantes do que fumantes no dataset. Podemos observar também uma concentração de jovens pelo histograma, ou ainda, uma baixa correlação entre IMC e gastos com saúde. Entretanto, nenhum dos gráficos acima se parece com o que a gente vê em notebooks que aparecem como vencedores de campeonatos do Kaggle, ou sendo muito aclamados na internet.

Não faltam apenas detalhes no título e nos rótulos, mas também faltam coisas que podem ajudar a interpretação, como caixas de mensagens, variação nas cores, além de criatividade mesmo, designs diferentes. O material de hoje será focado em levar vocë um pouco além na análise exploratória, vamos aprender a trabalhar melhor esses detalhes!

Se você não lembra de nada disso, ou se você é um iniciante em análise exploratória, assista aos seguintes tutoriais:

- Como fazer gráficos no Python: https://youtu.be/KMEJAJ1fwfk
- Gráficos no Python Utilizando Seaborn Pt.1: https://youtu.be/8aVgS3EW2zs
- Gráficos no Python Utilizando Seaborn Pt.2: https://youtu.be/lpNw-ut2Vb4
- Análise Exploratória no Python (Live mais detalhada): https://youtu.be/yj3JfNSuQs8



## ADICIONANDO DETALHES AO GRÁFICO 

Primeiro, vamos começar aprendendo a lidar com textos nos gráficos, seja usando nos rótulos ou adicionando mensagens, o uso de textos agrega muito a uma boa análise!

Começaremos adicionando rótulos aos eixos, título e modificando as cores dos elementos:

![img](https://lh3.googleusercontent.com/M5J8iqwgsPrrG4gWg3e1Z7SX2-GsgYdbf4zxBqfqA0CadfjVNTPuNkhlT8abOHj-7j9xxWGshvDrJXoXDeNxYng4UrMuobngTo8jwdM4mGWtuPzMseobyUWskAvBmBp14k8DZZgLiwdlCYdTuMu8f60)



![img](https://lh3.googleusercontent.com/B_pNfG2hBkpAAlN3WiOpv_ladSFkXGobyVRWxrGmhl7-w9H6UcDVEw2rtjL7mSr_5KSXwcJ80XjChMJle0pWSV0molvNPEWYoa5qe3cyoLzuFNj0JswudfOVwvQLGYEQlaezfr_5tupxbzksmk16sh8)

Veja que o gráfico no Matplotlib é bastante intuitivo, você apenas vai construindo parte por parte dele e adicionando (ou removendo) o que deseja através de comandos específicos, como xlabel (rótulo do eixo x), ylabel (rótulo do eixo y) e title (título do gráfico)!

Podemos ainda mexer nos contornos do "quadro" em que o gráfico é plotado.

![img](https://lh4.googleusercontent.com/IogaSbK4ExFHT4nL928ho7UsX0qsbGWUDruAkLy_b3-mni01QhHukDg9M4v8U_Zv7PDsM9PQ49A_B8Oj4wlC2ntSNEh_itXkBSRYAY9_M1NGedQCqJDOCLKHpVHURctDRWfKsR_zf7vJLb8YgfJT-og)

![img](https://lh4.googleusercontent.com/Ck9wWkrWSTBXu2qUy1Cte_QZJ-8Qlnh2WeguMbH_TL2sS5XTIxSihWthwjxcZe318otHVsAYEZxKXYiJ7egkLseuoQPjvn92FroeWD4gdY5mHnYvL9LpXkqVS7x194IQb3PAF4hxFBfDEaV4Pb5BCl0)

Você vai ver que este segundo gráfico é bastante comum entre algumas pessoas mais experientes, pois segue as boas práticas ensinadas por referências da área, como é o caso de Edward Tufte.  Nas boas práticas de análise exploratória, é falado muito sobre remover o que não é estritamente necessário, pois isso, em teste, facilita muito a leitura. Portanto, até mesmo essas linhas acabam sendo removidas.

Pela primeira vez, eu acho que o código ficou um pouco menos intuitivo, por conta do gca(). Esta é a abreviação de *get current axes* e precisa ser utilizada para mexer nos "spines", os contornos do quadro

 onde traçamos o gráfico.

Eu acredito que existe um jeito mais intuitivo, de modo geral, mas que pode causar uma pequena confusão na sua mente no começo, por conta da mudança no núcleo da sintaxe.

Veja o código a seguir: 

![img](https://lh4.googleusercontent.com/WTkFvUulEZg5_5vZjKLbk8a8aKKt2LqfRSQd1aePZtuusoB2j3NeOBkoFNUs04FeueTicSEL3rtgn64YMIeEfgX3XdNiHohXlvlrGpvfNQWSbqx3ysDszrJYHZTUFJbAcPJK396I96LD8ItnkGWp1Ps)

Ele gera exatamente o mesmo gráfico que geramos acima:

![img](https://lh4.googleusercontent.com/Ck9wWkrWSTBXu2qUy1Cte_QZJ-8Qlnh2WeguMbH_TL2sS5XTIxSihWthwjxcZe318otHVsAYEZxKXYiJ7egkLseuoQPjvn92FroeWD4gdY5mHnYvL9LpXkqVS7x194IQb3PAF4hxFBfDEaV4Pb5BCl0)

O que pode causar estranheza é que além de mudar alguns comandos, como de title para set_title, estamos ainda utilizando o subplot() para a construção de um único gráfico.

Afinal, por que usar subplot se não há **SUB**-plots?

A questão é que o uso de subplot abre espaço para o uso de fig e ax, o que facilita bastante na manutenção dos detalhes da imagem. No exemplo dado, fig e ax são variáveis que representam o objeto da figura e o objeto do eixo, respectivamente, criados usando a função subplots(). A figura (fig) é o objeto que representa a área em branco onde o gráfico será desenhado. Ela pode conter um ou mais eixos (ax). O eixo (ax) é onde os elementos do gráfico, como barras, linhas, pontos, entre outros, são plotados. Ao criar a figura e o eixo usando 'fig, ax = plt.subplots(figsize=(8, 6))', estamos atribuindo o objeto da figura à variável fig e o objeto do eixo à variável ax. 

Em seguida, as funções como 'ax.bar()', 'ax.set_xlabel()', 'ax.set_ylabel()', 'ax.set_title()', entre outras, são usadas para configurar e personalizar o gráfico no eixo específico (ax). Ter objetos separados para a figura e o eixo é útil quando você deseja fazer modificações específicas em um ou em ambos separadamente. Por exemplo, ajustar o tamanho da figura, alterar as propriedades dos eixos, adicionar legendas ou títulos, configurar os limites dos eixos, e assim por diante. No final, a chamada 'plt.show()' é usada para exibir o gráfico na tela com todas as configurações e personalizações aplicadas.

Em resumo, fig é a figura que contém o gráfico e ax é o eixo em que o gráfico é plotado. Eles fornecem uma estrutura organizada para a criação e configuração de gráficos.

Quer ver mais um exemplo do Matplotlib, para reforçar? Bora:



![img](https://lh6.googleusercontent.com/OfmP_MSN4gx6wd5TkrXkXQz5cSfDVWJ6D3HA3l67RuCkJ4bKbGaRkxkvIfds_1Y0_TPLU5QNpBgooxt5c67I8ulw5qeAJwNychFGtRds6OPSVlNJ44bNmYwICPYMK-QO8AWQiYaqm2JZPIBzFZ6t6Uw)

![img](https://lh6.googleusercontent.com/5ITrSJAdiYySyVqJVbUXcdMRW5Qhjwh1ud7HjPt3TMfbLzCOrjexgKYjyv1Ti4UXum70n4KYiRNOA4kgKSf1opCj9xj9jmYL4U0ktiMykYTOWoeT867QoV5cl2vqSFDkBq8VKK1co8jvpWaypLoENc8)

Ficou mais tranquilo, não?

Aliás, você notou que parece existir uma correlação, ainda que fraca, entre idade e cobrança? Parece que temos 3 retas ascendentes. Vale dar uma investigada no futuro!

Bom, antes de avançar, que tal você testar seus conhecimentos? Não tem nenhuma análise exploratória sua que valeria a

 pena dar uma trabalhada nos detalhes? 

Eu aposto que tem, vale dar uma pausa e já fazer uns testes, aproveitando para reforçar o que foi aprendido!

Dando sequência, vamos para o uso do subplot na criação de múltiplos gráficos. Eu quero criar, por exemplo, um gráfico de dispersão de cobrança x idade e de cobrança x bmi lado a lado, isso vai facilitar a leitura da análise!

![img](https://lh6.googleusercontent.com/xHXECVQ4fCxcTS8A5LKdHKeA-SB86Arn47cl6rueBpxL8OilzOiouzJ-Zw2WsDd-_VfMfGe6HIHBRLYMSQSxLTLXHYvd7VyT2BRzKiLnGdT_WrZt7ViAJrHacJaDZgR0uAHwNLb876bULOAQXkQwyLA)

![img](https://lh5.googleusercontent.com/r4tFkdvE0-Eg7cRy_KBR-ySxbZAsEWbMumgNfNRsvIb0ZjXUVoDkQz0OH7L_rBe_BG1cJe82JVeKAfbVIwRjBxQKGVSUd5RM0NinAN6ngFwR5ksuzqoQlhqwNZ9_YmesuqWXkhyNKtujMAGABQ9oBMA)

Vamos complicar? Que tal fazermos uma análise que envolva uma variável categórica e uma numérica? E aí, bora demonstrar como pegar a média de charges por cada classe de diferentes variáveis categóricas?

Você poderia fazer isso com o matplotlib, usando o bar plot. Entretanto, para ampliarmos mais o número de ferramentas que você conhece, vou utilizar a estratégia para plotar gráfico com o Pandas!

![img](https://lh4.googleusercontent.com/NH9f5yPbyPajXCaizkQF37c0n9TUwA-YcO4hknvWy-aWQdkfdI6ysSDZUIoqSOUpD6x0K95oxcfVk45h9KX4OCe72Qvfe0XTQXRGLFab8k2TVVMTaDB2XJgQ54E_bZDxO0WWJqIb_SVgFl83arq5ghI)

![img](https://lh5.googleusercontent.com/e9azVO6LbUByMGtqW7ZZZTti_S1PsCx_T7EVoq_NofXZLppn-HisR4rasitkZYCdLQTnQMKuNZriJqDy8jim_CFkxLP-Km5B_nc1IjbGZYss4yMJB-uxos0G6_iTrZah3y0XNSObcJ66rRUowR7cokc)

Desafio 1: Construa estes mesmos gráficos, mas com o Matplotlib, ao invés do Pandas.

Desafio 2: Remova os spines do topo e da direita dos 4 gráficos.

E se quisermos subplots de gráficos do Seaborn?

Neste caso, muda um pouco, pois a posição do eixo (ax) será passada como um parâmetro da função que você está usando para traçar o gráfico.

![img](https://api-club.hotmart.com/file/public/v5/files/29ef0979-4033-4231-9871-e402e3bcc40b)

![img](https://lh4.googleusercontent.com/KcGxQ5heb2dLJwbAvJot_7EK7hPeTOQWxSonZWrisJAO5KxN2Vff8mA2s27p3Quk6jHZuQsSAR-G0uJGe5R-p2aUzf0OT4pK_gUZhknVrwW4b3CslsK6xhZdD872xQjCWCKvdIOWIZpASevk0HOS3dw)

Desafio 3: Que tal escrever um tutorial explicando detalhadamente cada parâmetro do Matplotlib ou do Seaborn? Não é todo mundo que sabe tantos detalhes! 

Certo, agora já sabemos fazer gráficos com o máximo de detalhes, mexendo nos textos, nas cores e até mesmo nas linhas do "quadro" (local do plot) dele. Mas alguns truques ficaram de fora e eu vou mostrar agora:

![img](https://lh4.googleusercontent.com/Un8sh-eqrs6y1GrOjdzihIEU8fxopXkT9f2bOvy4BPAD8nyrYwNhpjyEvpGaFD7Fs2NO_ZdAOgzd5uT91VGAUWlI_pqtetorYUP2EKG9S0qSq8x5COybipSh_kwSqaAONHaSXU6A0JVKukVSCwhXicQ)

Veja como fica nosso scatterplot de age x charges no estilo ggplot:

![img](https://lh3.googleusercontent.com/i-2l7JHHGLDvE1RPbIgBOj9LzFtbRBzpRBIcDwqlHiV3Dv95AT7OqBwH8xp9teJvNOce7qS4Hbi40bBRRYhfh0DGkR7La1KGKKbWHVbkV5fpdt_dtODnrYlXwrVbUO_cLqBjAYmD3WKPuTBSGW5yBRo)

Eu achei muito melhor!

Outros estilos populares que você pode testar: fivethirtyeight, dark_background, classic.

Todos os estilos disponíveis você encontra aqui: https://matplotlib.org/stable/gallery/style_sheets/style_sheets_reference.html

Normalmente, colocamos o plt.style.use() na primeira célula do notebook, para pré-definir os estilos dos gráficos naquele reporte. Além disso, também é possível deixar o tamanho dos gráficos já pré-definido. Utilizar o comando 'mpl.rcParams' é uma maneira de manipular a configuração de gráficos do Matplotlib globalmente em um script Python. O rcParams é um dicionário (uma instância da classe matplotlib.RcParams) que armazena os valores padrão para várias propriedades que você pode controlar no Matplotlib.

Por exemplo, se você quiser definir o tamanho padrão para todos os seus gráficos:

![img](https://lh5.googleusercontent.com/x17kw0MNci-HOszTzZSQ-haP-zDML3zRWN8rloIMz1wJFlHSrcIUj12D2-j6Yer0BMtjNe7SyO4zA0tqTstQ7WY9SNyFSGGhBivNIsrwAKg3ZdcxPn1E7HSqj-KYoJOPFI3SwZyyczaOVOr1xnA-rRg)

Neste exemplo, o tamanho padrão para todos os gráficos será 10 x 5 (largura x altura).

Você pode alterar muitas outras propriedades com 'rcParams', como:

\- lines.linewidth: a espessura das linhas

\- axes.titlesize: o tamanho da fonte do título dos eixos

\- axes.labelsize: o tamanho da fonte dos rótulos dos eixos

\- xtick.labelsize e ytick.labelsize: o tamanho da fonte dos rótulos dos ticks

\- legend.fontsize: o tamanho da fonte da legenda

\- figure.dpi: a resolução dos gráficos

Para ver todas as opções disponíveis, você pode printar o dicionário rcParams:

![img](https://lh6.googleusercontent.com/pY4BfrZjrlJglKc7soN6scDp0-RVdXFQIH08Qz5AADu0k7jdf25_GNQjPCwawm2AGZhhNXfNdzc-ZzSJqftFBie4ZI77_9qmCW7GSmEppTQNjct8wKxJdGp8RF9T6YEuvRAiLrgDvWTstz6BEMJrw8E)

Lembre-se de que as alterações feitas ao rcParams são globais e afetarão todos os gráficos criados após sua execução. Se você quiser alterar as propriedades apenas para um gráfico específico, faça isso localmente, ajustando as propriedades do objeto de gráfico individual.

Nossa, já sabemos MUITA coisa de Matplotlib! Mas tem algo bem simples faltando, você chegou a notar? Você reparou que nossos gráficos não possuem o valor em cima das barras, ou em qualquer lugar que seja dentro deles?

Colocar rótulos nos gráficos não é tão simples no começo, nem parece muito intuitivo. Mesmo assim, eu garanto que fica fácil com a prática. Tudo o que você precisa entender é que o Matplotlib usa o plt.text() para adicionar textos, mas que você precisa dar a exata localização de onde o texto deve ser incluído. 

Veja, o plt.text() é capaz de criar o texto que você quiser na posição que você der:

![img](https://lh5.googleusercontent.com/WjF8ZC-ZLybT78hJ4x7jht26q0LPIZCBcErYo3T4G2YpXi59IqfGQI48IXqn_fWqot9X0yN1aJmffN0paaQIv0iD7d6eGdrJeOmqQeI_9Kf-RnY0CMDWqAAlqCpY3zdYgRDCn-bFqEFwRZA9OeQnUnI)

![img](https://lh4.googleusercontent.com/lFOApYruf3gWzZj-cnAa3uZi0gxqyYhvc_i9jxAwSu07xpK9yKNTQv63Tbc4LkDeFZTOeySNCKdP4EZrjTaPA_ML-6mEUitSbBLd-02rdsUNJ52RCfEDhTVbBGhJjKHXaukink8V3_VdmV33zt592bM)

Veja que nós passamos os valores indicando a posição onde o texto deveria começar, sendo 5 no eixo x e 2 no eixo y. Além disso, passamos o texto a ser escrito e o tamanho da letra.

É isso o que espanta as pessoas, ter que ficar localizando onde colocar os textos. Afinal, diferente de outros softwares, nós precisaremos determinar exatamente onde os rótulos dos valores devem ficar. 

Por outro lado, você vai ver que, como tudo no Python, estes textos são bem customizáveis! Veja um exemplo dado no site do próprio Matplotlib:

![img](https://lh5.googleusercontent.com/ARWmkaqh3AJbO8eRA8Oty1wySOC7QU1cHYcC2QsCRxUGq8VIZ1idl-30FREVUv5Y5Yt-wthrhXBd5YbYqgqTDDVFsU5la2e977C7FTyga_DqxEM2_L9pUe0SqbbUE_qpSSR3Im-xgX6quCoA7UGUAY0)

![img](https://lh6.googleusercontent.com/s4QvC_rF2TwwrSwwA_dKaEwVKrIORLD2JcQM-GJ9iabuEDxDVdkcJN6fcLbR6qzJvbLfRlmp25cbvZzYcwsXIACwpXcSzcqUXKPWqTEMbGq2r9INBWa6YrjM3_XhrVB0_2-439tK0YmcNSmCDnaiDyY)

Vamos ver na prática como funcionaria colocar os rótulos de valores nos nossos gráficos:

![img](https://lh6.googleusercontent.com/l8zNeNvyW1MzwPIfooPb_Vjw8j-S9sA7tkUhrIP4I4OPYFd2uV5gvWYpekJmIsfd1x14MUIMdkPCPLVug8lAv7FDh-kGt6T_lEEtIEM_ym5pEhANipR49y3rRx_lb97d7gy9xQM1quwuqiBtenKCAgg)

![img](https://lh4.googleusercontent.com/WwLSGuoEXypWj7Tx9tbCdvu_bzhy7fY-b5AAd9GtVm9a9HwrkTrjRuWZmMXByH45xY57v_I7O6SYgvPBJh4YMZlv5B4YnF8Gn4ewP9aBJVry4xQgehhZynOYgfiMIZjqni5Tg88H1ubwFgV7XutGq4E)

Correndo o risco de ficar redundante, vamos explicar passo a passo do que foi feito, porque quero garantir o entendimento do matplotlib, então você vai poder voltar a este material quantas vezes forem necessárias:

\1. Importamos a biblioteca matplotlib.pyplot com a abreviação plt, que é a biblioteca principal para visualização de gráficos no Matplotlib.

\2. Definimos a variável region_types como a contagem de ocorrências de cada tipo de região no DataFrame `insurance`. Isso é feito usando o método value_counts() no DataFrame, que conta as ocorrências de cada valor único na coluna region.

\3. Definimos a lista region_names com os nomes das regiões existentes. Esses nomes devem corresponder aos valores únicos da coluna region no DataFrame insurance.

\4. Definimos a lista colors com as cores personalizadas que serão atribuídas a cada barra no gráfico de barras. Cada cor da lista colors deve corresponder a uma região específica.

\5. Criamos uma figura e um eixo usando a função subplots() do Matplotlib. Passamos o parâmetro figsize=(8, 6) para definir o tamanho da figura com largura de 8 polegadas e altura de 6 polegadas.

\6. Usamos o método bar() no eixo ax para plotar o gráfico de barras. Passamos a lista region_names como os valores do eixo x e os valores da contagem region_types.values como os valores do eixo y. Também passamos a lista colors como o parâmetro color para atribuir cores personalizadas a cada barra.

\7. Configuramos os rótulos dos eixos usando os métodos set_xlabel() e set_ylabel() no eixo ax, e definimos o título do gráfico usando o método set_title().

\8. Utilizamos um loop usando o for para percorrer todos os valores de region_types.values. Em cada iteração, cada vez que o loop passava por um valor, a gente aplicava a função text() no nosso eixo (chamado de ax) para adicionar o valor da contagem sobre a barra correspondente. Veja que o enumerate vai nos dar um dos valores de region_types.values e também a ordem desse valor. Sendo assim, cada loop nos retorna um índice (um número ordenado) e o valor da contagem. Então quando o loop começa, ele retorna o número 1 e o valor da primeira contagem. A gente vai colocar isso no gráfico como sendo a posição no eixo x e no eixo y. Veja abaixo em que resulta cada loop:

![img](https://lh5.googleusercontent.com/K2Eg-SbwI_tFXcin6ri2BANnPWjxyesNmKn8cwK_BSsq44jdV5COhmdWCe3-iuo5Mb58_KZiln-G-xDW3XanGVdrPK4gTL9u4wdKQA0VOc-XYqwI2TxFH9buH66Y7dZvsew26D3xUeNSB3BbHZHFWH8)

Ou seja, nosso texto será colocado primeiro na posição 0 do eixo x e na posição 364 do eixo y. Já o segundo texto, será colocado na posição 1 no eixo-x e na posição 325 do eixo-y. O eixo-x é o eixo na horizontal, enquanto o eixo-y é a altura.

Veja como inserimos o texto:

ax.text(i, v, str(v), ha='center', va='bottom')

Veja que esta função é a mesma que demonstrei lá em cima no plt.text(), ela está recebendo a posição no eixo x, a posição no eixo y e o texto a ser inserido. Ou seja, quando i for 0 e v for 364, que é o caso da primeira iteração do loop, nós teremos basicamente a função abaixo:

ax.text(0, 364, str(364))

Em outras palavras, vamos colocar na posição 0 do eixo x e na posição 364 do eixo y, o texto 364, que é a contagem para aquela barra!

Reforçando mais uma vez: Passamos para a posição x, o valor de i; para a posição y, que é a altura, passamos o valor v; e o texto a ser inserido será o valor de v convertido para uma string, str(v). Esses são os principais parâmetros de text(). Além deles, definimos ha='center' para alinhar o texto horizontalmente no centro da barra e va='bottom' para alinhar o texto verticalmente na parte inferior da barra.

\9. Finalmente, exibimos o gráfico usando a função `show()`.

Veja como ficaria sem o loop:

![img](https://lh5.googleusercontent.com/OonC0AJ9lEWtrshR4LbBlS0A-R90n8dZzqg4sfUINqDjD2YmSZo5J_8Zm5HeeDoix70YtlsncPoKja5SuL9VBMk9heeYaihquGPSBEnScru6vF3V6APds5sQV-252cZLMYISX2l4zTX3bihd4nKA5ww)

Como é muita informação, vamos fazer mais alguns gráficos para fixar?

Vamos ver se a cobrança é diferente para sexos distintos:

![img](https://lh6.googleusercontent.com/OOekcfGHrBAGC1RXfjj8mdh9pU65kVIc5lgTL71n4KMzuueUMIw-Jl0MxpWJdjj5FSkiEkcJsxzl_ZKvD6fCwjyTKOAPvwZm2cG1VFhgZCXdVrhgHOIR5AUqVNxULaz91eDo4JHzGhKNEcMSzWoziTg)

![img](https://lh3.googleusercontent.com/GKT27tv8Rb1HNfZ8Rw7PDBqTIHWANuae1mDhVYCiXSrfgWY55yIN-7Mt-MUlmm12MkBpHlULubDsWGz1Zr82qWJxi29FWxn_u0wMfD2rUUNxhP4xwvhdIMxTNLKUEpUp9rojPm29-ecTeC6zjv64AXk)

Eu tentei fazer do jeito mais simples possível, mas tivemos alguns problemas, como a quantidade de decimais, a posição não centralizada (nós passamos o valor do eixo x, mas o Python entendeu que ali deveria ser o começo do texto e não o centro) e até mesmo o tamanho dos números me parecem pequenos demais. O importante é que entendemos a estrutura, certo? De qualquer forma, bora melhorar!

![img](https://lh5.googleusercontent.com/YXEBeWEAQomrf4wSH25CwXsPL0Lu63ZVY2CLgYKZ3RS6obUvcNhg5xQlaUdMVR0xzk4ebWL6oViLzw_sNcz35y6qelF0xFXa9A1ohHKQtd9MD_joicT2x_taFB5nMLeMlAB7XWbfDKAze70jI9Yxn8U)

![img](https://lh5.googleusercontent.com/aeBzaWZkC2jlF9P9BcNK6yXubzTkTcC7xK9iu5A-VbciPOphVHIvyxH0_vl3aoAMmA9QEWHDmroZUGmCnlzh3xzDQhowIgOye0Ei20mViyDEhoNac-RM9n3MImX6YuohCG2kmrvJbY-9HQn7qLsHUrU)

Vamos dar um passo maior ainda? Que tal colocar uma caixa de mensagem apontando para a diferença salarial entre os dois?

A primeira tentativa óbvia seria usar o próprio ax.text() que aprendemos:

![img](https://lh4.googleusercontent.com/LGSn6poUx7_5lESqjmBe_MWWyJ7Wtt92LigHJ4OpZ6rQfwRbnPNlt8GdTF2HtBxUqF7O8XQmrgT02eDEUaSqjox23x6qZgzKlO2ZYuyhG27tg1T1TY3VKv4joWyLdlmz-vueou3FQ3mPXqkYEpd--zM)

![img](https://lh3.googleusercontent.com/LVKNdVUBB7NRgnhVnUMeoao0RtRdEw79058m1ccYEwJT6O1Dn18dyvegJdkps4UENBAG2V1mjXjtVceXWgz9RqD8QakJuiPyBjcJ6D4wiH9d--qjC6SWdzxCb6n1J-HO8PDHW63sAG50WBDUrd43HI0)

Ele quase funcionou. Conseguimos ver a mensagem, mas temos muito a melhorar ainda, podemos, por exemplo, colocar a mensagem numa caixa, dando o devido destaque, e até alterar sua cor.

Isso não é difícil, basta fazer uso de mais um parâmetro, o bbox:

![img](https://lh6.googleusercontent.com/y7_WPkATBFlkojFiAqaviowoJIeySddZg5GuqtT26cMPkSS4CO2ysO4CsVTEiVX9hqfgJZh6mHdrOieDBcJLu-_UmqzRWL-KYRTlzl8AK6OqPM1uGdO-Q3-1YAX3G5UH3FHZVgZQnNt7xBfFRBOq710)

![img](https://lh5.googleusercontent.com/mtjyj4PSNCA8JohOPIjRWqcJQm3OBtJXMUc-mxSuyoz1PENta6f5VJc6HxVulj1BOK8gROmnNe6b-83j_n9CtgCMhH2agFMrdnk6-DB2E0VfWXJWblQ5LlzEnOfvYh7fSyPBQVuV3bY--xggMSe8OtY)

Vamos detalhar o parâmetro bbox e o que está contido nele:

O parâmetro bbox (bounding box) é usado para definir as propriedades de uma caixa que envolve o texto. É uma forma de delimitar a área da caixa que será exibida.

As propriedades contidas no bbox são:

\- facecolor: Define a cor de fundo da caixa. Neste exemplo, definimos como lightsteelblue, que é uma tonalidade de azul claro.

\- alpha: Define a transparência da caixa. O valor 1 indica que a caixa é totalmente opaca, enquanto valores menores que 1 deixam a caixa mais transparente. Neste exemplo, definimos como 1, ou seja, totalmente opaca.

\- pad: Define o espaçamento interno da caixa. É a distância entre o texto e as bordas da caixa. Quanto maior o valor, maior será o espaçamento. Neste exemplo, definimos como 0.7.

\- edgecolor: Define a cor da borda da caixa. none significa que não há borda. Podem ser utilizados nomes de cores ou códigos hexadecimais para especificar uma cor. Neste exemplo, definimos como none.

\- boxstyle: Define o estilo da caixa. round especifica que as bordas da caixa são arredondadas. Outros estilos disponíveis incluem square, round4, larrow, rarrow, roundtooth, entre outros.

Essas propriedades permitem personalizar a aparência da caixa que envolve o texto. Você pode ajustar os valores das propriedades conforme necessário para obter o estilo desejado.

Além das propriedades do bbox, também é possível definir outras configurações para o texto, como:

\- color: Define a cor do texto. Neste exemplo, definimos como black, que é preto.

\- fontsize: Define o tamanho da fonte do texto. Neste exemplo, definimos como 11.

Você deve estar pensando neste momento "Nossa, é muita coisa". Assim, é e não é. Explico: sim, é muito conteúdo. Mas vale lembrar: olha o tanto de coisa que você sabe hoje que lá atrás nem teria ideia de que saberia na ponta da língua, pd.read_csv, df.info(), plot, import as, e por aí vai! No começo, sempre parece muita coisa, mas eu posso te assegurar que é tranquilo e que fica mais fácil ainda quando você pode pedir ajuda no Google ou no ChatGPT para te relembrar do que está faltando! Fique tranquilo, você vai pegar o jeito!

Agora, que tal dar uma revisada nas suas análises exploratórias do passado e incluir alguns detalhes? Ou repassar o conhecimento fazendo algum tutorial no Medium ou um post rápido no Linkedin! Vai lá interagir na comunidade e ganhar seu espaço!