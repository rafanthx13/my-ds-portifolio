# V4 - Teste de Lógica

## Q1 - Quatro amigos participaram de uma corrida de pedestres

> ==> Quatro amigos participaram de uma corrida de pedestres e conseguiram completar o percurso, cada um com um tempo de prova diferente. Dentre eles, o que chegou em 2o lugar gastou 10% menos tempo do que aquele que chegou em 3o lugar. Já o que chegou em 1o lugar, gastou 10% menos tempo do que aquele que chegou em 2o lugar. O 4o colocado entre eles, chegou com um tempo 13% a mais do que aquele que chegou em 3o lugar. Sabendo que o amigo que chegou em 3o lugar percorreu a distância da prova em 40 minutos, é possível afirmar que o tempo que o amigo que chegou em 1o lugar esperou, até a chegada do amigo que tirou 4o lugar, é igual a Questão 1 Quatro amigos participaram de uma corrida de pedestres e conseguiram completar o percurso , cada um com um tempo de prova diferente . Dentre eles , o que chegou em 2o lugar gastou 10 % menos tempo do que aquele que chegou em 3o lugar . Já o que chegou em 1o lugar , gastou 10 % menos tempo do que aquele que chegou em 2o lugar . O 4o colocado entre eles , chegou com um tempo 13 % a mais do que aquele que chegou em 3o lugar . Sabendo que o amigo que chegou em 3o lugar percorreu a distância da prova em 40 minutos , é possível afirmar que o tempo que o amigo que chegou em 1o lugar esperou , até a chegada do amigo que tirou 4o lugar , é igual a​

URL DE RESPOSTA: https://brainly.com.br/tarefa/53220895

**RESPOSTA**

> O amigo que chegou em 1º lugar **esperou 12 minutos e 48 segundos**.

**SOLUÇÃO**

Para responder corretamente esse tipo de questão, devemos levar em consideração que:  

- para calcular o **acréscimo**, devemos multiplicar o valor inicial por **100%+y** onde y é o valor do aumento;

- para calcular o **desconto**, devemos multiplicar o valor inicial por **100%-y** onde y é o valor do desconto.

Sabemos do enunciado que o amigo que chegou em 3º lugar gastou 40 minutos, então, teremos:

- O 4º colocado levou 13% mais tempo:

t4 = 40·(100% + 13%) = 40·1,13 = **45,2 minutos**

- O 2º colocado levou 10% menos tempo:

t2 = 40·(100% - 10%) = 40·0,90 = **36 minutos**

- O 1º colocado levou 10% menos tempo que o segundo colocado:

t1 = 36·(100% - 10%) = 36·0,90 = **32,4 minutos**

A diferença entre os tempos do 1º e 4º colocados é:

45,2 - 32,4 = **12,8 minutos (12 minutos e 48 segundos)**



Leia mais sobre **acréscimos e descontos** em:

[brainly.com.br/tarefa/38621444](https://brainly.com.br/tarefa/38621444)



## Q3 - Dona Araci participa de um programa de auditório

> Dona Araci participa de um programa de auditório que oferece prêmios. Três prêmios serão entregues a quem acertar quais objetos valiosos estão ocultos em três baús, enumerados de 1 a 3 e posicionados lado a lado nesta ordem. Os prêmios são: um anel de brilhantes, uma barra de ouro e uma tiara de esmeraldas. Ao lado de cada um dos baús há uma pista escrita em um cartão. Dona Araci leu as três pistas. Pelas regras do programa, Dona Araci ganhará os três prêmios se descobrir em qual baú cada prêmio se encontra. As pistas dizem o seguinte:
>
> Baú 1 - Pista número 1: “O anel de brilhantes está no baú 3”.
> Baú 2 - Pista número 2: “A barra de ouro está no baú de número 1.
> Baú 3 - Pista número 3: “O anel de brilhantes está aqui”.
>
> Dona Araci foi avisada pelo apresentador do programa que a afirmação escrita na pista associada ao baú que guarda o anel de brilhantes tanto pode ser verdadeira quanto falsa, que a informação contida na pista relativa ao baú que contém a barra de ouro é falsa e que a informação contida na pista relativa ao baú que contém a tiara de esmeraldas é verdadeira. Com estes elementos, Dona Araci levará os três prêmios se disser que os prêmios que se encontram, respectivamente, nos baús 1, 2 e 3 são:
>
> A  anel de brilhantes, barra de ouro e tiara de esmeraldas
>
> B barra de ouro, tiara de esmeraldas e anel de brilhantes.
>
> C anel de brilhantes, tiara de esmeraldas e barra de ouro.
>
> D tiara de esmeraldas, barra de ouro e anel de brilhantes.
>
> E tiara de esmeraldas, anel de brilhantes e barra de ouro.
>
> 

**URLS**

+ https://www.qconcursos.com/questoes-de-concursos/questoes/3410b932-97?from_omniauth=true&provider=google_one_tap
+ Resposta em forma de vídeo:https://exatasparaconcursos.wordpress.com/2014/01/23/raciocinio-logico-icms-rj-2014/

**RESPOSTA**:

> D tiara de esmeraldas, barra de ouro e anel de brilhantes.

**SOLUÇÃO**:

OBS: EU vi o vídeo e escrevi

**Enumerando as coisas**

+ Quais sâo os prémios: ANEL  -- BARRA -- TIARA
+ Pistas para cada bau
  + bau 1 - 'o anel de brilhantes está em 3'
  + bau 2 - a barra de outro está no bau 1
  + bau 3 - o anel de brilhantes está aqui
+ Pista para cada premio
  + No bau do Anel => A pista é V/F
  + No bau da Barra =>A pista é F
  + No bau da Tiara => A pista é V

**Resolvendo**

+ A pista 1 e 3 são as mesmas, sobre o anel de brilhante está em 3
+ Entâo vamo começar a supr que o anel está ou nâo em 3
  + Vamos supor que o anel nâo está em 3
    + Entâo tanto a pista do bau 1 e 3 estâo mentindo
    + Se os baus 1 e 3 sao falsos entao a bau 2 está falando a verde e ele tem a tiara
    + O bau2 que é verdadei diz que a barra está em 1, **MAS** se for asism, o anel deveria está em 3. **chagamos em uma contradiçâo**
    + Portanto 'assumir que o anel está em 3 chega a uma contradiçao entâo
    + **O ANEL ESTÁ NO BAU NÚMERO 3**
+ Supondo que o anel está em 3 entao
  + Bau 1 e 3 estao dizendo a verdade
  + Assim, o bau 2 deverá estar mentindo **Esse será entao o bau da barar de ouro, pois é o bau que sabemos que tem informaçao 100% falsa**
+ Assim, já que o bau 2 dtem a barra e o bau 3 tem o anel entao o primeiro vai ter a tiara
+ Resultado: Tiara, barra, anel



## Q04 - Médicos e fomantes (Lógica)

> Considere verdadeiras as seguintes proposições: I - Nenhum professor é fumante. II - Existem médicos fumantes. A partir dessas proposições, é correto afirmar:
>
> A - Existem médicos não fumantes.
>
> B - Nem todo professor é médico.
>
> C - Nem todo médico é professor.
>
> D - Todo médico é fumante.
>
> 

links

https://www.youtube.com/watch?v=_Mg6G5COePw

https://www.qconcursos.com/questoes-de-concursos/questoes/7183b41b-3e

Resposta:

> Nem todo médico é professor.

Solução:

![](/home/rhavel/Documentos/NOTES-PROJECTS/my-random-notes/ULTIMATE EMPREGO/17-Questoes-Logica/teste-v4/imgs/aux-q04.png)

Pela descriçâo do problema podemos criar 4 conjuntos de médicos

+ Todos os médicos sâo fumantes (O conjunto M dentro de fumante)
+ Alguns Médicos sâo fumantes (COnjunto de baixo)
+ Alguns médicos sâo fumantes, outros nao fufmanete e nao professores e outros professores (o conjunto menor da esquerda)
+ Todos os professores sâo médicos (O conjunto maior) mas nem todo médico é professor

O que tem em comun em todas elas:, 

+ Pela descriçâo do problema **SABEMOS UE HÁ EPLO MENOS UM MÉDICO QUE NÂO É PROFESSOR**
+ Ou seja, alguma parte dos circulos vermelhos chega nos Fumantes

Entâo é letra B **Nem todo médico é professor.** Pois todos os outros casos sâo apenas possibildiades, mas somente essa é totalmente verdadeira



## Q05 - O professor de uma disciplina experimental de um curso de Engenharia

>  O professor de uma disciplina experimental de um curso de Engenharia estabeleceu no início do semestre que, para ser aprovado, um aluno teria de realizar pelo menos 5 das 6 experiências propostas e ter média de relatórios maior ou igual a 6,0. Como Juca foi reprovado nessa disciplina, pode-se concluir que ele, necessariamente,

>  A) realizou apenas 4 experiências e teve média de relatórios, no máximo, igual a 5,0.
>
>  B) realizou 4 ou menos experiências e teve média de relatórios inferior a 6,0.
>
>  C) realizou menos do que 5 experiências ou teve média de relatórios inferior a 6,0.
>
>  D) não realizou qualquer experiência, tendo média de relatórios igual a 0,0.
>
>  E) não realizou qualquer experiência ou teve média de relatórios menor ou igual a 5,0. 
>
>  

Links



Resposta

> C) realizou menos do que 5 experiências ou teve média de relatórios inferior a 6,0.

Soluçâo

Considere:

p: realizar pelo menos 5 das 6 experiências propostas (tem que realizar 5 ou 6);
q: ter média de relatórios maior ou igual a 6,0 (tem que ter média de 6, 7, 8, 9 ou 10).

Pra ser aprovado, Juca precisa ter p E q. 

+ Já que ele foi reprovado, aconteceu ~ (p E q) = ~p OU ~q.
+ Resposta: realizou menos do que 5 experiências ou teve média de relatório inferior a 6 (c).

Autor Ana Oliveira
Fonte: qc

## Q06 - Um indivíduo ser contador é condição suficiente

> Um indivíduo ser contador é condição suficiente para ele ter condições de trabalhar no ramo de Auditoria. Assim sendo, ([FCC - SEFAZ RJ - Auditor Fiscal da Receita Estadual - Área 3ª Categoria - 2014](https://questoes.grancursosonline.com.br/prova/sefaz-rj-rj-2014-fcc-auditor-fiscal-da-receita-estadual-area-3a-categoria-prova-2))
>
> .
>
> A = os indivíduos que têm condições de trabalhar no ramo de Auditoria sempre são contadores.
>
> B =  todos que têm condições de trabalhar no ramo de Auditoria são contadores.
>
> C  = é possível que alguns contadores não tenham condições de trabalhar no ramo de Auditoria.
>
> D  = um indivíduo que não tem condições de trabalhar no ramo de Auditoria nunca é contador.
>
> E  = a maioria dos indivíduos que tem condições de trabalhar no ramo de Auditoria são contadores.



Links

https://www.gabarite.com.br/questoes-de-concursos/338944-questao

Reposta

> D = um indivíduo que não tem condições de trabalhar no ramo de Auditoria nunca é contador.

Soluçâo:

Essa é fácil:

Teoria dos conjuntos: **Todos os contadore estâo dentro do grupo de auditores** sabendo isso vamos ver cada uma das afirmaçoes => 

Desenho: Dentro do grande conjunto de auditores há um subconjunto menor (mas nâo necessariamente igual0 de contadores e todos eles estoa no de auditores)

+ A = os indivíduos que têm condições de trabalhar no ramo de Auditoria sempre são contadores.
  + Nâo, pode haver nâo-contadores que podem ser auditores, nâo há nada que impossibilite isso
+ B =  todos que têm condições de trabalhar no ramo de Auditoria são contadores.
  + É a mesma coisa dita na alternativa anterios, entâo nao
+ C  = é possível que alguns contadores não tenham condições de trabalhar no ramo de Auditoria.
  + Nâo pois contradiz a afirmaçao de que'todo contador => auditor'
+ D  = um indivíduo que não tem condições de trabalhar no ramo de Auditoria nunca é contador.
  + Sim, pois, se ele fosse contador ele iria ser auditor o que contradiz essa afirmaçao, entâo **ESSA É A RESPOSTA**
+ E  = a maioria dos indivíduos que tem condições de trabalhar no ramo de Auditoria são contadores.
  + Nâo, pis, nao dá pra dizer que é maioria ou menoria, nâo temos essa informaçao



## Q07 - Uma afirmação que seja logicamente 

> Uma afirmação que seja logicamente equivalente à afirmação ‘Se Luciana e Rafael se prepararam muito para o concurso, então eles não precisam ficar nervosos’, é
>
> A
>
> Se Luciana se preparou para o concurso e Rafael não se preparou, então eles precisam ficar nervosos.
>
> B
>
> Se Luciana e Rafael precisam ficar nervosos, então eles não se prepararam muito para o concurso.
>
> C
>
> Se Luciana e Rafael não precisam ficar nervosos, então eles se prepararam muito para o concurso.
>
> D
>
> Se Luciana não se preparou muito e Rafael se preparou muito para o concurso, então Luciana precisa ficar nervosa e Rafael não precisa ficar nervoso.
>
> E
>
> Luciana e Rafael se prepararam muito para o concurso e mesmo assim ficaram nervosos.

lINKS

https://www.youtube.com/watch?v=Uj7LaxEWaao

Reposta

> B - Se Luciana e Rafael precisam ficar nervosos, então eles não se prepararam muito para o concurso.

sOLUÇAO

+ Essa afoirmaçâo é um 'SE ENTAO' e tem duas equivalencias
  + COntrapositiva (inverte a ordem e nega: p => q === ~p => ~q
  + Pela logica: p => q == ~p v q
+ Sabendo disso temos duas proposiçoes
  + p: Luciana e Rafael se prepararam muito para o concurso
  + q:  eles não precisam ficar nervosos
+ Entao so pode ser:
  + Contrapositiva: Se eles precisam ficar nevrosos entao Luciana e rafael nao se prepera muito para o concuros
  + logica: Luciana e Rafael nao se preparam ou  nâo precisam fica rnevrosos

**A UNICA QUE TEM ALGUMAS DESSA É A LETRA B**

> B = Se Luciana e Rafael precisam ficar nervosos, então eles não se prepararam muito para o concurso.



## Q10 - Quando dois dados idênticos são lançados simultaneamente

> Quando dois dados idênticos são lançados simultaneamente, qual é a probabilidade de se obterem dois valores diferentes cuja soma é par? Prova: [FUNPAR NC/UFPR - ITAIPU Binacional - Profissional de Nível Universitário Jr - Área Computação - Sistemas - 2017](https://questoes.grancursosonline.com.br/prova/itaipu-binacional-2017-funpar-nc-ufpr-profissional-de-nivel-universitario-jr-area-computacao-sistemas)
>
> - A.1/6.
> - B.1/5.
> - C.1/4.
> - D.1/3.
> - E.1/2



LINKS

https://questoes.grancursosonline.com.br/questoes-de-concursos/raciocinio-logico/898399

https://www.estudegratis.com.br/questao-de-concurso/601666

RESPOSTA

> D = 1/3

SOLUÇÂO

+ Um dado tem 6 lados, como dois lados sâo lançados entâo há 36 possívei combinações
+ Para dar soma par ou tem que dar 2 par ou 2 impares
  + Par com Par = 2 com 4 ou 6; 4 com 2 ou 6; 6 com 4 ou 6 = 6 possibildiades
  + Impar ocm Impar = da mesma foma = 6 possibiliaddes
+ 6+6/36 = 12/36 = 1/3 = LETRA D



## Q11 - Empresa tem 11 funcionários e resolveu sortear 

> Determinada empresa tem 11 funcionários e resolveu sortear entre eles uma viagem no final do ano. A regra para o sorteio consiste em distribuir entre eles, aleatoriamente, uma ficha numerada, com os números inteiros de 2 a 12. Posteriormente serão lançados dois dados perfeitos, ao mesmo tempo, e será verificada a soma dos números das faces voltadas para cima. O ganhador será o funcionário que tiver a ficha com o número coincidente com essa soma. Marcos está com a ficha de número 2, Renata com a de número 4, Beatriz com a de número 8, Fernando com a de número 10 e João com a de número 12. (**Provas:** [IADES - 2018 - CFM - Assistente Administrativo](https://www.qconcursos.com/questoes-de-concursos/provas/iades-2018-cfm-assistente-administrativo))
>
> Considerando essa situação hipotética, assinale a alternativa que indica a (o) funcionária(o) com maior probabilidade de ganhar o prêmio.
>
>  a - Beatriz
>  b - Marcos
>  c - Fernando
>  d - Renata
>  e - João

Links

https://brainly.com.br/tarefa/23784064

Reposta

> A - BEATRIZ

Solução

+ Reescrevendo a questâo: Será lançado 2 dados e serao somados os seus valores. Deve dar entre 2 e 12
+ M = 2; R= 4; B = 8; F = 10; J = 12
+ Quem tem maior prob de ganhar? é o caso que mais tem chance de sair
+ M = 2 
  + 1+1 ===> 1/36
+ R = 4
  + (1+3)x2, 2+2 ===> 3/36
+ B = 8
  + 4+4; (2+6)x2; (3+5)x2 => 5/36
+ F = 10
  + 5+5; 6+4x2 ===> 3/26
+ J = 12
  + 6+6 ==> 1/36

b=8 tem maior probabildiade





## Q13 - um equipamento de imagem por R$ 148.200,00 e obteve na compra um desconto

> O IBO comprou um equipamento de imagem por R$ 148.200,00 e obteve na compra um desconto de 20%. Qual era o preço deste equipamento antes do desconto?



REGRA DE 3



148200 == 80

​        X    == 100

x = 148200 * 100 / 80

x = 14820

**Resumindo**

Se você tme um desconto de Y entâo o valor real é

Original = ValorComDesconto * (100/Y)



## Q14 - Tem em seu estoque 32 unidades de um medicamento

> O IBO tem em seu estoque 32 unidades de um medicamento ao custo de RS 631,00 cada uma. Comprou 70 ao custo unitário de R$ 1.456,00. Qual o custo médio de cada medicamento de seu estoque?

Resposta

1.197,17

SOluçâo

Essa é uma simpeles questâo de matematica

Respsota = ((32 \*631) + (1456 \*70)) / (32 + 70) = 

1.197,17