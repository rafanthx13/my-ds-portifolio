# Questões de Lógica

Não dá pra ver no typora, mas dá pra ver no github

[link to github page](https://github.com/rafanthx13/my-random-notes/tree/main/ULTIMATE%20EMPREGO/17-Questoes-Logica)



# COMO FAZER O COLLAPSE

## How to

Copie o código a seguir. Tudo que nâ seja o *summary* é msotrado/fechado ao clicar no *summary*

````md
<details>
  <summary>Click me</summary>
  
  ........

</details>
````

## Example
<details>
    <summary>Click me</summary>

  ### Heading
  1. Foo
  2. Bar
     * Baz
     * Qux
     
  ### Some Code
  ```js
  function logSomething(something) {
    console.log('Something', something);
  }
  ```
</details>

**Rules**

1. Have an **empty line** after the `</summary>` tag or markdown/code blocks will not render.
1. Have an **empty line** after each `</details>` tag if you have multiple collapsible sections.





# Pacote de Questões 1

<details>
  <summary>Click me</summary>

  ........

</details>