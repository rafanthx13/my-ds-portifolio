# VItrio Teste

## Q1 - Uma folha de papel quadrada é dobrada ao meio duas vezes

> 

??????



## Q05 - Na tubulação esquematizada abaixo



> Na tubulação esquematizada abaixo, a água entra pelo cano A, sai pelos canos B, C, D e E e, em cada bifurcação divide-se em duas correntes da mesma vazão. As setas indicam o sentido que a água percorre cada cano.
> Se a vazão que sai pelo cano E é de 200 litros por minuto, então a vazão que sai pelo cano C, em litros por minuto é  
> a) 300  
> b) 360  
> c) 422,5  
> d) 637,5  
> e)1275,0
>
> ![anexo ativo](https://pt-static.z-dn.net/files/d00/42b0bc9d8e44c001922cc77b5a6ddddf.jpg)

Link:

https://brainly.com.br/tarefa/23237904

**Resposta**:

B = 360





## Q12 - Uma malha quadriculada de tamanho 3x3

> Uma malha quadriculada de tamanho 3x3 é formada por 3 linhas e 3 colunas, como mostra a figura . Há nessa malha quadrados de diferentes tamanhos, num total de 14 quadrados, como ilustrado na figura 2.  Considere agora duas malhas quadriculadas diferentes, de tamanho nxn e (n+1) x (n+1). Tomando os quadrados de todos os tamanhos possíveis, há nas duas malhas, no total, 6930 e 7714 quadrados, respectivamente. 
> Assim, o valor de n é:  
> 24 
> 25 
> 26 
> 27 
> 28
> 
LINKS
https://brainly.com.br/tarefa/21241070
RESPOSTA
D - 27





## Q13 - Um tabuleiro de xadrez é uma malha quadriculada de tamanho 8 x 8	

> Um tabuleiro de xadrez é uma malha quadriculada de tamanho 8 x 8, conforme a figura. Dois quadrados são considerados adjacentes nesse tabuleiro quando possuem um lado em comum. Uma pessoa deverá preencher os quadrados de um desses tabuleiros com grãos de feijão, de acordo com as seguintes regras: -em cada quadrado poderá ser colocado no máximo um grão; -o primeiro grão poderá ser colocado em qualquer quadrado; -a partir do segundo, cada grão deverá ser colocado num quadrado adjacente ao quadrado ocupado pelo grão imediatamente anterior, mas que NÃO seja adjacente a nenhum outro quadrado já ocupado. Nessas condições, o número máximo de grãos de feijão que poderão ser colocados no tabuleiro é:

LINKS

https://brainly.com.br/tarefa/25045582

RESPOSTA

D - 39