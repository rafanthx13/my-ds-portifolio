# Olavo de carvalho

## Como Vencer na Vida?

https://www.youtube.com/watch?v=SGcp4Yu19JQ&list=WL&index=61

O mundo nâo foi moldado para você
