# LayOffs - Vídeos

## Lucas Monteiro -  Sobre o Rant: a Bolha de Startups Estourou

url: https://www.youtube.com/watch?v=46jIc4I0Ez4

+ Busque trazer resultados para empresa, desenvolver networking.
+ Tem que se preocupar com sua saúde fnanciera
  - O que ele segue: Montar um fundo de emergencia para aguentar 1 ano sem trabalhar
+ Para conseguri um novo tralbaoh você vai precsiar muito mais de contatos do que 'aprender umalguma coisa nova'

+ Diversificar sua fonte de receita:
  - Criar um projeto paralelo que no futuro pode trazer onte de receita
  - Freela

INfelismente agora é a pior hora para pegar um primeiro emprego.
