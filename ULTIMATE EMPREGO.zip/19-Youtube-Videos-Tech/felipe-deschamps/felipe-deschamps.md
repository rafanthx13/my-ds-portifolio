

## Uma ÚNICA Coisa Me Faz Programar “10x” Mais Rápido (De Verdade)

Desenvolver com testes automazizados usando `watch` 

Aí você deixa uma tela com o console do `watch`

Como funciona:
+ VOcê coloca o console log dentro desse testes que está no watch, assim você tem muito mais domínio da coisas além de gerar um console.log no console

Você tem que deixar o console.log na mesma aba do editor,podendo ver os dois ao mesmo tempo.

**Vantegaem**
+ Se alguem mexer numa parte do codigo que altera as expectatvas do tetes automazido, entoa, vai ver na hora que deu error

Curso de testes em JS: Fábio Vedovelli

**Resumindo**:
+ Deixando uma Aba do console para testar a APi fivac mais fáicl do que ir pro postmen/pagaina web e ver o console log saindo la

## Como Ser “Dev do Mês” na Sua Empresa?

https://www.youtube.com/watch?v=wbD_fud-EhQ&ab_channel=FilipeDeschamps

O trabalho de um programador é praticemtne escrita. Se for remtoo, enttâo fica mais assincrno e dependente da comunicaçâo por texto.

Inversâo do esforço: ao invez de escrevre mensagens curtas, escrevea mensagnes longas para qur **o leitor trabalhe menos e a paessoa que escreva trabalha mais**

**Descriçao do post no tabnews**

O artigo da fonte apresenta o conceito de "aumentar a resolução" do que se escreve, com exemplos específicos para desenvolvedores, para melhorar a comunicação dentro de uma organização.

Eu tive que aprender isso na marra quando eu trabalhei em QA em uma empresa de tecnologia.

A gente tem a tendência natural de supor que a outra pessoa tem o total contexto do que a gente está falando, mas nem sempre isso é verdade.

Eu sempre utilizava uma ideia de "blocos de informação" quando me comunicava com desenvolvedores, em especial no Slack, mantendo uma thread para cada problema, o que dava a oportunidado extra de outras pessoas contribuírem para a discussão sabendo de todo o contexto.

**Exemplode comiunciaçao curta/longa para dev**

https://www.karlsutt.com/content/images/size/w1000/2022/10/dm-example.png

https://www.karlsutt.com/content/images/size/w1000/2022/10/team-chat-example.png

**COmo escreve melhor**

https://www.karlsutt.com/content/images/size/w1000/2022/10/write-think-learn.png

**Acesse esse site para evitar dizer so hello**

https://nohello.net/pt-br/

## Prevendo de Forma Responsável 2023

https://www.youtube.com/watch?v=YbmqF8tm1xc&ab_channel=FilipeDeschamps

Tópicos:
1. Big Techs 0:53
+ Está havendo uma grande revoluçâo liderada pela EUropa: Regulamentar as Big TEche e redes sociais
2. Revolução das IAs 3:09
+ DALLE e ChatGPT sâo só o começp
3. Linguagens de Programação 9:22
+ Rust ta crescendo muito
4. Metaverso 12:55
+ Esse ano o meta-verso tem que dar certo ou nâo
+ Um problema: Muitas pessoas que usam aquesles oculos, passam mal
+ A apple ta querendo criar um MetaVerso Particular e isso vai de encontra com o Facebook que quer um Meta verso mais Open-Source
5. Mercado de trabalho 17:16
+ Ta havendo muita demisao, mas rapidamente sao recoontratados
Extra: "Rope Burn" 20:34
+ Aprenda a dizer nao, e cuidado com burnout


