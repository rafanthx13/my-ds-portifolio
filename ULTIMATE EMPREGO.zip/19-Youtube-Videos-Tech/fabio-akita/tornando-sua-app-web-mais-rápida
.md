# Tornando sua App Web Mais Rápida! | 4 Técnicas de Otimização

https://www.youtube.com/watch?v=KyqFXVVgvIs

## capitulos

00:00 - Intro
01:19 - CAP 1 - Recapitulando como Requisição Web Funciona
04:55 - CAP 2 - Multi-processos e Proxy Reverso - Balanceando Carga
11:35 - CAP 3 - Calculando Uso de Recursos - Pool de Conexões
18:00 - CAP 4 - Estratégia de Caching - Economizando Recursos
21:46 - CAP 5 - Bancos de Dados Relacionais, NoSQL, difenças e quando usar - Replicas
28:23 - CAP 6 - Jobs Assíncronos - Devolvendo Rápido
37:05 - CAP 7 - Resumo Até Agora - Diagramas
41:32 - CAP 8 - Calculadoras e Monitores - Dados Analíticos
43:58 - CAP 9 - CDN - Assets mais Rápidos
48:31 - Bloopers

Objetivo: qual a diferna do ecomerce que vc faz seguindo tutorial de um ecomerce da amazon e etc..



## 01:19 - CAP 1 - Recapitulando como Requisição Web Funciona

PHP/Django/Springbot, em todos eles, quanado agente sobe a aplicaçao, por default agente sobe 'mono-tread'.

O que isso quer dizer: que se a maquina da aws que ta rodatado tiver 90 nucleo, so vamos usar seomente 1.

Entao, temos que usaros re

**Questao de porta**

E ao raodar em varios procesos, e as portas. 

Na verdade sabemos que na web a porta de serividores é80, mas, se há multi-processos qual ficaria lá na 80?

==> Processo de inverter ficam atras de um balanceador de carga, um NGinx ou HAProxy e eles fazerm **proxy reverso** efazem round-robon para mandar as requisitaçoes para algumas das portas  tentando manter todos igualmente ocupados.
- É somente neses prpxy reverso que agente coloca o certificado SSL, assim, dele para os nosso procesos nao tem SSL

Throughput (/truuputi): capacidade de responder por segundo

## 11:35 - CAP 3 - Calculando Uso de Recursos - Pool de Conexões

Pool De conexoes: AO nvez de se conectar ao banoc, se conecta a algo que rugala a qtd de requisiçoes e acesso ao banco. 
+ É um intermediáriod e balanemento, como o prxy reverso, mas entre as aplciaçoes (e seus varios process/servidores) e o banco de daods

Além do Poll, podemos ainda colocar um PGBouncer para regular melhor o acesos ao banco postgre

## 18:00 - CAP 4 - Estratégia de Caching - Economizando Recursos

Vimos até qaqui que apostar somente na infra-estrutura nâo é uma soluçao perfita, mas **será que da para melhorar o ecnário de uso de recuros por código?**

Caching: qguarad a última resposta ao invez de fazer a mesma requisiçâo a toda hora. COmo ficarai: ao invez de fazer o SELCT, veja se tem um arquivo criado em menos e 5min e use ele ao invez de fazer uma conexâo a banco de dados

**Esse é o tipo de otimizaçao imples com alto impacto**

## 21:46 - CAP 5 - Bancos de Dados Relacionais, NoSQL, difenças e quando usar - Replicas

Na realidade, nao suamos arquivos para caching, usamos bancos NoSQL para guarada ese chace. VOce nao rpecisa de tanto exatidao para ler o cache, e esse sbnaoc sao mais leves e simples de ler.

Pode ser um MEMCACHE ou um REDIS

A escolha do nosql (mongo, cassandra, redis, memcache) depende de suas caracterisica se encaixar ao nosso caso de uso.

Uma startup simples só precisa de : UM psotgre e um redis para cahce.

**Datawarehouse e copia do banco principal**

Imagine que voce tneha que fazer um relatiorio que faça 500 joins. É muito trablho. Se voce pede isos pro seu banco de dados relacional de uso do dia a dia vai deixar ele insamenmtne lento.

É por isos que esse banco do dia a dia é clonado par aum banco sepsrado que pode realizar essa consultas maix xomplexas,, sem atrabalhar o I/O do banco principal que registra transações

Gera uma réplica que servae para fazer os selexts complexos

O mais normal é:
+ ter um banco só pra escrita
+ uma replica para montar as páginas do site
+ e uma replixa exclusiva para tarefas administrativas com gerar relatorios

## 28:23 - CAP 6 - Jobs Assíncronos - Devolvendo Rápido

Usar jobs assincronors, porque em caso de muito tráfego, nao podemos deixar o ususairo esperando. Ex: ao confirmar a compra,quando agente manda o 'obrigado, volte sempre. vamos confirmar essa compbra' nao quer dizer que já a resgistramos no banoc. Ele está em um job assincrno e depois que for inserido no banco que vai confirmar no email

Serviçoes de fila: pode ser RabitMQ, Kafka, ActiveMQ

MQ = Message Queue = Mensagem em FIla = Manda para algo que mantem suspenso e de forma sincrono, quando tiver os recuros computacionais disponiveis, vai puxar e fazer tudo direitnho.

E sim,tem que usar um outro serviço, pis nao podemos pegar mais coisa do banco de dados.

Ai temos que criar os 'workes' que vao aguardar essa MQ para fazer o que elas pedirem

## 37:05 - CAP 7 - Resumo Até Agora - Diagramas

E como melhora mais ainda! MOnitorar 

Saber os numeros de cada coisa e assim saber os gargalos.

Assim agente chega ao Parteo: 20% deve confumir 80% da sua aplicaçoes, entao, use o monitoramente para saber quais sao essas 20% e melhorar elas

## 43:58 - CAP 9 - CDN - Assets mais Rápidos

Para o pesosal de front

## As 4 dias

1 - EStrateiga d cache
2 - Jobs Asincorno : kafka
3 - Monitore a sua app em produçao
4 - Use CDN

tenica extra: mqsl otimizada e instalar index adequados

# best coomentários

xxx

Mais um excelente vídeo, e só adicionando mais uma dica é de sempre ligar o compression (gzip) no Apache/Nginx, hoje quase todo navegador suporta e o ganho de performance é grande. A outra questão de banco de dados, acredito que a maioria use o MongoDB por ele ser um Document Database e poder gravar JSON direto na base... só que isso existe no PostgreSQL de maneira nativa (datatype) desde a versão 9.4  de 2014. Não que eu não goste do MongoDB, eu até escrevi um livro sobre ele, mas se você quer gravar JSON em banco pode usar o PostgreSQL sem problemas.
