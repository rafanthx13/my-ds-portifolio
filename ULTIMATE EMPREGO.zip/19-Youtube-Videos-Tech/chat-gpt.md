# Chat GPT

## Felipe Deschamps - A Última Jogada Genial (e do Mal) do Google

O google maps rpecisa da sua localiaçâo

Ao invés de usar maps.google.com O GOOGLE MUDOU ESSE DOMINIO PARA google.com/maps

O que faz essa diferença: Quando você aceita, vai te rastrear nao só no maps mas em todo domino que começa com `google.com`

Essa é uma mudança sutíl que vai rastrrae por muito mais lugares do que você imaginaria.

## Felipe Deschamps - Voltou o Papo Chato “ACABOU DEVS” (Minha Nova Opinião)

url: https://www.youtube.com/watch?v=ILrRbyUxE38

O ChatGPT converter um cídgio em php + Jquey para REact+TrypeScirtp, em seguinda umc ara pediu para pegar esse código e usar Axios ao invéz de fetch e Tailwind ao invez de css comun.

Vamos ver outras 7 coisa interressantes apra saber

**Exemplo 1**

==> O GCP É CAPAZ DE ENCONTRA BUS SEM VOCÊ PRECISAR INDICAR QUE TEM UM BUG

**Exemplo 2**

==> O chatGPT consegue criar prova de conceito e avaliar vulnerabilidade em código php

Resumindo: o chatGPT pode até aposentar o meancimso de bsuca do google, mas também abre oportunidade de simplificar o trabalho como dev

Entao, continue a se atualizar cada vez mais.

## Lucas Monteiro - Como Programadores podem ter mais sucesso que a ChatGPT em 2023

https://www.youtube.com/watch?v=aM4GANxbO1Y

5 dica para se tornar um progmra bem sucedido em 2023
+ 1 - Estude
+ 2 - Desenvolva habildade de resoluçâo de problemas
+ 3 - Trablhe em equipe - Habildaide em comunicaçao
+ 4 - Nunca pare de aprender
+ 5 - O roteiro desse video foi escrito por IA

**CUidado**
+ O jchatGPT é perigioso para progrmador Júnior: poois **Eo ChatGPT é o pior senior**, ou seja, você vai pegar a repsoata dele e vai achar que é a melhor, mas **VOCE DEVE VALIDAR A RESPOSTA DELE**

O ChatGPT é muito poderosa ma elea nâo é um senior que pode te repsonder as suas dúvidas.
