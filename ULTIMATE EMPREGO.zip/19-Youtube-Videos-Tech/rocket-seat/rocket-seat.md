# Rockeat Seat Vídeos

## Guia de estudo JavaScript em 2023! (o que eu focaria)

https://www.youtube.com/watch?v=EDotqZwJ4aA&ab_channel=Rocketseat

Nao fique ansioso para saber tudo que sera dito, calma:

+ Assita o vídeo "TUDO que deve estudar de JavaScript antes do React"
00:28 Compiladores e bundlers
17:52 Nullish Coalescing Operator
21:00 Objetos
24:13 Desestruturação
28:15 Rest Operator
33:10 Short Syntax
34:23 Optional Chaining
43:49 map()
48:40 filter()
50:21 every()
52:00 some()
52:52 find() e findIndex()
54:25 reduce()
59:49 Template Literals
1:02:38 Promises
1:17:35 Importação e exportação

Gerenciadores de Pacotes
+ npm e pmpm juntos
+ Nâo precisa mais do yan

TypeScript
+ TypeScript é agora OBRIGATÓRIO: Static Typing Checking

Coisa que voce deve aprender em cada um dos principais frameworks JS

Obs/; ALgumas ferramentas soa tao novas que

REACT
+ Estilização
  - tailwind CSS (Existe tmabem wind.css e uno.css)
  - stiches: ele é melhor para mudar o css por algum estado.
  - vanilla extract: CSS em SSR
  - cva

Formulario
+ React Hook Form
+ Zood (validaçao e tranformaçao de dados)

Gerencia de estados
+ Redux é a mais antiga, e a maior, mas há outras mais movedras
+ Lib: Jotai (pequenaos estados
+ Lib: susten (estados mais globai)
+ Por isos é recomendado Jotai e susten

Next.js
+ DOminou o mercado
+ Há outra alterantivas mais novas, mas nao tao gigante quanto o Next.js
+ ESTUDA CONCERTEZA Next
  - Remix
  - astro: masi rapido, serve para coisas pequenas, e serve para nuxt, angular e etc
  - qwik: edge computing, é algo ultra nova


Testse que manipula browse
+ Cypress
+ Playwright

Stremaing SSR

Server COmponents: REnderizar componentes no lado do sevidor: dá mais perfomance mas é umpouco mais difícil
















PAREI EM 37MIN
