# Trabalho em TI

## Lucas Monteiro - Mapa completo para tua carreira na Tecnologia

url: https://www.youtube.com/watch?v=1lTw-hNbJhw&t=2s

O que é necessário e as vagas em TI

FrontEnd:
+ O que precisa: Framework Front; HTML + CSS + JS


BackEnd
+ PHP
+ Java
+ Kotlein
+ Rust
+ Ruby
+ Go
+ Dot.Net/C#

Mobile
+ Multiplataforma
  - ReactNative: JS + TypeScrit
  - FLutter: Dart
+ MOno-Plataforma
  - ANdroid Nativo: Kotlin (Kotlin é o oficial no android) ou Java (O lcas mnteiro é senior em mobile Android)
  - IO Nativo: Ojective-C ou Swift (Swift é o mais atual)

Segurança
+ Salario de Senior:

Degrais

+ Frellancer: Valor varia: 25 dolares por hora

+ Stagio : 1k USD
+ Junior 3K USD
+ Pleno 5K USD
+ Senior 6,5 USD
+ Lead 7,6 UD
  - Staff
    * Principal
      - Distinguished
        - Fellow
  - Manager 
    * Director
      - VP : Vice presidente de tecnlogia

