# O que pedem e eu não tenho

## 12/10/2022

### ANALISTA DE DADOS JR

+ PBI
+ Excel Avançado: Macro e VBA

### Engenheiro de Dados

+ Qlik (Qlik View/Sense) ou ferramenta de BI
+ SQL Server

### Engheiro de Dados

**Hot Mart**

+ Terraform
+ Stack AWS (Athena, Glue, S3, Redshift, EMR, Kinesis, DynamoDB);
+ Experiência em ferramentas de monitoramento Grafana e Ganglia;

### Engnehiro de Dados

**A3Data**
+ Experiência com Docker/Kubernetes;
+ Esteja familiarizado com um ambiente baseado em nuvem, como AWS, AZURE ou GCP;
+ Experiência com Kafka e pipelines near real time;
+ Experiência com ferramentas de IAC (Terraform);
