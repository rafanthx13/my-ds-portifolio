# Soft Skills

Vídeos do Youtube sobre SoftSkilss

## Paulo Muzy

[O QUE SÃO SOFT SKILLS? | Cortes do Ciência Sem Fim](https://www.youtube.com/watch?v=rcoWG1VXCcU)

Exemplos
+ Saber apresentar suas ideias ebm (crack no slide)
+ Se relacionar com pessoas diferentes
+ Forma que você veste

**Comentários**
+ "As pessoas sao contratadas pelas hard skills e demitidas pela falta de soft skills" 

**Desenvolver**
+ Oratória; Vendas

## Código Fonte TV

[A Soft Skill que TODO Programador Precisa Desenvolver](https://www.youtube.com/watch?v=CNLLSNXZ_uE&ab_channel=C%C3%B3digoFonteTV)

Daniel Golemann: (o cara da intelignecia emocional): "Traço e comportamtneos que caracterizam nossos relacionamentos com os outros"

As soft skills mais importantes (pesquisa pela empresa trybe) 7
+ Comunicação
  - Demosntrar interesse por tudo
  - Escuta Ativa; Dar e receber feedback; Assertividade; Negociação
+ Liderança e gestão
  - Organização; Proatividade; Autonomia
+ Criatividade
  - Inovaçao; Curiosidade; Criaçao
+ Inteligencia Emocional
  - Como expressa suas amoeçoes
  - Autocoonhecimento; Empatia; Resiliência; Autogestão
+ Colaboração
  - Senso de time; Respeito e gentiliza; Inclusão; Respeito à Diversidade
+ Pensamento Crítico
  - Analisar o proprio pensamento; é focar no objetivo e não no resuultado; Identificar problemas que ninguém é capaz de ver
  - voce é questionador?
  - voce busca todas as infromaçoes sobre o problema?
  - como voce compara as informaçoes?
+ Aprender a aprender

**comment**

Po, ja fui demitido por ser bom tecnicamente mas dificil de lidar. O que vi aqui infelizmente aprendi da pior maneira: na pratica. Mudei. 2 fatores me fizeram mudar da agua pro vinho: 1) me mudei pra Alemanha. Devido a minha limitaçao com Alemao, ficou dificil ser arrogante e responder "na lata". Quando eu queria responder "na lata" demorava tanto pra pensar em alemao que eu desistia. 2)Ter um projeto particular SO MEU. Quando decidi criar um projeto SO MEU privado, eu pude ter a chance de colocar a prova a tal "genialidade" que eu achava que tinha. Assim, coisas incriveis que eu queria por na empresa, mas nao tinha chance, colocava no meu projeto. Na empresa eu liguei o modeo "exploda-se". Faço o que mandam e se sugiro algo que nao usam, eu nao ligo. Na empresa tenho uma personalidade, docil e cooperativa. No meu projeto eu sou mais agressivo e arrojado. Quem é "lone wolf" ou "genio indomavel" sugiro trabalhar fora de horario num projeto SEU. Vc vai ver que:1) nao é tao genio assim. 2) verá resultados diferentes do que se ve na empresa (para o bem ou para o mal). Meus chefes aqui na Alemanha gostam de mim e sempre me consideram em seus projetos pois tenho foco em resultado e nao debate tecnico infindavel.

## Trybe

[SOFT SKILLS | O que são? Por que são importantes?](https://www.youtube.com/watch?v=yA3sc5mnctg&ab_channel=Trybe)

comunicaçao, adaptabildaide e trabalho em grupo
