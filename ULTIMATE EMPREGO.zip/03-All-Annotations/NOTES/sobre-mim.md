# Sobre Mim

**ESCREVA AQUI TUDO QUE PENSE DE SI, SEM COPY/PASTE**

## Qualidade

**ORGANIZADO E PRÁTICO**

Além de Organizado eu sou prático. Penso sempre em Otimização. Criar procesos para as atividades sejam as melhores possíveis, com os melhores resultados.

Para isso, faço relatarios, road-maps, imagesn que sintetizme e melhore porceoss.

Quando organizo algo, eu nao só arrumo como ordeno ao ponto de otimizar as coisas. Ex: Ao arrumar a dinspensa, coloco tudo em ordem mas tambem deixo tudo visível, e deixo as coisa mais importantes na frente.

## Defeitos

**TIMIDEZ**

> A timidez em excesso é, sim, vista como um defeito, principalmente para o meio comercial, do marketing e para cargos de liderança. Profissionais tímidos tendem a ter dificuldades em se expressar, em compartilhar opiniões e em ter desenvoltura para conversar com clientes, gestores e equipe.
> No entanto, não é algo que possa macular sua carreira ou impedi-lo de conquistar uma vaga de emprego, principalmente se você frisar que vem trabalhando a sua autoconfiança.

**IMPACIENTE**

> Pessoas impacientes tendem a não pensar muito antes de agir e prezam pela rapidez e pela produtividade em detrimento da qualidade. Entretanto, pode causar uma boa impressão se a sua impaciência for associada à praticidade e à mobilização de soluções rápidas


