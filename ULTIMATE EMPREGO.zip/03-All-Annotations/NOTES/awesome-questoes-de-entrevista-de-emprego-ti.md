# 100 QUESTIOSN ULTRA LINK

No site abaixo há 100 questôes de entrevista de emprego e apra cada uma
+ o porque a pessao perguntou, e quala melhor resposta

https://collegegrad.com/tough-interview-questions




Inspirado no link: https://github.com/Appsilon/awesome-interview-questions

# awesome-interview-questions

# Table of context

- [Analytical skills](#analytical-skills)
- [Behavioral](#behavioral)
- [Communication skills](#communication-skills)
- [Critical thinking](#critical-thinking)
- [Cultural fit](#cultural-fit)
- [Emotional Intelligence](#emotional-intelligence)
- [Exit](#exit)
- [Leadership skills](#leadership-skills)
- [Manager](#manager)
- [Personality](#personality)
- [Phone](#phone)
- [Phone screen](#phone-screen)
- [Problem-solving](#problem-solving)
- [Reference check](#reference-check)
- [Team player](#team-player)
- [Technical](#technical)


## Analytical skills

* Descreva um projeto ou situação em que você demonstrou com sucesso suas habilidades analíticas.
* Quando você se depara com um problema, o que você faz? Descreva as etapas em sua abordagem de resolução de problemas.
* Dê-me um exemplo de uma situação em que você se arriscou para atingir um objetivo. Qual foi o resultado?
* Em sua experiência, você diria que desenvolver e usar um procedimento detalhado sempre foi necessário para o seu trabalho?
* Imagine uma situação em que um de seus colegas deseja resolver um problema de uma determinada maneira, mas o outro colega tem uma abordagem totalmente diferente em mente. Eles vêm até você pedindo ajuda para decidir sobre a abordagem correta. O que você faz?
* Como você compara e pesa prós e contras antes de tomar uma decisão?

## Behavioral

* Conte-me sobre uma ocasião em que você teve que lidar com um cliente difícil. Como você lidou com essa situação?
* Dê-me um exemplo de uma ocasião em que você não atendeu às expectativas do seu supervisor. O que aconteceu e como você reagiu?
* Conte-me sobre um momento em que você se deparou com prazos extremamente apertados. Como você lidou com isso?
* Dê-me um exemplo de uma ocasião em que você mostrou iniciativa e assumiu a liderança.
* Dê-me um exemplo de um grande erro que você cometeu. Como isso aconteceu? Como você procedeu com isso?
* Você já teve um subordinado cujo trabalho geralmente era insuficiente? Como você lidou com essa situação? O que aconteceu? Qual foi o resultado?
* Todos nós cometemos erros. Conte-me sobre uma situação no trabalho que você gostaria de ter tratado de forma diferente.
* Dê-me um exemplo de uma situação em que você teve que trabalhar em vários projetos simultaneamente. Como você priorizou?

## Communication skills

* Como você explicaria um problema técnico complexo para alguém sem conhecimento técnico, que não entende a terminologia técnica? Use o termo *[inserir termo apropriado]* como exemplo.
* Por favor, cite cinco coisas sobre a comunicação dentro de uma organização que devem estar presentes para que você possa dar o seu melhor e trabalhar de forma mais eficaz?
* Se você tivesse que escolher entre ser um bom ouvinte ou um bom comunicador, qual seria sua escolha? Por favor, explique sua resposta.
* Conte-me sobre o tempo que você teve para fazer uma apresentação para um grupo de pessoas sem preparação? Qual foi a principal dificuldade que sentiu? Como você lidou com isso?
* Descreva uma situação em que os membros da equipe em um projeto em que você estava trabalhando discordaram de suas ideias. O que você fez?
* Descreva uma situação em que você precisou trabalhar com um cliente ou cliente que era muito diferente de você. Como foi isso para você? Como você abordou essa situação?
* O que é uma crítica construtiva para você? Que tipo de crítica o ajudaria a melhorar e fazer um trabalho melhor da próxima vez?
* Como você prefere se comunicar? Em pessoa? Pelo telefone? Por e-mail ou mensagens? Por favor, explique sua escolha preferida.
* O que você faria se houvesse uma falha na comunicação no trabalho?
* Você já enfrentou alguns obstáculos ou dificuldades para comunicar suas ideias a um gestor? O que aconteceu? Como você lidou com isso?
* Com quem você tem a melhor comunicação?
* Imagine ter um colega com quem você não se dá bem, mas precisa da ajuda dele em um projeto pelo qual é responsável. Como você lidaria com essa situação? Você abordaria esse colega e pediria ajuda? Como você faria? Você tentaria obter ajuda de alguma outra forma?

## Critical thinking

* Com que rapidez você toma decisões? Como você faz isso? Você prefere pensar cuidadosamente antes de tomar uma decisão?
* Qual foi a decisão mais difícil que você teve que tomar no trabalho? O que foi isso? Qual foi o resultado?
* Dê-me um exemplo de uma situação em que seu colega lhe apresentou uma nova ideia que era estranha ou incomum. O que você fez?
* Dê-me um exemplo de uma vez em que você descobriu que seu chefe cometeu um erro. O que você fez? Qual foi o resultado?
* Descreva uma situação em que você teve que fazer uma escolha crítica com base em dados incompletos. Como você fez isso?

## Cultural fit

* No seu trabalho anterior - com quem você teve mais dificuldade em se comunicar e por quê? O que você fez para melhorar o relacionamento?
* Conte-me sobre o tempo em que você recebeu um feedback menos favorável. como você lidou com isto?
* Qual foi o maior desafio que você enfrentou trabalhando em um ambiente de equipe? como você lidou com isto?
* Como você motiva os outros a fazer o seu melhor trabalho?
* Como você descreveria a cultura nas empresas anteriores em que trabalhou? DEEPER: Você gostou de trabalhar nessa cultura da empresa? O que significa para você uma cultura de trabalho saudável?
* Que tipo de situação pode gerar estresse para você e, quando isso acontece, o que você faz para lidar com isso?
* Qual é o papel que você mais provavelmente desempenhará em uma equipe? Dê um exemplo.
* O que te deixa animado para vir trabalhar?
* Como você descreveria a cultura da nossa empresa?
* Com quais valores fundamentais da nossa empresa você se identifica mais/menos?
* Conte-me sobre uma vez que você resolveu um problema no trabalho. Qual foi o problema e como você o abordou?
* Como você gosta de ser gerenciado? DEEPER: Conte-me sobre um desentendimento que você teve com seu último gerente. Qual foi o problema e como você abordou a situação?
* Como você descreveria a cultura nas empresas anteriores em que trabalhou?
* Como você se sente quando alguém o interrompe enquanto você está no meio de uma tarefa importante?
* Conte-me sobre o momento em que você sentiu que foi mal interpretado no trabalho ao tentar transmitir algo. O que aconteceu? como você lidou com isto?
* Quando foi a última vez que você pediu ajuda em seu trabalho? Descreva a situação. Como você se sentiu ao pedir ajuda?
* Quando foi uma vez que você “parou e ajudou”, mesmo que não fosse sua responsabilidade?
* O que faz você perder a calma/detona você? Conte-me sobre a última vez que aconteceu.
* Descreva o tipo de ambiente de trabalho em que você pode realmente dar o seu melhor e ser mais produtivo.
* Você se tornou um bom amigo de algum de seus colegas em seu local de trabalho anterior (ou atual)? O que você acha de ter um relacionamento próximo com seus colegas de trabalho? Essa é uma prática boa ou ruim?
* Descreva uma situação em que seus colegas discordaram de suas ideias. O que você fez?
* Você prefere trabalhar sozinho ou em equipe? Por favor, explique sua resposta.
* Qual a sua opinião sobre levar trabalho para casa? Você costuma levar seu trabalho para casa? É uma boa prática na sua opinião?
* Cite três coisas que você mais gosta em nossa empresa.
* Descreva uma situação desafiadora que você enfrentou recentemente no trabalho e como você a enfrentou.
* Pelo o que você está interessado?
* Como é o seu dia de trabalho ideal?
* Quais são, na sua opinião, os principais ingredientes para manter relacionamentos comerciais bem-sucedidos?
* Conte-me sobre a situação mais estressante que você enfrentou no trabalho. O que aconteceu? como você lidou com isto?

## Emotional Intelligence

* Dê um exemplo específico de uma ocasião em que você teve que se dirigir a um cliente irritado. Qual foi o problema e qual foi o resultado?
* Descreva uma situação em que você estava liderando uma equipe em um projeto. O que você fez para motivar seus colegas a dar o melhor de si?
* Dê um exemplo de uma ocasião em que você cometeu um erro porque não ouviu atentamente o que seu colega tinha a dizer.
* O que te motiva a fazer o seu trabalho? O que te faz feliz no trabalho?
* As pessoas reagem de forma diferente quando as exigências do trabalho mudam repetidamente. Você já esteve em uma situação semelhante? Como você reagiu?
* Conte-me sobre uma ocasião em que você recebeu feedback negativo de seu chefe. Como aquilo fez você se sentir?
* É mais importante focar em resultados e tarefas ou pessoas e emoções? Explique sua resposta.
* Conte-me sobre uma vez que você cometeu um erro no trabalho. O que aconteceu? como você lidou com isto?

## Exit

* O que o levou a procurar outro emprego?
* Qual foi o maior fator que o levou a aceitar este novo emprego?
* Como sua função em nossa empresa se compara à nova função que você aceitou?
* O que você mais gostou no seu trabalho?
* O que você menos gosta no seu trabalho?
* Você tinha as ferramentas e recursos necessários para fazer seu trabalho com eficiência?
* Você ficou satisfeito com seus benefícios, regalias e outros incentivos?
* Você acha que nossa empresa oferece remuneração competitiva para sua posição?
* Você acredita que seu trabalho foi devidamente reconhecido e apreciado?
* Como era seu relacionamento com seu gerente?
* Quão agradável foi trabalhar com os membros de sua equipe?
* Como você descreveria sua relação de trabalho com seus colegas?
* Você acha que teve oportunidades suficientes para desenvolvimento de habilidades e promoção nesta empresa?
* Como você descreveria a cultura da nossa empresa?
* O que poderia ser feito para tornar esta empresa um lugar melhor para trabalhar?
* Você recomendaria nossa empresa a um amigo como um ótimo lugar para trabalhar? Por quê?
* Você consideraria trabalhar conosco novamente no futuro?
* Em uma escala de 1 a 10, como você classificaria a experiência de seus funcionários em nossa empresa?

### Exit interview tips

* Escolha um conjunto final de perguntas de entrevistas de saída que você fará a todos os seus funcionários de saída.
* Imprima esta lista final de perguntas da entrevista de saída e leve-a com você para a entrevista.
* Conduza entrevistas individuais com seus funcionários de saída em um ambiente privado.
* Criar um ambiente descontraído e fornecer garantia de confidencialidade ao funcionário que está saindo.
* Faça perguntas de acompanhamento quando necessário e anote as respostas do funcionário que está saindo.


## Leadership skills

* De acordo com sua experiência, qual é a melhor e mais eficaz maneira de motivar os membros de uma equipe que você lidera?
* Qual é a melhor parte de ser um líder de equipe? E o pior? Por favor, explique suas respostas.
* Você já teve dificuldade em fazer com que os membros de sua equipe aceitassem sua liderança? Qual foi sua abordagem? Funcionou?
* O que é mais importante para você, que os membros de sua equipe gostem de você ou que façam o trabalho?
* Como você mede seu sucesso como líder?
* O que te motiva a ser um líder?
* Conte-me sobre uma vez em que você teve que dar más notícias à sua equipe. Como você fez isso?
* Conte-me sobre um momento em que houve um desentendimento dentro de sua equipe. O que você fez?
* Cite cinco características que você mais valoriza nos membros de sua equipe.
* Dê-me um exemplo de uma ocasião em que você estava liderando uma equipe e algo deu errado. O que aconteceu? O que você aprendeu?

## Manager

* Descreva seu estilo de gestão em 3 palavras.
* O que você acha que é mais importante: Alcançar seus objetivos ou ser apreciado por sua equipe?
* Há quanto tempo você é gerente?
* Quantas pessoas você administrou até agora em sua carreira?
* Em sua experiência, qual é a chave para desenvolver uma boa equipe?
* O que você faria se um membro de uma equipe que você lidera se recusasse a seguir suas instruções?
* Dê-me um exemplo de um momento em que uma pessoa em sua equipe estava tendo um desempenho ruim. O que você fez?
* O que você faria se tivesse um prazo de projeto definido para amanhã e sua equipe informasse que não poderá terminar o trabalho a tempo?
* Quais estratégias você usa para motivar sua equipe?
* Como gerente, você recompensa as pessoas pelo trabalho duro ou pelos resultados alcançados?
* Faça uma lista final de um conjunto fixo de perguntas de entrevista para gerentes que você fará a seus candidatos.
* Desenvolva um sistema de classificação antes de entrevistar seu primeiro candidato.
* Siga sua lista durante a entrevista e pergunte a todos os seus candidatos a cargos gerenciais as mesmas perguntas, de preferência na mesma ordem.
* Certifique-se de anotar as respostas de seus candidatos durante a entrevista.
* Após a entrevista, revise suas anotações e avalie a resposta de cada um dos seus candidatos.
* Por fim, compare os 3 melhores candidatos e selecione o melhor.

## Personality

* Qual foi a melhor ideia que você teve em sua carreira? Como você aplicou?
* Você é o tipo de pessoa que sempre olha para o "grande quadro" ou é mais "detalhista"?
* Descreva um momento em que você apresentou uma solução criativa para uma situação desafiadora relacionada ao trabalho?
* Qual foi a crítica mais útil que você já recebeu?
* Como você lida com o estresse e a pressão no trabalho?
* Dê-nos três adjetivos que melhor descrevem você.
* O que você não gosta de fazer?
* Como você se sente quando alguém o interrompe enquanto você está no meio de uma tarefa importante?

## Phone

* Redução do tempo de contratação
* Custo reduzido por contratação
* Maior qualidade dos candidatos
* Testar as habilidades dos candidatos.
* Adequação ao cargo (qualificações, experiência e histórico de trabalho)
* Motivação (carreira e interesses desejados)
* Ajuste à cultura da empresa (preferências no local de trabalho e conhecimento sobre a empresa
* Preferências salariais (expectativas e salário atual)
* Disponibilidade (entrevista presencial e data de início se contratado).
* Quantos anos de experiência você tem em *[inserir cargo/indústria apropriada]*?
* Você tem uma *[inserir qualificação obrigatória apropriada, como: certificação, carteira de motorista, etc.]*?
* Você tem experiência usando o software [X] em algum de seus trabalhos anteriores?
* Estão autorizados/licenciados para trabalhar na área [X]?
* O que você está procurando em sua próxima posição?
* Como você ficou sabendo dessa vaga de emprego?
* O que fez você se candidatar a essa vaga?
* O que mais te excita nessa posição?
* Por que você está deixando seu local de trabalho atual?
* O que o motivou a escolher esta carreira?
* Em que tipo de cultura no local de trabalho você prospera?
* Descreva o tipo de ambiente de trabalho em que você pode realmente dar o seu melhor e ser mais produtivo.
* Descreva sua situação de trabalho ideal (ambiente de trabalho, horas, viagens e similares).
* O que você sabe sobre a nossa companhia?
* Por que você quer trabalhar em nossa empresa e não em outro lugar?
* Quanto você ganha agora?
* Quais são suas expectativas salariais para esta posição?
* Você está disposto a se mudar para este trabalho?
* O horário de trabalho para esta posição é *[inserir dias e horas apropriados]*. É que ok com você?
* Se você foi contratado, em quanto tempo pode começar?
* Você está disposto a concordar em fazer um teste de drogas, uma verificação de antecedentes criminais e educacionais, verificações de referências e outros testes apropriados para esta posição?
* Se convidássemos você para uma entrevista cara a cara, quando você estaria disponível?
* Você gostaria de me perguntar alguma coisa? / Você tem alguma pergunta?

### Phone interview tips

* Escolha até 10 perguntas de entrevista por telefone e ajuste-as para atender às suas necessidades de contratação (cargo e empresa).
* Desenvolver um sistema de classificação e criar scorecards de entrevista.
* Pergunte a cada candidato entrevistando para um determinado cargo as mesmas perguntas na mesma ordem.
* Anote as respostas dos candidatos!
* Pontue cada uma das respostas de seus candidatos.
* Compare as pontuações dos candidatos para escolher os melhores!

## Phone screen

* Quantos anos de experiência você tem em *[inserir cargo/indústria apropriada]*?
* Você tem uma *[inserir qualificação obrigatória apropriada, como: certificação, carteira de motorista, etc.]*?
* Você tem experiência usando o software [X] em algum de seus trabalhos anteriores?
* Estão autorizados/licenciados para trabalhar na área [X]?
* O que você está procurando em sua próxima posição?
* Como você ficou sabendo dessa vaga de emprego?
* O que fez você se candidatar a essa vaga?
* O que mais te excita nessa posição?
* Por que você está deixando seu local de trabalho atual?
* O que o motivou a escolher esta carreira?
* Em que tipo de cultura no local de trabalho você prospera?
* Descreva o tipo de ambiente de trabalho em que você pode realmente dar o seu melhor e ser mais produtivo.
* Descreva sua situação de trabalho ideal (ambiente de trabalho, horas, viagens e similares).
* O que você sabe sobre a nossa companhia?
* Por que você quer trabalhar em nossa empresa e não em outro lugar?
* Quanto você ganha agora?
* Quais são suas expectativas salariais para esta posição?
* Você está disposto a se mudar para este trabalho?
* O horário de trabalho para esta posição é *[inserir dias e horas apropriados]*. É que ok com você?
* Se você foi contratado, em quanto tempo pode começar?
* Você está disposto a concordar em fazer um teste de drogas, uma verificação de antecedentes criminais e educacionais, verificações de referências e outros testes apropriados para esta posição?
* Se convidássemos você para uma entrevista cara a cara, quando você estaria disponível?

### Phone screen tips

* Faça uma lista das perguntas da entrevista na tela do telefone que você deseja fazer aos seus candidatos.
* Desenvolva um sistema de classificação para cada pergunta e crie scorecards de entrevista.
* Pergunte a cada candidato entrevistando para um determinado cargo as mesmas perguntas na mesma ordem.
* Anote as respostas dos candidatos!
* Pontue cada uma das respostas de seus candidatos.
* Compare as pontuações dos candidatos para escolher os melhores!


## Problem-solving 

* Qual foi a situação mais estressante que você enfrentou no trabalho? como você lidou com isto?
* Descreva uma situação no trabalho em que você se deparou com um problema que não conseguiu resolver. O que você fez?
* Você é o tipo de pessoa que sempre tenta resolver o problema por conta própria antes de pedir ajuda?
* Descreva um momento em que você usou uma solução criativa para resolver algum problema relacionado ao trabalho.
* Como você lida com um desafio que nunca experimentou?
* Dê-nos um exemplo de uma situação em que você percebeu que não conseguirá cumprir o prazo estabelecido. O que você fez?
* Como você constrói um processo de solução de problemas?
* Na sua opinião, o que faz de você um ótimo solucionador de problemas?
* O que você faz em uma situação quando você não consegue encontrar a solução certa para um problema?
* Quando você se depara com um problema urgente, como você reage? Você é o tipo de pessoa que salta direto para a resolução de problemas, ou primeiro avalia cuidadosamente a situação?

## Reference Check

* Qual era a sua relação de trabalho com o *[nome do candidato] na [nome da empresa]?
* Quando *[nome do candidato]* trabalhou na sua empresa?
* Qual era o cargo *[nome do candidato]*?
* Por favor, indique as *[nome do candidato]* principais responsabilidades e deveres do trabalho?
* Como você classificaria o desempenho geral de *[nome do candidato]* em uma escala de 1 a 10?
* Por que *[nome do candidato]* saiu da sua empresa?
* Você recontrataria *[nome do candidato]*? Por quê?
* Como *[nome do candidato]* lidou com situações estressantes? Por favor, dê exemplos específicos.
* Você acha que *[nome do candidato]* é uma boa opção para *[cargo que você deseja preencher]*?
* Qual foi *[nome do candidato]* maior realização enquanto trabalhava para sua empresa?
* Quais habilidades você acha que *[nome do candidato]* precisa desenvolver para atingir todo o seu potencial?
* Em que tipo de cultura no local de trabalho você acha que *[nome do candidato]* prosperaria?
* O *[nome do candidato]* é mais produtivo como jogador solo ou em equipe de acordo com sua experiência?
* Como *[nome do candidato]* se deu bem com outros membros da equipe, clientes, parceiros de negócios e gerentes?

### Reference Check tips

* Peça aos seus candidatos detalhes do árbitro
* Sempre obtenha a permissão dos candidatos para entrar em contato com suas referências
* Prepare a lista de perguntas da entrevista de verificação de referência para fazer as referências de seus candidatos
* Sinta-se à vontade para fazer perguntas de acompanhamento quando necessário
* Escolha a pessoa certa para entrevistar - tente entrar em contato com o ex-supervisor de seus candidatos, não com seu melhor amigo de trabalho
* Forneça uma breve descrição de uma função que você deseja preencher e da cultura da sua empresa
* Preste atenção ao tom de voz da referência e como, não apenas o que eles dizem sobre o seu candidato.


## Team Player

* Você prefere trabalhar sozinho ou em equipe? Por favor, explique sua resposta.
* Você é mais produtivo quando trabalha sozinho ou como parte da equipe?
* O que faz de você um bom jogador de equipe?
* Como você lida com pessoas difíceis? Por favor, forneça um exemplo.
* Você tem experiência em liderar uma equipe? Conte-me sobre isso.
* Conte-me sobre sua melhor e pior experiência de trabalhar em equipe.
* Você se tornou um bom amigo de algum de seus colegas em seu local de trabalho anterior (ou atual)? O que você acha de ter um relacionamento próximo com seus colegas de trabalho? Essa é uma prática boa ou ruim?
* Conte-me sobre um momento em que houve um desentendimento dentro de sua equipe. O que você fez?
* Você já teve dificuldade em fazer com que os membros de sua equipe aceitassem sua sugestão ou ideia? O que aconteceu?
* Quais são as três características mais importantes das pessoas com quem você gosta de trabalhar?
* Conte-me alguns prós e contras de trabalhar em equipe.


## Technical

* Quantos anos de experiência você tem em *[linguagem de programação específica]*?
* Quais são suas certificações técnicas?
* Você tem experiência usando o software [X] em algum de seus trabalhos anteriores?
* Como você se mantém atualizado com as últimas tendências tecnológicas?
* Quais recursos on-line você usa para ajudá-lo a fazer seu trabalho?
* Conte-me sobre o maior desafio de TI que você enfrentou em sua carreira até agora? como você lidou com isto?
* O que você está procurando em sua próxima posição?
* Como você ficou sabendo dessa vaga de emprego?
* O que fez você se candidatar a essa vaga?
* O que mais te excita nessa posição?
* Por que você está deixando seu local de trabalho atual?
* Em que tipo de projetos de tecnologia você trabalha no seu tempo livre?
* Em que tipo de cultura no local de trabalho você prospera?
* Você prefere trabalhar sozinho ou em equipe?
* Descreva o tipo de ambiente de trabalho em que você pode realmente dar o seu melhor e ser mais produtivo.
* Descreva sua situação de trabalho ideal (ambiente de trabalho, horas, viagens e similares).
* O que você sabe sobre a nossa companhia?
* Por que você quer trabalhar em nossa empresa e não em outro lugar?

### Technical interview tips

* Faça uma lista das perguntas técnicas da entrevista que você deseja fazer aos seus candidatos.
* Desenvolva um sistema de classificação para cada pergunta e crie scorecards de entrevista.
* Pergunte a cada candidato entrevistando para um determinado cargo as mesmas perguntas na mesma ordem.
* Anote as respostas dos candidatos!
* Pontue cada uma das respostas de seus candidatos.
* Compare as pontuações dos candidatos para escolher os melhores!


----
----
----
----
----

## Perguntas que o recrutador pode fazer

[geek hunter](https://rhtech.geekhunter.com.br/12-perguntas-que-levam-o-recrutador-aos-melhores-desenvolvedores/)

Roteiro para entrevista entre gestor e desenvolvedor
Agora que você chegou até aqui, chegou a hora de conhecer 12 perguntas que costumam ser feitas durante a entrevista com gestor. 

+ O que atraiu você para a nossa empresa?
+ De que maneira você acredita que os seus conhecimentos podem nos ajudar?
+ Conte sobre a sua experiência na empresa X e indique um trabalho que você acredita que tenha feito a diferença por lá. E por que funcionou tão bem?
+ Fale sobre como se sente quando a entrega não atende com precisão o cliente. Lembra de algum exemplo que teria feito diferente?
+ Quais sites, blogs, fóruns você acompanha regularmente? Quais são as suas referências?
+ Quais habilidades e tecnologias você tem interesse em aperfeiçoar?
+ Como lida com desavenças na equipe? Você acha que trabalha melhor sozinho ou em equipe?
+ Qual foi o melhor emprego que você teve e por que o considera o melhor?
+ Que tipo de projetos motiva você?
+ O que é essencial que o seu empregador saiba sobre você?
+ O que faria com que você desistisse de aceitar uma oferta de trabalho do concorrente?
+ Existe outro cargo que interesse na empresa?
+ As perguntas listadas acima costumam ajudar bastante o entrevistador a acessar os melhores desenvolvedores, por isso, é sempre bom tê-las em mente.


## Hunt Club

https://www.huntclub.com/blog/29-unique-interview-questions

**Common interview questions**

Here's a smattering of the interview questions most employers ask:

+ Tell me about yourself.
+ What are your strengths and weaknesses?
+ Where do you see yourself in half a decade?
+ Why did you apply for this position?
+ Why are you leaving your current employer?
+ Do you have any questions for me?
Although these questions are essential, yo
u'll want to create ones that are a little more unique than this. Many applicants have gone through the interviewing process multiple times and have heard the same questions repeated ad infinitum.

**The Curveball Question**

Some jobs require employees to be quick or creative on their feet. Curveball questions are superb at revealing these attributes in applicants.

Use these queries to evaluate the creativity of candidates for jobs that depend on creativity or out-of-the-box thinking.

https://mindsharecollaborative.com/curveball-interview-questions/

**Icebreaker Questions**

Icebreaker questions help a candidate to relax at the beginning of an interview. 

They also give him a chance to warm up his communication skills, give him a tantalizing taste of your company's culture and a fun first impression.

Here are a few of them:

1 - If you could choose one superhuman ability, what would it be?
1 - What TV or movie character would you most like to have lunch with?
1 - Which one do you love more--felines or canines?
1 - If you were stuck forever on a deserted island and had all the food, water, and shelter you needed, what three personal items would you bring?
1 - Which literary character did you always dream of being?
1 - If you could visit any country on the planet, where would you go and why?
1 - Name ten uses for a stapler (other than its intended use).
1 - Do you think zombies should be slow or fast? Why?
1 - Describe this job to an extraterrestrial who just landed in Central Park.

**Other Unique Questions**

Ideally, you should create your own unique questions that are a perfect reflection of your workplace culture.

Here are some to either use as is or as fodder for your creative imagination:

1 - Tell me about a time you set a challenging goal for yourself and how you accomplished it.

The answer to this will show you how much effort the interviewee is willing to expend on challenges. Have him walk you through what they did to take their goal from nebulous idea to concrete reality.

Then, you'll know how they might act when challenges arise in your company. 

1 - Describe the work environment that will help you to contribute most effectively.

This question should give you an excellent indication of what the candidate’s ideal workplace is. After you get his response, you'll be able to assess whether he would flourish in your company. Or wither away because the work culture won’t be to his liking.

If that happens, you’ll have hired the wrong person—a mistake that might have been entirely avoidable had you asked the right questions.

1 - What kind of oversight would your ideal boss provide?

The response will reveal how self-directed your future employee is. Some employees need a lot of handholding.

If your company depends on autonomous team members, this is an excellent one to pose to weed these types of people out. 

1 - What project is your most significant career accomplishment?

You want team members whose actions add value to your company. If the applicant talks about an impressive achievement he helped to bring about and his story sounds credible, this might be someone you want to bring on board.

1 - What are the three most important attributes you’ll bring to our company?

Make sure the values your applicant mentions are congruent with those of your own workplace. If they’re wildly divergent, this might not be the person for you.

Talk to me about a period in your life when you had to conquer a significant limitation that stood in the way of you accomplishing a goal.
By asking this, you’ll get insight into how good an applicant is at transcending tough challenges.

The question might also help tease out their problem-solving style, which could be useful information to have when you’re making a hiring decision.

1 - What excites you most about this job?

This one will help you discover if the prospective employee has a passion for the job he's applying for. If he gives a lackluster response, you might want to steer clear of him and hire someone else.

1 - How would your co-workers describe you?

This one will help you assess if colleagues enjoy working with the candidate, which will help you know if he's a team player.  

1 - How would your current boss rate the quality of your work?

 This question might tell you how good the candidate is at accepting criticism and feedback. If the applicant uses this time to vent about how bad his previous supervisor was, this might be a red flag.

1 - How will your skills contribute to the accomplishment of our company's mission?

These days, applicants are expected to conduct preliminary research on the company they want to work for. This question will show how much initiative the candidate took to investigate his future employer before coming to the interview.

1 - How are you going to continue to develop your professional skills and knowledge?

You want to hire interviewees who passionately believe in the power of continuous improvement and development. 

1 - By asking this question, you'll also learn where the candidate needs improvement or areas where they need to expand their skills.

Pitch my business to me as if you were me, and I was an investor interested in buying the company.
 The candidate’s response will show you how skilled they are in the art of persuasion.

 His answer will show you his depth of understanding of what your company does and his ability to sell your product or service.  

1 - Name a professional experience you would never want to go through again. 
This question shows you how good the candidate is at learning from mistakes and extracting something of value even from the worst situations.

Is it better to have a job done perfectly, albeit late, or merely good but on time?
You don't want someone who can't meet deadlines because they're paralyzed by perfection. 

So really, there's only one right answer to this.

1 - In five minutes, can you explain something to me that you know well?
The candidate’s response will tell you how well your interviewee can articulate a subject to someone who doesn't know much about it.

In many companies, this can be a valuable communication skill to have.

1 - Tell me about a time you felt like a miserable failure. 
The candidate’s answer will tell you if he can take ownership of mistakes and learn something from them. Good explanations don't brush away failures but say how the individual fell short of what they were trying to achieve and how they would do things differently in the future.

Beware the candidate who says he never screws up!

Other people to avoid are those who blame others for everything wrong in their life.

1 - What's something you'd be ecstatic about doing every day for the rest of your professional career?

This question will uncover what makes the candidate happy at work—which is an excellent way to gauge whether he’d stay at your company long term. 

1 - If I gave you $100,000 to build your own business, what would you do?

The kind of venture the candidate chooses can be quite revelatory, giving you more than a mere glimpse into his interests. His answer will also tell you how much business acumen he has and the values he holds dear.

1 - See if you can also glean any information about his decision-making abilities from this question.

What's the most significant decision you made in the past year?
This is another question you can ask to gauge how an applicant's decision-making prowess. Find out if they quickly made that decision or if they stewed over it for some time.

You might also learn how the candidate decides between two competing alternatives.

1 - If you were tasked with re-branding this company for the (BLANK) industry, what would the press release's headline be?

This question lets your applicant show off his creative thinking abilities.

Let him dazzle you with them!
