# Mercado de Trabalho em TI - Vídeos Youtube

## Lucas Montano- Desvendando a falta de vagas para Programadores Júnior

https://www.youtube.com/watch?v=cTxpcFdAxOI&list=WL&index=24&ab_channel=LucasMontano

O que fazer se você é júnior
+ Tudo bem ganhar enquanto aprende viu
  - **VOCÊ PODE OFERECER FREELA, FAZER PROJETO PRÓPRIO, TUDO ISOS PARA TER EXPERIÊNCIA, PROVAR QUE É MESMO UM JÚNIRO E ASISM SE CANDIDATAR PARA AS VAGAS**
+ Vá atrás de prospectar, e asism conseguir experiência para se destacar nas suas entrevistas

**Comentário**

> William Canin :: há 2 dias
Perfeito o que você disse a partir do 7:57, Lucas. Em vez de eu ficar esperando por empresas reconhecer meu potencial e assim começar a investir em mim, eu mesmo reconheci meu potencial e investi em mim mesmo. Criei meus projetos, participei de uns sem compromisso financeiro e assim criei credibilidade. Junior não tem que pensar em carteira assinada, tem que pensar em fazer a sua própria imagem profissional sem esperar retorno imediato, uma especie de marketing de si mesmo, só depois o reconhecimento vem e assim é contratado.

> Alef há 2 dias :: Uma coisa que me desbloqueou recentemente foi algo que o programador Br postou, na verdade é algo bem simples e intuitivo e eu não tinha pensado nisso: feito é melhor do que perfeito!
Depois disso eu sinto q destravei minha mente, eu tenho uma ideia e vou lá e tento fazer, não sei se é o melhor jeito mas é o jeito que eu consigo agora então em vez de ore preocupar com outras coisas eu me dedico a fazer funcionar, tornar a ideia realidade! Quando aprender mais posso voltar e tentar melhorar como já aconteceu, mas agora o importante é aplicar o pouco que sei... O akita disse isso em um vídeo: com 20% de conteúdo tu consegue r solver 80% dos problemas


> Bruno Marcelo Ferreirahá 2 dias ::
Me formei no final de 2020 em Engenharia de Software na Universidade Federal do Pampa onde o curso adota a metodologia de Resolução de Problemas. Foram 6 disciplinas resolvendo problemas do município e da comunidade acadêmica por meio de desenvolvimento de software. Procurei vaga como júnior durante 1 mês e consegui minha primeira oportunidade em 2021. Os recrutadores adoraram ouvir que eu já tinha experiência resolvendo problemas reais mesmo em ambiente acadêmico. Não estou falando que sou melhor desenvolvedor que os outros, mas muita gente apenas copia projetos e já acha que possui experiência suficiente para ser dev jr. A minha dica é criem seus próprios projetos, tentem resolver problemas mesmo que pequenos e tenham vontade de aprender que vocês vão ter sucesso nessa área.
