## WPP - Vaga - Data Science



## Martins - Data Scince I



RESPONSABILIDADES E ATRIBUIÇÕES



- Realizar análise para identificação de problemas e oportunidades; 
- Descobrir e avaliar a relevância de novas fonte de dados; 
- Automatizar a criação de centenas de modelos de machine learning; 
- Trabalhar com grandes bases de dados para identificar padrões e segmentar clientes;
- Identificar novas oportunidades de aplicação de machine learning; 
- Produzir análises detalhadas sobre comportamento de usuários, modelos estatísticos, fontes de dados, etc.;
- Extrair insights através de metodologias de mineração de dados;
- Comunicar os resultados com profunda compreensão; 

REQUISITOS E QUALIFICAÇÕES



- Superior completo ou em formação em Ciência da Computação, Estatística, Sistema de Informação, Engenharia da computação, ou áreas correlatas.
- Conhecimento em Linguagens de programação de análise de dados (Python e SQL).
- Data Mining
- Modelagem Estatística
- Inglês intermediário