# Vagas WPP - Analista de Dados



##  CallLink - analista de dados

Vivemos a diversidade. Portanto, não nos importamos se o seu cabelo é verde ou
amarelo ou qual é o seu penteado preferido. Prezamos pela forma que faça você se
sentir bem, em casa.
O que priorizamos de verdade é a sua capacidade intelectual e, acima de tudo, seu
engajamento com o grande propósito que nos move. Respiramos o propósito e sabemos
a importância de cada um nessa jornada.
Se você é fora da curva, mente aberta, colaborativo e gosta de grandes desafios, essa
vaga é para você. Você fará parte de uma equipe responsável pela criação de um
produto inovador e inspirador!

**Responsabilidades:**

- Elaborar o controle e análises (ambiente digital) das operações, bem como seus indicadores e metas, reunindo todas as informações relevantes e estratégicas visando atender a necessidade do cliente contratante;
- Ser responsável por planejar a execução da extração de relatórios, compilação de dados extraídos de diferentes fontes em um único banco de dados;
- Criar e Desenvolver ferramentas de automatização para uso das operações, produzindo resultados técnicos e de negócios de acordo com os objetivos estipulados, visando atender a necessidade do cliente contratante;
- Realizar pesquisa de informações estratégicas, de quais métodos mais relevantes serão utilizados nas operações, definindo e direcionando quais arquiteturas de dados para relatórios serão utilizadas;
- Executar e desenvolve o aperfeiçoamento de execução de extração de informações: integrar, Extrair, atualizar e enviar relatórios;
- Definir novos padrões e melhorias constantes dos processos de desenvolvimento, garantindo que a arquitetura proposta seja seguida, visando atender a necessidade do cliente contratante;
- Identificar novas bases de dados para o crescimento do negócio quando for solicitado;
- Desenvolver relatórios via sistema, realizando a criação de fonte de dados, sua coleta, manutenção e análise dos dados;
- Criar demonstradores em sistema informando como o discador e o mailing está se comportando, bem como se este mailing está sendo trabalhado corretamente;
- Desenvolver rotinas automáticas, manutenção e atualização de rotinas, gerando desenvolvimento de Reports Gerenciais e Operacionais.

**Requisitos****:**

- Gestão de Serviços de TI com ITIL;
- Habilidade em Business Intelligence;
- Metodologias de Qualidade (PDCA, SDCA, entre outros);
- Conhecimento de MIS;
- Reporting Service;
- Integration Service;
- Experiência com QlikView;
- Programação VBA;
- Lógica de Programação Avançado;
- Habilidade em SQL Avançado.

**Diferencial****:**

- Habilidade em SQL



## Martins - Analista de dados

RESPONSABILIDADES E ATRIBUIÇÕES



- Limpeza de dados (identificação, correção de informações duplicadas, inválidas ou corrompidas); 
- Garantir a qualidade dos dados, das integrações e a consistência de relatórios; 
- Automatizar documentos para uso recorrente; 

REQUISITOS E QUALIFICAÇÕES



- Superior completo ou cursando;
- Conhecimento em linguagem SQL Server;
- ELT - Integration Server Microsoft;
- Visual Studio .Net - C#, .Net Core;
- Cloud server Azure;

INFORMAÇÕES ADICIONAIS



- Salário fixo;
- Convênio médico e odontológico;
- Gympass;
- Previdência privada;
- PLR;
- Acesso a plataformas de cursos: Simplesfica e Alura;
- Plano de carreira;