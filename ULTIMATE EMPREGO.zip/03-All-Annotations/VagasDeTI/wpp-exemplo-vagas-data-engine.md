## Kyros - Engenheiro de Dados

**O que você precisa saber:**



- Banco de dados relacional (Oracle ou Postgre ou SqlServer)
- Linguagem SQL e plsql
- Construção e ferramentas de ETL (Pentaho, PowerCenter ou outros)
- Modelagem de dados Tuning de queries
- Experiência com SQL, DDL, DML , tuning de queries, procedures e etc;
- Experiência com ambientes de Alta Criticidade e Alta Volumetria;

**Será um diferencial para você:**



- Python
- Apache Airflow
- Git
- Power BI
- Conhecimento com tecnologias como: AWS RDS, AWS Redshift, AWS S3; AWS Athena, AWS KMS, Jenkins
- Conhecimento em pipelines batch e near real time
- Docker ou Kubernets, Apache Airflow.
- Conhecimento em KPI’s, reporting e dashsboards.

## Check-up

https://www.linkedin.com/posts/carlosmorajr_trabalheconosco-cv-activity-6900146875023138817-3MOG/

https://media-exp1.licdn.com/dms/image/C4D22AQEzaegZ4UZNdg/feedshare-shrink_800/0/1645123212823?e=1649289600&v=beta&t=U_tGub9945WfJc9ndbRpAaOU_bhNlkpPAUnpOk1MhDE

## Projetas Eng Dados JR

##### ENGENHEIRO DE DADOS JR

![img](https://s3-us-west-2.amazonaws.com/ux.projetas.com.br/location.png) **Modalidade de contratação: Pessoa Jurídica**
![img](https://s3-us-west-2.amazonaws.com/ux.projetas.com.br/location.png) **100% Remoto
**
 Formação/ Especializações/ Certificações:

\- Superior Completo nas áreas de TI/Engenharia/Afins
\- Certificações AWS (Desejável)

Experiências desejáveis:

\- Experiência com bancos de dados não relacionais como: HBase, DynamoDB, Cassandra ou MongoDB;
\- Conhecimento de testes unitários
\- Vivência básica em processos de carga/gestão de dados em ambiente AWS
\- Conhecimento básico de pilha de serviços de Data Lake AWS.

Experiências úteis:

\- Experiência com bancos de dados relacionados como: SQL Server, Oracle, PostGreeSQL e MySql;
\- Atuação em projetos de BI, Big Data

Perfil Técnico:

\- Serviços AWS - EMR      
\- PySpark      
\- Python   
\- Conceitos de Data Lake     
\- Linguagem SQL    
\- Modelagem de dados    
\- Modelagem multidimensional   
\- Experiências em ferramentas ETL's     
\- Git   
\- Serviços AWS - S3   
\- Serviços AWS - Redshift    
\- Apache Airflow    


Principais atividades:

\- Criação dos processos de ingestão em projetos de Data Lake, passando pela camada de encenação e disponibilizando os dados na ferramenta de visualização de dados para o tempo de BI do cliente consumir.  





## Projetas - Eng Dado SR

##### ENGENHEIRO DE DADOS SÊNIOR

![img](https://s3-us-west-2.amazonaws.com/ux.projetas.com.br/location.png) **Modalidade de contratação: Pessoa Jurídica**
![img](https://s3-us-west-2.amazonaws.com/ux.projetas.com.br/location.png) **100% Remoto**

**Formação/ Especializações/ Certificações:**

- Superior Completo nas áreas de TI/Engenharia/Afins
- Certificações AWS (Desejável)

**Experiências desejáveis:**

- Experiência em geração de relatórios / dashboards em ferramenta de visualização, como Power BI / QlikView / QuickSight

**Experiências Comum:**

- Experiência em projetos de DW / BI / Data Lake
- Experiência em Desenvolvimento e Gestão de Tempos em Projetos desta Natureza
- Experiência como líder técnico
- Arquitetura de Data Lake AWS
- Vivência na área de Data Lake
- Conhecimento de modelagem de dados para BI
- Vivência de ao menos 1 ano em processos de carga/gestão de dados em ambiente AWS
- Conhecimento profundo da Stack de Serviços de Data Lake AWS
- Experiência em geração de relatórios / dashboards em ferramenta de visualização Tableau.

**Perfil Técnico:**

- AWS Lambda
- AWS RedShift
- AWS S3
- Linguagem Python
- Cola AWS
- Quadro
- Power BI / QlikView / QuickSight (Desejável)
- Kafka
- Serviços de Integração da Microsoft
- Pilha de Serviços AWS para Data Lake
- Formação de nuvens/lagos
- Apache NiFi

**
****Principais atividades:**

- Criação dos processos de ingestão de dados em Data Lake
- Desenho de arquitetura de solução para Data Lake
- Modelagem de dados de BI / Data Lake
- Extração de dados e geração de arquivos de saída
- Geração de Relatórios / Dashboards
- Mapeamento de dados
- System / Data Discovery - Entendimento dos sistemas de origem.
- Liderança Técnica do Tempo de Data Lake

## pROJETAS - Eng Dados PL

##### ENGENHEIRO DE DADOS PLENO

![img](https://s3-us-west-2.amazonaws.com/ux.projetas.com.br/location.png) **Modalidade de contratação: Pessoa Jurídica**
![img](https://s3-us-west-2.amazonaws.com/ux.projetas.com.br/location.png) **100% Remoto**

**Formação/ Especializações/ Certificações:**

- Superior Completo na área de tecnologia/engenharia/afins.
- Certificações AWS (Desejável)

**Experiências desejáveis:**

- Experiência em geração de relatórios / dashboards em ferramenta de visualização, como Power BI / QlikView / QuickSight / Tableau
- Conhecimento da linguagem Python

**Experiências Comum:**

- Experiência em projetos de Cloud / DW / BI / Data Lake
- Experiência em Desenho de Arquitetura e Criação de Serviços em Nuvem AWS, utilizando-se das melhores práticas de aplicabilidade, custos, segurança
- e governança
- Vivência na área de BI/Data Lake
- Conhecimento da Stack de Serviços do Data Lake AWS
- Conhecimento de modelagem de dados para BI
- Banco de dados (SQL Server): T-SQL, Query tunning, Particionamento
- Vivência em processos de ETL usando ferramentas de mercado (SSIS/Pyspark/Pandas/Boto/NIFI)
- Conhecimento em processos de ingestão de dados em Data Lake

**Perfil Técnico:**



- Conhecimento de toda a Stack de Serviços AWS
- Desenho de arquitetura em Cloud AWS
- AWS Lambda
- AWS Kinesis
- AWS VPC/sub-rede/grupos de segurança
- AWS RedShift
- AWS S3
- Linguagem Python
- Formação de nuvens
- Tableau/Power BI/QlikView/QuickSight (Desejável)
- SSIS
- SQL

**Principais atividades** :

- Desenho de arquitetura de processos de nuvem, especialmente para os processos de Data Lake, inclusive com interface com cliente
- Especificação de processos / estimativas de prazos para criação de serviços em nuvem
- Criação de processos de ingestão de dados / ETL
- Criação de pilha de serviços de Data Lake utilizando Cloud Formation
- Extração de dados e geração de arquivos de saída

## Engenheiro de dados SR | Remoto - Tribanco

## DESCRIÇÃO DA VAGA



Desenvolver uma arquitetura de dados robusta e escalável, que suporte os times de Dados (Analytics, BI, Data Science e Machine Learning) e demais áreas de negócio, democratizando o acesso aos dados, de forma segura, simples, estruturada e com qualidade.



## RESPONSABILIDADES E ATRIBUIÇÕES



- Implementar em parceria com a arquitetura de TI e Infraestrutura ambiente de dados para suportar o trabalho de análise nas empresas Tribanco.
- Resolver incidentes que impactam na entrega de informações da área de analytics.
- Corrigir problemas que impactam no fluxo da informação.
- Levantar dados técnicos e de negócios para construção de solução de analytics.
- Desenvolver solução técnica em analytics entregando valor em forma de dados, informações, KPIs ou modelos estatísticos para organização.
- Gerenciar ambiente técnico de servidores e softwares que sustentam a área de analytics, empregando os recursos necessários para as rotinas, prioridades, upgrade de softwares e releases.
- Analisar no que pode ser melhorado de acordo com as políticas, recursos, processos e rotinas sob nossa responsabilidade, assim garantindo maior eficiência menos tarefas manuais.
- Elaborar e desenvolver fluxos de ETL e ELT direcionados para DW ou Data Lakes.
- Suportar a operação e suas rotinas
- Garantir que as informações disponibilizadas estejam integras e concisas.
- Liderar tecnicamente o time de engenharia de dados



## REQUISITOS E QUALIFICAÇÕES



- Bacharelado em Sistemas de informação, Engenharia de Informação, Ciência da informação ou afins
- Especialização em algum tema que envolva Dados
- Conhecimento em IBM Infosphere DataStage e Cognos
- Conhecimento nas seguintes linguagens de programação: Python, Spark, Scala e Java.
- Conhecimento avançado em SQL
- Domínio em API’s (REST e SOAP)
- Especialização em Cloud (AWS, Azure ou similares)
- Ingestão de dados via streaming e batch
- Domínio em banco de dados SQL e NoSQL
- Construção de pipelines de ingestão e manipulação de dados (ETL/ELT: MS SSIS e Infosphere Data Stage)
- Domínio em orquestração de dados
- Modelagem de dados e camada de dados
- Conhecimento em ferramenta de versionamento de código (GIT)
- Domínio e conhecimento nos principais modelos relacionais e não relacionais