# Vagas de Trabalho

## Código Fonte TV

[Testamos Nossa Paciência Reagindo a Vagas para Programação Jr](https://www.youtube.com/watch?v=RGi24q4NAEM)

Dicas da análise das vagas
+ Nem sempre as vagas sao publicadas por alguem ténica
+ Saiba o salário e se o remoto ou não e se 100% remoto
+ Nem sempre aceite qualquer vaga, ainda mais se a vaga nâo for clara e minimamente decente

ceomnetarios

+ => A designação 'Junior' é referente ao salário que o coitado vai receber kkk, o que eles querem é um Senior!
+ => O problema é que as empresas de tecnologia querem um Dev Júnior com 30 anos de experiência 10 projetos e que saibam todas as linguagens de programação.
+ => Bom profissionais formados tem, o problema é que você se forma e cai no loop de ir atrás de experiência mas não conseguir porque para ter experiência você precisa ter experiência, juntando isso a vagas de Júnior com requisitos de anos de estudo e empresas que não querem ninguém que elas vão ter que treinar, aí cai nessa "escassez". Como recentemente em uma vaga que me candidatei os entrevistadores elogiaram meus projetos e meu código e que era excelentes para um Júnior e terminaram com um infelizmente procuramos alguém com experiência na área. Ou seja mesmo com projetos que demonstram que eu tenho experiência por nenhum desses projetos ter sido feito para uma empresa eu fui descartado. Aí fica difícil até querer continuar tentando entrar nessa área e para o meu azar é a única coisa que eu gosto de fazer.
+ => Não sou da área (ainda) mas meu irmão está a uns 5 anos na área e é Dev backend. Pelo que ele fala, a tendência do Brasil é ficar brigando por pleno/sênior, dão pouquíssimas vagas pra júnior. Os profissionais estão aprimorando o inglês e trabalhando pra empresas do exterior ganhando em dólar, assim como meu irmão está ganhando. Brasil vai demorar muuuuuuuuuuuuuuuito pra deixar o mercado legal.

## 

[Analisamos 6 Vagas Remotas para Devs que Pagam em Dólar ou Euro (Oportunidades para Brasileiros)](https://www.youtube.com/watch?v=mOto5IEi18U&ab_channel=C%C3%B3digoFonteTV)

Acesse uma Remessa Online apra recebr de fora

## 

15 DICAS PARA CONSEGUIR O PRIMEIRO EMPREGO NA ÁREA DE PROGRAMAÇÃO

LINKDIN
1. Crie o Linkedin e manteha ele atualizado
2. Nâo tenha vergonha de adicionar pessoa no seu linkedin
+ É normal adicionar sem se conhecer
3. Poste as conquistas (mesmo que seja bem básico)
4. Procure as plataformas da sua região
5. Crei um GitHub
6. Crie o seu próprio portifólio (use a criatividade)
7. Participe de comunidades na sua área
8. Não subestime seus professore e colegas de turma
9. Não te nha medo de se candidatar pras vagas
10. Pesquise sobre essa empresa
11. O que voce vai agregar pra nossa empresa?
+ voce vai ter que saber o que a empresa faz
12. Avalie se a empresa vai ser boa pra voce
13. Nâo minta sobre o seu currículo
14. Esteja preparao para as suas soft skills
15. Nâo deixe o recrutador no vácuo

