## Kyros - Consultor BI

https://www.kyros.com.br/oportunidade/

Graduação em curso de nível superior na área de Tecnologia da Informação ou conclusão de qualquer curso de nível superior acompanhado de certificado de curso de pós-graduação (especialização, mestrado ou doutorado) na área de Tecnologia da Informação de, no mínimo, 360 horas.
Local de trabalho: Há a possibilidade de trabalhar no modelo 100% remoto ou presencial
Salário e benefícios: a combinar

***\*Como Consultor (a) BI seus desafios serão\**:**

- Query SQL
- Análise de dados
- Integração de dados

***\*Requisitos\**:**

- Experiência com DataStage e Data Warehouse
- Experiência com o processo de extração, transformação e carregamento de dados
- Conhecimento de banco de dados e modelagem de dados
- Experiência com Banco de Dados relacionais

***\*Habilidades\**:**

- Proatividade
- Pontualidade



##  ValeCard - Analista de BI JR

DESCRIÇÃO DA VAGA

+ Lidar com análise e projetos de modelagem de dados usando dados coletados na organização.

RESPONSABILIDADES E ATRIBUIÇÕES

+ Analisar dados;
+ Auxiliar na identificação de tendências para tomada de decisão;
+ Construir Dashboard de indicadores de negócio.
+ Apoiar a construção de automatização de novos processos.

REQUISITOS E QUALIFICAÇÕES

+ Superior Completo em áreas de tecnologia / engenharias;
+ Conhecimento avançado em Excel;
  Plataformas de BI existentes no mercado;
+ Data Warehouse (DW);
+ Gerenciamento de processos;
+ Conhecimento de infraestrutura de TI;
+ Inglês intermediário.

## Assistente de BI - Martins