# Como dizer algumas coisas em inglês

## Resumo

+ job requirements 
  - Trad: Requisitos para a vaga (\\jób riquariments)
+ vacancy 
  - Trad: Vaga | (\\veicansi) / vacancies (\\veicansis)
+ job opening
  - Trad: Vagas abertas | (\\jóbi openin) | 
+ position 
  - Trad: cargo/vaga |  (\\pâzishion)
  - Usamos 'vaga' em portugues mas no ingles seria 'position' ao inve de 'vacancy'
    - Exmplo: "Eu quero uma vaga de analsita" é o mesmo que cargo, nâo vaga 
    - 'vacancy' tem sentido de espaço aberto para algo e 'position' cargo
+ lines
  - Não só significa linhas como o substantivo 'falas' / (\\laines)

**Números**
+ 26 = twenty-six (\\tuani-siks)
+ 2022 = two thousand twenty-two (\\tchu tausan tuani-tchu)

**Datas**
+ in April 2022 (\\in april tchuani tchuani-tchu)

## Frases corriqueiras

+ i'm glad to meet you

==================
==================
==================
==================

#### 'me falta'

I lack (\\ai lék)

#### 'intermedário

intermediate (\\intérmiria)

#### 'de quem'

woose (\\ruuzi)

#### 'reclamar'

complain (\\complein)

#### 'eu já'

I have already (\\ai rév ouéri)

#### 'estágio'

internship (\\intérship)

#### 'entrevistador'

interviewer (\\interviuér)

#### 'falas'

lines (\\laines)

Frase:
+ I have some lines memorized
 - \ai rév som lainis mêmorais

#### 'tcc'

+ Final paper
+ Term paper 
+ Undergraduate thesis


#### 'requisitos

job requirements (\\jób riquariments)

#### 'vagas'

[link](https://www.youtube.com/watch?v=2nkhmh1Ynyo)

Vagas de emprego

Vaga de emprego (vaga em aberto)
+ vacancy (\\veicansi) / vacancies (\\veicansis)
+ job opening (\\jóbi openin)
Cargo 
+ position (\\pâzishion) (obs: não em nenhum som de ó no inicio da palavra)

**vacany**

Ex:
+ We have some vacanies in the Marketing department
+ You can find all the job openings on our web-site
+ Sorry, we dont' have vacancies at the moment

ob: vacansies pode ser usada também para 'vaga em hotel'
+ We wanted to stay in that hotel but there were no vacancies

**position**

Agora, por exempol,  falar "qando eu estava ocupadano a vaga de atendente da unileve", quando vaga significa posisçao, qual palavra usar?
+ Nesse casao agente nao usa os temos anteoreis, agente usa *POSITION*. 

Nâo confunda usar vac
+ She has an important position in the company
  - Nesse caso nao troque d emaneira nehuma position por vacancy
+ I've applied fot the Marketing Manager position at Heineken
+ My last position there was a Sales Director
+ I am very interested ub this position
  - aqui tambme nao cabe o vacancy

