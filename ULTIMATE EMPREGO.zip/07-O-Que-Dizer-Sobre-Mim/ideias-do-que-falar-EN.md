# Ideas of what to say in English



## Who am I

**BR**

Hello, my name is Rafael Morais de Assis, I graduated from the Federal University of Uberlândia and did 2 years of internship at Neppo, also in Uberlândia



## What are you looking for at the moment

After finishing my TCC in April 2022, I'm looking for a job as a junior developer or even an intern.

I can also work as a full-stack, but with a special focus on the front end, because even though I could not work on the back-end, I didn't have many opportunities to really develop features.

As a front-end I have good experience in Vue.js

On the back end I have mixed experiences: the main one is using a Node stack with Express.

Working even I already played with: Java + Spring and PHP + SLim (micro-framework)

IN personal projects I have already developed: Python+ django or flask, php + laravel

As a data scientist, he had experience in my CBT, in addition to courses and some personal projects



## Personal projects

data science

+ API PREDICTOR (*work order*)
  + Consists of a web page where you can put the inputs and call the model by api.
  + It also has a backend in flaks that gives access to my TCC's machine learning model
  + Function: My TCC was together with a project in which an ML model was developed. The site basically allows you to pass the parameters and use the model to predict whether the client will open the OS in the next 15 days
+ Comment Evaluator
  + Consists of a machine learning model to predict whether the comment entered is a positive or negative review about a product/service



## My TCC

My TCC was part of a larger context of a research project that consisted of determining whether, through the parents of the telecommunications company Algar Telecom, it is possible to predict when the customer will complain about the internet. The idea was to connect the customer to their internet signals, understand if it was getting bad or not, and thus predict whether the customer would call complaining about the internet in the next 15 days. Provides for the opening of a service order, then allows you to send a technician to fix the network and thus prevent him from calling.





## What I like / Hobbies

### Books

I like to read books, fiction literature. The last ones I read unexploded were Stendhal's Red and Black.

*Stendhal - The Red and the Black*

It tells the story of Julien Sorel, a very intelligent young boy whose great idol/model is Napoleon, in a time after Napoleon, when many people hated him (for what he did).

The Subtitle of Estria is Chronicles of the 19th Century.

*Training Romance*

It is a formative novel: like The Apprenticeships of Wilhelm Meister (Goethe) (*Bildungsroman*), David Copperfield (Charles Dickes); Rye Catcher)

*Psychological Roamne*

The **psychological novel** is a literary genre that focuses less on the external constraints of the social and cultural environment and, more, on the intimate motives of human choices and actions, in the flow of affections and memories of the [unconscious](https: //pt.wikipedia.org/wiki/Unconscious) to the [conscious](https://pt.wikipedia.org/wiki/Conscious), determining behavior.

### Series and Anime

 I also follow some series and anime

### Walk

I go for walks from time to time, I also got some medals but not in a competitive way

## Why did you quit your last job

When he started working at neppo elea company it was a small company that used to be a third party company of another company. So, most of the projects were to provide services to other companies.

But they managed to build a product called Neppo Ominichael. After its success, it then began to reduce the workforce, stop being only outsourced and so I was one of the people to leave the company.

[Neppo website](https://neppo.com.br/omniechannel-e-multicanal/)

[Website about ominchannel](https://blog.cronapp.io/melhores-plataformas-omnichannel/)

## What is your level of English

My English level is intermediate.

I can read well, but I lack other skills like writing, listening and speaking.

But lately I've been learning pronunciation with the ELSA app and listening with BCC Leaning English. The first is a very good app for you to practice pronunciation, it's an app that tests what you say. The second use is more for listeing and also vocabulary, they are short videos that not only have a story but are also didactic because they present, in the video itself, very different words to serve as a reference as a new vocabulary.
