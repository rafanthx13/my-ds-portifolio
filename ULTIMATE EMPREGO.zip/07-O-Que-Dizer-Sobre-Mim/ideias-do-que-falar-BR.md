# Ideias do que falar em inglês




## Quem sou eu
Olá, meu nome é Rafael Morais de Assis, sou formado na universidade federal de Uberlândia e fiz 2 anos de estágio na empresa Neppo também em Uberlândia.




## O que você busca no momento
Após terminar o meu TCC em abril de 2022 busco uma vaga de trabalho como  júnior ou trainee para um dos seguintes cargos: analista de sistemas, desenvolvedor back-end/front-end/full-stack, engenheiro de software, programador, analista de BI, analista de dados, cientista de dados, engenheiro de dados. 



## Minhas experiências

**Back-End:** No Back-End tenha mais conhecimento na seguinte ordem: Node (Express), Python (Django/flask), PHP (Laravel, Slim), Java (Spring)

**Front-end**: No Front-End tenho mais conhecimento na seguinte ordem: Vue.js, React.js

**Ciência de dados**: Utilizando Python e Jupyter notebook tenho experiências com as seguinte libs:

+ `pandas`, `scikit-learn`, `numpy`, 
+ Visualização de dados: `matplotlib`, `seaborn`, `bokeh`, `plotly`, `plotly+dash`




## Projetos pessoais
Data Science
+ API PREDICTOR ( *service order*) 
  + Consiste numa página web onde você pode por os inputs e chamar por API o modelo. 
  + Também tem o backend em flask que dá acesso ao ao modelo de machine learning do meu TCC 
  + Função: O meu TCC foi junto a um projeto em que foi desenvolvido um modelo de ML. O site permite basicamente passar os parâmetros e usar o modelo para prever se o cliente vai abrir OS nos próximo 15 dias
+ Avaliador de Comentário 
  + Consiste em um modelo de machine learning para predizer se o comentário inserido é uma avaliação positivo ou negativo sobre um produto/serviço
+ State of Data 2021
  + Análise dos dados dos 4 principais cargos de dados (DS/DE/DA/BI) em relação a vários critérios: salário, senioridade, tecnologias e linguagens além da visão quanto ao trabalho remoto
  + Resultado: Deu pra entender bem o salário para cada nível e assim o quanto de salário você pode ter a depender da experiência


## Meu TCC
Meu TCC fazia parte de um contexto maior de um projeto de pesquisa que consistia em detectar se, por meio dos dados da empresa de telecomunicações Algar Telecom, é possível prever quando o cliente vai reclamar da internet. 

A ideia era ligar o cliente aos sinais da sua internet, entender se ela está ficando ruim ou não e assim prever se o cliente ligar reclamando da internet nos próximos 15 dias. Prevê a abertura de ordem de serviço permitindo então mandar um técnico para consertar a rede e assim evitar que ele ligue.

O TCC constitui nos seguinte passos: 1 - Obter os dados; 2 - Analisar os dados; 3 - Limpar os dados; 4 -obter insights dos dados; 5 - juntar os dados; 6 - formatar os dados; 7 - Cria o modelo de Machine Learning (Fabíola); 8 - Testar resultados; 9 - Criar web-app para testar o app online




## O que eu gosto / Hobbies
### Livros
Gosto de ler livros, literatura de ficção. O último que li por exemplo foi o Vermelho e o Negro de Stendhal.

#### Stendhal - O vermelho e o negro

Conta a história de Julien Sorel, um jovem rapaz muito inteligente que tem como grande ídolo/modelo Napoleão, isso numa época após Napoleão, quando muita gente odiava ele.

O subtítulo é 'crônicas do século 19' e se passa em 1830 anos depois da sua derrocada.

### Séries e Animes
 Eu também companhia algumas séries e animes
### Caminhada
Faço caminhada de tempos em tempos, também já consegui algumas medalhas mas não de forma competitiva
## Porque você saiu do último emprego
Quando comecei a trabalhar na empresa Neppo ela era uma pequena empresa que costumava  terceirizada por outras empresas. Grande parte dos projetos era prestar serviços para outras empresas. 

Como a demanda em TI tem crescido bastante todo mundo tinha serviço.

Porém eles conseguiram construir um produto chamado Neppo Omnichannel, que está firme e forte até hoje.

Após o seu sucesso começou então a diminuir a força de trabalho então fui dispensado com outras pessoas também.

**O que é Omnichannel**: a a convergência e integração entre os variados canais de comunicação da empresa (telefone, blog, redes sociais, chat, loja física, loja virtual), tornando mais ágil a interação com diversos públicos, independente da forma de acionamento.. Assim o cliente pode se comunicar por várias plataformas com a empresa que tudo será unificado





## Qual o seu nível de inglês
Meu nível de inglês é intermediário, B1.

Consigo ler bem, mas me falta treinar o escrever, ouvir e falar. 

Mas ultimamente tenho aprendido a pronúncia com o aplicativo ELSA e a ouvir com o BBC Learning English.

+ **ELSA** Primeiro é um aplicativo muito bom para você treinar a pronúncia, é um app que testa aquilo que você fala.
+ **BBC Learning** Já o segundo uso mais pra listening e também vocabulário, são vídeos curtos que não só tem uma história mas também que é didático por apresentar, no vídeo mesmo, palavras bem diferentes para servir de referência como um novo vocabulário

## Random Frases
Mesmo que eu não me saiba bem na entrevista, pelo menos eu posso sentir como é está numa entrevista em inglês.
> Even if I didn't do well in the interview, at least I can feel what it's like to be in an interview in English.

me falta treinar mais. Eu penso em uma frase mas não consigo encontrar as palavras corretas para formar uma boa frase me inglês.

> I need to train more. I think of a sentence but I can't find the right words to form a good sentence in English.

