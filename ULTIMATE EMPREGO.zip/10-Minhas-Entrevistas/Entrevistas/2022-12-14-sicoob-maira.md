Qual é o seu temperamento

O que voĈe consiedera um ambiente de trabalho ideal

O que te movitva?


