# Explo - 2022-11-18

Das 14:15 às 14:50 = 35 minutos

A entrevista foi em português e nâo em inglês como eu estava com medo

Ele me perguntou: 
+ Que tipo de experiência desagradável eu já tive e qual foi a liçâo que tirei
  - Falei de 2: uma da Neppo em que faltava as entregas (pentaho) teram mais qualidade 
  - E falei que na faculdade já levei esporro por apresentar muito mal, pois fazia num dia e depois apresnetava lendo muito slides. Depois desses exprros, aprendir a ler e praticar com muito mais antecedência as apresentações
+ Sobre ele
  - Ele já ficou 5 anos no Brasil, em Goiânia
+ Ele falou que daria um feedback pelo menos até 25/12
+ O que a explo pode ganahr com você
  - O que eu falei: "sou alguem dedicado que tem facildadade em aprender, enteo qualquer coisa que precisar estudar e implementar eu posso e estudar e fazer" (!!!)

O que eu perguntei:
+ A Stack usada no app 
  - Era React Native
+ Perguntei se seria só eu de estagiário
  - Ele falou que sim, que ele gostava de um feedback 1 a 1 e que seria
  - Por isso cpegaria 1 ou 2 a cada mes ou 2 meses
