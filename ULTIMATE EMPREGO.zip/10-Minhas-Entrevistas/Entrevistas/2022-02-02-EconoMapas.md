# Perguntas feitas em entrevistas de Emprego



## Ecnonomapas - Engenheiro de Dados Júnior

Via Microsoft Teams: 02/02/2022

+ Qual foi o seu projeto mais desafiador?
+ Me conte sobre sua experiência na área de dados

Como sempre, ela perguntou se eu tinha mais alguma pergunta



## Backend Júnior - SoftConta

Respondida por google form em: 05/03/2022

+ Fale um pouco sobre você
+ Qual foi a implementação que você já fez, ou participou, na qual você mais se orgulha, e qual foi a sua contribuição?
+ Quais as suas metas de estudo, o que pretende aprender para melhorar as suas skills? 
+ Qual esta sendo a sua maior motivação para buscar uma nova oportunidade? 
