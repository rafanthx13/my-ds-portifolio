# 30/11/2022 - Tarken - Engenharia de dados

14:00 - 14:36

querem saber quem eh o rafael e com o que ja trablou

Querem ser lider em crédito para o agro.

estao com a proposta de auxilaire os forncedeores: fornece analises fincancieras do produto rual.

eng de dados: conseguir extrari todas as informçaoes necessárias para o creidto para o produto rural. Serasa e 'boa vista' auxilia o mercao a transmitir uma ideia  melhor se a pessoa é bom

o objetivo final é fornece algo similar ao score do serasa pmas para o produtor rural.

fazem análse de satelites das plantaçoes, o que esse cara andou plantando,.


Agora estao focados na disponibilziaçao de credito: 

CTO é o Carlão

## O que eu achei da entrevista

+ Essa foi a entrevist amais longa (36min)
+ ELe falou bastante dele e eu d emim memso
+ JoÂo pelo menos entendeu que eu tinha projetos de portifolio, 
  - Mas infelsimente quase nada em PowerBI e engnehraia  de dados (AWS, Airflow
