+ https://dock.tech/
  - Software Engineer II (Python - Clearing)

+ https://alpes.one/
  - Alpes One: Nâo encotnrei vagas

+ https://tripla.com.br/
  - https://tripla.solides.jobs/
  - Nenhuma vaga para meu perfil
    - Especialista de Dados - Banco de Talentos

+ https://rockcontent.com/br/blog/
  - https://rockcontent.com/br/carreiras/
  - Nâo tem vagas para meu perfil, só sênior

grabs jobs
  - O unico lugar que enconretrei coisa da rock content

Tia, na Alpes One e a Rock Content não encontrei vaga. Já na Dock me candidatei em 'Software Engineer II (Python - Clearing)' e na tripla em 'Especialista de Dados - Banco de Talentos'.
