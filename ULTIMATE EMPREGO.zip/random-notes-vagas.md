# RANDOM NOTES


==================================
==== O que inserir ============
==================================

https://github.com/rafanthx13
https://www.linkedin.com/in/rafael-m-de-assis/

netvagas.com.br
  rafanthx10 :: default avançada

Recrutei
  senha default_avancada

+ **BairesDev**
  - https://applicants.bairesdev.com
  - Usuário: rafael.assis6
  - Senha: oNdD/SvR

Rua Rio Paraíba, Eldoradinho, Contagem - MG - CEP 32371520


==================================
[==== Que vagas buscar ==========]
==================================

**BH**
+ Presencial, hibrido, remoto

**Tecnologias**
+ Back: Java, PHP, Node
+ Front: Vue

**Termos**
+ Analista de Sistemas; Engenheiro de Software; Desenvolvedor; Programador
+ EN: Software Developer; Software Engineer; Dev;

==================================
[==== SITES VAGAS ===============]
==================================

Roteiro com links de vagas
+ progmramador-thor : @linkedin
+ geek-thunder : @ login / senha
+ coodesh : @gmail
+ remotar : @gmail
+ turing: 
+ br.talent.com
+ br.hacendo.com
+ br.recruit.net
+ https://app.skeel.com.br/candidato/candidate/dashboard

==================================
[==== EMPRESAS EM BH NÃO CAT ====]
==================================

======= EMPRESAS BH  =======

https://www.linkedin.com/company/conexa-saude/life/?lipi=urn%3Ali%3Apage%3Ad_flagship3_job_details%3B32IbPnQjRzib64qtr7psrw%3D%3D

https://www.linkedin.com/company/grupohinova/life/?lipi=urn%3Ali%3Apage%3Ad_flagship3_job_details%3BJwLzcc6TRhCNXBKF3a1FQA%3D%3D

https://www.linkedin.com/company/ibrowse-consultoria-e-inform-tica/life/?lipi=urn%3Ali%3Apage%3Ad_flagship3_job_details%3BojpgxiTBQMCX9ezCd8mT%2FQ%3D%3D

https://www.linkedin.com/company/toralogistica/life/?lipi=urn%3Ali%3Apage%3Ad_flagship3_job_details%3Bwp00cpsSRLuxSsZpGdnyiA%3D%3D

https://www.linkedin.com/company/79342009/?lipi=urn%3Ali%3Apage%3Ad_flagship3_search_srp_jobs%3Bs8HEgheCS2iW7LAva%2Ff3Ew%3D%3D

https://www.linkedin.com/company/databit-tecnologia-da-informa%C3%A7%C3%A3o/jobs/

https://www.linkedin.com/company/ivory-talent/life/?lipi=urn%3Ali%3Apage%3Ad_flagship3_job_details%3B%2FkQj8i3NRO6%2BnzgVwCmmWA%3D%3D

https://www.linkedin.com/company/syngenta-digital-brasil/life/?lipi=urn%3Ali%3Apage%3Ad_flagship3_job_details%3B%2BVUDiPJJSMOrmVGv27gmVQ%3D%3D

https://www.linkedin.com/company/dxctechnology/life/?lipi=urn%3Ali%3Apage%3Ad_flagship3_job_details%3B1gc00%2Bh4RP6FprC8j00CUA%3D%3D

https://www.linkedin.com/company/rhf-talentos/life/?lipi=urn%3Ali%3Apage%3Ad_flagship3_job_details%3BnfXAb3leSRS1Iog1xyY9cg%3D%3D

https://www.linkedin.com/company/arco-consultoria/life/?lipi=urn%3Ali%3Apage%3Ad_flagship3_job_details%3BrIvmh19xR1KIohFHWVAWtA%3D%3D

https://www.linkedin.com/company/selpegenteegestao/life/?lipi=urn%3Ali%3Apage%3Ad_flagship3_job_details%3BdEPL9ENGQmm3kr8Ncjqtvw%3D%3D

======= OUTRAS CIDADES =======

FLORIANOPOLIS
https://www.linkedin.com/company/fluidapi/


PORTO ALEGRE
https://www.linkedin.com/company/juntos-somos-mais/


CURITIBA
https://www.linkedin.com/company/watch-brasil/

SAO PAULO
https://www.linkedin.com/company/refera/life/?lipi=urn%3Ali%3Apage%3Ad_flagship3_job_details%3BtnoIU3YMT7mAGc%2B8Nq0Hcw%3D%3D
https://www.linkedin.com/company/hospital-albert-einstein/life/?lipi=urn%3Ali%3Apage%3Ad_flagship3_job_details%3BS%2BCNVFz2RaaWJnIDAd1rCQ%3D%3D
https://www.linkedin.com/company/accesstagebr/
https://www.linkedin.com/company/dafitigroup/about/
https://www.linkedin.com/company/evob/
https://www.linkedin.com/company/foursys/
https://www.linkedin.com/company/gringobr/
https://www.linkedin.com/company/konectabrasil/life/?lipi=urn%3Ali%3Apage%3Ad_flagship3_job_details%3BC2QycCvtRJeQiEw9oaPdmg%3D%3D
https://www.linkedin.com/company/papaya-payments/life/?lipi=urn%3Ali%3Apage%3Ad_flagship3_job_details%3BkemrTfSxTreFE1H0bYxl%2Bw%3D%3D
https://www.linkedin.com/company/cadmus-ti/life/?lipi=urn%3Ali%3Apage%3Ad_flagship3_job_details%3BxAuxwc4kTAeCDz8eo%2FDGQw%3D%3D
https://www.linkedin.com/company/iterative-/life/?lipi=urn%3Ali%3Apage%3Ad_flagship3_job_details%3BP6koq6NkRMmuxPMyXQW%2Blw%3D%3D
https://www.linkedin.com/company/eleflow/life/?lipi=urn%3Ali%3Apage%3Ad_flagship3_job_details%3BOtWfHMwnQ96DeW9n63r0Rw%3D%3D
https://www.linkedin.com/company/semantixai/life/?lipi=urn%3Ali%3Apage%3Ad_flagship3_job_details%3BoEFHRAN1RkqMPcAKMB00oA%3D%3D
https://www.linkedin.com/company/hvar-consulting/life/?lipi=urn%3Ali%3Apage%3Ad_flagship3_job_details%3BbQbiG1ZOT06pgaL4eW6oVA%3D%3D
https://www.linkedin.com/company/axonius/life/?lipi=urn%3Ali%3Apage%3Ad_flagship3_job_details%3BExMwtGe7TQ6ONB9S2yFguw%3D%3D
https://www.linkedin.com/company/simple-energy-assessoria/life/?lipi=urn%3Ali%3Apage%3Ad_flagship3_job_details%3BEnaqgxxVSougi1PEPxaUag%3D%3D
https://www.linkedin.com/company/cosmobots/
https://www.linkedin.com/company/getnet-br/life/?lipi=urn%3Ali%3Apage%3Ad_flagship3_job_details%3Bgnkb4TWgSc%2BN0w%2FZjpssuQ%3D%3D
https://www.linkedin.com/company/agencia-jussi/life/?lipi=urn%3Ali%3Apage%3Ad_flagship3_job_details%3BGZkVdHoeRY6ErVAOG0GyJg%3D%3D
https://www.linkedin.com/company/engenha/jobs/

CONTAGEM
https://www.linkedin.com/company/grupo-bamaq/life/?lipi=urn%3Ali%3Apage%3Ad_flagship3_job_details%3BKSljUU91SLS3Ao4aE70wBw%3D%3D

RIO
https://www.linkedin.com/company/applaudo/life/?lipi=urn%3Ali%3Apage%3Ad_flagship3_job_details%3BzSS8D8CpTCGRrYkRjisTHg%3D%3D
https://www.linkedin.com/company/mro-logistics/life/?lipi=urn%3Ali%3Apage%3Ad_flagship3_job_details%3BQgwfBflHRdSD%2FwLqgM1DgA%3D%3D

GREAT EMPRESA
https://www.linkedin.com/company/dataside-data-ia/life/?lipi=urn%3Ali%3Apage%3Ad_flagship3_job_details%3BAg8n6WnfTDKIuJSi%2Bop1uQ%3D%3D

RECEIFE
https://www.linkedin.com/company/vidyacode/

VITORIA
https://www.linkedin.com/company/diamondbigger/
https://www.linkedin.com/company/rede-gazeta/life/?lipi=urn%3Ali%3Apage%3Ad_flagship3_job_details%3BPD6%2Fj7CjS%2FqmJ1LmswZpxQ%3D%3D
https://www.linkedin.com/company/trustly/life/?lipi=urn%3Ali%3Apage%3Ad_flagship3_job_details%3BjCHa5qbvSe6oWn6gy53zoQ%3D%3D
https://www.linkedin.com/company/nexatecnologia/life/?lipi=urn%3Ali%3Apage%3Ad_flagship3_job_details%3Bu9T%2BUGVnSy6FKM5od4Z0Xg%3D%3D

CURITIBA
https://www.linkedin.com/company/bydhr/life/?lipi=urn%3Ali%3Apage%3Ad_flagship3_job_details%3BkAKAIyPVQM%2Bu9lt9Y6TzOA%3D%3D
https://www.linkedin.com/company/madeiramadeira/life/?lipi=urn%3Ali%3Apage%3Ad_flagship3_job_details%3BT0i0nrtfRx%2Bgo%2BXnCXyOZw%3D%3D

PELOTAS
https://www.linkedin.com/company/checkplant/

LISBOA/PORTUGAL
https://www.linkedin.com/company/vilt/


==================================
[==== REQUISITOS UNCATHEGORIZE ==]
==================================




==================================
[==== GOVERNANÇA DE DADOS =======]
==================================

**Analista de Governança de Dados Sênior**

https://www.linkedin.com/jobs/view/3381913220/?refId=74922652-2042-4c36-9238-db7d89f1c17f&trackingId=aIdROidKRyaRGOwgz%2F%2FfDw%3D%3D&trk=flagship3_job_home_savedjobs


Requisitos

- Graduação em cursos da área de Tecnologia da Informação;

- Vivência em gestão de projetos: especialmente metodologia ágil;

- Glossário de Negócio, Dicionário de Dados e Linhagem de Dados;

- Coleta e organização de metadados técnicos;

- Taxonomia para mapeamento e classificação de dados;

- Catálogo de dados;

- Arquitetura e modelagem de dados;

- Documentação técnica;

- Conhecimento em estrutura de dados;

- Inglês Avançado - Conversação;

- Banco SQL;

- Excel.


Diferencial: conhecimento do setor de seguros e LGPD




**Analista de Qualidade de Dados**


https://www.linkedin.com/jobs/view/3384013880/?refId=21d1570f-ebf8-40d5-bedd-589730d70f01&trackingId=HqW5paaORPusViekA3aTbw%3D%3D&trk=flagship3_job_home_savedjobs

Qualificações Essenciais

Olhar e pensamento analítico; Facilidade de criação e interpretação de relatórios; Facilidade de comunicação, principalmente para atender áreas de negócio e comunicar impactos de problemas de dados; Capacidade de avaliação das medidas de sucesso estabelecidas para mapear e controlar a qualidade do dado; Realizar avaliação quantitativa da qualidade de dados, para criação de processos automatizados de observação de valores; Experiência para realizar avaliações qualitativa da qualidade, sendo capaz de capturar a percepção e expectativa dos usuários sobre a qualidade dos dados. Capacidade de tomar decisões quanto ao direcionamento das manutenções corretivas e evolutivas nos produtos de dados; Experiencia em estruturação de documentação de métricas e dimensões. Experiência e conhecimentos Avançados em SQL, realização de profiling de dados de grandes volumes de dados. Conhecimentos LGPD / GDPR Experiência Ferramenta Tableau

Qualificações Desejáveis

Experiência framework DAMA DMBOK - Governança de Dados Conheciemnto Arquitetura MDM - Master Data Management Conhecimentos modelagem de dados conceitual, logica e fisica Conhecimentos SAS

Nossa missão é Auxiliar as empresas a extrair todo o potencial de Dados e Digital objetivando aumentar seu desempenho, ajudando na transformação, gerando novas alavancas de crescimento e competitividade.




**VIVO - Consultor(a) de Governança de Dados**

https://www.linkedin.com/jobs/view/3348231465/?refId=85c239dc-fcc7-4448-a539-f309fed5ba58&trackingId=5uzNHDsfQDudxuXsDBqYUg%3D%3D&trk=flagship3_job_home_savedjobs

Requirements And Qualifications

Experiência em programa Federado de Governança de Dados;
Conhecimento em Linhagem e Catalogação de Dados (EDC);
Experiência com Qualidade de Dados (Quantitativo e Qualitativo);
Facilidade com a elaboração de Workshops para disseminação da governança;
Conhecimento em Master Data Management (MDM);
Noções de LGDP;
Capacidade analítica, técnica e de negócio em relação aos ativos de dados;
Habilidade em Gestão de Conflito;
Relacionamento Interpessoal;
Capacidade de Ensinar e engajar;
Superior Completo.


**Analista de Governança de Dados - Banco de Talentos**

https://www.linkedin.com/jobs/view/3343591268/?refId=60ddafae-f134-4285-8d0a-ef597db64cff&trackingId=LSPq8FsSTCa69ahUNsH%2BCQ%3D%3D&trk=flagship3_job_home_savedjobs

Sobre a vaga
Atividades a serem realizadas:

Atuar na criação e manutenção de políticas de Governança de dados;
Suporte a implementação de boas práticas e documentação em todo ciclo de vida de um projeto de dados (ingestão, tratamento, processamento, higienização, carregamento, expurgo etc);
Apoio aos times de dados da empresa em definição de regras, segurança, métricas e qualidade dos dados.
Definir e apoiar padrões de catalogação e classificação de metadados;
Identificar melhorias continuas nos processos e modelos em relação ao uso de dados;

Skills:
Experiência com governança de dados;
Conhecimento em ferramentas como Purview, collibra etc
Conhecimento no framework DAMA.

**Analista de Governança de Dados Pl.**

https://www.linkedin.com/jobs/view/3382118703/?refId=21d1570f-ebf8-40d5-bedd-589730d70f01&trackingId=mDpaG%2F6SR%2BWax4%2BeljVTAQ%3D%3D&trk=flagship3_job_home_savedjobs

Responsabilities and assingments

Analisar, sustentar e evoluir a camada de processos de gestão de metadados e disseminar seu uso na Cia.
Apoiar as áreas de dados e negócios no mapeamento e execução de planos de ações referentes aos processos de selos de qualidade de dados visando o aumento contínuo quanto à confiabilidade dos dados.
Apoiar a organização quanto à implementação de políticas e processos de governança de dados, com foco em proteção dos dados.
Promover a conscientização junto às áreas de negócio quanto aos temas de governança de dados, por meio de workshops.

Requirements And Qualifications

Superior em Ciências da Computação, Engenharia da Computação, Sistemas da Informação ou áreas correlatas.
Conhecimento em conceitos e boas práticas de governança de dados, com foco em gestão de metadados, qualidade de dados e segurança.
Conhecimento em banco de dados relacionais (Oracle, SQL Server, MySQL e/ou PostgreSQL).
Conhecimento em Lei Geral de Proteção de Dados (LGPD).
Experiência com modelagem de dados.
Experiência com metodologias ágeis.
Experiência com linguagem SQL.
Experiência com implementação de framework de governança de dados, preferencialmente, DAMA.
Experiência com criação de políticas e processos de governança de dados.


Informações Adicionais

Experiência com ferramentas de catálogo de dados.
Conhecimento em conceitos de dimensões de qualidade de dados.
Experiência com implementação de processos de qualidade de dados

**Analista de Governança de Dados**

https://www.linkedin.com/jobs/view/3305588151/?refId=94ae3e46-de0d-4938-9709-f74ab4d5a521&trackingId=wNO3OmrMQFWo7EMNqYnFrg%3D%3D&trk=flagship3_job_home_savedjobs

O que esperamos de você?

Estamos buscando pessoas que queiram se desenvolver e aprender constantemente, compartilhando, colaborando, inovando e entregando valor para todos os nossos clientes.

Você irá contribuir para desenvolver na nossa organização uma cultura direcionada à dados e conforme a visão dos clientes, atuando na criação, monitoramento, avaliação e evolução dos processos da governança de dados: qualidade, metadados e riscos! Buscamos pessoas que tenham paixão por analisar dados, que encaram desafios com simplicidade e saibam colaborar para evoluir o uso e a confiança dos nossos ativos de dados!



Como será o seu dia a dia?

Usar muitos dados sobre os dados
Apoiar as áreas de negócio na gestão do risco de dados
Aumentar o uso e confiança dos dados
Evoluir a qualidade dos metadados


OUTROS CASOS
=========
==== 

ENGHEIRO DE DADOS

https://www.linkedin.com/jobs/view/3367442400/?refId=85c239dc-fcc7-4448-a539-f309fed5ba58&trackingId=4%2FTqCvvAQ3eUPmnJzmf%2FUQ%3D%3D&trk=flagship3_job_home_savedjobs

 Para concorrer a essa vaga, você deve:
Python Avançado;
Experiência com Spark, Kafka, Airflow, Docker e Kubernetes;
SQL e NoSQL;
Conhecimento em ShellScript/bash;
Experiência em ETL/ELT de pipelines com Cloud (AWS);
Experiência com ambiente AWS (S3, EMR, Athena, Lambda, SQS, AWS Glue, RDS, Redshift, DynamoDB, etc);

=======

VAGA DE ENGENHEIRO DE DADOS

https://www.linkedin.com/jobs/view/3367565597/?refId=85c239dc-fcc7-4448-a539-f309fed5ba58&trackingId=%2Fd8KZ3zgQteCudDxdcivQw%3D%3D&trk=flagship3_job_home_savedjobs

O que esperamos de você?
Domínio Avançado em Python e SQL;
Domínio em Github, PostgreSQL, Redshift e Webservices REST;
Domínio dos conceitos de Data Lake, Data Warehouse, ETLs, Arquitetura e Governança dos Dados;
Experiência em serviços AWS voltados à tratamento de dados;
Conhecimentos aprofundados em gestão de entregas aplicando metodologias ágeis, como o Kanban e Scrum;
Conhecimento e experiência em Plataformas de Visualização de Dados (ou BI) (ex: Tableau, Kibana, Grafana, Metabase, PowerBI, Google DataStudio ou similares);
Paixão por aprender sempre;
Ser ágil para resolução de problemas;
Domínio em Apache Airflow (ou outro orquestrador de pipelines);
Ser bastante organizado;
Vibrar com desafios;
Boa atuação em situações com nível médio de pressão;
Expressar suas opiniões de forma coerente.
Espírito de liderança e condições para liderar squads e/ou projetos.



vaga da refera, completar cadastro




https://www.linkedin.com/jobs/view/3372372607/?refId=70f3946d-7cf1-456f-b030-3778b6b55f26&trackingId=5lNbogIYQ3et%2BBdtUH4nkg%3D%3D&trk=flagship3_job_home_savedjobs








====== STACK MUITÍSSIMA USAZADA dot net ======

- Linguagem de programação: .Net | C# | WebAPI

- Front end: Angular | TypeScript | HTML | CSS | BootStrap

- Nuvem: Azure

- Banco de dados: SQL Server

- Noções em orientações a objeto e clean code.











==================================
[==== ANALISTA DADOS - TECNOLOGIAS ESTRNHAS =======]
==================================

https://www.linkedin.com/jobs/view/3387116240/

Sobre a vaga
Missão do Cargo

Criar e manter pipelines de dados que irão ser utilizados para responder perguntas de negócio, servir como origem de Dashboard Power BI e modelos de Machine Learning.

Sugerir soluções baseadas em dados completos e eficientes.

Auxiliar na definição de boas práticas de código, governança e gestão de dados.

Auxiliar na definição de arquiteturas de dados.

Somos inquietos, somos desbravadores e estamos em constante transformação.

Por isso, estamos na busca constante de crescimentos do nosso time com profissionais inovadores, que desafiam os limites e estejam preparados para embarcar em uma cultura totalmente nômade.

SOMOS NÔMADES, NOSSAS VAGAS SÃO PARA QUALQUER LUGAR!

Seja qual for o seu gênero, orientação sexual, idade, raça, etnia, crença ou deficiência, todos são bem-vindos no nosso time.

Responsabilidades e atribuições

==> Principais Responsabilidades
Responsável por realizar a verificação de cenários e o diagnósticos de marcas nos canais digitais a partir de dados e do monitoramento.
Responsável por traduzir os dados em análises, fatos e insights que servem de insumos e orientação para os demais times envolvidos.
Responsável por identificar padrões de comportamento, necessidades e expectativas, percepções de públicos, identificação de oportunidades de comunicação e de negócio.

==> Requisitos e qualificações
Graduação em comunicação social, ciências sociais, administração ou áreas correlatas.
Excel avançado
Conhecimento de ferramentas de monitoramento (V-Tracker, Stilingue)
Conhecimento de Google Analytics
Conhecimento de ferramentas de visualização de dados (Iramuteq, Gephi)
Conhecimento de ferramentas de visualização de dados
Conhecimento de analytics de redes sociais
Queries de pesquisa
Experiência prévia em equipes de BI
Experiência em comunicação digital
Experiência em trabalhar com grande volume de dados
Conhecimento básico de mídia online


==================
DATA SEANLSYT SENIOR 

Experience with dashboard development (Tableau preferred)
Python - highly desired but not mandatory
Experience in building big data pipelines and datasets in the AWS environment;
Experience across the entire analytics flow: from understanding business requirements to data mining, data transformation, QA checks, pipeline building, reporting, and dashboards;
Strong knowledge of SQL, data modeling, and data warehouses;
Good practices for developing dashboards;
Advanced English.


=============


ENGENHIERO DE DADOS

Responsabilidades:

- Construir soluções técnicas para obter, processar e armazenar dados de várias fontes;

- Desenvolver novas soluções para a área de Engenharia de Dados, provendo dados aos times de Business Intelligence e Cientista de Dados;

- Automatizar os processos de ingestão de dados no Data Lake;

- Propor estratégias e ferramentas de monitoramento contínuo das ingestões, performance e qualidade dos dados;


Requisitos:

- Tenha disponibilidade para trabalho híbrido em Belo Horizonte;

- Familiaridade com ambiente baseado em nuvem AWS, GCP ou AZURE;

- Domine programação com Python ou Java;

- Saiba desenvolver com Apache Spark (Python ou Scala);

- Experiência com Docker/Kubernetes;

- Tenha domínio em SQL.



=======
