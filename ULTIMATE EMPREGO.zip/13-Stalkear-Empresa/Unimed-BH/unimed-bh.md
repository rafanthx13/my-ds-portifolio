# UNIMED - BH

## Descrição linkedin

**Visão geral**
Há mais de 51 anos nos dedicamos ao cuidado pela vida. Hoje, mais de 1,4 milhão de clientes em Belo Horizonte e na região metropolitana contam com assistência médica de qualidade.

Nossa equipe é formada por quase 10 mil profissionais de diversas áreas administrativas, da saúde e médicos cooperados.

Quer fazer parte desse time? Acesse vagas.unimedbh.com.br, escolha a oportunidade com a qual você mais se identifica, candidate-se e boa sorte. 

Respeitamos a diversidade e inclusão em todas as nossas vagas. Sem distinção de gênero, orientação sexual, raça, religião ou deficiência.

**Site**
vagas.unimedbh.com.br

**Número de telefone**
4020-4020O telefone é 4020-4020

**Setor**
Serviços de bem-estar e condicionamento físico

**Tamanho da empresa**
+ de 10.001 funcionários
+ 3.674 no LinkedIn 
  - Inclui usuários com a empresa atual listada como Unimed-BH, incluindo funções em meio período.

**Sede**
Belo Horizonte, Minas Gerais Fundada em 1971
=> OBS: Tem 9 locais em BH

**Especializações**
Atendimento médico, Urgência, Emergência, Pronto-socorro, Planos de saúde, Saúde Suplementar, Trabalho médico, Hospitais, Promoção da Saúde, Médicos Cooperados e Cooperativa de trabalho médico
