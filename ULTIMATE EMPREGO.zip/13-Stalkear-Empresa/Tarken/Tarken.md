# Tarken

## links

+ https://blog.tarken.ag/
+ https://www.linkedin.com/company/tarken-ag/about/

## Sobre a Empresa

A Tarken é uma empresa de tecnologia no agro que tem como missão conectar digitalmente produtores e distribuidores de insumos para um processo mais rápido e de confiança no acesso ao crédito rural e transações de grãos. 
