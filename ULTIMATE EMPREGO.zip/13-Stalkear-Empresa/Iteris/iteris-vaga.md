Requisitos e qualificações

O que você precisa conhecer?
Java 8/11
Maven e/ou Gradle
Spring Framework (Boot, Data e Web)
JPA / JTA
Testes unitários (JUnit, Mockito)
Git, GitFlow
Desenvolvimento de APIs RESTful
Banco de dados relacionais (SQL Server, Oracle, MySQL) e não relacionais (Redis, MongoDB, DynamoDB)

Conhecimentos extras que podem ajudar ainda mais na sua contratação?
Spring Framework (Batch, Integration, Cloud, Webflux, e Web Flow)
Kafka
Arquitetura (design patterns, CQRS, SOLID, injeção de dependência, DDD e microsserviços)
Monitoring/logs(AppDynamics, Splunk)
Cloud (AWS, Azure ou GPC)



Código da transaçâo VIking:
HP150416705021035
