# Explor

## Descrição da vaga

[link](https://www.linkedin.com/jobs/view/3276601044/)

Position: Backend Engineer Internship
Company: Explor
Local: Portugal
Modality: Estágio Remoto



## Sobre a vaga

👉 Who we are

Explor is a Lisbon based startup on a mission to provide users with relevant, locally curated, recommendations in real-time. Our product combines contextual data with personalization to give better recommendations to travelers, removing all visual trash in the process!Our reality and vision empower our engineers to use artificial intelligence and machine learning to transform real-time data, software, and algorithms into tourism recommendations.We are:

+ Backed by some of the best European VCs and angels
+ Growing fast
+ Looking for people who can help us build the future of tourism recommendations

*Currently we are all working remotely but plan to open offices in Lisbon to move back to flexible working.*

💡What we're looking for

We are looking for a talented **Backend Engineer Intern** to join the founding team of Explor.We're a tight-knit, dynamic, hands-on team that takes pride in high standards and modern development practices. You'll be working alongside our founding team in order to develop and improve our backend system, using the highest standards to guarantee privacy, speed and quality content. Our team of creatives, technologists, and academics looks beyond the traditional to develop creative solutions.

As a **Backend Engineer Intern**, you’ll have an opportunity to grow more quickly than you ever envisioned, as you contribute with high-quality code directly to Explor main product that is deployed frequently, directly affecting users.You should be passionate about software engineering and building a product end-to-end through the technical design, coding, testing, and deployment phases.

✅ **You will be a great fit if you**

+ Have a Computer Science or similar discipline competences
+ Have coding skills (such as Python, R, Java, or Scala). Regardless of which frameworks you use or how you learned them, we’re looking for people who can write clean, effective code.
+ Have Git experience
+ Are open-minded and motivated to work in a multicultural team
+ Have a strong analytical and organizational skills
+ Are excellent at communication, collaboration, and interpersonal skills: empathy, listening, teamwork, and responsibility
+ Understand how technical decisions impact the people who will use what you’re building.
+ Are enthusiastic and creative
+ Pay attention to detail
+ **Have english proficiency**

💭 Some activities you would do on a typical day at Explor

+ Develop and maintain solutions using FastAPI, SQLAlchemy and other technologies
+ Interact with other developers and stakeholders
+ Participate in the creation and implementation of new features
+ Write beautiful, readable, and scalable code
+ Code review and grooming
+ Participate and run task plannings and daily stand-up meetings

❓ Reasons to join us

This is a place where you're welcomed as your own perfectly unique self, and celebrated for the skills, talent, and perspective you bring to the team. Come, and be where it begins.

+ You will be solving a real problem that people around the world struggle with, and being successful will mean your work has an impact on a global scale
+ As an internship member at this early stage, you will help shape the entire business, and we will invest in you to help you achieve your career goals
+ 1:1 Mentorship
+ Intern Specific Events & Projects
+ Peer & Senior Level Networking
+ Explor proudly celebrates diversity. We are an equal opportunity employer committed to promoting inclusion in our workplace. We consider all qualified applicants for internship without regard to race, ethnic origin, religion or belief, gender, gender identity or expression, sexual orientation, national origin, disability or age





## Email que enviaram

Thank you for applying to the Backend Engineering Internship position at Explor. We’ve reviewed your application materials carefully, and we’re excited to invite you to interview for the role!

Your interview will be conducted as a conversation between us and last roughly 45 minutes. You’ll be speaking with myself, as I’m the CTO here at Explor.

Please let us know when you are available during the following times:
+ **Friday, 18/11 – 5:15PM, UTC**
+ Monday, 21/11 – 3PM, UTC
+ Tuesday, 22/11 – 2PM, UTC

## Pessoas da Empresa - Linkedin

+ [Ricardo ´orfão](https://www.linkedin.com/in/ricardo-%C3%B3rf%C3%A3o?miniProfileUrn=urn%3Ali%3Afs_miniProfile%3AACoAADCmgvcByWCu79F3DYgIvGttmJAyVEuykhE&lipi=urn%3Ali%3Apage%3Ad_flagship3_search_srp_people%3BtCW2SIfjQQ%2BA4gCFOfL3Tg%3D%3D)
  + Lisboa
+ [Dan Jones](https://www.linkedin.com/in/electronicdog?miniProfileUrn=urn%3Ali%3Afs_miniProfile%3AACoAAAO-P1sBpR8HWK7oGoPWNRe29mRIDiT8vug&lipi=urn%3Ali%3Apage%3Ad_flagship3_search_srp_people%3BtCW2SIfjQQ%2BA4gCFOfL3Tg%3D%3D)
  + Lisboa
+ [Patícia Machado](https://www.linkedin.com/in/patricia-machado-040301a1?miniProfileUrn=urn%3Ali%3Afs_miniProfile%3AACoAABWUevABQ9K_fqeV3WyDs3wZzyde-UQVVYI&lipi=urn%3Ali%3Apage%3Ad_flagship3_search_srp_people%3BtCW2SIfjQQ%2BA4gCFOfL3Tg%3D%3D)
  + Porto e Região



## Ricardo Órfão - CTO

+ [Linkedin](https://www.linkedin.com/in/ricardo-%C3%B3rf%C3%A3o/)
+ [Github](https://github.com/ricardoorfao)
+ [Explor - Site da Empresa](https://getexplor.com/)

Chief Technology Officer
