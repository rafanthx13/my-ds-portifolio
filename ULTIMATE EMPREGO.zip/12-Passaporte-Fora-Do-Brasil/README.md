## Como irara passaporte para viajar para fora do Brasil

## Links

https://www.s2vistos.com.br/noticias/postos-da-policia-federal-para-tirar-passaporte/

http://cglondres.itamaraty.gov.br/pt-br/passaporte.xml#Validade_do_passaporte

https://www.ie.com.br/intercambio/quanto-custa-passaporte/

## OBSERVAÇÃO

Além de providenciar a documentaçâo, você terá que agendar uma consulta à PF para passar os documentos, isso pode demorar muito mais do que você pensa, tipo, 2 messe apartir da data em que você pensa em fazer o agendamento

## Quanto custa o passaporte 2022?

Atualmente (2022), **tirar o passaporte** custa R$ 257,25 em caso de primeira via, ou para quem apresentar seu antigo passaporte.

E a diferença entre emitir pela primeira vez e **renovar o passaporte**, [é que quando renovar](https://www.ie.com.br/intercambio/como-renovar-passaporte/), será necessário apresentar o passaporte antigo, ou o BO em caso de perda ou roubo. 

Sendo assim, se o requerente não possuir tal passaporte na hora da renovação, ou um Boletim de Ocorrência (BO), a taxa para emitir o passaporte passa a ser de R$ 514,50.

Além disso, em caso de pressa para emissão do documento, restrito para questões profissionais e da saúde, o valor para **tirar o passaporte** emergencial é de R$334,42.

## Validade

Passaporte com validade máxima: de 10 anos. Aplicável apenas para para maiores de 18 anos.

## Onde não precisa de Passaporte

Argentina, Uruguai e Paraguai

## Documentos

**O que precisa SER** para conseguir tirar o passaporte
+ Ser brasileiro,
+ Estar quite com o serviço eleitoral (isto é, ter título de eleitor caso tenha mais de 18 anos e menos de 65, e ter votado na última eleição ou pago a multa correspondente),
+ Estar quite com o serviço militar obrigatório (no caso de homens),
+ Não estar impedido de sair do país pela justiça.

**Documentos que talvez possam ser necessários**
+ Além disso, você vai precisar de seu CPF, 
+ documento de identidade, certidão de casamento (caso tenha mudado de nome), 
+ certificado de naturalização (caso tenha se naturalizado brasileiro) e 
+ passaporte anterior (se esse não for seu primeiro).

Não é obrigatório levar título de eleitor ou certificado de reservista do serviço militar. Isso porque a consulta à sua situação junto à Justiça Eleitoral e ao serviço militar serão conferidas na hora. Mas se você tiver esses documentos, pode ser uma boa ideia levá-los para possíveis imprevistos. Assim, caso haja qualquer problema, você consegue comprovar que votou e que está quite com o serviço militar.

!!!!!!!!!!!
**No meu caso, acredito que a documentaçâo que já tenho em casa já serve, e tem que ir lá com ela original**
!!!!!!!!!!!

## Postos da Polícia Federal para tirar Passaporte 

**Lembre-se,você vai lá uma vez e depois vai voltar lá para retirar o passaporte**

#### Como tirar passaporte em MG?

Todo o processo de emissão de Passaporte em um primeiro momento deve ser realizado diretamente no site da PF, para todas as localidades o processo será o mesmo. Sendo assim, para a emissão desse documento o solicitante deve comparecer presencialmente em um posto escolhido para atendimento presencial da PF. Veja quais são os postos da PF para Passaporte em Minas Gerais.

**LOCAIS DA PF EM BH**
=> Resumindo: Gutierrez, Centro e Anchieta (10h as 17h)
==> Resumindo os locais: 4 pontos
  - Um perto da Rodoviario
  - Um perto do SHoping BH
  - Um perto do SHoping Anchieta
  - Um no bairro Gutierrez

- **Superintendência Regional** – Endereço: Rua Nascimento Gurgel, n° 30 – Bairro Gutierrez / CEP 30430-340;
- **Delegacia de Imigração** – DELEMIG (atendimento a passaportes e estrangeiros) – Av. Francisco Deslandes, 900, Bairro Anchieta / CEP 30310-530;
- **Delegacia Regional Executiva** – DREX – Rua Nascimento Gurgel, 30, Bairro Gutierrez / CEP 30430-340;
- **PEP – UAI Praça Sete – Centro;**
- **Delegacia Regional de Combate ao Crime Organizado** – DRCOR – Rua Nascimento Gurgel, 30, Bairro Gutierrez / CEP 30430-340;
- **PEP – Shopping Anchieta – Anchieta**
- **PEP – Aeroporto Internacional Tancredo Neves** – Confins/MG 

O horário de atendimento dos postos para emissão do Passaporte em Minas Gerais é das 10h às 17h. 

#### Onde tirar Passaporte na Bahia?

Conheça todos os postos para atendimento de Passaporte na Bahia. O Horário de atendimento é de segunda a sexta, das 9h às 17h.

- **SAC Salvador Shopping** *–* Endereço: Av. Tancredo Neves, nº 3133, Caminho das Árvores, Salvador/BA, CEP 41820-021;
- **SAC Feira de Santana** – Endereço: Rua Vasco Filho, n° 23, Centro, Centro, Feira de Santana/BA, CEP: 44001-400;
- **Posto SAC Conquista II** – Vitória da Conquista (Serviços: Passaporte, Estrangeiros, Armas e Antecedentes Criminais) Endereço: SAC II, Boulevard Shopping – Av. Olívia Flores, nº 2500, Candeias, Vitória da Conquista/BA, CEP 45.028-610;
-  **SAC Shopping Barra** – Endereço: Av. Centenário, nº 2992, Chame-Chame, Salvador/BA, CEP 40155-151;
- **PEP- SAC Ilhéus -BA** – Endereço: Rua Eustáquio Bastos n 308- Centro, CEP- 41745-000 – Ilhéus/BA;
- **PEP- Aeroporto Internacional de Porto Seguro** – Endereço: Estrada do Aeroporto, S/N, Cidade Alta, CEP: 45.810-000, Porto Seguro/BA; 
- **DELESP – Delegacia de Controle de Segurança Privada** – Endereço: Av. Sete de Setembro, nº 2365, Vitória, Salvador/BA, CEP 40080-002; 
- **DELEMIG – Delegacia de Polícia de Imigração** – Endereço: Aeroporto Internacional Luís Eduardo Magalhães – Praça Gago Coutinho, nº 282, São Cristóvão, Salvador/BA, CEP 41520-970;
- **Delegacia em Barreiras** – Endereço: Rua Gilberto Bezerra, n° 281, Quadra 11, Lote 456, Morada Nobre, Barreiras/BA, CEP 47810-056;
- **Delegacia em Ilhéus** – Endereço: Av. Governador Roberto Santos, nº 11, Fundão, Ilhéus/BA, CEP 45658-635;
- **Posto SAC Barreiras** (Serviços: Passaporte e Informações) – Endereço: Av. Barão do Rio Branco, 149 – Vila Rica, Barreiras – BA, CEP 47813-010; 
- **Delegacia em Juazeiro** – Endereço: Rua Amazonas, nº 99, Bairro Santo Antônio, Juazeiro/BA, CEP 48903-240;
- **Porto Seguro** – Endereço: Estrada do Aeroporto, nº 917, Cidade Alta, Porto Seguro/BA, CEP 45810-000;
- **Delegacia em Vitória da Conquista** – Endereço: Av. Juracy Magalhães, nº 3956, Felícia, Vitória da Conquista/BA, CEP 45055-901; 
- **Posto Avançado em Feira de Santana** – Endereço: Rua Leolinda Barcelar, 887, Ponto Central, Feira de Santana/BA, CEP 440750-75;

=== FIZ EM 16/05/2023 ===

Protocolo: 1.2023.0001633534

Número da GRU: 00190000090294129800884107594172893720000025725
Vencimento da GRU: 05/06/2023
Valor da GRU: R$ 257.25

At o dia do seu atendimento presencial, certifique-se de que sua situao eleitoral (Artigo 7 da Lei 4.737 de 1965) e militar (Artigo 210 do Decreto 57.654 de 1966) se encontram regulares, sob pena de no ser possvel a emisso do seu passaporte.
1. A taxa para emissão de passaporte, depois de paga, pode ser utilizada por até 5 anos, desde que seja pelo mesmo titular.

2. O agendamento do pagamento, ou seja, a programação para data futura, não é suficiente para emitir o passaporte, nem para agendar o atendimento presencial.

3. Após a compensação do pagamento, é necessário agendar o atendimento presencial. Casos de urgência ou emergência, devem seguir as instruções disponíveis no portal do serviço Obter Passaporte.

4. No dia do atendimento presencial, será tirada uma fotografia facial, serão coletadas as impressões digitais do solicitante e deverão ser apresentados todos os documentos necessários, em via original, que serão devolvidos ao solicitante ao final do atendimento.

5. Os documentos poderão ser recusados se o tempo de expedição ou mau estado de conservação impossibilitarem a identificação do solicitante ou de alguma informação imprescindível ao atendimento.

6. No caso do menor de 18 anos, juntamente com o boleto é gerada uma autorização para emissão de passaporte já parcialmente preenchida. Mesmo que a forma escolhida seja PagTesouro, o arquivo contendo o boleto e autorização pode ser salvo.

7. O menor de 5 (cinco) anos deve apresentar, além dos demais documentos, 1 (uma) fotografia facial colorida recente, tamanho 5x7, sem data, com fundo branco e que identifique plenamente o menor.

8. Após o atendimento presencial, alcançado o prazo de entrega, não esqueça de retornar ao posto para buscar seu passaporte pronto: após 90 (noventa) dias, o passaporte não retirado é cancelado, com total prejuízo da taxa paga.

Opções de Pagamento

Boleto GRU: Pode ser pago na rede bancária e internet banking e a identificação do pagamento ocorre entre 24 e 72 horas.

PagTesouro: Permite opções adicionais de pagamento, como PIX e cartão de crédito. A identificação do pagamento ocorre em poucos minutos.

CÓDIGO
==> 00020101021226980014br.gov.bcb.pix2576apipixstn.tesouro.gov.br/v2/cobv/nqlHPRBZePuaSJdoGUtkLzCZwWMPufi6gaIL1PaOQRJ5204000053039865802BR5916TESOURO NACIONAL6008BRASILIA62070503***630409F1
