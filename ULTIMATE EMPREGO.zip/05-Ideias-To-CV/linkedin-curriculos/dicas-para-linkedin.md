
##

Um perfil completo do LinkedIn (com 100% de pontuação) tem mais chances de receber oportunidades de emprego. Isso ocorre porque um perfil concluído recebe mais pontos no algoritmo interno, o que significa que é mais provável que você apareça. 

– Foto do perfil

– Localização

– Experiência (ocupações anteriores)

– Habilidades (pelo menos três)

– Formação (faculdade ou cursos)

– Pelo menos 50 conexões

O LinkedIn facilita o alcance de um perfil 100% completo, dando dicas e recomendações ao longo do caminho.

**Seçâo de resumos**

A seção de resumo é sua única chance de escrever livremente no LinkedIn. Nessa área você pode contar sua história, descrever habilidades e tudo o que o motiva. Por exemplo: “Criei sites para amigos e familiares, estagiei em uma empresa local e já fiz trabalhos freelancer. Estou ansioso para trabalhar em tempo integral.”

Além disso, inclua tecnologias e linguagens com os quais você deseja trabalhar. Escreva na primeira pessoa , como se estivesse conversando com o contratante, explicando o que você faz. Embora seja importante usar palavras-chave, não exagere. 

O algoritmo do LinkedIn pode entender que você está se aproveitando do sistema.
Por fim, verifique se o resumo tem mais de 40 palavras. Assim, será melhor indexado nos resultados de pesquisa interna no LinkedIn.

## Chamar para conhecer melhor

Sempre inclua uma frase de chamariz. Isso vai chamar a atenção para o seu perfil. A ideia é fazer com que os contratantes queiram descobrir mais sobre você. O melhor lugar para fazer isso é na seção de resumo. Aqui estão alguns exemplos que você pode usar:

– Sinta-se à vontade para entrar em contato diretamente em: nome@gmail.com.

– Veja amostras do meu trabalho em: portfolionome.com.

– Conheça meus projetos do Github em: meugithub.com.

**Evite concorrencia**

 evite a concorrência. Retire a caixa da sua página acessando “Privacidade e configurações”.

## https://becode.com.br/linkedin-para-profissionais-de-ti/

Defina sua profissão com clareza
Quando os recrutadores vão realizar a busca por profissionais eles sabem daquilo que suas empresas necessitam, por isso nada de inventar na hora de definir sua profissão no LinkedIn.

Prefira expressões mais conhecidas como: Analista de Sistemas, Desenvolvedor Front-end/Back-end, Full-Stack, Mobile Developer, Administrador de Sistemas, Administrador de Banco de Dados e por aí vai.

Dessa forma suas chances de ser encontrado e selecionado aumentam significativamente.

Otimize sua URL
url

A rede social permite que você personalize a URL de seu perfil, tornando-a mais amigável e consequentemente melhorando o seu desempenho nos motores de busca, desta forma, alcançando melhores posições.

Para realizar essa ação, basta selecionar o ícone de ajuste ao lado da URL que o LinkedIn oferece (abaixo de sua foto).

Em casos de nomes com muitos homônimos, prefira o seu sobrenome mais exótico para assim ser encontrado com maior facilidade.

Feito isso, insira a URL do Linkedin em seu CV. Desta forma, você mostra confiança ao facilitar o acesso para o recrutador, provando também que você confia em suas habilidades e não tem algo a esconder.

Construa um bom resumo
É fundamental que preenchas o campo “resumo”. Este serve como uma breve apresentação sobre você, sua carreira, objetivos, formação e habilidades.

Lembre-se que esse campo irá fornecer a primeira impressão a quem acessa seu perfil. Uma dica é aproveitar todos os caracteres disponíveis, utilizando palavras chaves relacionadas a sua área de atuação. Também é essencial criar uma versão do em inglês, idioma fundamental para se destacar no mercado hoje em dia. Principalmente se você sonha em trabalhar fora do país, o que é uma realidade muito próxima para quem é bom no que faz e trabalha com TI.

Uma dica é escrever o resumo e passar para um amigo ler. De preferência, aquele amigo chato que sabe todas as regras de gramática, concordância, crase e tudo mais! O mesmo vale para a versão em inglês.

Adicione Projetos
foguete

Sabemos que para o profissional de TI, especialmente os ligados ao desenvolvimento de sites e plataformas, é importante oferecer referências de trabalhos já desenvolvidos, comprovando assim suas habilidades e capacidades.

Por isso aproveite os recursos que a rede oferece e produza um portfólio atraente, divulgue os seus projetos!

Campo “outros”
Nem só de experiências profissionais se faz um currículo, aproveite o campo outros para mostrar um pouco de sua personalidade e valores, sem deixar de fora atuação em ONGs e trabalhos voluntários.

Embora muitos atribuam importância menor a esse campo, a realidade é que as informações apresentadas aqui podem ser um diferencial no momento da recrutamente. Ainda mais se os trabalhos realizados possuem relação com a área de atuação.

Certificados
Se você possui certificados de cursos, publique-os! Ainda mais se eles forem em PDF. Assim, o seu recrutador poderá ver que por trás do seu conhecimento, também há uma grande instituição de ensino.

###Erros que voce pode estar cometenedo

https://www.brasilcode.com.br/7-erros-mais-cometidos-por-profissionais-de-ti-no-linkedin/

### 

https://startecjobs.com/artigos/guia/como-melhorar-o-seu-perfil-do-linkedin-para-atrair-recrutadores-de-ti/

O poder das palavras-chave
Algumas técnicas de SEO (Searching Engine Optimization) podem melhorar o seu LinkedIn. Essas técnicas são muito utilizadas no marketing digital principalmente para colocar um site no topo dos resultados de buscas feitas no Google.

O principal recurso do SEO que pode ser aproveitado no seu LinkedIn é o uso estratégico das palavras-chave. Quando você busca por uma vaga na sua empresa dos sonhos o que aparece como requisitos? Qual o nome da vaga que mais te interessa? Quais são as habilidades que mais se repetem nos perfis de LikedIn dos devs que você mais admira?

Essa são perguntas interessantes de responder para chegar nas suas palavras-chave. A ideia aqui não é copiar, mas entender quais os termos mais utilizados e quais você pode utilizar de acordo com as suas experiências, habilidades e objetivos.

Palavras-chave possíveis são linguagens que você domina, o nome da vaga que você ocupa ou deseja ocupar e tecnologias com as quais você sabe trabalhar. Alguns exemplos são: desenvolvedor, full stack, back-end, front-end, quality assurance, ruby on rails, AWS, etc.

Elenque as principais palavras-chave que estão de acordo com os seus conhecimentos, habilidades e experiências. São essas palavras que vão estar no seu título, resumo, experiências e se possível em todo o seu perfil.

Entretanto, tenha cuidado para encaixar essas palavras de uma maneira orgânica no seu texto. O que você escrever precisa fazer sentido. Outras pessoas precisam conseguir entender e não ficar parecendo que um robô escreveu aquilo, sabe?

Faça uma lista das palavras-chave secundárias, aquelas que não vão estar no seu título, mas podem aparecer no resumo e na descrição das suas experiências. Elas também são importantes e merecem atenção especial.

O conjunto das palavras-chave principais e secundárias utilizadas da maneira correta já vai te ajudar a melhorar o seu perfil no LinkedIn. Atraindo recrutadores e conexões qualificadas.

Capriche nas experiências
Esse é o momento de mostrar o que você já fez, então preencha com atenção e capricho. Elenque as suas principais experiências até hoje, não se esqueça de descrever sua atuação e principais conquistas em cada uma delas.

Vale incluir como experiência não só trabalhos formais, mas também estágios, freelancers, hackathons e até projetos pessoais. Uma dica boa para qualquer dev é mostrar que você sempre está se atualizando, faça com que as suas experiências mostrem isso por você.

As experiências também são uma ótima maneira de conseguir conexões mais qualificadas e condizentes com o seu objetivo profissional.

Não se esqueça dos projetos!
Profissionais de TI geralmente possuem  vários projetos pessoais e ainda se envolvem nos dos amigos. Essa bagagem também conta e é deve estar presente no seu perfil do LinkedIn. 

Assim, mesmo com poucas experiências formais em determinada linguagem, por exemplo, você consegue comprovar suas habilidades e capacidades.

Se você tiver links, prints e fotos da equipe é melhor ainda. Coloque todos os links, anexos e documentos possíveis em cada projeto e experiência profissional, assim você constrói um portfólio atraente dentro do seu LinkedIn.

 

Educação e certificados
Para devs é muito importante estar sempre atualizado em novas linguagens e tecnologias e o LinkedIn permite que você mostre isso de diferentes formas. Tanto na categoria educação que é para cursos mais formais e robustos como universidade, pós-graduação ou MBA, quanto com cursos de curta duração.

Sempre coloque seus certificados em PDF ou links para quem acessar o seu perfil ter a comprovação de que você realmente concluiu aquele curso. E a instituição de ensino que oferece a capacitação também pode agregar a credibilidade aos olhos dos visitantes.

3 – RESUMO VENDEDOR

Um dos principais erros que profissionais comentem no perfil LinkedIn é “copiar e colar” o resumo das qualificações do CV para o LinkedIn. E a sugestão aqui é que o faça como se fosse o seu site pessoal. Voce.com, com toda a sua bagagem e potencial que oferece ao mercado.

Um espaço que, além de descrever suas habilidades, “conquiste e venda” os seus diferenciais como profissional e pessoa. Assim como tudo no mundo digital, seu perfil é dinâmico, atraente e provoca na pessoa que o lê uma vontade enorme de conhecê-lo, seja para uma entrevista de emprego, contratar sua consultoria, conhecer seu negócio ou ampliar sua rede de relacionamento.  Assista ao vídeo Como escrever um resumo de destaque no perfil LinkedIn. 

