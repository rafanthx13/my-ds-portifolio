# Currículo Matador



## 01. Apresentação Currículo Matador


## 02. Como fazer o curso, dúvidas e bônus

## 03. Objetivo do Currículo

1. Mostrar que você cumpre os pre-requisitos de uma vaga
2. Despertar curiosidade na pessoa que vai lê-lo

## 04. Como pensar na hora de fazer o seu currículo

**Não escreva coisa que só você possa entender**

Tem que colocar as coisa no currículo de acordo com os olhos de um leigo, de um recrutador.

Pense: 

```
O que isso dá de informação de experiência real ppara que vai ler: que tipo de experiência a pessoa deduz do que vai ler
```

Cuidado para não por coisa genéricas demais.

**Para cada informação que você colocar, deve ficar claro para um leigo**



## 05. E se eu não tiver todos os pré-requisitos

Depende.

Mas existe vagas que realmente é essencial.

**LEMBRE-SE, MUITAS VEZES VOCÊ NÃO PASSA POR NÃO TER O PRÉ-REQUISITO É O QUE FAZ SER CORTADO**. 

Exemplo: Se pede Excel, vai cobrar Excel. Agora se a vaga pede inglês, isso pode ser um filtro mais fácil para separar pelo recrutador.

**Mesmo assim há gente que passa pois você pode parecer interessante**



## 06. Tudo vai funcionar para mim

**O MERCADO DE TRABALHO É VOLTADO A RESULTADO: NÂO IMPORTA O QUE VOCÊ FEZ, MOSTRE RESULTADO**

## 07. Não existe gabarito

Aqui vai algumas dicas, maspode haver também outras

## 08. Os 8 Pontos de Atenção - Os 8 pilares do Currículo

Há 8 tópicos. 2 opcionais:

1. Informações Gerais: Idade, Endereço, email, telefone (Contato)
2. Formação Acadêmica: Curso, faculdade
3. Resumo (Opcional): Características não óbvias suas, coisas só sua
4. Experiências Profissionais: Trabalhos remunerado e não-remunerados
5. Idiomas
6. Conhecimentos: Software
7. Cursos
8. Isca de Atenção (Opcional)

## 09. Tamanho e formato

Formato: em PDF

Tamanho: Dentro de 1 página. Tem que ser conciso sempre.

# Tópico 1



## 10. Tópico 1: Informações gerais

Não precisa colocar foto

## 11. Tópico 1: Observação sobre seu endereço

Para vagas presenciais, o endereço importa, mas nao precisa colocar rua, só o bairro tá bom

# Tópico 2

## 12. Tópico 2: Formação acadêmica

Qual a faculdade, curso, previsão de formatura e Período

## 13. Tópico 2: Quantas formações colocar no Currículo

De prefeÊncia nâo precisa por o Ensino Médio, pois pode ser muito distante da vaga que você está buscado.

Lembre-, tem que colcoar informaçôes mais importantes

E nâo colocar coisa muito antigas

## 14. Tópico 2: Devo colocar o CR (Para vagas de início de carreira)

CR é a nota da faculdade.

Só coloque o seu CR se for um diferencial seu.

Pode ter Vagas que pede CR acima de algum valor, ai voce tem que colocar

## 15. Tópico 2: Tempo ideal pra formatura (Para vagas de estágio)

No meu caso não rpecisa

# Tópico 3

## 16. Tópico 3: Resumo (opcional)

,Muitos recrutadores consideram opcional

Ponha informações inusitadas. Tipo, aí você pode por 'confiável' e não por 'confiável' como diferencial. Se for para descrever com adjetivos, você coloca ai no resumo.

**Quando é interessante**: Quando você perceber que combina com o fit cultural da empresa. Se você tem características suas que podem combinar com a empresa

## 17. Resumo (o que não fazer)

**Exemplo de Resumo: que nâo fazer**

Sou uma pessoa dedicada, confiável, me relaciono bem com as pessoas, gosto de trabalhar em equipe e de aprender com os outros.

**O que coloque**: Coisa não obvias

## 18. Resumo (o que fazer)

**Resumo bom**

Gosto de conhecer culturas novas, tenho facilidade para me relacionar com pessoas e tenho paixão pelo aprendizado contínuo. Trabalhar em equipe me anima mais do que exercer funções individuais, mas entendo que essas são importante em certos momentos

# Tópico 4

## 19. Experiências profissionais

Para os recrutadores é de extrema importância, chama muito atenção

É bom explicar que:

**Você já viveu algumas coisas, tarefas que vai ter alguma coisa haver com o que você vai fazer**

Coloque

+ Período
+ Atividades que realizou
+ Resultados com a experiência

Não coloque todos: até 4 principais já é o suficiente

## 20. Principais resultados - Holofote

**OS RESULTADOS DE SUAS EXPERIENCIA FAZ A TOTAL E ABSOLUTA DIFEENÇA**

**Não omita o resultado, qualquer coisa que você fez e todo mundo curtiu**

## 21. Como ordenar as experiências

Coloque por ordem mais recentes se forem experiências parecidas;

Agora se tiver algo bem impcatntate, coloque já no topo

**O que o recrutador que ta com preça olha**

1. Curso
2. Experiência Profissional

## 22. Dicas para suas experiências

1. Nos resultados que são resultado de equipe, você deve mostrar sua participação, oq eu você fez para aquele resultado ser alcançado

2. Empresa em geral valorizam mutio empresa júnio, Enactus, Equipe de Competição

3. Cuidado na hora das experiências | **Coloque as que realmente podem ser úteis para a vaga**

4. Nunca coloque as tarefas em formato de texto

   !!!!!!!!

   **OS RECRUTADORES ODEIAM QUANDO QUANDO VOCÊ DESCREVE AS TAREFAS EM TEXTO LIVRE, FALANDO DEMAIS.  UM TEXTO DE 4/5 LINHAS JÁ É MUITO APRA QUEM TEM PRESSA**

   Além do amis, você deve falar pouco mas ser o suficiente para a pessoa ficar curiosa para ver mais

## 23. Tempo de cada experiência

Pense bem se sua experiencia foi bom o suficenite para ser impactante e por no currículo.

SE VOCê TIVER UMA EXPERIENCEIA MUIOTO CURTA QUANDO NAO DEVERIA, ENTAO, NAO COLOLQUE. 

## 24. Não tenho experiência nenhuma, o que fazer

Olha o módulo de bônus

# Tópico 5

## 25. Idiomas

Tem que ser direto ao ponto.

Em idiomas soloque se sabe ou nao e o nível de como sabe. Nâo precisa colocar mais nada a nao ser que tiver um certificado fodão amplamente reconhecedo

Não coloque Portugues, pois nao tem diferencial aqui no Brasil, mas teria lá fora.

## 26. Intercambio de línguas - onde coloco

sim

# Tópico 6

## 27. Conhecimentos em software

Coloque coisa do word/power-pint/excel.

Pacote Office: Avançado

## 28. Como organizar idiomas e conhecimentos

Separe idiomas e esses conhecimento de softwares

**Os topicos de cad informaçao deve está bem destacado para facilitar quem vai ler entender tudo**

# Tópico 7

## 29. Cursos e experiências

Coisa demoradas e relamente interresasntes.

**AUQI VOCE COLOCA TAMBÉM PROJETOS PESSOAIS, DESDE QUE SEJA RELEVANTE A VAGA QUE ESTÁ CANDIDATO**

## 30. Como escrever cursos e experiências

Lembres, nao escrva muito. E se escrever conhecimentos técnicos, uma descriçâo simples

# Tópico 8

## 31. Meu currículo ta vazio - o que eu faço

Não é bom que sobre espaço.

Pense em alguma coisa que fez alguma coisa própria.

**lembre-se desdeque seja relevante a vaga que está se candidatando**

## 32. Onde colocar outras informações

no final

## 33. Formatação de currículo

**LEIA AUI**

O modelu que eles disponibilizaram nâo tem arquivo,mas tirei foto


## 34. Email de candidatura

Modelo do Email

```
Prezados,

Segue em anexo meu CV para candidatura à vaga X

Qualquer dúvida, estou À disposição

Atensiosamente,
Joâo Paulo Ferreira Mrtins
Estudanete de Graduação do 8 periodo de Engenria - UFF
Tel: (XX)X XXXX-XXXX
```

o-que-dizer-01

# Garimpar Expericnia

O IC que fiz em conjundo ao BRAIN DA ALGAR TELECOM: Fale em "sistema preditiva para a algar telecom"

+ Experiencia semi-profissionais
+ Trabalhos Voluntários
+ Experiencias Pessoais
  + Projetos Paralelos: Algo que destaque; Criar algo do zero;
+ Projetos de Faucldade
  + Só coloque se nao tiver nehum outro
  + Coloque projetos que demorou muito como IC e TCC

O que desssa experiencias tem mais haver com minha área