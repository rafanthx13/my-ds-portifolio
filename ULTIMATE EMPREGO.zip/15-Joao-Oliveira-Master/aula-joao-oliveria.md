# Aulão João Oliveira (31/10/2022) - Como subir na carreira de Data Science

## Dicas Gerais

+ Executa algo e mostra do que aprendeu é mais importante do que a complexidade do projeto
+ Documente tudo que você faz
+ Para analista de BI o foco é SQL



## Como vai ser a mentoria dele

**o que vai ser a mentoria**

+ Como estudar? Como ser visto por profissionais de recrutamento? Como ver projetos de freelancer e empreender na área? Como criar portfólio?

Ele vai da dar uma  mentoria com 50% codando uns 500



## Pensando em trilha de engenharia de dados onde começar

+ SQL, Python, Spark, Cloud

+ Formação de engenharia de dados do Fernando Amaral, renovou e agora está na AWS

  

## Arquitetura e governança

+ Ele fala me direciona aonde adquirir o conhecimento, mas não ensina isso

**Como é a mentoria**
+ Ele direciona ao que estudar: 
  - direciona estudar livros mais para coisas conceituais já que um livro de pbi, por exemplo, rapidinho fica obsoleto

**Dica para fazer os projetos de portfólio:**Assiste bastante e só depois você pratica



## Importância do portfólio

**Portfolio vale sempre**

+ Mesmo empregado, sempre poste no portfólio

**Portifólio tem método e forma de comunicar**

+ Você tem que se vender, ao invés de vender um produto do cara que fez o curso
+ Faça o DRE do Karpinski, aprenda, e pratique em outras coisa



## Como estudar

**Dá pra ficar só em video aulas do youtube ou tem que pagar alguma coisa**

+ É importante trabalhar com cursos, porque eles trabalham com método
+ O que deveria está fazendo 
  - Fazendo algum curso da udemy
  - aprender a fazer as perguntas certas e perguntar no youtube
+ O youtube é bom mas não tem método, e os curso tem método com início meio e fim.

www.mentoriajoaooliveira.com.br

**Como mostrar que você tem experiência?**
+ Pois muitas pedem experiência.
+ Você ele ensina como demonstrar essa experiência

**Como estudar** direcionamento das vagas?

+ Estudar 3 vezes, alterando a forma e assim é um novo conteúdo.  **POR ISSO UM BOM PORTFÓLIO É IMPORTANTE**



## As área e tecnologias

**As áreas**
+ DS, DA, DE, BI
+ Entre esses caras não têm hierarquia, nenhum BI è mais que DS, podem ganhar salários mais ou menos
- - São só fundições em um projeto. Como no futebol, você pode ter um goleiro ganhando mais do que um atacante.

DSA PowerBi: É um bom curso, mas para entrar na mentoria não precisa estudar tanto.

**Quanto a cloud: azure/aws/gcp/on-premise (open-source**
+ Ex: Pentaho vs ADF, não faz diferença muito

A certificação sempre vale a pena, mesmo que você não passe, pois você está aprendendo mesmo a utilizar a ferramenta



## Dicas de cursos

+ Midori Toyota: Um curso é bem legal, pois te dá do básico ao avançado para fazer as análises de dados .É o essencial para trabalhar com o SQL (Para manipulação de dados de SQL)

+ Felipe Mafra: BI 
  
  - Nesse ele mapa toda a arquitetura para fazer um projeto de BI do 0 ao sucesso
+ Fernando amaral: BigData
  
  - Pois ensina on-premise e em nuvem
  
  

**Na área de dados, o MAIOR TRABALHO É SEMPRE NO INÍCIO DO PROJETO, NA COLETA E TRATAMENTO DOS DADOS PARA SUA SUAS FUNÇÕES**



## Dicas de Linkedin

**No canal do youtube há uma aula de linkedin**

+ E no mentoria tem aula de como transformar em máquina de oportunidade



## Pessoas que estavam na live

+ Alexandre Batista
+ Luís Gomes
+ Igor Azevedo
+ Áquila Porfirio
+ Daniel Coelho
+ Yanni Marinho
+ Júlio César Pereira
+ Mayara Andrade
+ Rogério Carneiro



## Carreira Internacional

**Eles procuram muito BR pois pagando pouco recebe 5x aqui, então nos pagam pouco**

Cássio Bolba: Eles  migraram de aula juntos, mas o Cássio é mochileiro e já sabia inglês. Mas antes ele já trabalhava no Brasil até lá fora.
+ Esse Cássio ta na comunidade dele

Ele tem 2 mentoras em Portugal, 1 na Angola e outra na Alemanha.

Fuso horário é importante: então, 4h de diferença de fuso-horário é muita diferença, então toma cuidado com isso, pois o seu organismo não vai aguentar

Participe dessa comunidade, faça perguntas Quem não é visto não é lembrado

https://us06st1.zoom.us/web_client/9r7x5mv/html/externalLinkPage.html?ref=https://www.linkedin.com/in/cassiobolba/?originalSubdomain=de

+ Pesquise esse cara no linkedin: Alexandre Trovato



## Principais Soft Skills

COMUNICAÇÃO E NEGOCIAÇÃO SÃO AS PRINCIPAIS DOFTWAKILL

NEGOCIAÇÃO: Não é só mandar é fazer um marketing para convencer o cara a seguir a minha ideia

Linkedin Premium: Não precisa pagar


A Interação no linkedin é a chave: técnica e estratégia: tem que ser pensado, planejado e executado

**OBJETIVIDADE**: Seja objetivo em tudo, direto, curto, reto direto e de forma que **CAPTURE A ATENÇÃO DA AUDIÊNCIA**



## Como é o trabalho no Canadá

No Canadá o trabalho é sério: ninguém conversa, se quiser trocar de empresa troca. Se os caras nao se interessar em seu serviço você sai, então, **JAMAIS FIQUE APEGADO A UM LUGAR OU VAGA. É COMO A NEPPO, QUANDO QUISEREM TE TIRA, TIRA. VOCÊ É SÓ MAIS UM NÚMERO**

Para a empresa você é só um número, vai pra próxima.

Siga o livro: "Seja egoísta com a sua carreira"

Não pense que vai ser genial só porque manda mil e uma coisinhas. É trabalho, quando acabar acabou. Hj ta na moda eles darem um monte de coisa como se fosse um playground.

Seja egoista, vaga de negro e PCD é mais para eles tirarem foto de você e fazer maketing nas redes sociais. É uma relação de conveniência. Tudo é assim



## Diferença de trabalhar CLT e PJ

+ Basicamente: CLT você trabalha como se fosse exclusividade; enquanto que no PJ você negocia as horas
+ Em PJ é de empresa pra empresa, então você define bem com a pessoa, tem que tomar mais cuidado

O seu salário no PJ é 2,5 o CLT



## Revisando: PONTOS MAIS IMPORTANTES

Minha análise sobre o que foi mais importante na live:

+ **Portfolio** Foque em criar bons projetos para o portfólio. Ter boas thumbnails e publicá-los no linkedin.
+ **Soft Skills:** A comunicação significa o seguinte: "você é capaz de explicar para uma criança de 5 anos?"
+ **Como estudar:** Dá pra aprender bastante com os vídeos gratuitos do youtube mas infelizmente não é tão bom porque não há uma metodologia que tem em cursos
+ **O que fazer:** Buscar quem é mentorando dele e ver o que fazem nas redes sociais

