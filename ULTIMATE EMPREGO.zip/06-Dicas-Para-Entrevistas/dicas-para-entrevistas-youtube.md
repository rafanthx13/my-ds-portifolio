# Dicas para entrevista de Emprego

## Index

+ [Dicas para entrevista de Emprego](#dicas-para-entrevista-de-emprego)
  - [Index](#index)
  - [RESUMINDO PRINCIPAIS TÓPICOS](#resumindo-principais-tópicos)
  - [DICAS DE YOUTUBE VÍDEOS](#dicas-de-youtube-vídeos)
    * [COMO SE SAIR BEM NUMA ENTREVISTA DE EMPREGO | Lutz Podcast](#como-se-sair-bem-numa-entrevista-de-emprego-|-lutz-podcast)
    * [Código Fonte TV](#código-fonte-tv)
    * [Filipe Deschamps](#filipe-deschamps)
    * [Lucas Montano](#lucas-montano)
    * [Eric Fer](#eric-fer)
  - [primo rica - ultra aaaaaaaaaaaaaaaaaaaaa](#primo-rica---ultra-aaaaaaaaaaaaaaaaaaaaa)
    * [POR QUE VOCÊ DEVE SER CONTRATADO?](#por-que-você-deve-ser-contratado?)
    * [FALE SOBRE VOCÊ](#fale-sobre-você)





## RESUMINDO PRINCIPAIS TÓPICOS

+ COMO SE SAIR BEM NUMA ENTREVISTA DE EMPREGO | Lutz Podcast
  - Estude sobre a empresa: saiba o que ela faz, se recebeu investimentos (pre-seed, seed) e comente no meio da entrevista que você já sabe em que ponto vai se encaixar na empresa pois, **98% das pessoas não comentam sobre o trabalho da empresa na entrevista**



---

---

---



## DICAS DE YOUTUBE VÍDEOS



### Como se dar bem numa entrevista de emprego | Lutz Podcast

[link](https://www.youtube.com/watch?v=EIizt7cCnX8&list=WL&index=4&ab_channel=CortesdoLutz%5BOFICIAL%5D)

Você tem que saber tudo que a empresa faz.

+ Tipo: Porque as vendas aumentaram tanto no último trimestre

**98% DAS PESSOA NÃO COMENTAM SOBRE A EMPRESA, DURANTE A ENTREVISTA**
SABER A FUNÇÃO, O QUE A EMPRESA FAZ

Saber dos concorrentes da empresa: saber da vaga e da empresa



### Código Fonte TV

[As 3 MELHORES DICAS de Entrevistas de Emprego para Programadores](https://www.youtube.com/watch?v=e_0yQQ9Bksg&ab_channel=C%C3%B3digoFonteTV)

1. Saiba mais sobre a empresa e a oportunidade
+ A cultura da empresa é essencial. Você tem que conhecê-la bem para assim saber responder "porque você quer trabalhar na nossa empresa"
+ Coloque no papel pontos positivos e negativos, pese tudo isso e responda você mesmo.
+ Consiga conversar com alguém que já está lá na empresa: tentar entender a empresa
  + Glassdoor tem um ótimo feedback dos funcionários para com a empresa
+ **Stalkear o recrutador**



2. Se planeje prevendo um futuro
+ Saiba responder essa perguntas: "Qual foi o programa mais difícil que já teve que resolver". Escreva a resposta e relia várias vezes
+ Conseguir se fazer entender e a forma é mais avaliado



3. Pratique e resolva muitos problemas de programação
+ Eles testam mais seu processamento lógico: estruturas de dados; ordenar array; recursão



### Filipe Deschamps

[Entrevista de emprego: 3 dicas para ser um candidato irresistível (dicas da Pixar)](https://www.youtube.com/watch?v=DRacV64Mt1I)

3 Caracteristicas que Randy Nelson fez numa conferência da Apple em 2008 do que procurava nas pessoa para trabalhar na pixar

1 - Profundidade
+ Se conseguir recuperar de erros: ou seja, resiliência e adaptabilidade
+ Tenha maestria: seja mestre em alguma coisa. Pois se você é capaz de ser um mestre em uma área, então você deverá ser capaz de ser em outras. A prova de ser mestre em uma área já mostra isso
  - Porque O cérebro de quem é master em uma coisa é diferente de quem não é em nada, mesmo que seja em algo inútil, e esse mindset vai servir para resolver qualquer problema de programação

2 - Abrangência
+ Ser interessado ao invés de ser interessante, é meio que ter uma empatia aos problemas e ao 'share'

3 - Comunicação

**Comentários**

=> Meu antigo chefe me falou uma vez: estamos procurando cada vez mais pessoas com inteligência emocional. É muito fácil ensinar a alguém o que fazer numa situação previsível, cotidiana. Porém é difícil ensinar alguém a como reagir a uma situação inusitada e principalmente caótica. As pessoas que conseguem enfrentar um problema com calma e  sabedoria, são as mais requisitadas no mercado de trabalho.

=> resumindo, procure um emprego que seja a sua paixão, ai na hora da entrevista, você vai ser profundo no assunto, extremamente conhecedor sobre o assunto e saberá o que fazer sempre sem desistir 



### Lucas Montano

[COMO GARANTIR NA ENTREVISTA (como Programador)](https://www.youtube.com/watch?v=P2y1n_NyJy0)

Usei o site GlassDoor na empresa. Lá terá uma aba sobre a empresa, review e processos de contratação.

Self-Introduction: anote parágrafos e decore sobre você mesmo

Se prepare para perguntas comportamentais: "porque você quer deixar a empresa atual"

Pesquise perguntas mais comuns e decore as respostas

**FAÇA PERGUNTA** Será que aquela vaga é ideal pra você? Ninguém gosta de perder tempo, então, garanta fazer perguntas para o entrevistador. Isso garante: que você saiba bem onde vai

Exemplos de pergunta para ao entrevistador:
+ Porque estão precisando de um profissional para essa vaga
+ O que o meu trabalho contribui para a missão da empresa
+ Pergunte sobre política de trabalho remoto e como é a comunicação remota
+ Pergunte sobre os maiores desafios da empresa tecnicamente



### Primo Rico

[Como Passar em uma Entrevista de Emprego | 6 Truques COMPROVADOS!](
https://www.youtube.com/watch?v=bstb-3xuTq4&ab_channel=PAPCURSOSECONCURSOS)

+ 1 - Seja a solução
+ 2 - Demonstre Energia
+ 3 - Demonstre Valor e não esforço
+ 4 - Jornada do Herói
+ 5 - Não seja arrogante

**COMENTÁRIO DO VÍDEO 1**

Vou passar para vocês o que eu sei sobre passar em uma entrevista:

1 - Desligue o celular antes de entrar na empresa (o entrevistador pode achar que você não está muito interessado na vaga) 

2 - Fique atento assim que chegar na empresa, pois ali você já pode estar sendo analisado. ( De bom dia para quem passar por você, seja educado, espere sua vez com postura, evite cochilar no banco de espera).

3 - Na entrevista: Esteja com uma roupa um pouco mais formal (sem decotes, cores chamativas, calças rasgadas e roupas mal passadas e sujas) 

4 - Não finja ser quem você não é (não invente respostas que estão longe de ser verdade, não diga coisas que você sabe que não vai ser capaz de fazer)

5 - Mostre interesse na vaga (diga o por que você se encaixaria bem nessa vaga).

6 - Tente responder todas as perguntas (às vezes o entrevistador só quer testar como você reage a perguntas inesperadas, se seu raciocínio é rápido, se você consegue minimizar uma situação onde um cliente te perguntam coisas que você pode não saber, evite falar "não sei".

7 - tente se sentir à vontade para falar (Pense que o entrevistador é uma pessoa qualquer que quer saber sobre você)

8 - Não deixe se dar por vencido se por acaso não tiver experiência na Área, ou seu trabalho anterior era diferente do que quer ocupar  (diga que mesmo as pessoas que já tem experiência na função que vai exercer, ela tem que aprender com a nova empresa trabalha que é um jeito diferente, único deles e que você pode aprender o que a empresa precisa)

9 - lembre se isso são dicas e não um roteiro que exatamente você tem que fazer ( aja naturalmente, coloque em prática de sua maneira confirme a  situação, não haja nem um robô que decorou atos e palavras para fazer/dizer....)

**COMENTÁRIO DO VÍDEO 2**

Sempre buscava uma fórmula mágica, mas aprendi com você que não existe magia, mas conhecer a mim mesma e desenvolver, coloquei no papel , falei na frente do espelho e realmente me achei nas respostas, desejo colocar em prática e que venha as entrevistas por favor.


### Porque você deve ser contrato?

[POR QUE VOCÊ DEVE SER CONTRATADO?](https://www.youtube.com/watch?v=t06HP1mmn_o&ab_channel=SeOrientteCarreiras)

Você deve vender o seu peixe: você deve dizer que a partir da sua experiência e vivência o que a empresa vai ganhar. Pois cada um é único, então mostre o que você tem de único que nenhum outro candidato terá: ou seja, demonstre sua competência, proatividade e posições que requerem algum esforço que você conquistou

