# Como responder as eprguntas difícies

## Index

## Links and Posts

### Como você se vê daki a 5 anos?

[Onde você se vê daqui a 5 anos?](https://www.linkedin.com/feed/update/urn:li:activity:6995738417158369280)

**O que o recrutador quer saber de você**: Entender as suas pespectivas para o futuro. Saiba que ao escolher uma pessoa, a empresa está investindo (pagando o saĺario) em você, e como tal espera obter lucro (espera que você valhe muito mais do que o salário)

Por conta disso,eu nâo acho uma boa ideia falar: pretendeno me ver no facebook, por exempllo. Isso já mostra que você **já pensa em cair fora da empresa**, nâo dê essa impressão.

Resposta que ela deu no post:

"Imagino que dentro desse período de 5 anos eu já tenha desenvolvido todas as competências e habilidades necessárias na minha área de atuação, pretendo ter concluído alguns cursos e certificações e quero ter aprimorado meu conhecimento em inglês, que hoje vejo que é um requisito em muitas empresas. Acredito que essa empresa tenha um bom plano de desenvolvimento que irá me permitir evoluir enquanto profissional"

#### MINHA RESPOTA

> Em 5 anos eu já espero ter desenvolvido bem todas as minhas habilidades e experiências nescessárias para me considerar um dev sênior. Pretendo até então ser fluente em ingles e ter concluido ccursos e certificaçôes que possam me deixar mais atualizado na minha área como Docker, DevOps, Cloud, Figma, UX além de ter um conhecimento mais sólido nas linguagens que já desenvolvo (React/Vue, Java/Node/PHP).
(*PARTE IMPROTATNE DEIXAR DESTACADA*) Acredito que essa empresa tenha um bom plano de desenvolvimento que irá me permitir evoluir enquanto profissional


