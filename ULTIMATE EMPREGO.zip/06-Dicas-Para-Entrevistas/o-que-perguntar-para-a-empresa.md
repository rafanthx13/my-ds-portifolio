# O que perguntar para a empresa

## Fontes

+ [Como garantir uma vaga como programador)](https://www.youtube.com/watch?v=P2y1n_NyJy0)

---
---
---

### [Como garantir uma vaga como programador](https://www.youtube.com/watch?v=P2y1n_NyJy0)

+ Porque estão precisando de um profissional para essa vaga
+ O que o meu trabalho contribui para a missão da empresa
+ Pergunte sobre política de trabalho remoto e como é a comunicação remota
+ Pergunte sobre os maiores desafios da empresa tecnicamente

### RANDOM

+ Pergunra sobre: Horario, rotina de atividades, flexibildiade de horario
