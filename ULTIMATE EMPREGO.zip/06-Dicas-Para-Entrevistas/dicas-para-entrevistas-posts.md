# Dicas para entrevistas

## Dicas de Posts da internet

### Linkedin - DICAS PARA SE CANDIDATAR A UMA VAGA DE TI

link da publicação: https://www.linkedin.com/posts/orlandodasilvajunior_dicas-vagas-trabalho-activity-6889160683422838784-mF05

1. Tenha um objetivo claro no currículo. "Quero contribuir com a empresa" é diferente de "Analista de Dados Jr".

2. Hoje não existe desculpa para não ter pelo menos 3 cursos com certificado na área que você está se candidatando.

3. Faça perguntas na entrevista, como: por que estão me contratando? Com o que vou trabalhar? Quem são os principais clientes da empresa?

