# Perguntas feitas pelos entrevistadores

# Perguntas que o recrutador pode fazer

Roteiro para entrevista entre gestor e desenvolvedor
Agora que você chegou até aqui, chegou a hora de conhecer 12 perguntas que costumam ser feitas durante a entrevista com gestor. 

+ O que atraiu você para a nossa empresa?
+ De que maneira você acredita que os seus conhecimentos podem nos ajudar?
+ Conte sobre a sua experiência na empresa X e indique um trabalho que você acredita que tenha feito a diferença por lá. E por que funcionou tão bem?
+ Fale sobre como se sente quando a entrega não atende com precisão o cliente. Lembra de algum exemplo que teria feito diferente?
+ Quais sites, blogs, fóruns você acompanha regularmente? Quais são as suas referências?
+ Quais habilidades e tecnologias você tem interesse em aperfeiçoar?
+ Como lida com desavenças na equipe? Você acha que trabalha melhor sozinho ou em equipe?
+ Qual foi o melhor emprego que você teve e por que o considera o melhor?
+ Que tipo de projetos motiva você?
+ O que é essencial que o seu empregador saiba sobre você?
+ O que faria com que você desistisse de aceitar uma oferta de trabalho do concorrente?
+ Existe outro cargo que interesse na empresa?
+ As perguntas listadas acima costumam ajudar bastante o entrevistador a acessar os melhores desenvolvedores, por isso, é sempre bom tê-las em mente.


+ ESCREVA 10 QUALIDADES QUE VOCE POSSUI

https://collegegrad.com/tough-interview-questions/what-sets-you-apart-from-other-qualified-candidates

## DEFEITOS E QUALIDADES

**Defeitos**

• nervosismo;
• medo de falar em público;
• perfeccionismo;
• ansiedade;
• timidez;
• conversar demais;
• dificuldade em enxergar injustiças;
• ter padrões muito elevados;
• dificuldade em desenvolver confiança nos outros;
• dificuldade de organização.

**Qualidades**

• criatividade;
• pontualidade;
• proatividade;
• experiência;
• positividade;
• liderança
• honestidade;
• autoconfiança;
• tranquilidade em situações tensas.
