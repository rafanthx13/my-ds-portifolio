# Dados para inserrir nas Vagas



REQUISITOS E QUALIFICAÇÕES



**O que esperamos de você para essa vaga:**




- Análise de dados com python/R e conhecimento básico de ferramentas de visualizações de dashboards (PowerBi, DataStudio, Tableau, etc);
- Conhecimento básico de Engenharia de Machine Learning (Docker e ferramentas de pipelines como: Kubeflow, Airflow)
- Conhecimento básico de Cloud (GCP, AWS), SaaS e PaaS;



**Será um diferencial, caso você conheça:**



- Diferêncial: Conhecimento de bibliotecas e modelos de Processamento de linguagem natural - NLP (Gensim, Word2vec, fastText, BERT, etc)



## ENTRAR EM COISAS

DIO: Crowthunder_8x9
lpsg: 432@g :: pinkthunder
pandlr : 
Linkedin : LinkedinThunder_47

Thor Progmraamdor Teste
https://radartec.com.br/vaga/10462
abler  completar
https://candidatos.abler.com.br/app/profile

catho :: google acc mas tem pouca coisa


Rua Mem de Sá 105
2 andar Centro
Eunápolis, BA 45820052
Brasil

https://github.com/rafanthx13
https://www.linkedin.com/in/rafael-m-de-assis/

Rafael Morais de Assis
rafaassis15@gmail.com
34993166595
Belo Horizonte
Estagiário Dev Full-Stack
Neppo

vagas.com.br

rafael_assis_23
Crowthunder_7
@hot

Qualquer dia útil as 9h ou 15h

empregoss.com.br
Senha: Crowthunder_

**BairesDev**
https://applicants.bairesdev.com
Usuário: rafael.assis6
Senha: oNdD/SvR

## EMPRESA DE TI BH para inserir no GoogleSheet

+ Aec
  - Rua Espírito Santo, 871, Centro, BH
  - http://www.aec.com.br
  - https://www.linkedin.com/company/aec/jobs/

+ Teknisa

+ SS Consultoria


## Descrições do Linkedin


### About me

### Neppo

Estagiário‍ do‍ Programa‍ da‍ Neppo‍ atuando‍ em‍ 2 projetos como desenvolvedor Full-Stack:

O primeiro projeto consistia na elaboração de um sistema web para realizar consultas no banco de dados, além de fornecer relatórios personalizados em excel/pdf. Foi desenvolvido uma usando PHP no backend para realizar as consultas SQL e Angular.JS‍ como‍ FrontEnd. Além disso foi usado a ferramenta Pentaho para realizar ETL, para extrair dados de uma API externa e internalizar no banco de dados além de muitas outras operações

O segundo projeto foi um sistema para cadastro e gerenciamento de usuários da empresa. Foi utilizado Java‍ (Spring‍ Framework)‍ como‍ BackEnd‍ e‍ Vue.js‍ como‍ FrontEnd.

Em ambos‍ os projetos foram utilizados HMTL,‍ CSS,‍ banco‍ de‍ dados‍ MySQL e git além de terem sidos gerenciados pela metodologia‍ Scrum‍.

### UFU

Nota: 85.6

Atividades e grupos: Iniciação científica na área de ciência de dados envolvendo empresa de telecom. Foi obtido como resultado um artigo científico por participar do grupo de pesquisa e meu TCC.
