# Termos e Atividade

======================
## Engenharia de dados
======================

## https://www.linkedin.com/jobs/view/3376766075/

O Engenheiro de Dados desenvolve, constrói, testa e mantém arquiteturas, como bancos de dados e sistemas de processamento em grande escala, seja no local ou na nuvem.. Para esta posição você precisa ter:

Qualificações e Experiências

Conhecimento em Data Warehouse; Data Lake e ETL/ELT, Integração de Dados;
Experiencia com ferramenta Informática Cloud (IICS);
Conhecimento em Modelagem de Dados;
Conhecimento em cloud AWS (S3, Redshift, Sage Maker, Code Build);
Conhecimento em Databricks;
Experiência em CI/CD aplicadas a projetos de dados (Code pipeline, Terraform, GiT);
Conhecimento em banco de dados;
Prática em linguagem Python, Spark e SQL;
Conhecimento em ferramenta de visualização de Dados Power BI.

Habilidades e Atribuições

Construir com o time, discutindo tecnologias, arquitetura, ferramentas, processos e organização;
Apoiar na implementação de pipelines de extração, transformação e carga de dados;
Apoiar na modelagem, gerenciamento e organização das novas bases de dados, e ajudar na construção ETLs e ELT's para novas solicitações;
Atuar na análise e desenvolvimento de novas integrações entre sistemas e Banco de Dados;
Atuar diretamente no projeto de construção da arquitetura de dados (AWS).

Será legal se você também tiver

Facilidade com análise e solução de problemas e transitar muito bem entre tecnologia e negócios;
Saber identificar necessidades geradas pelo projeto dentro modelo analítico de dados;
Boa comunicação para interlocução com o time técnico e outras áreas de negócios.

======================
## Analista de dados
======================

======================
## Ciêntista de dados
======================

### BIX - Cientista de Dados Júnior

url: https://www.linkedin.com/jobs/view/3403563152/

Responsabilidades e atribuições

O que você fará em seu dia a dia:
Realizar todas as atividades listadas abaixo em projetos nacionais e/ou internacionais sempre que necessário;
Realizar reuniões com os analistas do cliente, por meio de videoconferência, desenvolvendo os questionamentos estratégicos voltados ao seu negócio/processo, a cada início de projeto ou sprint;
Definir junto ao cliente e ao tech lead, por meio de videoconferência, as métricas de negócio do projeto e como elas se relacionam com o modelo de machine learning para entregar a melhor solução, sempre que houver um novo projeto;
Realizar consultas e extrair dados do banco do cliente, utilizando linguagem SQL, para construção dos modelos de machine learning, sempre que houver um novo projeto;
Construir gráficos utilizando linguagem de programação Python e bibliotecas como matplotlib, seaborn, plotly, de modo a gerar as visualizações dos dados durante a fase de análise exploratória do projeto;
Construir pipelines de tratamento de dados em Python, principalmente bibliotecas Pandas e scikit-learn, para treinamento e inferência dos modelos de machine learning, sempre que houver um novo projeto;
Planejar e realizar a comprovação dos modelos de machine learning, utilizando técnicas como validação cruzada, para obter a aceitação do cliente, sempre que houver um novo projeto;
Criar e/ou utilizar métricas de avaliação utilizando linguagem de programação Python e biblioteca scikit-learn, para avaliar performance de modelos de machine learning, sempre que houver um novo projeto;
Construir apresentação em slides para evidenciar os resultados da análise exploratória e resultados de modelo para o cliente, demonstrando os impacto para o negócio em linguagem não técnica, sempre que houver um novo projeto;
Desenvolver e documentar o projeto, utilizando ferramentas de gerenciamento de atividades, github e jupyter notebooks, para a gestão de conhecimento, sempre que necessário.

Requisitos e qualificações

O que esperamos que você tenha:
Ensino Superior cursando ou completo, em áreas correlatas a sua função: engenharias, cursos de computação e cursos relacionados à área de exatas;
Experiência prévia em utilizar git, como github, gitlab, etc;
Conhecimentos básicos em banco de dados e SQL para realizar consultas em banco de dados durante projeto;
Conhecimentos básicos de probabilidade e estatística;
Conhecimentos sobre machine learning: principais modelos, trade-offs, boas práticas de projeto de ML, avaliação de métricas e modelos;
Conhecimento teórico do funcionamento de modelos de redes neurais artificiais;
Habilidade para criar pipeline de tratamento de dados em Python e desenvolver modelos de machine learning em Python usando bibliotecas de mercado;
Habilidade em criar e analisar gráficos em Python.

O que será um diferencial que você tenha:
Experiência em ferramentas de BI e engenharia de dados;
Experiência em realizar deploy de modelos de machine learning;
Ter conhecimento de modelagem de dados estrela e snow flake.




### Cientista de Dados - PJ

url: https://www.linkedin.com/jobs/view/3393689750/

O que esperamos de você?

Formação Superior em Estatística, ciência da computação, matemática ou áreas afins;
Conhecimento em técnicas de mineração de dados, técnicas de modelagem como Regressão Logística, Árvores de Decisão, Machine Learning, entre outras;
Conhecimento em manipular grandes volumes de dados em diferentes ambientes/ferramentas e formatos;
Conhecimentos em R, Python, SQL;
Conhecimento em Data Visualization (Power B.I);
Conhecimento em WebScraping
Boa capacidade para identificar e propor soluções para problemas, garantindo a aplicabilidade das soluções;
Boa comunicação, habilidade de transmitir análises complexas de forma simples para as áreas de negócios.

O que você vai fazer?

Análise e interpretação de dados;
Análise preditiva e descritiva;
Criar estudo de novas técnicas para desenvolvimento de modelos estatísticos;
Estudar oportunidades ocultas nos dados;
Participar de reuniões para entendimento de problemas de negócio e necessidades;
Desenvolver dashboards gerenciais para tomada de decisões;
Validar impressões e resultados para o negócio com equipe;
Formular e analisar hipóteses que ajudem a empresa a alcançar seus desafios estratégicos;
Pesquisar novas técnicas e metodologias em Ciência de Dados e testar sua aplicação no negócio;
Trabalhar em parceria com a equipe transversal na resolução dos problemas.

### Data Scientist

https://www.linkedin.com/jobs/view/3388877706/

A vaga

O objetivo da área de Data & Analytics é criar um portfólio de soluções baseadas em dados para otimizar os produtos e serviços que simplifiquem o dia a dia dos nossos clientes, fornecedores e parceiros.

Buscamos uma pessoa cientista de dados com alta capacidade de inovação, inventiva, com sentido analítico e orientada a negócios. Que tenha vontade de experimentar, testar e criar soluções a problemas usando dados.

Essa pessoa irá trabalhar no nosso produto de inteligência de dados, que oferece ao Food Service insights sobre a competitividade de diferentes players, sua precificação de produtos, mix e estratégias de aquisição de clientes. Que seja versátil do stack de dados, ou seja, que consiga extrair e manipular dados, fazer modelos e colocar em produção assim como prototipar aplicações e visualizações e apoiar em alguns estágios da engenharia.


O que você fará

Entender os problemas de negócio e traduzi-los em problemas de dados;

Desenvolver análises de elasticidade de preço, apontando oportunidades de diferentes estratégias de precificação e descontos;

Desenvolver modelos de Machine Learning para distintas aplicações voltadas a monetização de dados;

Identificar efeitos de sazonalidade para diferentes categorias, buscando isolar a influência de eventos e fatores externos a tendências do mercado.


O que esperamos de você

Conhecimentos em algoritmos de classificação, regressão e agrupamento;

Proficiência em alguma linguagem como R ou Python;

Conhecimento sólido em SQL;

Entendimento de estatística;

Curiosidade por descobrir informação a partir de dados;

Ótima análise exploratória de dados internos externos e domínios de ferramentas para reprodutibilidade de experimentos;

Interesse em deployment de modelo e MLOps;

Boas práticas do desenvolvimento de software (Git, reproducibilidade, logging e documentação, teste).


Vamos adorar se você tiver conhecimento e/ou experiência com:

Ferramentas nativas da AWS (S3,Redshift, Sagemaker);

Ter trabalhado em projetos de monetização de dados;

Interpretabilidade de modelos black box;

Familiaridade com Ferramentas de MLOps;

Startups early stage ou ambientes inovadores/não tradicionais e no segmento de foodservice.

======================
## Back End
======================

## Desenvolvedor PHP Júnior

url: https://www.linkedin.com/jobs/view/3398243545/

Responsabilidades e Experiências Desejáveis
Ensino superior completo nos cursos de Análise e Desenvolvimento de Sistemas, ou Computação Aplicada, ou Engenharia de Software e áreas correlatas;
Conhecimentos em HTML; CSS; JavaScript;
Conhecimentos em PHP e Framework Laravel;
Conhecimentos em Linguagem SQL; SGBD MySQL; SGBD SQL Server; Web Services e Web Socket;
Responsável pelo desenvolvimento e manutenção de sistemas para ambiente web;
Responsável pela utilização de ferramentas e novas tecnologias de desenvolvimento web.

### Software Engineer II (Backend - Financial Services)

https://www.linkedin.com/jobs/view/3399303344/


E o dia a dia como será? 💼

Construir novas aplicações de diversas naturezas (APIs, consumidores de eventos, etc), sendo totalmente responsável pelo seu código
Analisar situações e ajudar a propor soluções eficientes
Resolver problemas de forma rápida e criativa
Participar da concepção, desenvolvimento e evolução de produtos


O que esperamos de você? 🎓

Experiência de no mínimo 3 anos com Node.js, Java ou Python
Conhecimento na codificação de testes unitários
Conhecimento de banco de dados relacionais, especialmente PostgreSQL
Bom raciocínio lógico
Vivência em times que utilizam o Git Flow
Facilidade de trabalhar em equipe de forma 100% remota
Curiosidade e vontade de aprender novas ferramentas, plataformas e tecnologias

⭐ Antes de qualquer coisa saiba que você irá se destacar super bem no nosso time, se:⭐

Conhecimentos de cloud AWS
Algum conhecimento na criação e consumo de APIs REST
Conhecimento em meios de pagamentos e mercado financeiro
Algum conhecimento de automação e/ou infraestrutura como código (vivência em cultura DevOps)
Algum conhecimento em metodologias ágeis



======================
## Front End
======================

### HotMart - Desenvolvedor (a) FrontEnd

url: https://www.linkedin.com/jobs/view/3398247725/

Suas responsabilidades / Seu dia a dia
Atuar na construção de soluções que objetivem agir sobre problemas de diversos níveis de complexidade, buscando sempre otimizar os nossos processos e tecnologias;
Atuar na análise, definição, desenho técnico e na proposta de solução para o escopo de um problema;
Realizar a implantação da solução desenvolvida;
Analisar os possíveis pontos de impacto que afetem a execução técnica do trabalho;
Revisar a qualidade das soluções propostas pelos seus pares.
Qualificações que você precisa ter:
Inglês intermediário;
Dominar JavaScript, TypeScript, HTML, CSS, ES6 e ES7;
Sólido conhecimento e experiência em React;
Considerável experiência em modelagem e arquitetura front-end, integrações utilizando API REST e com controle de versão, preferencialmente Git e uso do GitHub.
Você terá ainda mais vantagens se possuir…
Conhecimento em Vue, Flux, bundlers e transpilers;
Experiência com metodologias ágeis, PWA e Service Workers.
Benefícios
Plano de saúde e odontológico;
Bolsa de idiomas e incentivo à educação;
Vale Refeição/Alimentação e Cartão Multibenefícios;
Licença Maternidade e Paternidade estendidas;
Auxílio creche;
Bonificações e Participação nos Lucros;
Hotmart Recharge: Bônus de 30% como incentivo à utilização das férias dentro do período aquisitivo;
Saúde e Bem-estar: parceria com rede de psicólogos e nutricionistas.
Por que a Hotmart?

Fundada em 2011, a Hotmart é uma empresa global de tecnologia, líder em produtos digitais e focada na Creator Economy (Economia dos Criadores de Conteúdo). Nossa missão é possibilitar que as pessoas vivam de suas paixões, transformando sua audiência em clientes, habilidades em produtos, e influência em negócios.



### Desenvolvedora Software Front-End (Júnior ou Pleno)

url: https://www.linkedin.com/jobs/view/3403749039/

Responsabilidades e atribuições

Programar, codificar e testar linguagens de programação

Levantar requisitos para novas implementações, avaliando o impacto nas funcionalidades existentes

Executar manutenção dos sistemas, aplicando eventuais correções, visando melhorar a performance para dos usuários

Contribuir para a melhoria contínua dos sistemas da empresa, buscando agregar valor e melhorar a experiência do usuário

Criar e/ou atualizar documentações pertinentes aos sistemas desenvolvidos

Disseminar conhecimentos técnicos, tornando-se um multiplicador das inovações

Requisitos e qualificações
Conhecimento em Reactjs
Javascript
CSS
HTML
GIT/TFS

Você se destaca se tiver:
.NET
Typescript



======================
## Full Stack
======================

### Analista Desenvolvedor de Sistemas JR - Contagem

url: https://www.linkedin.com/jobs/view/3393517907/

Sobre a vaga
Atuar com o desenvolvimento e manutenção de soluções baseadas em tecnologia alinhadas com a demanda da empresa, através do uso de ferramentas com o API de Desenvolvimento PHP, SQL Server, PHP, Laravel e JQUERY.

Responsabilidades e atribuições

Desenvolver Webaplicativos com uso de PHP, Jquery e CSS.
Desenvolver integrações entre as ferramentas utilizadas pela empresa.
Manter-se informado sobre novas tecnologias.
Participar da especificação de desenvolvimento com os usuários da empresa.
Analisar problemas de integração de webservice com as soluções contratadas.
Efetuar publicação das aplicações desenvolvidas em servidores Linux

Requisitos e qualificações

Cursando superior em Análise e Desenvolvimento de Sistemas, Sistema de Informação, Ciência da Computação

Experiência com desenvolvimento em desenvolvimento Web com uso de PHP com Laravel

Desenvolvimento linguagem PHP, Jquery, T-SQL, HTML

## Desenvolvedora Full-Stack Jr

url: https://www.linkedin.com/jobs/view/3394668461/

💡 No dia a dia você irá:
Fazer parte de uma Squad junto com outros Desenvolvedores, QAs,Tech Leader, POs, SM, sendo responsável junto com o time pela construção e ciclo de vida do produto digital, utilizando as metodologias ágeis.
Codificar junto com outros desenvolvedores, utilizando os melhores padrões de desenvolvimento, arquitetura e frameworks.
Participar ativamente das decisões do time quanto a tecnologias, padrões e demais assuntos que apoiem o desenvolvimento do produto.
Garantir a qualidade do seu código através das melhores práticas de testes, bem como participar de review de código de outros engenheiros.
Utilizar as práticas de CI/CD para versionamento e automação de deploys em produção.
Utilizar ambientes Clouds, Containers, Micro Serviços, APIs, Serviços de Mensageria e Banco de dados relacional e não relacional.
Conhecer o mercado de seguros, seguradoras, corretores, consumidores como um #TechInsurance

Requisitos e qualificações

🔍 Para se candidatar, você precisa ter:
Uma boa lógica da programação;
Experiência em desenvolvimento em linguagens/frameworks: Python/Django, PHP/Laravel, VueJS;
Experiência com Git, Bitbucket, Gitflow, JIRA, Scrum, Kanban
Experiência em ambientes Clouds em especial AWS.
Experiência em Docker, MySQL, PostgreSQL, MongoDB. DynamoDB;
Experiência com MicroServiços, APIs,
Conhecimentos Domain Driven Design, Test Driven Development, Clean Architecture, Clean Code e Solid;
Graduação completa em curso superior Ciências da Computação, Sistema de Informação ou afins.

Soft Skills Requeridas:
Ótima comunicação, interação e trabalho em equipe (time e steakholders);
Forte senso de dono;
Resolução de problemas.
Capacidade de trabalhar em um ambiente de ritmo acelerado, onde a inovação contínua está ocorrendo;
Ter abertura para dar e receber feedbacks.

É um diferencial se você tiver:
Conhecimentos em serviços de mensageria com RabbitMQ, Kafka;
Conhecimentos em linguagens como Flutter, Node.js, React;
Inglês intermediário.

## Analista de sistemas

url: https://www.linkedin.com/jobs/view/3367031287/

Sobre a vaga
Chegou a sua oportunidade de experimentar o que é fazer parte de uma das Melhores Empresas para se trabalhar em Minas. Estamos buscando pessoas que gostem de desafios, têm brilho nos olhos, alto engajamento, boa comunicação, proatividade e focados em resultado.


O que você precisa:

Vivência com levantamento de requisitos;
Metodologia de desenvolvimento de sistemas (UML, Ágil);
Ferramentas de desenvolvimento de softwares;
Banco de dados DB2 e SqlServer;
Conhecimento COBOL, CICS, VSAM, e/ou Web service, API, .NET.

Será um diferencial:

Conhecimento de sistemas na área bancária.

O que você irá encontrar aqui:

Realizar as atividades inerentes ao desenvolvimento e sustentação dos sistemas;
Realizar levantamento dos requisitos das regras de negócio dos produtos envolvidos, efetuando análise, implementação, testes e homologação dos artefatos e liberar para a implantação;
Atender demandas relativas a inconsistências verificadas em sistemas, buscando a sua solução, providenciando ajustes de programa ou direcionando para as providências de outros analistas ou para outras áreas de atuação;
Executar testes individuais;
Homologar os processos do sistemas junto aos usuários.

### Analista de Desenvolvimento PHP - Laravel - Full Stack - Junior

https://www.linkedin.com/jobs/view/3395032660/

Responsabilidades e atribuições
Desenvolvimento e manutenção de aplicações web;
Criação de API Rest;
Desenvolvimento e manutenção de aplicações mobile;
Realizar a manutenção e criação de novas funcionalidades;
Desenvolvimento de funcionalidades no Front-End;
Desenvolvimento de funcionalidades no Back-End;
Desenvolver e sustentar integrações;
Dailys
Weeklys

Requisitos e qualificações
Experiência em PHP 7+ e Laravel 6+
HTML
Bootstrap
API's Rest
Banco de Dados MySQL
Versionamento Git
Ionic
Angular
Noção de Gerenciamento de Projetos
Scrum e Sprint
Disponibilidade de horário
