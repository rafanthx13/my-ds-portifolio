# Nova Descrição do Linkedin

===============================

## Título

**antigo**

Dev Full-Stack | Data Analyst | Data Science | Python | Vue.js | Node.js | SQL

**novo**

Desenvolvedor Full Stack | Analista de Dados | Cientista de Dados | Python | Vue.js | Node.js

===============================

## Novo Sobre mim



### Antigo

Oi eu sou Rafael Assis, graduado em Ciência da Computação na UFU. Desde criança tenho me interessado na área de tecnologia, tanto que meu ensino médio foi atrelado ao técnico em informática, onde tive meu primeiro contato com algoritmos. Na faculdade pude me aprofundar na computação, e por meio do estágio que durou 2 anos, me tornei um desenvolvedor full-stack. 

A partir do meu contato com a Iniciação Científica me apaixonei pela área de Ciência de Dados. Essa experiência resultou na participação da confecção de um artigo científico.

No decorrer da graduação e do estágio pude trabalhar com várias tecnologias, dessas as que acabei mais usando foram: Vue.JS para Front-End, Node.JS para Back-End e Python para Ciência de dados.

Recentemente tenho buscado me especializar na área de Engenharia de Dados.

Para ver meu Portfólio e mais informações de contato:
https://rafaelmassis.com.br/

### Novo

Graduado em Ciência da Computação pela Universidade Federal de Uberlândia e com experiência em desenvolvimento de software em estágio, estou em busca do primeiro emprego após terminar a minha graduação.

Aficionado por tecnologia e dados, acredito que essa combinação tem tudo para melhorar o mundo: agilizar processos, reduzir custos e otimizar operações.

Possuo 2 anos de experiência como Estagiário em Desenvolvimento de software Full Stack na Neppo, o que me deu habilidades tanto em Back quanto em Front.

Na área de dados, tive experiência na minha iniciação científica, TCC em cursos, projetos pessoais e desafios. Fiquei entre os 10 melhores no desafio da Data Hackers para construir uma excelente análise com storytelling sobre os dados coletados de uma pesquisa da área de dados no Brasil.

Atualmente tenho me dedicado a desenvolver as habilidades que já possuo com projetos e cursos e a estudar Engenharia de Dados, Big Data e Cloud.

Principais Tecnologias:
- Vue.js, PHP e Java (Spring) (muito usados em meus 2 anos de estágio)
- Node.js (Express.js/Nest.js) para construção de API REST modernas.
- Python e SQL para análise de dados, ciência de dados e machine learning

Outra ferramentas e tecnologias que já tive contado: 
Spark (Pyspark) | DBT | MySQL | Python Frameworks (Django, Flask) | Web Scraping (com Python) | GIT | API | ETL | Pentaho | Git e GitHub | Power BI | Excel | Docker | AWS | React.js | Next.js | DataViz (Seaborn, Plotly) | PHP Frameworks (Slim, Laravel) | Machine Learning (Scikit-Learn) | Data Wrangling e Data Cleaning (Pandas) | Estatística | HTML | CSS | JavaScript | TypeScript | Tailwind CSS | Bootstrap CSS |

Links: 
- Site pessoal / Portfólio: rafaelmassis.com.br
- Git: https://github.com/rafanthx13
- Projeto de Análise de dados: https://www.kaggle.com/code/rafanthx13/analise-da-rea-de-dados-no-brasil/notebook
- Co-autor de artigo na Iniciação Científica: https://repositorio.usp.br/item/002968832

## Novo em Inglês

Graduated in Computer Science from the Federal University of Uberlândia and with experience in software development in the internship, I'm looking for my first job after finishing my graduation.

Passionate about technology and data, I believe that this combination has everything to improve the world: streamline processes, reduce costs and optimize operations.

I have 2 years of experience as an Intern in Full Stack Software Development at Neppo, which gave me skills in both Back and Front.

In the data area, I had experience in my scientific initiation, my Final Paper, courses, personal projects, and challenges. I was among the top 10 in the Data Hackers challenge to build an excellent analysis with storytelling on the data collected from a survey of the data area in Brazil.

Currently, I have dedicated myself to developing the skills I already have with projects and courses and studying Data Engineering, Big Data, and Cloud.

Main Technologies:
- Vue.js, PHP and Java (Spring) (used a lot in my 2 years of internship)
- Node.js (Express.js/Nest.js) for building modern REST APIs.
- Python and SQL for data analysis, data science and machine learning

Other tools and technologies I've already told:
Spark (Pyspark) | DBT | MySQL | Python Frameworks (Django, Flask) | Web Scraping (with Python) | GIT | API | ETL | Pentaho | Git and GitHub | Power BI | Excel | Docker | AWS | React.js | Next.js | DataViz (Seaborn, Plotly) | PHP Frameworks (Slim, Laravel) | Machine Learning (Scikit-Learn) | Data Wrangling and Data Cleaning (Pandas) | Statistics | HTML | css | JavaScript | TypeScript | Tailwind CSS | Bootstrap CSS |

Links:
- Personal website, Portfolio: rafaelmassis.com.br
- Git: https://github.com/rafanthx13
- Data Analysis Project: https://www.kaggle.com/code/rafanthx13/analise-da-rea-de-dados-no-brasil/notebook
- Co-author of a paper in Scientific Initiation: https://repositorio.usp.br/item/002968832

===============================

## Trabalho (Antigo e Novo) Na Neppo

### Antigo

Estagiário‍ do‍ Programa‍ da‍ Neppo‍ atuando‍ em‍ 2 projetos como desenvolvedor Full-Stack:

O primeiro projeto consistia na elaboração de um sistema web para realizar consultas no banco de dados, além de fornecer relatórios personalizados em excel/pdf. Foi desenvolvido uma usando PHP no backend para realizar as consultas SQL e Angular.JS‍ como‍ FrontEnd. Além disso foi usado a ferramenta Pentaho para  realizar ETL,  para extrair dados de uma API externa e internalizar no banco de dados além de muitas outras operações

O segundo projeto foi um sistema para cadastro e gerenciamento de funcionários da empresa. Foi utilizado Java‍ (Spring‍ Framework)‍ como‍ BackEnd‍ e‍ Vue.js‍ como‍ FrontEnd.

Em ambos‍ os projetos foram utilizados HMTL,‍ CSS,‍ banco‍ de‍ dados‍ MySQL e git além de terem sidos gerenciados pela metodologia‍ Scrum‍.

### Novo

Estagiário‍ do‍ Programa‍ da‍ Neppo‍ como desenvolvedor Full Stack atuando nas seguintes atividades:

- Desenvolvimento de Software para realizar consultas personalizadas ao banco de dados e geração de relatórios em excel ou pdf utilizando PHP com o Framework Slim para construçâo da API REST, Angular.js e SQL.

- Levantamento de Requisitos, Implementar e melhorar sistema responsável por provisionamento e faturamento de serviço de cloud utilizando a ferramenta Pentaho para o ETL e SQL.

- Desenvolvimento e manutenção de soluções baseadas em Vue.js e em Java com Framework Spring.

Em todos os projetos foram utilizados HMTL,‍ CSS, Javascript,  banco‍ de‍ dados‍ MySQL e git além de terem sidos gerenciados por metodologia‍ Scrum‍.

### Novo em Inglês

Trainee‍ of the‍ Program‍ of‍ ‍ Neppo‍ as a Full-Stack developer working in the following activities:

- Software development to perform customized queries to the database and generate reports in excel or pdf using PHP with the Slim Framework for building the REST API, Angular.js and SQL.

- Requirements Gathering, Implementing, and improving the system responsible for cloud service provisioning and billing using the Pentaho tool for ETL and SQL.

- Development and maintenance of solutions based on Vue.js and Java with Spring Framework.

HMTL,‍ CSS, Javascript, database‍, MySQL, and git were used in all projects, in addition to having been managed by the methodology‍ Scrum‍.

===============================

## Trabalho de outras pessoas

### Descrição da Rafaela - Neppo:

Monitoramento das integrações de um sistema responsável pelo faturamento e provisionamento de serviços em nuvem, e desenvolvimento de melhorias e correções no ambiente. 

Tecnologias utilizadas: PHP (Slim Framework), AngularJS, HTML, CSS, MySQL, ETL Pentaho, APIs REST e APS.

===============================

## Como deve ser a descriçâo das atividades

+ Verbo de Ação + Objeto da Ação + Como (técnica ou método) +
  - ....
  - Resultado em [métricas mensuráveis]
  - Participando do resultado em
  - em [Empresa conhecida]
  - em [posição da empresa em algum ranking]


+ Exemplos:
  - Developed a new CRO and experimentation program that led to an increase in a 20% increase of qualified leads while reducing CPL in 87%
  - Tested and launched new acquisition channels: affiliates, influencers and referrals that incresead in 85% the amount of conversions.
  - Led a 5 people multidisciplinary team comprised of Paid Media, CRM, SEO, Design and Content Specialists
  - Redesigned the multi-area squads using growth management frameworks that saved a 6 digits monthly investment on new HCs.

===============================
