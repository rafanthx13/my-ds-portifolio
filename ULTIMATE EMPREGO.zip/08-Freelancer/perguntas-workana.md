Workana

1 - Workana me dá a garantia do pagamento de um projeto quando:
A) Termino um projeto segundo o que foi acordado com o cliente e ele aprova o trabalho realizado
B) Quando completo uma parte do projeto e o cliente aprova a minha entrega parcial

2 - Se um cliente aceitar minha proposta e pagar por ela, tenho a obrigação de terminar o projeto. Não realizá-la pode implicar em:
B) Workana pode aplicar uma penalidade em meu perfil
C) Minhas propostas podem ser suspensas na plataforma por um tempo determinado
D) Minha conta pode ser suspensa definitivamente

3 - É preferível entrar em contato com os clientes por email do que pelas mensagens da Workana?
B) Não. Devo comunicar-me através da Workana. Se acaso isso não acontecer, a Workana pode encerrar minha conta definitivamente e eu perco a garantia oferecida pela plataforma

4 - Nas políticas da Workana está especificado que não posso ter as seguintes informações em meu perfil
A) Informação de contato ou meios de pagamento.
D) Informação copiada de outro perfil


5 - As melhores propostas são:
A) Aquelas feitas depois de esclarecidas todas as dúvidas acerca das especificações do cliente
B) Aquelas que detalharam claramente o trabalho a ser realizado, o cronograma do trabalho, compromissos e entregas a serem realizadas
C) Aquelas que são personalizadas de acordo com o projeto
D) Aquelas que são realizadas logo após ter acordado com o cliente o trabalho a ser realizado, os prazos de entrega e o valor do projeto


6 - Se eu tiver dúvidas sobre como funciona a Workana, eu posso:
B) Buscar soluções em el Centro de ajuda
C) Escrever para o suporte se acaso não encontrar a ajuda que precisava


7 - A garantia da Workana funciona da seguinte forma:
B) O cliente paga para a Workana e eles liberam o pagamento quando o cliente está satisfeito com o trabalho que recebeu


8 - Quando você pedir para liberar o dinheiro de um projeto, você deve enviar uma entrega?
B) Sim, sempre. Pedir liberação dos fundos sem ter realizado uma entrega viola as políticas da Workana e posso ser penalizado

9 - Se utilizo o Skype, email ou outro modo de contato externo durante a execução de um projeto, o que acontece se tenho uma arbitragem?
B) Tudo o que foi acordado e conversado fora da plataforma não será válido.


10 - O que acontece se eu não cumprir o que foi acordado com um cliente em um projeto?
C) Podemos cancelar o projeto, mas não cumpri-lo significa ter uma marca em meu perfil, a suspensão de propostas e inclusive o encerramento definitivo da minha conta.

11 - Se um cliente me tratar mal ou de forma ofensiva devo:
C) Respirar e tratar de entender e solucionar o problema
D) Se os maus tratos continuarem, devo denunciar à Workana

12 - Se ainda não ganhei nenhum projeto na Workana, posso fazer o seguinte:
B) Completar alguns testes oferecidos pela Workana para certificar minhas habilidades
C) Tentar melhorar as minhas propostas e ler os conselhos da Workana no Centro de Ajuda
D) Encontar os projetos que são perfeitos para mim e tentar enviar uma proposta personalizada


13 - Que tipos de projetos posso encontrar na Workana?
B) Projetos remunerados que posso cobrar por hora trabalhada ou por trabalho concluído

14 - Quando você pedir para liberar o dinheiro de um projeto, você deve enviar uma entrega?
B) Sim, sempre. Pedir liberação dos fundos sem ter realizado uma entrega viola as políticas da Workana e posso ser penalizado
