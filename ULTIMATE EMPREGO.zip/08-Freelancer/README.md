# Sites

+ Workana
  - [PHP](https://www.workana.com/jobs?skills=php)
  - [Vue](https://www.workana.com/jobs?language=pt&skills=vue-js)
  - [Node](https://www.workana.com/jobs?skills=node-js)
  - [Python](https://www.workana.com/jobs?language=pt&skills=python)
  - [Power BI](https://www.workana.com/jobs?language=pt&skills=power-bi)

+ 99Freela
  - [Vue](https://www.99freelas.com.br/projects?q=vue.js)
  - [Node](https://www.99freelas.com.br/projects?q=nodejs)
  - [Python](https://www.99freelas.com.br/projects?q=python)
  - [Java](https://www.99freelas.com.br/projects?q=java)
