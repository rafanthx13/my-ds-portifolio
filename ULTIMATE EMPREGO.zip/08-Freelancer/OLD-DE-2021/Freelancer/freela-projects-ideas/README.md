# Project Freelancer

Ideias de Projetos ou do que estudar para um JOB

## Fontes de Templates

https://codecanyon.net/item/truesupport-support-tickets-system-knowledge-base/25593773

https://elements.envato.com/pt-br/graphic-templates/app?_ga=2.128007428.92182507.1621886738-1909555398.1621886734&ec_promo=ca_app-design-templates&ec_topic=code

## Freelancer : Ranking de pedidos

**Linguagens e Tecnologias**

+ PHP
+ WordPress
+ Web Scraping
+ Laravel
+ Node

**Web Apps**

+ Landing Page
+ Site Institucional
+ E-commerce

**Apps Mobile**

+ Delivery

## 99 Freela: Exemplos de Pedidos

### EX1 Site institucional

21/05/2021 às 09:50

**Descrição do Projeto:**

O que precisamos que tenha no nosso site:
*Hiperlinks:* Ícones para sites terceiros "hiperlinks" ex: "área do cliente", "marketplace";

*Suporte:* Formulário com abertura de chamado (tipo de serviço, nome, e-mail, telefone, campo
para descrição);

*Blog:* Sistema de notícias na home inicial das últimas publicações e aba concentrando todo o
conteúdo do blog;

*WhatsApp Web:* Botão flutuante no canto direito da tela. Acompanhar a rolagem e quando a pessoa clicar, abrir o WhatsApp business;

*Integração com Instagram:* Através de uma publicação realizada no Instagram e vinculado na
postagem uma hashtag, a publicação irá aparecer de maneira automática no mural do site;

*Formulário de contato (agenda de visita):* Formulário atrativo para captação de lead e com recurso de captcha para minimizar spam;

*Formulário trabalhe conosco:* Formulário de preenchimento de contatos e envio de CV;

*Redes Sociais:* Botões laterais com atalho para as redes sociais;

*Chat:* Integração com o sistema Jivochat ( versão free para 1 usuário) para atendimento por chat
no computador do atendente diretamente ao visitante do site;

*Newsletter:* Área de cadastro de nome e e-mail para captação de dados para envio de notícias;

*Adequação à nova lei de LGPD* (Lei Geral de Proteção de Dados Pessoais. Lei nº 13.709/2018).

