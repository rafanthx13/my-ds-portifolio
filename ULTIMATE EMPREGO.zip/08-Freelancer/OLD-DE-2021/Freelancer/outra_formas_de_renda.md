# Outra formas

+ Formatar
  + R$ 50,0: pergunta se salva as coisas ou não
+ Dar aula
  + R$25,00 a hora
+ Vender doce/salgado
  + marmita, geladinho, bombom, bolo no pote, LANCHE NATURAL, MARMITA FITNESS
+ Andar com cachorros
+ Procurar freelances nos grupos da cidade
+ **OFERECER UM SERVIÇO PELA METADE DO ´REÇO COM O PAGAMENTO ANTECIPADO E INTEGRAL**
+ VENDER LIVROS E MANGAS
+ Digitação