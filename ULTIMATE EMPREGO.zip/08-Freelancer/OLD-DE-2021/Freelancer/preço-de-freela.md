# Preço em Freela

ABRIL DE 2021

## USA

Lá o "salário mínimo" (não é mínimo pois lá é feito por hora) é de US$ 8,00 que é R$ 44,00.

## Brazil

1.1000 por mês : 8h de segunda À sexta: 5 dias 8h por cerca de 4 semanas assim: 

```
4 semanas => 5 dias úteis => 20 dias
20 dias => em horas => 20 x 8 = 160 horas
1.100 / 160 => R$ 6,87 por hora
```

## Ganho na Neppo

Quanto ganhava na neppo: R$ 1.600,00 trabalhando 6h de segunda a sexta
1 mês = 30 dias = 4 semanas 
dias úteis trabalhados : 4 * 5 = 20 dias / por mês
horas trabalhadas: 20 *  6 = 120h / mês
Ganho de horas por mês 1.600R$ / 120h = R$ 13,30

 13,30 R$ = 2,40 US$ por horas por Mês