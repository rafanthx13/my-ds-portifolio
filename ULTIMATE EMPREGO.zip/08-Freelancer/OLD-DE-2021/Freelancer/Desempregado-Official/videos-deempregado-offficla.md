# CESAR ANICETO O DESEMPREGADO OFICIAL

## O que ele efaz

Ensinar a vender em alta perfomance na rua

## Corte

Canal me Popue e o Primo Rico sâo referencias pra ele. É necessário fazer renda extra. Pra eles, é inspiração


## Vídeos bons

Vídeo : COMO GANHAR DINHEIRO SEM GOLPE, PIRÂMIDE E DEPENDENDO SÓ DE VOCÊ? | CESAR ANICETO O DESEMPREGADO
Canal : Cortes do Isto Não É - PodCast [OFICIAL]
URL : https://www.youtube.com/watch?v=d3qEZNpp_-M&list=WL&index=5&ab_channel=CortesdoIstoN%C3%A3o%C3%89-PodCast%5BOFICIAL%5D




