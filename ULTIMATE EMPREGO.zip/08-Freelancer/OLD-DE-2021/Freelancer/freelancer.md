# Freelancer

## Canais do Youtube

+ [Programador Sagaz]()
  + Nota 1
+ [Freelancer Academy](https://www.youtube.com/channel/UCXi4_YrL0KweWvzPgmYclEQ)
  + Nota 10
+ [Attekita Dev](https://www.youtube.com/channel/UCetRsdZxDQDcgVDJd6erz6g)
  + Nota 9
+ [Bernardo Castanheira](https://www.youtube.com/channel/UCgC3dgePHl7m2vNO4yvkmxg)
  + Nota 9

## Meus dados

Todos pelo GMAIL :: Freelathunder_8

## Site de Freela

+ GeekHunter
+ GetNinjas
  + A plataforma faz o meio de canpo entre uma proposta e alguns freelancers. Ele oferece resumos dos projetos somente, e ai vocÊ tme que pagar para ver o contato da pessoa compelto. Assim, voce só paga pelos projetos que tem interresse e potencial de concluir
+ Workana
  + Plataforma queidinha do canal Attekita Dev
  + Similar ao 99 Frrelas: É posto projetos e o Freela faz as propostas. Gratuita para começar a trabalhar
  + Eles avaiam muito bem o seu perifl
+ 99 Frellas: Maior plataforma do Brasil (Tem mais serviços que somente DEV/TI,)
  + Essas plataformas, o contrattante deposita o dinheiro e fica lá, entao o pagamento é mais seguro tnaot pro Freela cquanto ao contratente. A parte juridica é cudiado pela plataforma.
+ Fiver : Plataforma global de freelancer
  + Há varios tipos de profissionais e de clientes. **LÁ É UMA GALERIA DE FREELAS**. Por isos os valores sâo reduzidos. Ex; lá as vezes você faz coisas bme pequenas memso
+ UpWork: Receber em dolares americanos
  + Semelhante a 99 frellas. o contratnte manda prosposta e varios freelas manda repostas. Se ele gostar, ele vai fazer uma entrevista com vocÊ em ingles.

## Programador Sagaz

[link - Programador Sagaz](https://www.youtube.com/watch?v=_DXdmuGqXLg&list=WL&index=2&t=15s&ab_channel=ProgramadorSagaz)

É necessário ter REPUTAÇÃO.

2 DICASPARA COMEÇAR O FREELANCER:

+ Espalhe a sua palavra. Deixe que as pessoas saibam que você é um programador freelancer para as pessoas te procurar quando pensarem em alguma coisa. ENTÂO VOCÊ PRECISA DIVULGAR SEU SERVIÇO
+ Não espere ser o master em uma linguagem de computação para fazer o projeto. Então você precisa se expor ao DESCONFORTO.

## Como ganhar dinheiro sendo um programador iniciante?

[Léo Andrade - link](https://www.youtube.com/watch?v=rzecO6-kF1Y&ab_channel=L%C3%A9oAndrade)

+ Criação de aplicativos
  + Você pode criar aplicativos para resolver pequenos problemas do dia-a-dia
+ Criar portal de notícias
  + Colocar coisas que você gosta muito de fazer
  + Você ganha com Google Adsense ou Espaço  de Banner para publicidade
+ Existe diversas empresas que não possuem sites
  + Aí você pode ser criar um site sozinho.
  + Aí pense de forma simples. Como WordPress
+ **O QUE DIFERENCIA É A INICIATIVA E NUNCA PARE DE ESTUDAR. SEJA ESPECIALISTA EM POUCAS COISAS PARA COISAS IMPORTANTES E AS APLIQUE NOS ESEUS PROJETOS**



## Trabalho Remoto: Como Ganhar em Dólar com Programação?

[Filipe Deschamps](https://www.youtube.com/watch?v=0C-_6H4P20E&ab_channel=FilipeDeschamps)

X-Team: Empresa especializada em trabalho remoto.



## O caminho mais rápido para ganhar dinheiro com programação.

A ideia da programação é RESOLVER PROBLEMAS mesmo em PEQUENOS NEGÓCIOS.

Página de vendas, página de captura;

**VOCÊ SEMPRE TEM QUE GERAR MAIS PELO PROJETO DO QUE O CURSTO, ASISM VÂO TE REQUISITAR MAIS **

Todo negócio precisa de um site. Mas todo negócio não precisa de aplicativo.

## 5 pilares para ser freelancer

https://www.youtube.com/watch?v=XUPBNMjkJ0A&ab_channel=OneBitCode

1. AutoGerenciamento: Escolha um horário fixo para trabalhar e avise aos outros para nao te encontrar

2. Marca Pessoal: Tenha o seu portfólio Online e coloque depoimentos

3. Mantenha projetos interessantes no github
4. Persistência: Se mantneha firme: Ser freelancer vai requeri habildiade que vocÊ nunca havia desenvolvido
5. Trate como um negócio: Nicho específico (foque em poucas coisas)
6. Registre as suas interações com o cliente

**Dica para o primeiro freela**

+ Comece mais leve, dando longos prazos (pouco dinheiro)
+ Se acahar que nâo consgue, fala que o cliente nâo precisa pagar nada



## Comece a Trabalhar SEM Experiência // Vlog #68

[Código Fonte TV](https://www.youtube.com/channel/UCFuIUoyHB12qpYa8Jpxoxow)

Sabemos que a maioria das vagas são feita para quem tem experiência

São 7 dicas para Ter/Mostrar experiência em uma área:

+ 1 - FOCO
  + Comece escolhendo um nicho
  + Web: Back,Fronte; Segurança; Games; Apps
  + Se especializa em poucas tecnologias. Invista muitas horas nisso e nâo perca o foco. Planeje ir a eventos, as pessoas experts e leia muito código
+ 2 - TER EXPERICENCIA
  + Para quem terminou a facul, o foco é ter ganhado experiência
+ 3 -  PROJETOS NA FACULDADE
  + Use os projetos de faculdade
+ 4 - PROJETOS OPEN-SOURCE
  + Ver e aprender. Watch and Learn.
+ 5 - SEJA ENCONTRADO
  + Linkedin; Ir em eventos e conhece pessoas
  + IMPACTE PESSAOS E NEGÓCIOS
+ 6 - ATUE COMO FREELANCE DE FREELANCERS
  + Ajude Freelancers: Ele costumam trabalhar em vários projetos ao mesmo tempo, então, você pode ir lá aprender vendo ele codando e isso vai te dar uma baita experiencia
+ 7 - CRIAR UM PRODUTO PEQUENO
  + Plugin, extensoes, apis ,enfim, alguma c

## GANHE DINHEIRO COMO FREELANCER COMEÇANDO HOJE [guia completo 2021]

(link)[https://www.youtube.com/watch?v=OH5idb6LWOc&ab_channel=NerdsdeNeg%C3%B3cios]



Começar no mercado como freelancer. Peter já contratou muito freelancer;

+ 1 - ENTENDER BEM DO ASSUNTO QUE VAI MEXER: SE ESPECIALIZE. ESPECIZLIE E PRATIQUE MUITO
+ 2- MESMO SENDO FREELANCER, TENHO UM NIXO DE ESPECIALIZAÇÂO
+ 3 -TER NETWORK, GRUPO DQUE FALE DAS MESMA OCISAS E SE INTERAJA COM OUTROS FRELACER
+ 4 - respeite o cliente, entregue um trabalho bem feito a ponto de ele quere te ocntratar depois. **EU TE IMPLORO, NAO PENSE EM DINHERIO**
+ **A IMPRESSÂO É O QUE FICA**. 
+ **QUEM NÂO É VISTO NÂO É LEMBRADO**
+ NUNCA PARE DE APRENDER.

## Como Ser Freelancer Online (Passo a Passo NA PRÁTICA - WORKANA)

[LINK](https://www.youtube.com/watch?v=41WlKVdAqsI&ab_channel=BernardoCastanheira)

Workana:

+ Workana come 20% do seu valor

+ Na plataforma, o contraten manda os projetos e voce pode pega ruma quantidde limitada, vocÊ repsonde com uma proposta de preço
+ OLhe ara um contratente com uma boa avaliaçao
+ Gestao de tempo: VocÊ tem que saber/estipular qunato tempo vai gastar
+ Pense em assinar planos do Workana, nao sao tao caos e os trabalhos vao cumprir ele
+ **COM O WOARKANA É SORTE. VOCê VAI TR UQUE FICAR DE OLHO TODO DIA E TODA HORA**

## UPWORK - US$80/h - a proposta que EU ENVIEI

[EXEMPLO DE ENTREVISTA](https://www.youtube.com/watch?v=XfHfcHkwfDQ&ab_channel=FreelancerAcademy)

Freela não se trata de quem grita mais alto ou tme o menor preço. Se trata de confiança, já que dinheiro o cara já tem disponível.

90% dos que nâo pegam trabalho é por causa de postura do atendimento. Você tem que saber se comportar, e entender que 

**SER FREELANCER É SER EMPREENDEDOR**

**NÂO PENSE EM SIMPLEMENTES EM TROCAR DINEHIRO POR TRABALHO. O CLIENTE TEM QUE VER VALOR NO SEU TRABALHLO**

Dicas:

+ Tente varias vezes
+ Olhe para perfis de outros freelas.
+ E CUIDADO PARA NÂO COPIRAR GENTE QUE NÂO SABE SE COMPORTAR NA PLATAFORMA.
+ SEJA ESPECIALSITA. NÂOS EJA UM FAZ TUDO

**AS PESSAO DE LÁ NÂO VAO TER A MENTALIDADE QUE EU TENHO DE SER MESQUINHO, MELANCOLICO, DESCONFIADO. ELES SÂO COMO PEDRO PAULO, WUELER. DEINER RPETR. VÂO ADORAR VALOR, IMPCAO, SMILES, E AO MESMO TEMPO CORDIALIDADE DE MARKETING**

Você nÂo tem que se vender ocmo alguém capaz de entregar o job. E sim alguém capaz de ajudar o cliente a ganhar valor pelo seu serviço como um profissional no mercado.

DEMONSTRE SEGURANÇA NO SEU REÇO E NA SUA PRPOSTA

Reusmo de dicas para conseguir

+ Timeing: Fique de olho, pegue logo e se apressente
+ A forma como se apresentou ::  demonstre que quer ajudar no negocio dele, e nao apenas fazer e acabou, deixe-se aberto para possuiveis ideias de trablhaos futuros
+ Nâo implore para o cliente te contrate

## Propostas no Workana. ISSO foi o que eu recebi... | Freelancer Academy

[link](https://www.youtube.com/watch?v=E1bfllok5dE&list=WL&index=3&ab_channel=FreelancerAcademy)



Avaliando propostas que as pessoas fazem no workana. **Como enviar melhores propostas**

Ele ofereceu no Workana uma vaga de Ghostwriter e queria saber como as pessoas mandariam as propostas.

**O que é legal**

+ Demosntre que entende da proposta do cleinte e de que tem os requisitos para fazela. Ou seja, ao escrever fale sobre a proposta 
+ Demosntre que você etapa naquele nicho, com toral clareza
+ "TEM QUE FALAR EM COMO VAI ATENDER AO REQUISITO DO CLEINTE"
+ Falar o nome do cliente em sue texto
+ Ter cara de empreendedor

**O que não é lega**

+ Nâo comece com "Estou buscando oportunidade". Nâo se trata de vocÊ e sim no negócio do cleinte. O lciente nÂo quer saber o seu interrese, e sim o resulado.
+ Nâo fale nada fora da proposta. Nâo proponha , tipo, fala que faz 5 sites  por 4 ou algo do tipo
+ Se for barato demais, o contratante vai acahr estranho. Nâo tenha medo de cobrar mais se for um bom profisisonal
+ Faça um texto bem elaborado
+ NÃO SEJA GENÉRICO
+ Nâo mande muitos links e nem faça um texto muito grande



## SITES PARA FREELANCER: POR ONDE COMEÇAR

[lnk](https://www.youtube.com/watch?v=4TKNWf9Yxa8&list=WL&index=2&ab_channel=doisbits)

+ UPWORK
  + Cobra taxa 20% até 500 US$, 10% de 500 À 10.000 e acima de 10k é 5%
  + É TUDO EM INGELS, ENTAO SAIBA BEM INGLES
  + 53% das vagas terminanm em nada, ou seja, vocÊ tenta e nao dar em nada
+ Freelancer
  + Tem em BR também
  + Taxa das baixas
  + Desvantagem para quem começar agora lá: você pode tentar 8 Jobs por mês, o que é pouco.
  + Desvantagem: Você vai competir com muita gente
  + 83% das vagas dão em nada
+ 99FREELAS
  + TOTALMENTE EM PORTUGUES
  + Voce que define o oçamento
  + Desvantange: Qeum tem uma conta lá, consegue ver uma aba nas suas primeiras 24horas enquanto os outros não, entâo. A taxa nâo é cara, mas pra quem começar nâo é tão bom.
  + PREÇO EM REAL. Ela come 10% + R$0,40
+ Fiverr
  + VocÊ posta o seu serviço e é o empregado que vai buscar
  + É tipo mercaod livre. A cometiçÂo é muito grande, vai ter que fazer muito SEO.
  + LÁ É MAIS PARA TRABALHOS PICADOS.
  + PREÇOS MUITO BAIXOS e cobra 1/5 do seu ganho