# ChatGPT: Leia um arquivo em texto em python, pegue todas as urls, retire duplicatas e escreva as novas urls em um outro arquivo

import re

# Lê o arquivo em texto
with open('msgs.txt', 'r') as f:
    texto = f.read()

# Encontra todas as URLs no texto
regex = r"(?i)\b((?:https?://|www\d{0,3}[.]|[a-z0-9.\-]+[.][a-z]{2,4}/)(?:[^\s()<>]+|\(([^\s()<>]+|(\([^\s()<>]+\)))*\))+(?:\(([^\s()<>]+|(\([^\s()<>]+\)))*\)|[^\s`!()\[\]{};:'\".,<>?«»“”‘’]))"

urls = re.findall(regex, texto)

urls = list(map( lambda x: x[0], urls))

# Remove duplicatas
urls = list(set(urls))

print(urls)

# Escreve as URLs em um novo arquivo
with open('links.txt', 'w') as f:
    for url in urls:
        f.write(url + '\n')

