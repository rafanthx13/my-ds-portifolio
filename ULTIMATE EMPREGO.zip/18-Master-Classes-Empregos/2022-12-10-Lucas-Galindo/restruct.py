# Gerado pelo ChatGPT
# PERGUNTA AO GPT: Escreva um programa em python que leia um arquivo de texto. Ele deve restruturar o arquivo juntando doas as linhas que possua um horário com a linha anterior e dar um espaço em branco
# Presicou de mais algumas modificaçôes para se adeuaqr melhor ao senário do 'txt' base

# Abre o arquivo em modo de leitura
with open('msgs.txt', 'r') as arquivo:
    # Lê todas as linhas do arquivo e armazena em uma lista
    linhas = arquivo.readlines()

# Agora você pode iterar sobre as linhas do arquivo
#for linha in linhas:
#    print(linha)

linhas_restruturadas = []
linha_anterior = ""

# Itera sobre as linhas do arquivo
for linha in linhas:
    if(linha == "default user avatar\n"):
        continue	
    # Verifica se a linha atual começa com um horário
    if linha[0:2].isdigit() and linha[2] == ":":
        # Se a linha atual começar com um horário, junta com a linha anterior
        # e adiciona um espaço em branco
        linhas_restruturadas.pop() # Pois eh o nome sozinho
        linhas_restruturadas.append('\n==> ' + linha_anterior.strip() + " " + linha + "\n")
    else:
        # Se a linha atual não começar com um horário, adiciona a linha
        # sem alterações
        linhas_restruturadas.append(linha)
    
    # Atualiza a linha anterior para a linha atual
    linha_anterior = linha

# Abre o arquivo em modo de escrita
with open('nome_do_arquivo_restruturado.txt', 'w') as arquivo:
    # Escreve as linhas restruturadas no arquivo
    for linha in linhas_restruturadas:
        arquivo.write(linha)
