# Lucas Galindo Live em 10/12 - Como preparar o Linkedin para vagas internacionais

## Objetivo do Webinar

+ Ser mais abordado por recruiter internacionais
+ Saber o que fazer quando abordado
+ Saber pesquisar vagas fora do Brasil com visto ou que pode remoto
+ Tirar as principais dúvidas com especialistas

## Para quem é o Webinar

Quem tem mais chances de receber chamadas para vagas:

Dev > Dados > TI > UX, UI, product, Growth, RH > CX Vendas e Compliance

A cada 6 pessoas que seguirem as dicas, uma vai conseguir.

## Depoimentos

Até quem não é dessas áreas consegue vagas internacionais se organizar bem o linkedin.

## 09min - Requisitos

+ Inglês é o principal, em Portugal, as melhores vagas vão pedir inglês

+ Experiência é um requisito também, não precisa ser exatamente na área

+ Faculdade para algumas coisas é obrigatório, e para outras ajuda bastante.

+ **Existe vagas para júnior**: Sim, mas tem muita exploração, mas o salário compensa. 
 - Ex: eles te pagam 100 USD mas se fosse um nativo não pagaria isso. Mas 1000USD é mais do que uma empresa aqui daria.

## 11min - 'Work and Travel' e 'Worldpackers'

São programas para ir para o exterior e trabalhar

Work and Travel: 
+ 3k dólares para escolher uma empresa para ir lá e trabalhar por 3 meses e meio.
+ Você gasta dinheiro mas também recupera pois vai lá trabalhar

WorldPackers:
+ Você vai e trabalha num hostel, você trabalha para ficar ali, dá para então conhecer o mundo com isso

## 14min - Dica 1: Crie perfil em BR e ENG no Linkedin

**Crie perfil em BR e ENG no Linkedin**

## Dúvida: Como avaliar as empresa para me aplicar (inflamação, guerra) e como evitar riscos

+ Responsabilidade fiscal na empresa, saber quem está monitorando as métricas o 'product marketing fit', ou seja, **ter lucratividade**

+ **Para evitar golpe**: Glassdoor, DigitalFootPrint

+ Veja se você pode entrar em contato com alguém do time

## 19min - Dica 2: Título

Coloque palavras chaves que vocÊ quer se encontrado
+ Cargos: Back-End | Front-End
+ Tecnologias

Não coloque 'Estudante de desenvolvimento', coloque 'desenvolvimento'

**Você vai colocar as palavra chaves pelas quais você quer ser encontrado**

## Dúvida: Um Sênior no BR deve ir para Júnior no exterior

Se você tem um colega que faz o mesmo que você e ganha o triplo, você fica incomodado.

Há 3 tipos de empresas: as que querem pessoas globais e as que querem explorar um trabalhador barato

Mas isso de receber menos varia muito **do que faz sentido pra você**

## Dica 3: Coloque a localização do linkedin no local que você quer trabalhar

E você pode colocar mesmo que não more lá, é porque você quer trabalhar para lá. E ai depois pode vir Vaga Remoto

Não se preocupe se seu chefe ver ou não,  na verdade, hoje o Linkedin te protege de ser visto pelo seu próprio RH.

Se quer trabalhar remoto coloque EUA, Canadá ou Inglaterra. Coloque em uma cidade grande, para assim o pesquisador, quando buscar um cargo, achar o seu nome

## 29min - Como fazer uma ótima Cover Letter

+ São aquelas que já começam dizendo o porquê você gostou daquela vaga, bem específico. E aí você conecta a sua trajetória com o que a empresa trabalha.

+ Antes de mandar, procure no linkedin quem é BR lá e pergunte como é a experiência dessa pessoa lá naquela empresa. Uma conversa de uns 15 minutos. E coloca isso na cover letter, que depois o rh vai atrás da pessoa.
  - OBS: Não vá atrás do pessoal de RH
  - Foque no BR lá na empresa e depois no membro do time que você iria entrar

**LEMBRE-SE, ESPECIFICIDADE É TUDO**

Se você quer um lugar específico coloque a capital ou uma cidade grande lá.

**Vagas com visto**

+ Para países menores: Bélgica, Luxemburgo, Holanda, Polónia, Suécia. Eles financiam a sua vaga.

+ Para EUA e Canadá é muito difícil

+ Alemanha, Holanda e Bélgica são mais fáceis de pegar vistos.

**Nas opções de encontrar vagas você pode colocar para só Recruiters verem que você é OpenWork**

Em tipos de vaga coloque todas

## 40min - Como ser encontrado por recrutadores fora do Brasil

Coloque em 'Editar preferências de vaga'  e coloque várias cidades: Ex: Talin na Estónia; Alemanha/Áustria/Suíça/ Amesterdão, Holanda; Nova York; Londres. Coloque tanto em presencial quanto em Remoto

## Dúvida: Como responder a expectativa salarial para fora

Saiba o valor líquido que você vai ganhar no Brasil. Se atente mais ao nível em que você será contratado.

O salário Líquido tem em uma Live do Vinícius, o mesmo cara de contabilidade que tava na live

## 49min - Sobre mim

**Quanto mais tecnologias e key-words você colocar, melhor**

Aí você coloca todas, dando destaque as principais, à certificação, a nível de inglês também

## Dúvida: Mínimo de experiência para trabalhar para fora do Brasil

Junior vai ter mais dificuldade, mas se for senior demais também vai está difícil.

Existem vagas júniors mas você também vai está competindo com júniors locais.

Se você está entre Pleno e Sênior há muitíssima mais vagas.

**O IMPORTANTE DO JÚNIOR É SABER FAZER, DESDE QUE VOCê ENTREGUE O QUE A VAGA PEDE**

**O principal é vender que vocÊ sabe fazer**

**Muita vezes você vai ter que ter auto-confiança**

## 1h00min - Como descrever a sua experiência profissional

Coloque os resultados que você conseguiu para a empresa e as ferramentas usadas para desenvolver esse resultados.

!!!!!!!!!!!!!!!!
**COLOCAR O IMPACTO DO VOCÊ FEZ**, ISSO É MUITO, MAIS MUITO IMPORTANTE
!!!!!!!!!!!!!!!!

Se você fala : 'trabalhei com HTML/CSS/JS/PHP' isso pode ser para um site de padaria. Agora se vocÊ colocar 'trabalhei num app usado hoje por mais de 1 MM de pessoa' isso vai chamar muito mais esperiEĉnai

Busque por uma métrica nisso; Saiba se vender

Coloque também o que é relacionado a sua empresa, ex: fintech, fábrica de software e etc.

**SIM, O LINKEDIN PROTEGE O SEU PERFIL OPE-TO-WORK DO PRÓPRIO RH**

## 1h08min - Vale a pena pôr o selo verde do linkedin

É algo muito duvidoso. O Linkedin colocou esse selo para ajudar mas tem gente que olha com maus olhos isso.

Pesquisa o perfil: "Amy Miller", é uma recrutadora da Amazon que falou que só contrata quem tem esse selo. Ela tem um blog que mostra como funciona a cabeça do RH americano.

## Dúvida : Sobre mentir a localização no linkedin

Você pode mentir mas se alguém te contata você fala a verdade, na hora, diz que é BR e que quer trabalhar remoto ou precisa de visto.

O jogo é esse, mas não minta.

A ideia de mudar a localizaçao é você aparecer nessa primeira busca daquele recrutador gringo.

## (!!!) AS DICAS DO WEBINAR SÓ VAI DAR CERTO SE VOCÊ TIVER 1500 Conexões

Como fazer:
+ Busque por 'Tech Recruter'
+ Depois coloca '2 grau'  e depois manda 100 convites
+ Conforme você adiciona tech-recruiter e pessoas, o recturado vai pensar que você é parecido com certas pessoa e então vai te contara
  - Lembre-se, VOCÊ TEM QUE DIMINUIR O RISCO. TER VÁRIAS CONEXÕES VAI QUERER DIZER QUE VOCÊ NÃO É NENHUM ESTRANHO ENTÃO VAI DIMINUIR ESSA IDEIA DE QUE VOCÊ É UM COMPLETO ESTRANHO.

Adiciona recrutadores do lugar que você quer trabalhar. E depois poste alguns conteúdos.

**Porque ter bastante conexões**
+ O recrutador vai na aba de pesquisa e buscar, por exemplo, 'data engineer'. Quanto mais conexões em comum você tiver com aquela pessoa, mas você vai aparecer no topo da pesquisa.

**ESSA LIVE NA VERDADE É: FAZER SEO NO LINKEDIN**

## 1h22min - Produza conteúdo

+ Produza conteúdo preferencialmente em inglês, vá adicionando pessoas e construindo relacionamentos
+ É pelos posts que você vai ser lembrado e assim vão te chamar primeiro, talvez até mesmo antes da vaga abrir no linkedin.

Adicione as pessoa de forma desinteressada

## 1h26min - Lista de vagas

+ relocate.me
+ vanhack
+ nevermind

## 1h27min - Como é o Zoom que Lucas Galindo usou

+ Para fazer um Webinar para 3000 pessoas custou R$ 8000, por isso não é gratuito
+ Não dá pra piratear, pois não dá pra baixar e se você passar pra outra pessoa eles vão saber.
+ A única forma de baixar a live é gravado tela e som do PC, o que não é tão fácil

## 1h28min - Saiba pesquisar vagas com visto

+ Canadá/EUA/UK: Você pode arrumar emprego do Brasil
+ Europa: Tem que se mudar

Vá pesquisar no linkedin com a keyword 'visa' 'relocation', só assim vai achar vagas que vão pedir visto pra você;

Palavras chaves: 'contractor', 'b2b'. Mas é melhor sites especializados no Brasil.

**Não há vaga com visto para os EUA**

Leandro:
+ Pesquisa "Jobs from everywhere"

### 1h31min - Saiba Pesquisar vagas Remotas

+ Canada/UK/EUA são os países mais comuns para trabalhar remoto, pois tem mesmo horário
+ Ganha-se mais trabalhando do Brasil trabalhando pra fora
  - O IMPOSTO DO PJ ŃO BRASIL TEM QUE TER, MAIS É POUCO, E SE VOCÊ FOR PRA FORA VOCê PAGA MUITO EM IMPOSTO DE RENDA AO MORAR LÁ

Por exemplo, na live o cara que trabalha na Alemanha falou que 42% do salário dele é comido por imposto,mas o objetivo dele não é ficar rico, é ter uma vida melhor.
  - O que você compra com 1500 Euros não é o mesmo que compra 1500 reais, nem mesmo se você converter de euro para Real

Se você trabalha para o exterior você paga menos imposto do que se você trabalha-se para um PJ. **CHEGA A 10% DE IMPOSTO NO SEU SAL**

## 1h40min - Dica: Conectar com a pessoa de RH da vaga

Muitas vezes as vagas são atreladas a uma pessoa de RH. Pode mandar um 'conectar' com essa pessoa antes mesmo de se candidatar a vaga. Muitas vezes vai chamar a atenção e a pessoa pode ir falar diretamente com vocễ só por causa disso.

Outra dica: siga a newsletter: "pragmatic enginner". Ele criou um questionário no google forms

## As pessoas desta live

Adicione:
+ Laura Oliveira (Recrutamento, carreira toda na gringa )
+ Leticia Quevedo (Tech Recruiter na NeverMind, compartilhá mais pelo Twitter)
+ Jhonatan Matias (tem mentoria exclusiva para ir para alemanha)
+ Vinícius tem uma empresa para fazer esse PJ para o exterior (assessoria, calculus, se precisa abrir CNPJ, eles resolvem e regularizam muita coisa)

Use o grupo do linkedin, pois esse pessoal tá postando muita coisa boa lá.

**Aprenda a meter as caras e não fica se achando tão inferior assim**

## 1h46min - Crie um kanban para as suas aplicações

Crie um quadro, excel, que você anota quando mandou o CV, como foi, o que deu certo, o que deu errado, e o que melhorar.

## 1h49min - Seja insanamente cordial e tende ajudar o recrutador que for falar com você

## 2h09min - Começa a falar da mentoria





