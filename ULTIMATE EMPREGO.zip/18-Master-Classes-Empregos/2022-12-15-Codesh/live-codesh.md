# Live Codesh

## Dicas para sair bem nas entrvistas

+ Pesquisa sobre a oportunidade
+ Tenha em mente sobre seus objetvos e expectativas e fale sobre isso
+ Comente sobre sua trajetória profissional
+ Conte sobre suas experiências com as tecnlogias (projetos, pessoas, freelancer, estágio e etc..)
+ Demonstre que você busca por atualização profissionais
+ Foque em seus pontos fortes (comente sobre conhecimentos que você domina)
+ Faça perguntas! Tire suas dúvidas 

## Exigência perfeita da linguagem

Muitas vezes não saber uma linguagem mas saber uma semelhante pode ou nâo ser condiçâo apra fazer o processo seletivo: **DEPENDE**

Depende mais da fase do lado da empresa. Talbez eles queiram um júnior mais cru ou até alguém que já saiba que vai chegar e já programar mesmo.

## Quanto ao salário?

Varia muito, entâo procure a média do salário pelo glassdoor.

## O que define junior e senioridade

O que um júnior faz
+ ai criar soluçôes nâo performáticas
+ presadde mentoria


Conforme ganha senioridade
+ ela produz soluçêos reutilizáveis
+ aprende mais sobre negpoicios e regras de negócios
+ começa a mapear fluxos e a gerenciar pessoas

## Comentário de uma falante

boa noite, Armando!
Muitas empresas não dão oportunidade pro júnior mostrar seus conhecimentos mesmo. Por isso é importante se candidatar nas vagas da coodesh e realizar os testes técnicos, para ter o perfil validado em que você possa mostrar tudo que sabe!
Talvez também seu linkedin não esteja chamando atenção, no final vou falar sobre a mentoria individual que você pode solicitar

## O que falar

+ cUROSS QUE JÁ FEZ
+ PROJETOS PESSOAIS E OS SEUS RESULTADOS

## Grande demanda

+ Tem aumentanto demanda em QA, infra e DevOps

## EU tenteo tento e nao da em nada ...

+ 1- Depende por onde se candidata. Talvez a avaliaçâo de currículo pode ser feita por IA e aí já te corta na hora.
+ 2 - A coodesh avalia primeiro o seu linkedin, só depois o github e os projetos. **Por isso deve deixar as palavra chaves espalhadas por todo o linekdin: sobremim, experiencia, tituilo e etc..**
+ 3 - Só anexar o currículo nâo garante que você vai ser chamado, talvez eles localizem seu curriculo pelos campos que voce digita. digita
+ 4 - Atualize bem o seu github
