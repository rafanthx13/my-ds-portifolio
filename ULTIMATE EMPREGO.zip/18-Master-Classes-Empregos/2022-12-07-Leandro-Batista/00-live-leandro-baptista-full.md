# Leandro Batista - Live de 07/12/2022 - Quarta

**Objetivo**: Ganhar em Dólar sem sair do Brasil

Essa é uma Master Class, um guia pra fazer um 'faça você mesmo' intensivão. A mentoria seria o próprio Leandro e uma equipe para ajudar você pessoalmente.

Quem é Leandro: Formado em engenharia de produção, já trabalhou para várias empresas de fora do Brasil, mas sem sair de Volta Redonda (RJ). Hj ajuda uma empresa americana a contrata profissionais no Brasil

## Plano da aula

+ 1. Vagas para o exterior - onde encontrar e o que exigem
+ 2. Montando toda a sua estrutura de aplicação:
  - a. Resume;
  - b. LinkedIn;
+ 3. “Sou júnior, o que fazer?”
+ 4. Inglês: o que eu fiz para desbloquear o meu;
+ 5. Recebendo grana do exterior - tips & tricks;

## 6 min - Como encontra a vaga certa para trabalhar para o exterior

Tem que ter as seguintes inscrições:
+ Vagas “remote from anywhere”;
  - Essa é a principal, as outras são mais para se adequar mais a você que mora no Brasil, por causa do fuso-horário
+ Vagas “remote from Américas";
+ Vagas “remote from UTC -3”;
+ Dica: foque em sites especializados em remoto para o exterior.

**Hacking Sites para devs**
+ Um atalho para quem é de tecnologia, são os sites: BairesDev, TUring, X-tam, VanHack.
+ Eles tem um vestibular em tecnologia que avaliam bem mesmo você. Infelizmente isso acaba eliminado profissionais júnior, vão contratar os top dos tops
+ Como funciona: Você faz um perfil e quando chega uma vaga nesse sites, vai tentar dar um match com o seu perfil

## 12min - Entendendo o que as vagas pedem

**SE A VAGA NÃO ESPECIFICA NADA, ENTÃO ELES ESTÃO QUERENDO PLENO**

Sigla PTO:
+ Significa 'Paid Time Off' que é a política de ferias da empresa. EM seguida tem outros termos:
  - Paid Vacations = “Férias”
+ Paid Sick Leave = "Licença médica remunerada”
+ Paid Holidays / Local Holidays = Feriados / Feriados locais

Procure pedir vagas que tenha PTO, isso não é pedir muito

## Dúvidas

==> Como fica o tempo dessa férias:
+ Costuma ser 4 semanas a cada 1 ano

==> A empresa segue o feriado dela ou o seu?
+ Tem que conversar, mas tente insistir com que ganhe férias nos dias do Brasil, pois vai fazer diferença ao se relacionar com sua família

**DATA ENGINEERING É O QUE MAIS TÁ QUENTE NO MOMENTO (DEZ-2022)**

==> Usa-se linkedin para achar essa vagas para fora do brasil?
+ NÃO. Boa parte dos cases de sucesso são por sites especializados. Pois no Linkedin também a competição é muito maior do que nesses sites menores

==> Sobre o salário por contratar um BR ser menor do que contratar um americano
+ Você deve vê da seguinte forma. Esse salário ainda será maior do que a média no Brasil?
+ Pois o que importa é salário alto. Para a empresa contratar um dev BR é uma
 forma de economizar, pois há muita diferença entre você e um nativo que denomina 100% o idioma deles
+ Então sim, se contratarem um BR vão pagar menos do que um americano, mas veja se na conversão vai ser ainda maior do que o mesmo cargo no Brasil
+ Mas essa é a visão de Leandro.

==> Não fique preocupado em ter 4+ year de EXP em algo. Olhe as tarefas e veja se você já praticou muito aquilo e se consegue entregar.

Quando é o salário para júnior/trainee no exterior: ENtre 1000 a 2000 dólares que dá entre 5k a 10k Reais

## 43 min - Parte 2 - Achei a vaga, agora o que fazer

Há 2 tipos de candidatura, a que é quando você vai atrás (ativa) e a que os outros vão atrás de você (passiva)

+ Candidatura ativa
 - Corre atrás das vagas e recrutadores.
 - Tem que fazer a candidatura e ficar na fila.

+ Candidatura passiva
 - Você atrai recrutadores.
 - Geralmente passa na frente da fila de quem tá na candidatura ativa.

Antes de entender como fazer a candidatura passiva (a melhor, quando eles veem atras de voce) vamo tentar entrar na cabeça de um recrutador

### 36min - O que tá na cabeça do recrutador

**O que está no slide do Leandro**

+ Recrutador vs dono da vaga (hiring manager);
+ Eles querem encontrar alguém que resolva o problema;
+ Querem minimizar o risco de investir na pessoa errada → buscam resultado comprovado;
+ O recrutador quer encontrar o que o HM pediu → usa termos e palavras-chave;

**Passo a passo de como isso acontece**
+ 1 - Em primeiro lugar há um Hiring Manager, um cara que tá querendo resolver um problema e precisa de uma pessoa para isso
+ 2 - Ele fala com a diretoria, e se aceitam, fala para o pessoal de RH para contratar uma pessoa
+ 3 - Hiring Manager: **Eu quero muito resolver um problema as tenho muito medo dessa contratação, pois há prazos e custos envolvidos**
  - Então, o cara do outro lado tá querendo te contratar,  porém ele quer evitar os riscos
  - **ESSE É O MEU TRABALHO: EVITAR OS RISCOS, MOSTRAR PRA ELE QUE NÃO HÁ NENHUM PROBLEMA EM ME CONTRATAR, QUE VOU DAR CONTA DO RECADO E SUPERAR EXPECTATIVAS QUE VOU  RESOLVER O PROBLEMA E FAZER MAIS**

+ 4 -Como o cara de RH diminui o risco: 'Se a pessoa foi boa no passado ela será boa no futuro'
  - **O QUE VOCÊ TEM QUE FAZER: Mostra que meu passado foi maravilhoso e que já resolveu/resolve os problemas que apensos está sofrendo**

+ 5 - (!!!) O CARA DE RH não sabe bem como resolver essa dor do hiring manager, ele é um simplificador, então, ele vai usar as palavras chaves que o hiring manager mandar (pois, como é o cara de RH ele não sabe direito)
  - ENTÃO, **USAR AS MESMAS PALAVRAS CHAVES, TERMOS, INDICADORES DA VAGA ´E MUITO IMPORTANTE**

Assim, se você escrever bem essas keywords, ele vai se interessar em você.

### 39 min - Usando esse mindset para uma vaga

+ Para publicar as vagas
  - Colocam os termos que os HMs pediram;
  - Constroem os requisitos da “lista de desejos”

+ Para encontrar os candidatos
  - Pesquisam pelas palavras-chaves;
  - Usam ferramentas como a busca do LinkedIn

+ Para avaliar candidatos
  - Querem encontrar os requisitos técnicos nos documentos;
  - Querem encontrar evidências que diminuam o risco

OBS: Tendo 50% dos requisitos você já avança na vaga

### 40min - Fórmula do sucesso

+ 1. Identificar as palavras chave;
+ 2. Elencar nossas experiências e habilidades;
+ 3. Somar e usar ambas:
  - a. Título no LinkedIn;
  - b. Descrição de experiências (LinkedIn e Resume);

Aqui lendário aprenderá como usar o excel do gerador de resume. É muito bom, ele pega um exemplo além de que, um dos arquivo já esse esse modelo para uma pessoa 'John Park'

### 52min - Mexer no Linkedin

+ Habilite o seu linkedin em inglês
+ Use as keywords, e use as principais que você quer ser achado.
+ Na parte: 'Feature' coloque coisa muito boa que viralizou, github, enfim, essas coisas
+ About: Será o 'pitch' parecido com seu resume, mas já apresentando de cara quem você é o que faz e habilidades
+ OBS: Essa parte tá bem no gerador de CV
+ Skills: Peça para seus amigos indicarem suas skills, além disso, essa depoimentos de outras pessoas

### 1h01min - Dúvidas dessa parte 2

Como falar de case se o que eu fiz foi apenas 'uma telinhas'?
+ Você floreia, fala da importância desta tela ao invés do impacto. **SEMPRE HAVERÁ ALGUMA CAUSA INDIRETA DO SEU TRABALHO**

Eu preciso colocar meu linkedin em inglês?
+ Não, o modo em inglês serve para mostrar aquela página a quem usa o linkedin em inglês
+ Você pode usar seu linkedin em portugues e mais tendo aquele em inglês bem estruturado

Ele não recomenda dizer que você está em outro país.

O linkedin é uma grande vitrine ao seu trabalho. É pra isso que ele serve. Quem não é visto não é lembrado.

Como driblar robô e garantir que a IA vai ler corretamente o seu currículo
+ Mandar curriculo simples
+ Colocar muitas colunas e imagens. 
+ O modelo já passa por IA

Um CV Não deve passar de 2 páginas

Algumas vagas dão preferência a quem tem bacharelado

Cúrriculo bonitinho só é famoos porque é propagando de prooduto gringo que quer que você compre o rpduto deles
+ Criatividade no CV apenas se vocÊ for designer, e seria um design minimalista bams bem pensando que passe bem as skils pelo RObô

**PROJETOS PROPRIO AJUDA MUITO PARA MUDANÇA DE CARREIRA**

==> NÃO MANDE CURRÍCULO DO LINKEDIN COMO SEU CV, PORQUE É GRANDE, HORRÍVEL DE LER 

==> Tem bem menos vaga far-time do que full-time, a maioria é full-time

==> CV mande sempre PDF

O caso de Linkedin e CV em Júnior
+ É um caso bem específico, por isso ele nao vai mostrar nada
+ Mas você encontra bastante coisa em inglês no youtube sobre isso. Só digita: "junior tech area resume"

## 1h25min - Parte 4 - E se eu for júnior?

Tudo que vimos até agora também vale para júnior

O que é específico para junior
+ 1 - Ser resiliente:
  - Vai ser mais difícil achar vaga do que para pleno/sênior
+ 2 - Não tenha medo de aplicar ficha
+ 3 - Produza o máximo que você conseguir e deixe sem seu resume isso. COisa produzidas por vocÊ mesmo
  - Uma grande dica: trabalhe como freelancer e mostre isso em seu portfólio. Isso já te joga acima de 90% dos outros caras
+ 4 - Tente mandar para um CANTO, direto, faça um pitch de valor (isso serve para casos de startups)

**Principal hack para junior**
+ Trabalhe como freelancer e coloque no freelancer, e coloque os projetos que você fez:
  - Isso vai jogar na frente de 99% de todos os outros junior

## 1h31min - Como desbloquear o inglês

Como eu acelerei meu aprendizado do inglês
1. Imersão: filmes e séries em inglês (áudio + legenda em inglês);
  - Tudo que for assistir coloque em inglês, vá fazer isso para forçar o seu ambiente

2. Vocabulário: duolingo, dussu e jogos;

3. Conversação: aula com professores nativos / aula com inglês para entrevistas;

4. Exposição: não ter medo de fazer entrevistas e Meetup.com;

**Hacking com meetup.com**

+ Você consegue ver eventos digitais em países e específicos e com temas específicos
+ É um lugar ótimo para fazer networking e aprender inglês

**TOEFL**
+ Isso desbloqueia o seu inglês, estudar para o TOEFL
+ VOCE APRENDE A MANIDERA DE REPSONDER OS GRINGOS COMO UM GRINGO, E N O SÓ A TRADUZIR AO PE DA LETRA CADA COISA QUE ELES FALAM

**Dicas de ouro**

+ Deixe muito claro o seu objetivo;
+ Faça “mock interviews”;
  - Um professor que vai simular uma entrevista em inglês com você e depois vai avaliar o seu inglês
+ Leve conteúdos de job hunting para discutir na aula;
+ Leia em conjunto job posts;
+ Revise sua aplicação durante as aulas (LinkedIn, Cover Letter, etc)

**Foque em aprender a**:
+ Contar a sua estória
+ Contar os case de sucesso
+ Enfim: saiba responder as perguntas em inglês

**Faça intensivos (cursos curtos mas com muito tempo gasto)**

**Comentários na live para inglês**
+ Esse site é excelente para conversação...pessoas do mundo todo.
  - gratuito  https://www.free4talk.com/
+ Faça mock interview (pedir para um professor te entrevistar)
+ Google interview
  - https://grow.google/certificates/interview-warmup/
+ Esse canal é bem bacana para dicas de entrevistas 
  - https://www.youtube.com/@CareerVidz

### 1h38min - Como receber do exteriors

Mas fique de olho
+ Não vale a pena receber como PF → IRPF é muito alto.
+ No tipo de empresa que será aberta (MEI tem limite baixo de faturamento e nem todas as profissões podem ter);
+ No CNAE da empresa → define alíquotas do simples;
+ Pro-labore, Fator R, etc;

Como funciona o trabalho pro exterior*
1. A grande maioria das vagas são de “Contractor”;
2. Você abre uma PJ no Brasil;
3. Traz o dinheiro para real (Husky, Payoneer, Inter);
4. Emite Invoice para a empresa lá fora (não recolhe impostos);
5. Emite NF aqui dentro (recolhe impostos);

+ **Dica 1** - não receba como PF
+ **Dica 2** - não tenha medo de contador
+ **Dica 3** - explore possibilidades como exportação de serviço

## 1h48min - A proposta da mentoria

**evite perder tempo e dinheiro com erros simples aos olhos de quem entende do assunto**

Quem são as pessoas
+ Lucas Galindo
+ Karol Attekita
+ Leandro Baptista
+ Laura Oliveira
+ Jonathan Mathias
+ Ana Buschinelli
+ Vinícius Pinheiro

**Mentoria de 12x 277R$**
+ Para participar da mentoria: https://globally.tech/
+ O da mentoria é para pleno/sênior, pois para juniors o resultado deve demorar mais
+ Link do grupo do zap:
  - https://chat.whatsapp.com/Bspk1nOuU5iLVrW60Hy0xB
+ A mentoria vai  está aberta até sábado

**INFELIZMENTE A GRAVAÇÃO É MENOR DO QUE A AULA AO VIVO, NO FINAL ELE TIROU UM MONTE DE DÚVIDA**

## Comentários na live

**Comentários do zoom**
+ ==> Tem uma dica legal sobre keyworks no linkedin. Clica no botão "more" ou mais do seu perfil, depois em "build resume" - escolha o nome da função que procura, o linkedin vai te mostrar palavras chaves daquela função procurada é o que tem no seu resumo do linkedin. Ajuda a voce achar o que o linkedin nao achou e vc completar 
+ ==> https://www.conta49.com.br/ - recomendo
+ ==> Não conheço se eles oferecem um bom serviço mas tem um serviço contábil com foco para desenvolvedores https://contabilprimor.com.br

**BairesDEV**
+ BairesDev: usa IA + Pessoas
+ Então enche de coisa lá
+ Mantenha o seu perfil atualizado

**Outros vídeos do Leandro**
+ Se eu assistir a live somente pela tela do vimeo, depois que ela acaba, ela vai  me recomendar outros vídeos do leandro baptista **que talvez ele nem saiba que pode ser acessado**
+ https://player.vimeo.com/video/779191207?h=9cba385bff&title=0&byline=0&portrait=0&color=4f46e5&transparent=0&app_id=122963





