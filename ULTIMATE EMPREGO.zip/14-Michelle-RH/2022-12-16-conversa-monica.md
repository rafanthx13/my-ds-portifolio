o que dizer de ambiente ideal

+ flexibildiade para conversar com as pessoa
+ ambiente de trabalho masi estável /9nao diga que nao gosta de reuniao)
+ ambiente com abertura ,para que tenha troca com os gestores, 

e muitao improante msotra que conehce a empresa
+ cultrua e valores
+ voce te que ser cpaz de dzer "eu me identifico com os valores X"

lembre-se de destacar osmesmso termos das descriçoes da vaga

OB: Ela recomenda se increver nos bancos de talentos

as pessoa precisam de pessoa empenhadas " se eu nao souber eu posso ir atras, posso me adaptar'

Tarefas que monica me passou
+ 1 - Mandar novo currículo e antigo, apos eu alterar com as coisa do Leadnro e do Galindo
+ 2 - Dar um feedback após a entrevista da UNIMED
+ 3 - Mandar arquivo gerado pelo gulpyW
