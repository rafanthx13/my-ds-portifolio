eu eu me adaptei mais do que os outros

dificudade: ralado a entrega, mas devido ao meu notebok, mas depois que obitve um notbeook melhor eu entreguei as demandas solicitadas pela empresa. Sim,eu tive dificuldade na entregar e em testar


se eu falar algo ruim, fale a melhorai: ganha pesosal da exp e soluçao do problema




FICAR 5MINUTOS JÁ NA CHAAMA ANTESDE ENTRAR


MELHORAR CURRICULO
+ por o mes no currículo


Se mostar interressado sempre e sempre pra cima.

PERUNTAR: O QUE A OUTRA PESOSA VER NA TELA DO GUPY
