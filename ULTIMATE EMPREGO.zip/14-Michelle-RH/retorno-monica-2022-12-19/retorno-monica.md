1 - Mandar para ela meu currículo que foi melhorado
2 - Mandar meus dados da Gupy
3 - FeedBack da entrevista da UNIMED. Foi mais uma conversa para que o Marcos me conhece-se. Na verdade eu não me candidatei a nehuma vaga, ele que veio me procurar. Eu acessei o linkeidn da Unimed e nâo achei vaga em Engneharia de Dados; Ele falou bastante da Unimed BH e nas várias área que atua; De ruim, ahco que esqueci de por na conversa mais alguns pontos importante que poderiam chamar atenção
4 - O que fiz nesses últimso dias
  - Melhorei o sobre mim e a experiência profissional do meu linkedin; Renovei meus CVs e busquei aprender a como melhorar o CV
